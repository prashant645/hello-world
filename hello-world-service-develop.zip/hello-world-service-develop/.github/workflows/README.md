# GitHub Actions Workflows

This directory contains CI/CD workflows for the hello-world-service project.

## Workflows Overview

### Shared Kyma setup helper
- Kyma preflight jobs use `scripts/setup-kubeconfig-kubectl.sh` to decode kubeconfig and ensure `kubectl` is available.
- Input is passed from environment-specific GitHub secrets as a base64 string:
  - `secrets.KYMA_KUBECONFIG_DEV`
  - `secrets.KYMA_KUBECONFIG_QA`
  - `secrets.KYMA_KUBECONFIG_PROD`
- Post-deploy readiness uses `scripts/wait-apirule-ready.sh`.

### Development & QA Deployments
- **Deploy to Kyma Dev** - Triggers automatically on push to `ias` branch
  - Verifies bootstrap and Kyma API Gateway prerequisites
  - Runs post-deploy IAS smoke verification with `scripts/test-ias-auth.sh`
  - Requires GitHub secrets `IAS_CLIENT_ID_DEV` and `IAS_CLIENT_SECRET_DEV`
  - Optional GitHub secret `IAS_SCOPE_DEV` overrides the default scope
- **Deploy to Kyma QA** - Triggers automatically on push to `main` branch
- **Deploy to CF Dev** - Manual trigger for Cloud Foundry dev environment
- **Deploy to CF QA** - Manual trigger for Cloud Foundry QA environment

### Production Deployments
- **Deploy to Kyma Prod** - Triggered automatically by Create Release workflow or manual trigger
- **Deploy to CF Prod** - Triggered automatically by Create Release workflow or manual trigger

## Workflow Discovery Note

All workflows are at root level (`.github/workflows/`) for proper GitHub Actions discovery on this GitHub Enterprise instance.
