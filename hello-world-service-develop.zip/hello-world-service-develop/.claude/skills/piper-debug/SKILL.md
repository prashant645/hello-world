# Piper Pipeline Debugging

1. First, read relevant Piper docs at https://www.project-piper.io/
2. Ask user to confirm exact Vault path structure
3. Check existing working configs in the repo
4. Only then suggest specific fixes with exact parameter names
