#!/usr/bin/env bash
set -euo pipefail

ENVIRONMENT="${1:?usage: verify-kyma-bootstrap-contract.sh <environment> <namespace> <runtime-sa-name> [deployer-sa-name]}"
NAMESPACE="${2:?usage: verify-kyma-bootstrap-contract.sh <environment> <namespace> <runtime-sa-name> [deployer-sa-name]}"
RUNTIME_SA_NAME="${3:?usage: verify-kyma-bootstrap-contract.sh <environment> <namespace> <runtime-sa-name> [deployer-sa-name]}"
DEPLOYER_SA_NAME="${4:-kyma-deployer}"

fail() {
  echo "❌ PREFLIGHT FAILED: $1"
  exit 1
}

require_can_i() {
  local verb="$1"
  local resource="$2"
  local namespace="${3:-}"
  local args=(auth can-i "$verb" "$resource")

  if [ -n "$namespace" ]; then
    args+=( -n "$namespace" )
  fi

  if [ "$(kubectl "${args[@]}" 2>/dev/null || true)" != "yes" ]; then
    if [ -n "$namespace" ]; then
      fail "Current deployer identity is missing required permission: $verb $resource in namespace $namespace"
    else
      fail "Current deployer identity is missing required permission: $verb $resource"
    fi
  fi
}

forbid_can_i() {
  local verb="$1"
  local resource="$2"
  local namespace="${3:-}"
  local args=(auth can-i "$verb" "$resource")

  if [ -n "$namespace" ]; then
    args+=( -n "$namespace" )
  fi

  if [ "$(kubectl "${args[@]}" 2>/dev/null || true)" = "yes" ]; then
    if [ -n "$namespace" ]; then
      fail "Current deployer identity has forbidden permission: $verb $resource in namespace $namespace"
    else
      fail "Current deployer identity has forbidden permission: $verb $resource"
    fi
  fi
}

echo "🔍 Verifying Kyma bootstrap contract"
echo "  Environment: $ENVIRONMENT"
echo "  Namespace: $NAMESPACE"
echo "  Deployer SA: $DEPLOYER_SA_NAME"
echo "  Runtime SA: $RUNTIME_SA_NAME"

kubectl get namespace "$NAMESPACE" >/dev/null 2>&1 || fail "Namespace '$NAMESPACE' does not exist"
kubectl get serviceaccount "$DEPLOYER_SA_NAME" -n "$NAMESPACE" >/dev/null 2>&1 || fail "Deployer ServiceAccount '$DEPLOYER_SA_NAME' not found in namespace '$NAMESPACE'"
kubectl get serviceaccount "$RUNTIME_SA_NAME" -n "$NAMESPACE" >/dev/null 2>&1 || fail "Runtime ServiceAccount '$RUNTIME_SA_NAME' not found in namespace '$NAMESPACE'"

AUTOMOUNT="$(kubectl get serviceaccount "$RUNTIME_SA_NAME" -n "$NAMESPACE" -o jsonpath='{.automountServiceAccountToken}')"
if [ "$AUTOMOUNT" != "false" ]; then
  fail "Runtime ServiceAccount '$RUNTIME_SA_NAME' must set automountServiceAccountToken=false"
fi

# Required rights for the shared deploy workflow.
require_can_i get namespaces
require_can_i create namespaces
require_can_i patch namespaces
require_can_i get services kube-system
require_can_i get secrets "$NAMESPACE"
require_can_i list secrets "$NAMESPACE"
require_can_i create secrets "$NAMESPACE"
require_can_i patch secrets "$NAMESPACE"
require_can_i get deployments.apps "$NAMESPACE"
require_can_i list deployments.apps "$NAMESPACE"
require_can_i watch deployments.apps "$NAMESPACE"
require_can_i create deployments.apps "$NAMESPACE"
require_can_i patch deployments.apps "$NAMESPACE"
require_can_i get replicasets.apps "$NAMESPACE"
require_can_i list replicasets.apps "$NAMESPACE"
require_can_i watch replicasets.apps "$NAMESPACE"
require_can_i get services "$NAMESPACE"
require_can_i list services "$NAMESPACE"
require_can_i create services "$NAMESPACE"
require_can_i patch services "$NAMESPACE"
require_can_i get pods "$NAMESPACE"
require_can_i list pods "$NAMESPACE"
require_can_i watch pods "$NAMESPACE"
require_can_i get events "$NAMESPACE"
require_can_i list events "$NAMESPACE"
require_can_i watch events "$NAMESPACE"
require_can_i get apirules.gateway.kyma-project.io "$NAMESPACE"
require_can_i list apirules.gateway.kyma-project.io "$NAMESPACE"
require_can_i create apirules.gateway.kyma-project.io "$NAMESPACE"
require_can_i patch apirules.gateway.kyma-project.io "$NAMESPACE"

# Forbidden rights: pipeline identity must not manage runtime SAs or mutate RBAC.
forbid_can_i create serviceaccounts "$NAMESPACE"
forbid_can_i update serviceaccounts "$NAMESPACE"
forbid_can_i patch serviceaccounts "$NAMESPACE"
forbid_can_i delete serviceaccounts "$NAMESPACE"
forbid_can_i create roles.rbac.authorization.k8s.io "$NAMESPACE"
forbid_can_i update roles.rbac.authorization.k8s.io "$NAMESPACE"
forbid_can_i patch roles.rbac.authorization.k8s.io "$NAMESPACE"
forbid_can_i delete roles.rbac.authorization.k8s.io "$NAMESPACE"
forbid_can_i create rolebindings.rbac.authorization.k8s.io "$NAMESPACE"
forbid_can_i update rolebindings.rbac.authorization.k8s.io "$NAMESPACE"
forbid_can_i patch rolebindings.rbac.authorization.k8s.io "$NAMESPACE"
forbid_can_i delete rolebindings.rbac.authorization.k8s.io "$NAMESPACE"
forbid_can_i create clusterroles.rbac.authorization.k8s.io
forbid_can_i update clusterroles.rbac.authorization.k8s.io
forbid_can_i patch clusterroles.rbac.authorization.k8s.io
forbid_can_i delete clusterroles.rbac.authorization.k8s.io
forbid_can_i create clusterrolebindings.rbac.authorization.k8s.io
forbid_can_i update clusterrolebindings.rbac.authorization.k8s.io
forbid_can_i patch clusterrolebindings.rbac.authorization.k8s.io
forbid_can_i delete clusterrolebindings.rbac.authorization.k8s.io

echo "✅ Bootstrap-owned ServiceAccounts and deployer permissions verified"

