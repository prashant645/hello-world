#!/usr/bin/env bash
set -euo pipefail

IAS_HOST="${IAS_HOST:-a3enmtmdf.accounts400.ondemand.com}"
TOKEN_ENDPOINT="${TOKEN_ENDPOINT:-}"
CLIENT_ID="${IAS_CLIENT_ID:-${CLIENT_ID:-}}"
CLIENT_SECRET="${IAS_CLIENT_SECRET:-${CLIENT_SECRET:-}}"
CLIENT_DEPENDENCY_NAME="${IAS_CLIENT_DEPENDENCY_NAME:-${CLIENT_DEPENDENCY_NAME:-scope}}"
RESOURCE_URN="${IAS_RESOURCE_URN:-urn:sap:identity:application:provider:name:${CLIENT_DEPENDENCY_NAME}}"
EXPECTED_IAS_API="${EXPECTED_IAS_API:-${IAS_API_PERMISSION:-readers}}"
EXPECTED_ISSUER="${EXPECTED_ISSUER:-https://${IAS_HOST}}"
NAMESPACE="${NAMESPACE:-dev}"
APIRULE_NAME="${APIRULE_NAME:-hello-world-service}"
API_URL="${API_URL:-}"
API_PATH="${API_PATH:-/api/v1/greetings}"
REQUEST_BODY="${REQUEST_BODY:-{\"message\":\"IAS smoke test\"}}"
EXPECTED_STATUS="${EXPECTED_STATUS:-200}"
REQUIRE_IAS_API="${REQUIRE_IAS_API:-true}"

require_cmd() {
  command -v "$1" >/dev/null 2>&1 || {
    echo "Missing command: $1" >&2
    exit 1
  }
}

fail() {
  echo "[FAIL] $*" >&2
  exit 1
}

require_cmd curl
require_cmd jq
require_cmd python3
require_cmd kubectl

[[ -n "$CLIENT_ID" ]] || fail "Set IAS_CLIENT_ID (or CLIENT_ID)"
[[ -n "$CLIENT_SECRET" ]] || fail "Set IAS_CLIENT_SECRET (or CLIENT_SECRET)"

if [[ -z "$TOKEN_ENDPOINT" ]]; then
  TOKEN_ENDPOINT="$(curl -fsS "https://${IAS_HOST}/.well-known/openid-configuration" | jq -r '.token_endpoint // empty')"
fi
[[ -n "$TOKEN_ENDPOINT" ]] || fail "Unable to resolve IAS token endpoint"

echo "[INFO] IAS host: ${IAS_HOST}"
echo "[INFO] Token endpoint: ${TOKEN_ENDPOINT}"
echo "[INFO] Client dependency name: ${CLIENT_DEPENDENCY_NAME}"
echo "[INFO] Resource URN: ${RESOURCE_URN}"

TOKEN_JSON="$(curl -sS -u "$CLIENT_ID:$CLIENT_SECRET" \
  -H 'Content-Type: application/x-www-form-urlencoded' \
  --data-urlencode 'grant_type=client_credentials' \
  --data-urlencode "resource=${RESOURCE_URN}" \
  "$TOKEN_ENDPOINT")"

ACCESS_TOKEN="$(printf '%s' "$TOKEN_JSON" | jq -r '.access_token // empty')"
[[ -n "$ACCESS_TOKEN" ]] || {
  echo "$TOKEN_JSON" | jq . >&2 || echo "$TOKEN_JSON" >&2
  fail "IAS token request failed"
}

echo "[INFO] Token acquired successfully"

ACCESS_TOKEN="$ACCESS_TOKEN" EXPECTED_ISSUER="$EXPECTED_ISSUER" EXPECTED_IAS_API="$EXPECTED_IAS_API" REQUIRE_IAS_API="$REQUIRE_IAS_API" python3 - <<'PY'
import ast, os, json, base64, sys

token = os.environ["ACCESS_TOKEN"]
expected_issuer = os.environ["EXPECTED_ISSUER"]
expected_ias_api = os.environ.get("EXPECTED_IAS_API", "")
require_ias_api = os.environ.get("REQUIRE_IAS_API", "true").lower() == "true"

parts = token.split('.')
if len(parts) != 3:
    print("[FAIL] Access token is not a JWT", file=sys.stderr)
    sys.exit(1)

def decode(part):
    part += "=" * (-len(part) % 4)
    return json.loads(base64.urlsafe_b64decode(part.encode()).decode())

payload = decode(parts[1])
issuer = payload.get("iss")
if issuer != expected_issuer:
    print(f"[FAIL] Token issuer mismatch. expected={expected_issuer} actual={issuer}", file=sys.stderr)
    sys.exit(1)

def claim_values(value):
    if value is None:
        return []
    if isinstance(value, list):
        return [str(v) for v in value if v is not None]
    if isinstance(value, str):
        stripped = value.strip()
        if stripped.startswith('[') and stripped.endswith(']'):
            try:
                parsed = ast.literal_eval(stripped)
            except (SyntaxError, ValueError):
                parsed = None
            if isinstance(parsed, (list, tuple)):
                return [str(v).strip() for v in parsed if str(v).strip()]
        return value.split()
    return [str(value)]

scopes = claim_values(payload.get("scope"))
scopes += claim_values(payload.get("scp"))
authorities = claim_values(payload.get("authorities"))
ias_apis = claim_values(payload.get("ias_apis"))
all_values = list(dict.fromkeys(scopes + authorities + ias_apis))

if require_ias_api and expected_ias_api:
    expected_parts = [s for s in expected_ias_api.split() if s]
    for expected in expected_parts:
        if expected not in ias_apis:
            print(f"[FAIL] Expected IAS API permission '{expected}' not found in token ias_apis claim. ias_apis={ias_apis}", file=sys.stderr)
            sys.exit(1)

if not all_values:
    print("[WARN] Token does not expose authorization-like claims (scope/scp/authorities/ias_apis); relying on API response for authorization check")

print("[INFO] Token payload sanity checks passed")
print(json.dumps({
    "iss": issuer,
    "ias_apis": ias_apis,
    "scope": scopes,
    "authorities": authorities,
    "sub": payload.get("sub"),
    "aud": payload.get("aud"),
    "azp": payload.get("azp")
}, indent=2))
PY

if [[ -z "$API_URL" ]]; then
  host="$(kubectl get apirule "$APIRULE_NAME" -n "$NAMESPACE" -o jsonpath='{.spec.hosts[0]}' 2>/dev/null || true)"
  if [[ -z "$host" ]]; then
    host="$(kubectl get apirule "$APIRULE_NAME" -n "$NAMESPACE" -o jsonpath='{.spec.host}' 2>/dev/null || true)"
  fi
  [[ -n "$host" ]] || fail "Unable to resolve APIRule host for ${NAMESPACE}/${APIRULE_NAME}"
  API_URL="https://${host}${API_PATH}"
fi

echo "[INFO] API URL: ${API_URL}"

body_file="$(mktemp)"
trap 'rm -f "$body_file"' EXIT

status="$(curl -sS -o "$body_file" -w '%{http_code}' \
  -X POST \
  -H "Authorization: Bearer $ACCESS_TOKEN" \
  -H 'Content-Type: application/json' \
  --data "$REQUEST_BODY" \
  "$API_URL")"

if [[ "$status" != "$EXPECTED_STATUS" ]]; then
  echo "[FAIL] API call returned HTTP ${status}, expected ${EXPECTED_STATUS}" >&2
  cat "$body_file" >&2 || true
  exit 1
fi

echo "[OK] IAS smoke test passed with HTTP ${status}"
cat "$body_file" | jq . 2>/dev/null || cat "$body_file"

