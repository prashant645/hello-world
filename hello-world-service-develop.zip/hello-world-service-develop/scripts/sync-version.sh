#!/bin/bash
# Centralized version sync script
# Reads version from VERSION file and updates project manifests
#
# In CI: Piper's artifactPrepareVersion already updated mta.yaml with cloud version,
#        so we skip mta.yaml but still sync other files (package.json, pyproject.toml)
# Locally: Syncs VERSION to all manifests including mta.yaml

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"

VERSION_FILE="$PROJECT_ROOT/VERSION"

if [ ! -f "$VERSION_FILE" ]; then
  echo "ERROR: VERSION file not found at $VERSION_FILE"
  exit 1
fi

VERSION=$(tr -d '[:space:]' < "$VERSION_FILE")

# Validate semantic versioning (MAJOR.MINOR.PATCH with positive integers only)
if ! echo "$VERSION" | grep -qE '^[0-9]+\.[0-9]+\.[0-9]+$'; then
  echo "ERROR: Invalid version format: '$VERSION'"
  echo "Version must follow semantic versioning: MAJOR.MINOR.PATCH (e.g., 1.0.0, 2.1.3)"
  echo "Only positive integers are allowed."
  exit 1
fi

echo "Syncing version: ${VERSION}"

# MTA - skip in CI (Piper already updated mta.yaml with cloud version)
if [ -f "$PROJECT_ROOT/mta.yaml" ]; then
  if [ -n "$CI" ] || [ -n "$GITHUB_ACTIONS" ]; then
    echo "  ⊘ mta.yaml (skipped in CI - Piper handles versioning)"
  else
    sed -i.bak "s/^version: .*/version: '${VERSION}'/" "$PROJECT_ROOT/mta.yaml"
    rm -f "$PROJECT_ROOT/mta.yaml.bak"
    echo "  ✓ mta.yaml"
  fi
fi

# Node.js (if package.json exists)
if [ -f "$PROJECT_ROOT/package.json" ]; then
  cd "$PROJECT_ROOT"
  npm version "$VERSION" --no-git-tag-version --allow-same-version >/dev/null 2>&1
  echo "  ✓ package.json"
fi

# Python (if pyproject.toml exists)
if [ -f "$PROJECT_ROOT/pyproject.toml" ]; then
  sed -i.bak "s/^version = .*/version = \"${VERSION}\"/" "$PROJECT_ROOT/pyproject.toml"
  rm -f "$PROJECT_ROOT/pyproject.toml.bak"
  echo "  ✓ pyproject.toml"
fi

echo "Version sync complete: ${VERSION}"
