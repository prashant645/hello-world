#!/usr/bin/env bash
set -euo pipefail

# Interactive IAS Authorization Code + PKCE and RFC 8693 token exchange.
# The client secret is read without echo and is never written to disk.

IAS_HOST="${IAS_HOST:-https://a3enmtmdf.accounts400.ondemand.com}"
MCP_CLIENT_ID="${MCP_CLIENT_ID:-32e0450f-44a1-40ec-a4f4-292777d52eca}"
REDIRECT_URI="${REDIRECT_URI:-http://localhost:18766/mcp-callback}"
RESOURCE_URN="${RESOURCE_URN:-urn:sap:identity:application:provider:name:scope}"
BACKEND_URL="${BACKEND_URL:-}"

require_cmd() {
  command -v "$1" >/dev/null 2>&1 || {
    echo "Missing command: $1" >&2
    exit 1
  }
}

require_cmd curl
require_cmd jq
require_cmd openssl
require_cmd python3

if [[ -z "${MCP_CLIENT_SECRET:-}" ]]; then
  read -r -s -p "MCP client secret: " MCP_CLIENT_SECRET
  echo
fi

export MCP_CLIENT_SECRET

read -r PKCE_CODE_VERIFIER PKCE_CODE_CHALLENGE OAUTH_STATE < <(
  python3 - <<'PY'
import base64
import hashlib
import secrets

def b64(value):
    return base64.urlsafe_b64encode(value).rstrip(b"=").decode()

verifier = b64(secrets.token_bytes(48))
challenge = b64(hashlib.sha256(verifier.encode()).digest())
state = secrets.token_urlsafe(24)
print(verifier, challenge, state)
PY
)

CALLBACK_FILE="$(mktemp -t ias-obo-callback)"
cleanup() {
  [[ -n "${CALLBACK_PID:-}" ]] && kill "$CALLBACK_PID" 2>/dev/null || true
  rm -f "$CALLBACK_FILE"
}
trap cleanup EXIT

CALLBACK_FILE="$CALLBACK_FILE" REDIRECT_URI="$REDIRECT_URI" python3 - <<'PY' &
import os
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import parse_qs, urlparse

callback_file = os.environ["CALLBACK_FILE"]
expected_path = urlparse(os.environ["REDIRECT_URI"]).path

class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        parsed = urlparse(self.path)
        if parsed.path != expected_path:
            self.send_error(404)
            return
        query = parse_qs(parsed.query)
        code = query.get("code", [""])[0]
        state = query.get("state", [""])[0]
        error = query.get("error", [""])[0]
        with open(callback_file, "w", encoding="utf-8") as output:
            output.write(f"{code}\n{state}\n{error}\n")
        body = "Authentication received. You can close this browser tab."
        self.send_response(200 if code else 400)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.end_headers()
        self.wfile.write(body.encode())
        raise SystemExit

    def log_message(self, *_):
        pass

port = urlparse(os.environ["REDIRECT_URI"]).port or 80
HTTPServer(("127.0.0.1", port), Handler).handle_request()
PY
CALLBACK_PID=$!

AUTH_URL="$(
  IAS_HOST="$IAS_HOST" MCP_CLIENT_ID="$MCP_CLIENT_ID" REDIRECT_URI="$REDIRECT_URI" \
  PKCE_CODE_CHALLENGE="$PKCE_CODE_CHALLENGE" OAUTH_STATE="$OAUTH_STATE" \
  python3 - <<'PY'
import os
from urllib.parse import urlencode

params = {
    "response_type": "code",
    "client_id": os.environ["MCP_CLIENT_ID"],
    "redirect_uri": os.environ["REDIRECT_URI"],
    "scope": "openid",
    "code_challenge": os.environ["PKCE_CODE_CHALLENGE"],
    "code_challenge_method": "S256",
    "state": os.environ["OAUTH_STATE"],
}
print(os.environ["IAS_HOST"] + "/oauth2/authorize?" + urlencode(params))
PY
)"

echo "Open this URL in a browser and sign in:"
echo "$AUTH_URL"
if command -v open >/dev/null 2>&1; then
  open "$AUTH_URL" >/dev/null 2>&1 || true
fi

echo "Waiting for the IAS callback on $REDIRECT_URI ..."
for _ in {1..300}; do
  [[ -s "$CALLBACK_FILE" ]] && break
  sleep 1
done

[[ -s "$CALLBACK_FILE" ]] || {
  echo "Timed out waiting for the IAS callback" >&2
  exit 1
}

IFS= read -r AUTHORIZATION_CODE < "$CALLBACK_FILE"
IFS= read -r CALLBACK_STATE < <(sed -n '2p' "$CALLBACK_FILE")
IFS= read -r CALLBACK_ERROR < <(sed -n '3p' "$CALLBACK_FILE")

[[ -z "$CALLBACK_ERROR" ]] || {
  echo "IAS authorization failed: $CALLBACK_ERROR" >&2
  exit 1
}
[[ "$CALLBACK_STATE" == "$OAUTH_STATE" ]] || {
  echo "OAuth state mismatch" >&2
  exit 1
}

summarize_token() {
  ACCESS_TOKEN="$1" python3 - <<'PY'
import base64
import json
import os

payload = os.environ["ACCESS_TOKEN"].split(".")[1]
payload += "=" * (-len(payload) % 4)
claims = json.loads(base64.urlsafe_b64decode(payload))
print(json.dumps({
    "sub": claims.get("sub"),
    "user_uuid": claims.get("user_uuid"),
    "sap_id_type": claims.get("sap_id_type"),
    "ias_apis": claims.get("ias_apis"),
    "aud": claims.get("aud"),
}, indent=2))
PY
}

TOKEN_JSON="$(curl -sS -X POST "$IAS_HOST/oauth2/token" \
  -u "$MCP_CLIENT_ID:$MCP_CLIENT_SECRET" \
  -H 'Content-Type: application/x-www-form-urlencoded' \
  --data-urlencode 'grant_type=authorization_code' \
  --data-urlencode "code=$AUTHORIZATION_CODE" \
  --data-urlencode "redirect_uri=$REDIRECT_URI" \
  --data-urlencode "client_id=$MCP_CLIENT_ID" \
  --data-urlencode "code_verifier=$PKCE_CODE_VERIFIER")"

USER_ACCESS_TOKEN="$(printf '%s' "$TOKEN_JSON" | jq -r '.access_token // empty')"
[[ -n "$USER_ACCESS_TOKEN" ]] || {
  echo "IAS authorization-code exchange failed:" >&2
  printf '%s\n' "$TOKEN_JSON" | jq . >&2 || printf '%s\n' "$TOKEN_JSON" >&2
  exit 1
}

echo "Authorization-code token claims:"
summarize_token "$USER_ACCESS_TOKEN"

SUBJECT_TOKEN="$(printf '%s' "$TOKEN_JSON" | jq -r '.id_token // empty')"
SUBJECT_TOKEN_TYPE='urn:ietf:params:oauth:token-type:id_token'
if [[ -z "$SUBJECT_TOKEN" ]]; then
  SUBJECT_TOKEN="$USER_ACCESS_TOKEN"
  SUBJECT_TOKEN_TYPE='urn:ietf:params:oauth:token-type:access_token'
  echo "No ID token returned; using the access token for RFC 8693 exchange." >&2
else
  echo "Using the authorization-code ID token as the session-bearing subject token."
fi

EXCHANGED_JSON="$(curl -sS -X POST "$IAS_HOST/oauth2/token" \
  -u "$MCP_CLIENT_ID:$MCP_CLIENT_SECRET" \
  -H 'Content-Type: application/x-www-form-urlencoded' \
  --data-urlencode 'grant_type=urn:ietf:params:oauth:grant-type:token-exchange' \
  --data-urlencode "subject_token=$SUBJECT_TOKEN" \
  --data-urlencode "subject_token_type=$SUBJECT_TOKEN_TYPE" \
  --data-urlencode 'requested_token_type=urn:ietf:params:oauth:token-type:access_token' \
  --data-urlencode "resource=$RESOURCE_URN")"

BACKEND_ACCESS_TOKEN="$(printf '%s' "$EXCHANGED_JSON" | jq -r '.access_token // empty')"
[[ -n "$BACKEND_ACCESS_TOKEN" ]] || {
  echo "IAS RFC 8693 token exchange failed:" >&2
  printf '%s\n' "$EXCHANGED_JSON" | jq . >&2 || printf '%s\n' "$EXCHANGED_JSON" >&2
  exit 1
}

echo "User token claims:"
summarize_token "$USER_ACCESS_TOKEN"
echo "Exchanged backend token claims:"
summarize_token "$BACKEND_ACCESS_TOKEN"

if [[ -n "$BACKEND_URL" ]]; then
  curl -fsS -i -X POST "$BACKEND_URL/api/v1/greetings" \
    -H "Authorization: Bearer $BACKEND_ACCESS_TOKEN" \
    -H 'Content-Type: application/json' \
    --data '{"message":"IAS OBO test"}'
fi
