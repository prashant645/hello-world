#!/usr/bin/env python3
#
# vault debugging tool
"""Validate the Docker registry credential format used by this repo's Vault/Piper flow.

Supports three input modes:
- --from-file PATH              raw Docker config JSON or a Vault JSON document containing dockerConfigJSON
- --from-json-string VALUE      raw Docker config JSON string or a Vault JSON document containing dockerConfigJSON
- --from-k8s-secret NS NAME     kubernetes.io/dockerconfigjson secret to decode and validate

By default, validates the expected registry host for this repository:
  gtlc-docker.common.repositories.cloud.sap

Optional: --login-test performs a Docker login using a temporary Docker config directory
without printing the username/password.

Optional: --scope-test REPOSITORY checks bearer token minting for both
repository:REPOSITORY:pull and repository:REPOSITORY:pull,push scopes.
"""

from __future__ import annotations

import argparse
import base64
import json
import re
import ssl
import subprocess
import sys
import tempfile
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any

DEFAULT_REGISTRY = "gtlc-docker.common.repositories.cloud.sap"


class ValidationError(Exception):
    pass


def _load_text(args: argparse.Namespace) -> str:
    modes = sum(
        bool(value)
        for value in (args.from_file, args.from_json_string, args.from_k8s_secret)
    )
    if modes != 1:
        raise ValidationError(
            "Choose exactly one input source: --from-file, --from-json-string, or --from-k8s-secret."
        )

    if args.from_file:
        return Path(args.from_file).read_text(encoding="utf-8")

    if args.from_json_string:
        return args.from_json_string

    namespace, name = args.from_k8s_secret
    result = subprocess.run(
        [
            "kubectl",
            "get",
            "secret",
            name,
            "-n",
            namespace,
            "-o",
            "jsonpath={.data.\\.dockerconfigjson}",
        ],
        text=True,
        capture_output=True,
        check=False,
    )
    if result.returncode != 0:
        raise ValidationError(
            f"Failed to read Kubernetes secret {namespace}/{name}: {(result.stderr or result.stdout).strip()}"
        )
    if not result.stdout.strip():
        raise ValidationError(
            f"Kubernetes secret {namespace}/{name} does not contain .dockerconfigjson data."
        )
    try:
        return base64.b64decode(result.stdout.strip()).decode("utf-8")
    except Exception as exc:  # pragma: no cover - defensive
        raise ValidationError("Failed to base64-decode .dockerconfigjson from Kubernetes secret.") from exc


def _parse_outer_document(text: str) -> dict[str, Any]:
    try:
        data = json.loads(text)
    except json.JSONDecodeError as exc:
        raise ValidationError(f"Input is not valid JSON: {exc}") from exc
    if not isinstance(data, dict):
        raise ValidationError("Top-level JSON must be an object.")
    return data


def _extract_docker_config(text: str) -> dict[str, Any]:
    outer = _parse_outer_document(text)

    if "auths" in outer:
        docker_config = outer
    elif "dockerConfigJSON" in outer:
        inner = outer["dockerConfigJSON"]
        if not isinstance(inner, str):
            raise ValidationError("Field dockerConfigJSON exists but is not a JSON string.")
        docker_config = _parse_outer_document(inner)
    else:
        raise ValidationError(
            "JSON must be either a Docker config object with 'auths' or a Vault-style object containing 'dockerConfigJSON'."
        )

    auths = docker_config.get("auths")
    if not isinstance(auths, dict) or not auths:
        raise ValidationError("Docker config does not contain a non-empty 'auths' object.")

    return docker_config


def _extract_credentials(registry_entry: dict[str, Any]) -> tuple[str, str]:
    username = registry_entry.get("username")
    password = registry_entry.get("password")

    auth = registry_entry.get("auth")
    if auth:
        if not isinstance(auth, str):
            raise ValidationError("Registry auth entry exists but is not a string.")
        try:
            decoded = base64.b64decode(auth).decode("utf-8")
            auth_user, auth_pass = decoded.split(":", 1)
        except Exception as exc:
            raise ValidationError("Registry auth value is not valid base64(username:password).") from exc

        if username and password:
            if username != auth_user or password != auth_pass:
                raise ValidationError(
                    "Registry entry contains both auth and username/password, but they do not match."
                )
        else:
            username, password = auth_user, auth_pass

    if not username or not password:
        raise ValidationError(
            "Registry entry must contain either base64 auth or explicit username/password."
        )

    if not isinstance(username, str) or not isinstance(password, str):
        raise ValidationError("Resolved username/password must be strings.")

    return username, password


def _login_test(registry: str, username: str, password: str) -> None:
    with tempfile.TemporaryDirectory() as tmp_dir:
        result = subprocess.run(
            [
                "docker",
                "--config",
                tmp_dir,
                "login",
                registry,
                "--username",
                username,
                "--password-stdin",
            ],
            input=password,
            text=True,
            capture_output=True,
            check=False,
        )

    if result.returncode != 0:
        tail = (result.stderr or result.stdout or "").strip().splitlines()
        detail = tail[-1] if tail else "unknown docker login error"
        raise ValidationError(f"Docker login test failed: {detail}")


def _basic_auth(username: str, password: str) -> str:
    return base64.b64encode(f"{username}:{password}".encode("utf-8")).decode("ascii")


def _curl(url: str, *extra_args: str) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        ["curl", "--silent", "--show-error", "--location", *extra_args, url],
        text=True,
        capture_output=True,
        check=False,
    )


def _registry_challenge(registry: str) -> tuple[str, str]:
    result = _curl(f"https://{registry}/v2/", "-D", "-", "-o", "/dev/null")
    if result.returncode != 0:
        detail = (result.stderr or result.stdout or "").strip()
        raise ValidationError(f"Failed to contact registry challenge endpoint: {detail}")

    header = next(
        (line.split(":", 1)[1].strip() for line in result.stdout.splitlines() if line.lower().startswith("www-authenticate:")),
        "",
    )
    realm_match = re.search(r'realm="([^"]+)"', header)
    service_match = re.search(r'service="([^"]+)"', header)
    if realm_match and service_match:
        return realm_match.group(1), service_match.group(1)
    raise ValidationError(f"Registry challenge did not include bearer realm/service details: {header or 'missing header'}")


def _scope_test(registry: str, username: str, password: str, repository: str, scope_actions: str) -> None:
    realm, service = _registry_challenge(registry)
    scope = f"repository:{repository}:{scope_actions}"
    params = urllib.parse.urlencode({"service": service, "scope": scope})
    request = urllib.request.Request(
        f"{realm}?{params}",
        headers={"Authorization": f"Basic {_basic_auth(username, password)}"},
    )

    try:
        with urllib.request.urlopen(request, context=ssl._create_unverified_context()) as response:
            status_code = response.status
            payload_text = response.read().decode("utf-8")
    except urllib.error.HTTPError as exc:
        payload_text = exc.read().decode("utf-8", errors="replace")
        raise ValidationError(
            f"Scope token request failed for {scope}: HTTP {exc.code} {payload_text.strip()}"
        ) from exc
    except urllib.error.URLError as exc:
        raise ValidationError(f"Scope token request failed for {scope}: {exc}") from exc

    try:
        payload = json.loads(payload_text)
    except json.JSONDecodeError as exc:
        raise ValidationError(
            f"Scope token request for {scope} returned non-JSON payload: {payload_text.strip()}"
        ) from exc

    if not isinstance(payload, dict) or not any(key in payload for key in ("token", "access_token")):
        raise ValidationError(
            f"Scope token request for {scope} succeeded but no token field was returned."
        )


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--from-file", help="Path to Docker config JSON or Vault JSON document")
    parser.add_argument("--from-json-string", help="Raw Docker config JSON or Vault JSON document")
    parser.add_argument(
        "--from-k8s-secret",
        nargs=2,
        metavar=("NAMESPACE", "NAME"),
        help="Read and decode .dockerconfigjson from a Kubernetes secret",
    )
    parser.add_argument(
        "--registry",
        default=DEFAULT_REGISTRY,
        help=f"Registry host to validate (default: {DEFAULT_REGISTRY})",
    )
    parser.add_argument(
        "--login-test",
        action="store_true",
        help="Attempt a Docker login with the extracted credential",
    )
    parser.add_argument(
        "--scope-test",
        metavar="REPOSITORY",
        help="Check bearer token minting for repository pull and pull,push scopes",
    )
    args = parser.parse_args()

    try:
        text = _load_text(args)
        docker_config = _extract_docker_config(text)
        auths = docker_config["auths"]

        if args.registry not in auths:
            raise ValidationError(
                f"Docker config does not contain an auth entry for registry '{args.registry}'."
            )

        registry_entry = auths[args.registry]
        if not isinstance(registry_entry, dict):
            raise ValidationError("Registry auth entry must be a JSON object.")

        username, password = _extract_credentials(registry_entry)
    except ValidationError as exc:
        print("contract_check=failed")
        print(f"error={exc}")
        return 1

    print("contract_check=success")
    print(f"registry={args.registry}")
    print(f"username_present={bool(username)}")
    print(f"password_present={bool(password)}")
    print(f"auth_entry_count={len(auths)}")

    exit_code = 0

    if args.login_test:
        try:
            _login_test(args.registry, username, password)
            print("login_test=success")
        except ValidationError as exc:
            print("login_test=failed")
            print(f"error={exc}")
            exit_code = 1
    else:
        print("login_test=skipped")

    if args.scope_test:
        try:
            _scope_test(args.registry, username, password, args.scope_test, "pull")
            print("pull_scope_test=success")
        except ValidationError as exc:
            print("pull_scope_test=failed")
            print(f"error={exc}")
            exit_code = 1

        try:
            _scope_test(args.registry, username, password, args.scope_test, "pull,push")
            print("pull_push_scope_test=success")
        except ValidationError as exc:
            print("pull_push_scope_test=failed")
            print(f"error={exc}")
            exit_code = 1
    else:
        print("pull_scope_test=skipped")
        print("pull_push_scope_test=skipped")

    return exit_code


if __name__ == "__main__":
    sys.exit(main())

