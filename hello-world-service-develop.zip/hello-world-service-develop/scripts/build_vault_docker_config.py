#!/usr/bin/env python3
#
# Vault debugger tool
"""Build a Vault-ready docker-config payload from a working Docker config entry.

The output matches this repository's expected Vault shape:
{
  "dockerConfigJSON": "{\"auths\":{...}}"
}

Optionally, include a plain "password" field for consumers that still read it.

Examples:
  python3 scripts/build_vault_docker_config.py \
    --from-file "$HOME/.docker/config.json" \
    --output /tmp/vault-docker-config.json

  python3 scripts/build_vault_docker_config.py \
    --from-file "$HOME/.docker/config.json" \
    --include-password-field \
    --output /tmp/vault-docker-config-with-password.json

  python3 scripts/build_vault_docker_config.py \
    --from-file "$HOME/.docker/config.json" \
    --print-docker-config-json-only
"""

from __future__ import annotations

import argparse
import base64
import json
import sys
from pathlib import Path
from typing import Any

DEFAULT_REGISTRY = "gtlc-docker.common.repositories.cloud.sap"


class BuildError(Exception):
    pass


def _parse_json_file(path: str) -> dict[str, Any]:
    try:
        data = json.loads(Path(path).read_text(encoding="utf-8"))
    except FileNotFoundError as exc:
        raise BuildError(f"Input file not found: {path}") from exc
    except json.JSONDecodeError as exc:
        raise BuildError(f"Input file is not valid JSON: {exc}") from exc

    if not isinstance(data, dict):
        raise BuildError("Top-level JSON must be an object.")

    return data


def _extract_docker_config(data: dict[str, Any]) -> dict[str, Any]:
    if "auths" in data:
        docker_config = data
    elif "dockerConfigJSON" in data:
        inner = data["dockerConfigJSON"]
        if not isinstance(inner, str):
            raise BuildError("Field dockerConfigJSON exists but is not a JSON string.")
        try:
            docker_config = json.loads(inner)
        except json.JSONDecodeError as exc:
            raise BuildError(f"dockerConfigJSON is not valid JSON: {exc}") from exc
    else:
        raise BuildError("Input must be a Docker config object or a Vault-style dockerConfigJSON object.")

    auths = docker_config.get("auths")
    if not isinstance(auths, dict) or not auths:
        raise BuildError("Docker config does not contain a non-empty 'auths' object.")

    return docker_config


def _resolve_credentials(entry: dict[str, Any]) -> tuple[str, str, str]:
    username = entry.get("username")
    password = entry.get("password")
    auth = entry.get("auth")

    if auth is not None:
        if not isinstance(auth, str):
            raise BuildError("Registry auth entry must be a string when present.")
        try:
            auth_user, auth_pass = base64.b64decode(auth).decode("utf-8").split(":", 1)
        except Exception as exc:
            raise BuildError("Registry auth value is not valid base64(username:password).") from exc

        if username and password:
            if username != auth_user or password != auth_pass:
                raise BuildError("username/password do not match the auth field.")
        else:
            username, password = auth_user, auth_pass
    elif not username or not password:
        raise BuildError("Registry entry must contain either auth or username/password.")

    if not isinstance(username, str) or not isinstance(password, str):
        raise BuildError("Resolved username/password must be strings.")

    canonical_auth = base64.b64encode(f"{username}:{password}".encode("utf-8")).decode("ascii")
    return username, password, canonical_auth


def _canonicalize_entry(entry: dict[str, Any], username: str, password: str, auth: str) -> dict[str, Any]:
    canonical = dict(entry)
    canonical["username"] = username
    canonical["password"] = password
    canonical["auth"] = auth
    return canonical


def _auth_only_entry(auth: str) -> dict[str, str]:
    return {"auth": auth}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--from-file",
        default=str(Path.home() / ".docker" / "config.json"),
        help="Path to a Docker config JSON file or an existing Vault-style JSON file",
    )
    parser.add_argument(
        "--registry",
        default=DEFAULT_REGISTRY,
        help=f"Registry host to extract (default: {DEFAULT_REGISTRY})",
    )
    parser.add_argument(
        "--output",
        help="Where to write the Vault-ready JSON payload",
    )
    parser.add_argument(
        "--include-password-field",
        action="store_true",
        help="Also include a plain password field in the Vault payload",
    )
    parser.add_argument(
        "--pretty",
        action="store_true",
        help="Pretty-print the output JSON instead of writing a single line",
    )
    parser.add_argument(
        "--auth-only",
        action="store_true",
        help="Emit a minimal Docker auth entry containing only the auth field",
    )
    parser.add_argument(
        "--print-docker-config-json",
        action="store_true",
        help="Print only the dockerConfigJSON field value to stdout for direct Vault pasting",
    )
    parser.add_argument(
        "--print-docker-config-json-only",
        action="store_true",
        help="Print only the dockerConfigJSON field value and suppress status output",
    )
    args = parser.parse_args()

    if args.print_docker_config_json and args.print_docker_config_json_only:
        print("build_status=failed")
        print("error=Choose at most one of --print-docker-config-json and --print-docker-config-json-only.")
        return 1

    if not args.output and not args.print_docker_config_json and not args.print_docker_config_json_only:
        print("build_status=failed")
        print("error=Provide --output and/or one of the --print-docker-config-json options.")
        return 1

    try:
        source_data = _parse_json_file(args.from_file)
        docker_config = _extract_docker_config(source_data)
        auths = docker_config["auths"]

        if args.registry not in auths:
            raise BuildError(f"Registry '{args.registry}' was not found in the input auths map.")

        entry = auths[args.registry]
        if not isinstance(entry, dict):
            raise BuildError("Registry auth entry must be a JSON object.")

        username, password, auth = _resolve_credentials(entry)
        canonical_entry = _auth_only_entry(auth) if args.auth_only else _canonicalize_entry(entry, username, password, auth)
        docker_config_json = json.dumps({"auths": {args.registry: canonical_entry}}, separators=(",", ":"))
        payload = {"dockerConfigJSON": docker_config_json}
        if args.include_password_field:
            payload["password"] = password

        if args.output:
            output_path = Path(args.output)
            output_path.parent.mkdir(parents=True, exist_ok=True)
            text = json.dumps(payload, indent=2 if args.pretty else None, separators=None if args.pretty else (",", ":"))
            output_path.write_text(text + ("\n" if args.pretty else ""), encoding="utf-8")
        else:
            output_path = None

        if args.print_docker_config_json or args.print_docker_config_json_only:
            print(docker_config_json)

        if args.print_docker_config_json_only:
            return 0

        print("build_status=success")
        print(f"registry={args.registry}")
        if output_path is not None:
            print(f"output_file={output_path}")
        print(f"username_present={bool(username)}")
        print(f"password_field_included={args.include_password_field}")
        print(f"auth_only={args.auth_only}")
        return 0
    except BuildError as exc:
        print("build_status=failed")
        print(f"error={exc}")
        return 1


if __name__ == "__main__":
    sys.exit(main())

