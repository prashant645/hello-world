#!/bin/bash
# Verification: Compare our manifests against official Helm chart
# This script extracts the actual images and configurations from SAP's official Helm chart

set -e

echo "=== BTP Operator Manifest Verification Against Official Helm Chart ==="
echo ""

# Add/update Helm repo
helm repo add sap-btp-operator https://sap.github.io/sap-btp-service-operator 2>/dev/null || true
helm repo update sap-btp-operator 2>/dev/null

# Get latest chart version
CHART_VERSION=$(helm search repo sap-btp-operator/sap-btp-operator --output json | jq -r '.[0].version')
APP_VERSION=$(helm search repo sap-btp-operator/sap-btp-operator --output json | jq -r '.[0].app_version')

echo "Latest Helm Chart Version: $CHART_VERSION"
echo "Application Version: $APP_VERSION"
echo ""

# Extract images from Helm chart
echo "=== Official Images from Helm Chart ==="
helm show values sap-btp-operator/sap-btp-operator | grep -A 3 "image:" | grep -E "repository:|tag:"
echo ""

# Extract actual deployment manifest to compare
echo "=== Extracting Official Deployment Manifest ==="
helm template sap-btp-operator sap-btp-operator/sap-btp-operator \
  --set manager.secret.clientid=test \
  --set manager.secret.clientsecret=test \
  --set manager.secret.sm_url=test \
  --set manager.secret.tokenurl=test \
  > /tmp/helm-generated-manifest.yaml

echo "Generated manifest saved to: /tmp/helm-generated-manifest.yaml"
echo ""

# Extract key configurations for comparison
echo "=== Container Images Used ==="
grep "image:" /tmp/helm-generated-manifest.yaml | sort -u
echo ""

echo "=== Container Args Used ==="
grep -A 5 "args:" /tmp/helm-generated-manifest.yaml | grep "^        -" | sort -u
echo ""

echo "=== Environment Variables ==="
grep -A 2 "env:" /tmp/helm-generated-manifest.yaml | grep "name:" | sort -u
echo ""

# Compare with our manifests
echo "=== Comparing with Our Manifests ==="
echo ""
echo "Our deployment file: k8s/btp-operator/4-operator-deployment.yaml"
echo ""
echo "Our container images:"
grep "image:" k8s/btp-operator/4-operator-deployment.yaml | grep -v "^#"
echo ""
echo "Our container args:"
grep -A 5 "args:" k8s/btp-operator/4-operator-deployment.yaml | grep "^        -"
echo ""

# Verification checks
echo "=== Verification Summary ==="
echo ""

# Check if images match
HELM_CONTROLLER_IMAGE=$(grep "ghcr.io/sap/sap-btp-service-operator/controller" /tmp/helm-generated-manifest.yaml | head -1 | awk '{print $2}' | tr -d '"')
OUR_CONTROLLER_IMAGE=$(grep "ghcr.io/sap/sap-btp-service-operator/controller" k8s/btp-operator/4-operator-deployment.yaml | grep -v "^#" | head -1 | awk '{print $2}' | tr -d '"')

echo "Controller Image:"
echo "  Helm:  $HELM_CONTROLLER_IMAGE"
echo "  Ours:  $OUR_CONTROLLER_IMAGE"
if [ "$HELM_CONTROLLER_IMAGE" = "$OUR_CONTROLLER_IMAGE" ]; then
  echo "  ✓ MATCH"
else
  echo "  ✗ MISMATCH"
fi
echo ""

HELM_PROXY_IMAGE=$(grep "kube-rbac-proxy" /tmp/helm-generated-manifest.yaml | grep "image:" | head -1 | awk '{print $2}' | tr -d '"')
OUR_PROXY_IMAGE=$(grep "kube-rbac-proxy" k8s/btp-operator/4-operator-deployment.yaml | grep "image:" | grep -v "^#" | head -1 | awk '{print $2}' | tr -d '"')

echo "RBAC Proxy Image:"
echo "  Helm:  $HELM_PROXY_IMAGE"
echo "  Ours:  $OUR_PROXY_IMAGE"
if [ "$HELM_PROXY_IMAGE" = "$OUR_PROXY_IMAGE" ]; then
  echo "  ✓ MATCH"
else
  echo "  ✗ MISMATCH"
fi
echo ""

# Check if images are pullable
echo "=== Image Pull Verification ==="
for IMAGE in "$HELM_CONTROLLER_IMAGE" "$HELM_PROXY_IMAGE"; do
  if docker manifest inspect "$IMAGE" &>/dev/null; then
    echo "✓ $IMAGE is pullable"
  else
    echo "✗ $IMAGE CANNOT be pulled"
  fi
done
echo ""

echo "=== Verification Complete ==="
echo ""
echo "Next steps:"
echo "1. Review /tmp/helm-generated-manifest.yaml for full official deployment"
echo "2. If mismatches found, update k8s/btp-operator/4-operator-deployment.yaml"
echo "3. Re-run this script after updates to verify"
