#!/bin/bash
# Automated test: Verify webhook validation behavior
# This test validates that:
# 1. Invalid resources are REJECTED in labeled namespaces (webhook enforcing)
# 2. Invalid resources are ACCEPTED in unlabeled namespaces (webhook bypassed)

set -e

echo "=== Webhook Validation Behavior Test ==="
echo ""

# Test namespace names
LABELED_NS="webhook-test-labeled"
UNLABELED_NS="webhook-test-unlabeled"

# Cleanup function
cleanup() {
  echo ""
  echo "Cleaning up test namespaces..."
  kubectl delete namespace $LABELED_NS --ignore-not-found=true
  kubectl delete namespace $UNLABELED_NS --ignore-not-found=true
}

trap cleanup EXIT

# Create test namespaces
echo "1. Creating test namespaces..."
kubectl create namespace $LABELED_NS
kubectl label namespace $LABELED_NS btp-operator=enabled
kubectl create namespace $UNLABELED_NS
echo "   ✓ Namespaces created"
echo ""

# Grant secret access to both namespaces (so RBAC isn't the failure point)
echo "2. Granting secret access to test namespaces..."
for NS in $LABELED_NS $UNLABELED_NS; do
  cat <<EOF | kubectl apply -f -
apiVersion: rbac.authorization.k8s.io/v1
kind: Role
metadata:
  name: sap-btp-operator-secret-access
  namespace: $NS
rules:
- apiGroups: [""]
  resources: ["secrets"]
  verbs: ["get", "list", "watch", "create", "update", "patch", "delete"]
---
apiVersion: rbac.authorization.k8s.io/v1
kind: RoleBinding
metadata:
  name: sap-btp-operator-secret-access
  namespace: $NS
roleRef:
  apiGroup: rbac.authorization.k8s.io
  kind: Role
  name: sap-btp-operator-secret-access
subjects:
- kind: ServiceAccount
  name: sap-btp-operator
  namespace: sap-btp-operator
EOF
done
echo "   ✓ RBAC configured"
echo ""

# Invalid ServiceInstance manifest (empty offering/plan names)
INVALID_MANIFEST=$(cat <<'EOF'
apiVersion: services.cloud.sap.com/v1
kind: ServiceInstance
metadata:
  name: webhook-validation-test
spec:
  serviceOfferingName: ""
  servicePlanName: ""
EOF
)

# Test 1: Invalid resource in LABELED namespace (should be REJECTED)
echo "3. Test 1: Invalid ServiceInstance in LABELED namespace"
echo "   Expected: REJECTED by webhook"
if echo "$INVALID_MANIFEST" | kubectl apply -n $LABELED_NS -f - 2>&1 | grep -q "admission webhook.*denied\|Required value"; then
  echo "   ✓ PASS: Webhook rejected invalid resource in labeled namespace"
  TEST1_PASS=true
else
  echo "   ✗ FAIL: Webhook did NOT reject invalid resource in labeled namespace"
  echo "   This indicates webhook is not functioning or namespace is not properly labeled"
  TEST1_PASS=false
fi
echo ""

# Test 2: Invalid resource in UNLABELED namespace (should be ACCEPTED - bypass)
echo "4. Test 2: Invalid ServiceInstance in UNLABELED namespace"
echo "   Expected: ACCEPTED (webhook bypassed)"
if echo "$INVALID_MANIFEST" | kubectl apply -n $UNLABELED_NS -f - 2>/dev/null; then
  echo "   ✓ PASS: Invalid resource accepted in unlabeled namespace (webhook bypassed)"
  echo "   ⚠️  WARNING: This is by design for blast radius control, but creates security gap"
  TEST2_PASS=true
else
  echo "   ✗ FAIL: Invalid resource was rejected in unlabeled namespace"
  echo "   This indicates webhook is NOT properly scoped by namespace selector"
  TEST2_PASS=false
fi
echo ""

# Summary
echo "=== Test Results ==="
if [ "$TEST1_PASS" = true ] && [ "$TEST2_PASS" = true ]; then
  echo "✓ ALL TESTS PASSED: Webhook validation behavior is correct"
  echo ""
  echo "Summary:"
  echo "  - Labeled namespaces: Validation ENFORCED ✓"
  echo "  - Unlabeled namespaces: Validation BYPASSED ⚠️"
  exit 0
else
  echo "✗ TESTS FAILED: Webhook validation behavior is incorrect"
  echo ""
  echo "Summary:"
  [ "$TEST1_PASS" = true ] && echo "  - Test 1 (labeled): ✓" || echo "  - Test 1 (labeled): ✗"
  [ "$TEST2_PASS" = true ] && echo "  - Test 2 (unlabeled): ✓" || echo "  - Test 2 (unlabeled): ✗"
  echo ""
  echo "Troubleshooting:"
  echo "  - Verify webhook is running: kubectl get validatingwebhookconfiguration"
  echo "  - Check namespace labels: kubectl get namespace $LABELED_NS -o yaml"
  echo "  - Review webhook logs: kubectl logs -n sap-btp-operator -l app=sap-btp-operator -c manager"
  exit 1
fi
