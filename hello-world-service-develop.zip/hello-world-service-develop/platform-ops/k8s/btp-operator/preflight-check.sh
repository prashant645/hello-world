#!/bin/bash
# Preflight check: Verify all prerequisites before BTP operator installation
# Run this before starting Step 1 to catch missing dependencies early
#
# Usage:
#   ./preflight-check.sh                    # Uses kubectl
#   KUBECTL=k ./preflight-check.sh          # Uses custom command (e.g., k)
#   KUBECTL="kubectl --context=my-ctx" ./preflight-check.sh

set -e

# Allow override of kubectl command via environment variable
KUBECTL="${KUBECTL:-kubectl}"

echo "=== SAP BTP Operator Installation Preflight Check ==="
echo "Using command: $KUBECTL"
echo ""

PASS=0
FAIL=0
WARN=0

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

pass() {
  echo -e "${GREEN}✓${NC} $1"
  ((PASS++))
}

fail() {
  echo -e "${RED}✗${NC} $1"
  ((FAIL++))
}

warn() {
  echo -e "${YELLOW}⚠${NC} $1"
  ((WARN++))
}

# 1. Kubernetes version
echo "1. Checking Kubernetes version..."

# Try multiple methods to get server version
K8S_VERSION=""

# Method 1: Get from nodes directly (fastest, most reliable)
if [ -z "$K8S_VERSION" ]; then
  K8S_VERSION=$($KUBECTL get nodes -o jsonpath='{.items[0].status.nodeInfo.kubeletVersion}' 2>/dev/null)
fi

# Method 2: JSON output with grep (if Method 1 fails)
if [ -z "$K8S_VERSION" ]; then
  K8S_VERSION=$($KUBECTL version -o json 2>/dev/null | grep -A 20 '"serverVersion"' | grep '"gitVersion"' | head -1 | cut -d'"' -f4 2>/dev/null)
fi

# Method 3: --short flag (older kubectl)
if [ -z "$K8S_VERSION" ]; then
  K8S_VERSION=$($KUBECTL version --short 2>/dev/null | grep "Server Version" | awk '{print $3}')
fi

if [ -n "$K8S_VERSION" ]; then
  # Extract major and minor version
  MAJOR=$(echo "$K8S_VERSION" | cut -d. -f1 | tr -d 'v')
  MINOR=$(echo "$K8S_VERSION" | cut -d. -f2)

  # Validate we got numeric values
  if [[ "$MAJOR" =~ ^[0-9]+$ ]] && [[ "$MINOR" =~ ^[0-9]+$ ]]; then
    if [ "$MAJOR" -ge 1 ] && [ "$MINOR" -ge 17 ]; then
      pass "Kubernetes version $K8S_VERSION (requires 1.17+, recommended 1.20+)"
    else
      fail "Kubernetes version $K8S_VERSION is too old (requires 1.17+)"
    fi
  else
    fail "Could not parse Kubernetes version: $K8S_VERSION"
  fi
else
  fail "Cannot connect to Kubernetes cluster or retrieve server version"
  echo "   Debug: Try running '$KUBECTL cluster-info' to verify cluster connectivity"
fi
echo ""

# 2. $KUBECTL context
echo "2. Checking $KUBECTL context..."
CONTEXT=$($KUBECTL config current-context 2>/dev/null || echo "none")
if [[ "$CONTEXT" == *"prod"* ]] || [[ "$CONTEXT" == *"production"* ]]; then
  warn "Current context '$CONTEXT' appears to be PRODUCTION - proceed with caution"
else
  pass "Current context: $CONTEXT"
fi
echo ""

# 3. cert-manager installed
echo "3. Checking cert-manager installation..."
if $KUBECTL get namespace cert-manager &>/dev/null; then
  pass "cert-manager namespace exists"

  # Check cert-manager pods
  if $KUBECTL get pods -n cert-manager -l app=cert-manager &>/dev/null; then
    READY=$($KUBECTL get pods -n cert-manager -l app=cert-manager -o jsonpath='{.items[*].status.conditions[?(@.type=="Ready")].status}' 2>/dev/null)
    if [[ "$READY" == *"True"* ]]; then
      pass "cert-manager controller is running and ready"
    else
      fail "cert-manager controller pods exist but not ready"
    fi
  else
    fail "cert-manager controller pods not found"
  fi

  # Check cert-manager webhook
  if $KUBECTL get pods -n cert-manager -l app=webhook &>/dev/null; then
    READY=$($KUBECTL get pods -n cert-manager -l app=webhook -o jsonpath='{.items[*].status.conditions[?(@.type=="Ready")].status}' 2>/dev/null)
    if [[ "$READY" == *"True"* ]]; then
      pass "cert-manager webhook is running and ready"
    else
      fail "cert-manager webhook pods exist but not ready"
    fi
  else
    fail "cert-manager webhook pods not found"
  fi

  # Check cert-manager CRDs
  if $KUBECTL get crd certificates.cert-manager.io &>/dev/null && \
     $KUBECTL get crd issuers.cert-manager.io &>/dev/null; then
    pass "cert-manager CRDs are installed"
  else
    fail "cert-manager CRDs not found"
  fi
else
  fail "cert-manager not installed"
  echo ""
  echo "   Install cert-manager:"
  echo "   $KUBECTL apply -f https://github.com/cert-manager/cert-manager/releases/download/v1.13.0/cert-manager.yaml"
  echo "   $KUBECTL wait --for=condition=available --timeout=300s deployment/cert-manager -n cert-manager"
fi
echo ""

# 4. Network connectivity test (optional but recommended)
echo "4. Checking network connectivity..."
if command -v curl &>/dev/null; then
  # Test connectivity to common BTP regions
  if curl -s --connect-timeout 5 https://service-manager.cfapps.eu10.hana.ondemand.com/health &>/dev/null; then
    pass "Network egress to BTP Service Manager (EU10) is reachable"
  else
    warn "Cannot reach BTP Service Manager EU10 (https://service-manager.cfapps.eu10.hana.ondemand.com)"
    echo "   This may indicate network/firewall restrictions"
  fi
else
  warn "curl not available - skipping network connectivity test"
fi
echo ""

# 5. Required tools
echo "5. Checking required tools..."
for tool in $KUBECTL jq docker; do
  if command -v $tool &>/dev/null; then
    pass "$tool is installed"
  else
    if [ "$tool" = "jq" ]; then
      warn "$tool not found (recommended for JSON processing)"
    elif [ "$tool" = "docker" ]; then
      warn "$tool not found (needed for digest pinning in production)"
    else
      fail "$tool not found (required)"
    fi
  fi
done
echo ""

# Summary
echo "=== Preflight Check Summary ==="
echo -e "${GREEN}Passed:${NC} $PASS"
if [ $WARN -gt 0 ]; then
  echo -e "${YELLOW}Warnings:${NC} $WARN"
fi
if [ $FAIL -gt 0 ]; then
  echo -e "${RED}Failed:${NC} $FAIL"
fi
echo ""

if [ $FAIL -gt 0 ]; then
  echo -e "${RED}✗ PREFLIGHT CHECK FAILED${NC}"
  echo "Fix the failed checks above before proceeding with installation."
  exit 1
elif [ $WARN -gt 0 ]; then
  echo -e "${YELLOW}⚠ PREFLIGHT CHECK PASSED WITH WARNINGS${NC}"
  echo "Review warnings above. You may proceed with installation."
  exit 0
else
  echo -e "${GREEN}✓ PREFLIGHT CHECK PASSED${NC}"
  echo "All prerequisites are met. You can proceed with installation."
  exit 0
fi
