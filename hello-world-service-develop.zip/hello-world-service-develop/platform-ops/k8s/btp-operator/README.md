# SAP BTP Service Operator - Quick Install and Verification

Use this guide to install the operator with the manifests in this folder and verify it is working correctly.

This guide covers the **cluster-level operator setup** only.

After the operator is installed:
- prepare each target namespace using `platform-ops/k8s/xsuaa/README.md`
- provision each app's XSUAA once using `platform-ops/k8s/xsuaa/README.md`
- then run the Kyma pipeline
- Helm will deploy the app and mount the pre-created binding secret during deployment

Important:
- if an app uses XSUAA, then deploying that app's XSUAA `ServiceInstance` and `ServiceBinding` is a **distinct mandatory prerequisite procedure**
- this must complete successfully before the app deployment pipeline is allowed to use XSUAA resources
- these requirements apply to **deployable** pipeline runs only; PR build/test workflows that do not deploy do not require BTP operator or XSUAA setup

## Prerequisites

- `kubectl` connected to the target cluster
- `cert-manager` installed and healthy
- BTP Service Manager service key values (`clientid`, `clientsecret`, `sm_url`, `url`)
- `jq` installed (used by `copy-credentials.sh`)

Important:
- If your cluster has Kyma BTP Operator module (`app.kubernetes.io/managed-by: btp-manager`), disable/uninstall that module first.
- Kyma-managed resources are reconciled automatically and can recreate CRDs/webhooks while you install manually.

## Fresh reset (from previous attempts)

Run this once before reinstalling:

```bash
kubectl delete servicebindings.services.cloud.sap.com --all --all-namespaces --ignore-not-found
kubectl delete serviceinstances.services.cloud.sap.com --all --all-namespaces --ignore-not-found
kubectl delete validatingwebhookconfiguration sap-btp-operator-validating-webhook-configuration --ignore-not-found
kubectl delete clusterrolebinding sap-btp-operator --ignore-not-found
kubectl delete clusterrole sap-btp-operator --ignore-not-found
kubectl delete crd serviceinstances.services.cloud.sap.com servicebindings.services.cloud.sap.com --ignore-not-found
kubectl delete namespace btp-operator-test --ignore-not-found
kubectl delete namespace sap-btp-operator --ignore-not-found
```

Confirm clean state before install:

```bash
kubectl get ns sap-btp-operator btp-operator-test
kubectl get crd serviceinstances.services.cloud.sap.com servicebindings.services.cloud.sap.com
kubectl get clusterrole sap-btp-operator
kubectl get clusterrolebinding sap-btp-operator
kubectl get validatingwebhookconfiguration sap-btp-operator-validating-webhook-configuration -o yaml
```

Expected:
- `NotFound` for namespaces/CRDs/cluster RBAC is OK (clean)
- If webhook still exists with labels `app.kubernetes.io/managed-by: btp-manager` and service namespace `kyma-system`, Kyma is still managing it; stop and disable that module first.

## Install (ordered)

Run these steps in order.

### 1) Check cluster prerequisites

```bash
kubectl config current-context
kubectl get ns cert-manager
kubectl get deploy -n cert-manager cert-manager cert-manager-webhook
```

### 2) Create operator credentials secret

```bash
cp platform-ops/k8s/btp-operator/1-operator-secret.template.yaml platform-ops/k8s/btp-operator/1-operator-secret.yaml
vi platform-ops/k8s/btp-operator/1-operator-secret.yaml
kubectl apply -f platform-ops/k8s/btp-operator/1-operator-secret.yaml
kubectl get secret -n sap-btp-operator sap-btp-service-operator-credentials -o jsonpath='{.data}' | jq 'keys'
```

Expected keys:
- `clientid`
- `clientsecret`
- `sm_url`
- `tokenurl`

### 3) Install CRDs and RBAC

```bash
kubectl apply -f platform-ops/k8s/btp-operator/2-crds.yaml
kubectl apply -f platform-ops/k8s/btp-operator/3-rbac.yaml
kubectl get crd | grep services.cloud.sap.com
kubectl get clusterrole sap-btp-operator
kubectl get clusterrolebinding sap-btp-operator
```

### 4) Install certs, operator deployment, then webhook config

```bash
kubectl apply -f platform-ops/k8s/btp-operator/5a-webhook-certificates.yaml
kubectl wait --for=condition=ready --timeout=120s certificate/webhook-server-cert -n sap-btp-operator
kubectl apply -f platform-ops/k8s/btp-operator/4-operator-deployment.yaml
kubectl wait --for=condition=ready --timeout=300s pod -l app=sap-btp-operator -n sap-btp-operator
kubectl apply -f platform-ops/k8s/btp-operator/5b-webhook-configuration.yaml
```

### 5) Enable each application namespace

For each namespace where you will create `ServiceInstance` or `ServiceBinding`:

```bash
./platform-ops/k8s/btp-operator/copy-credentials.sh <namespace>
kubectl label namespace <namespace> btp-operator=enabled --overwrite
kubectl get secret sap-btp-service-operator -n <namespace>
kubectl get namespace <namespace> -o jsonpath='{.metadata.labels.btp-operator}'
```

This namespace preparation is the required precondition before the **first** Kyma pipeline run for that namespace.
You do not need to reinstall the operator for each app.

## Verification (operator works correctly)

### A) Operator health

```bash
kubectl get pods -n sap-btp-operator
kubectl logs -n sap-btp-operator -l app=sap-btp-operator -c manager --tail=100
```

Pass criteria:
- two operator pods are `2/2 Running`
- logs do not show recurring credentials/RBAC/cache-sync errors

### B) Webhook readiness

```bash
kubectl get certificate -n sap-btp-operator webhook-server-cert
kubectl get validatingwebhookconfiguration sap-btp-operator-validating-webhook-configuration -o jsonpath='{.webhooks[*].clientConfig.caBundle}'
```

Pass criteria:
- certificate is Ready
- `caBundle` is non-empty

### C) Functional provisioning test

This step validates operator communication with BTP Service Manager backend. **Failure here is NOT an operator issue** — it's a BTP credentials or connectivity problem.

This is a manual verification step for the operator itself.
In normal app deployment flow, the Kyma pipeline uses Helm to create the app-specific `ServiceInstance` and `ServiceBinding` after the namespace is prepared.

```bash
./platform-ops/k8s/btp-operator/copy-credentials.sh btp-operator-test
kubectl apply -f platform-ops/k8s/btp-operator/test-serviceinstance.yaml
kubectl apply -f platform-ops/k8s/btp-operator/test-servicebinding.yaml
kubectl get serviceinstance test-xsuaa -n btp-operator-test
kubectl get servicebinding test-xsuaa-binding -n btp-operator-test
kubectl get secret test-xsuaa-binding -n btp-operator-test
```

Pass criteria:
- ServiceInstance shows `STATUS=Created` with `READY=True`
- ServiceBinding shows `STATUS=Created` with `READY=True`
- Secret `test-xsuaa-binding` exists in the namespace with 23 data keys

**Critical:** `ServiceInstance` and `ServiceBinding` MUST include `externalName` field in spec. Without it, BTP returns "missing service instance name" error.

```yaml
spec:
  serviceOfferingName: xsuaa
  servicePlanName: application
  externalName: test-xsuaa  # REQUIRED
  parameters: ...
```

Failure symptoms & causes:
- `STATUS=CreateFailed` with message containing `error parsing response body ... invalid character '<'`
  - **Cause:** `tokenurl` missing `/oauth/token` path OR BTP credentials (`clientid`, `clientsecret`) are wrong
  - **Fix:** 
    1. Verify `tokenurl` ends with `/oauth/token` (e.g., `https://..../oauth/token`)
    2. Verify `clientsecret` matches exactly (character-by-character) with BTP Service Manager key JSON
    3. Update `platform-ops/k8s/btp-operator/1-operator-secret.yaml` and reapply:
       ```bash
       kubectl apply -f k8s/btp-operator/1-operator-secret.yaml
       kubectl rollout restart deployment/sap-btp-operator-controller-manager -n sap-btp-operator
       ```
- `STATUS=CreateFailed` with message `"invalid_client" "Bad credentials"`
  - **Cause:** `clientsecret` character typo (common: confusing 'a' with 'q', 'l' with '1')
  - **Fix:** Compare BTP JSON with YAML character-by-character, fix typo, reapply secret and restart operator
- `STATUS=CreateFailed` with message `missing service instance name`
  - **Cause:** Missing `externalName` field in ServiceInstance or ServiceBinding spec
  - **Fix:** Add `externalName` field (value can be same as resource name) and reapply
- `STATUS=Blocked` on ServiceBinding
  - **Cause:** Parent ServiceInstance is not Ready
  - **Fix:** First resolve ServiceInstance status

## Fast troubleshooting

### Missing credentials secret in target namespace

```bash
./k8s/btp-operator/copy-credentials.sh <namespace>
kubectl get secret sap-btp-service-operator -n <namespace>
```

### RBAC/cache-sync issues in operator logs

```bash
kubectl apply -f k8s/btp-operator/3-rbac.yaml
kubectl rollout restart deployment/sap-btp-operator-controller-manager -n sap-btp-operator
```

### Webhook TLS issues (`caBundle` empty)

```bash
kubectl delete validatingwebhookconfiguration sap-btp-operator-validating-webhook-configuration
kubectl apply -f k8s/btp-operator/5b-webhook-configuration.yaml
```

## Optional (dev/test only)

If you need temporary cluster-admin for troubleshooting:

```bash
vi k8s/btp-operator/cluster-admin-rbac.yaml
kubectl apply -f k8s/btp-operator/cluster-admin-rbac.yaml
```

Replace `REPLACE_WITH_USER_PRINCIPAL` before apply. Do not use this in production.
