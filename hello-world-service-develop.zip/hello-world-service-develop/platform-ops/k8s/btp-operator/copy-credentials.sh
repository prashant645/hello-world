#!/usr/bin/env bash
# Fix BTP Operator - Copy credentials secret with correct name to application namespace
#
# The operator looks for secret named "sap-btp-service-operator" (not "sap-btp-service-operator-credentials")
# in the SAME namespace as the ServiceInstance.
#
# This script copies the credentials from operator namespace to application namespace with the correct name.

set -euo pipefail

if [ $# -lt 1 ]; then
  echo "Usage: $0 <namespace>"
  echo ""
  echo "Example: $0 hello-world"
  echo ""
  echo "This copies BTP credentials from sap-btp-operator namespace to the specified namespace"
  echo "with the name the operator expects (sap-btp-service-operator)"
  exit 1
fi

NAMESPACE=$1
SOURCE_SECRET="sap-btp-service-operator-credentials"
TARGET_SECRET="sap-btp-service-operator"

echo "Copying BTP credentials to namespace: ${NAMESPACE}"

# Create namespace if it doesn't exist
kubectl create namespace ${NAMESPACE} --dry-run=client -o yaml | kubectl apply -f -

# Get the secret from operator namespace
kubectl get secret ${SOURCE_SECRET} -n sap-btp-operator -o json \
  | jq --arg name "${TARGET_SECRET}" --arg ns "${NAMESPACE}" '
    .metadata.name = $name |
    .metadata.namespace = $ns |
    del(.metadata.resourceVersion, .metadata.uid, .metadata.creationTimestamp, .metadata.managedFields)
  ' \
  | kubectl apply -f -

echo "✓ Secret ${TARGET_SECRET} created in namespace ${NAMESPACE}"

# Verify
echo ""
echo "Verification:"
kubectl get secret ${TARGET_SECRET} -n ${NAMESPACE}
