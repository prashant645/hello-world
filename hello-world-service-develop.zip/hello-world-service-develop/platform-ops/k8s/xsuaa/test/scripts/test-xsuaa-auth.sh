#!/usr/bin/env bash
set -euo pipefail

# Smoke-test XSUAA-protected endpoints using client_credentials from the binding secret.
# By default this script auto-discovers the app URL:
# 1) APIRule host -> HTTPS FQDN
# 2) Service LoadBalancer IP -> HTTP
# 3) localhost:8080 fallback (for port-forward)

NAMESPACE="${NAMESPACE:-}"
SERVICE_INSTANCE="${SERVICE_INSTANCE:-}"
BINDING_SECRET="${BINDING_SECRET:-}"
APP_URL="${APP_URL:-}"
AUTO_PORT_FORWARD="false"
SERVICE_NAME="${SERVICE_NAME:-hello-world-service}"
APIRULE_NAME="${APIRULE_NAME:-hello-world-service}"
KYMA_DOMAIN="${KYMA_DOMAIN:-}"
READ_PATH="${READ_PATH:-/api/v1/greetings}"
WRITE_PATH="${WRITE_PATH:-/api/v1/greetings/update}"
STRICT_SCOPES="${STRICT_SCOPES:-false}"
REQUIRE_HTTPS="${REQUIRE_HTTPS:-false}"
REQUIRE_APIRULE="${REQUIRE_APIRULE:-false}"
APP_URL_SOURCE=""

usage() {
  cat <<'EOF'
Usage: test-xsuaa-auth.sh [options]

Options:
  -n, --namespace <ns>            Kubernetes namespace (required unless NAMESPACE is set)
  -i, --service-instance <name>   ServiceInstance name (default: hello-world-xsuaa-<namespace>)
  -b, --binding-secret <name>     Binding secret name (default: hello-world-xsuaa-binding-<namespace>)
  -u, --app-url <url>             App base URL (auto-discovered when omitted)
  -s, --service-name <name>       K8s service for auto port-forward (default: hello-world-service)
      --apirule-name <name>       APIRule name for HTTPS discovery (default: hello-world-service)
      --kyma-domain <domain>      Cluster domain if APIRule host is short (optional)
      --port-forward              Start kubectl port-forward for service/<service-name> to localhost:8080
      --read-path <path>          Read endpoint path (default: /api/v1/greetings)
      --write-path <path>         Write endpoint path (default: /api/v1/greetings/update)
  -h, --help                      Show this help
      --strict-scopes             Fail if app scopes are not present in token
          --require-https            Fail unless the discovered/provided app URL uses HTTPS
          --require-apirule          Fail unless the app URL was discovered from an APIRule

Examples:
  bash platform-ops/k8s/xsuaa/test/scripts/test-xsuaa-auth.sh -n dev
  bash platform-ops/k8s/xsuaa/test/scripts/test-xsuaa-auth.sh -n qa --port-forward
  NAMESPACE=dev bash platform-ops/k8s/xsuaa/test/scripts/test-xsuaa-auth.sh
EOF
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    -n|--namespace)
      NAMESPACE="$2"; shift 2 ;;
    -i|--service-instance)
      SERVICE_INSTANCE="$2"; shift 2 ;;
    -b|--binding-secret)
      BINDING_SECRET="$2"; shift 2 ;;
    -u|--app-url)
      APP_URL="$2"; shift 2 ;;
    -s|--service-name)
      SERVICE_NAME="$2"; shift 2 ;;
    --apirule-name)
      APIRULE_NAME="$2"; shift 2 ;;
    --kyma-domain)
      KYMA_DOMAIN="$2"; shift 2 ;;
    --port-forward)
      AUTO_PORT_FORWARD="true"; shift ;;
    --read-path)
      READ_PATH="$2"; shift 2 ;;
    --write-path)
      WRITE_PATH="$2"; shift 2 ;;
    --strict-scopes)
      STRICT_SCOPES="true"; shift ;;
    --require-https)
      REQUIRE_HTTPS="true"; shift ;;
    --require-apirule)
      REQUIRE_APIRULE="true"; shift ;;
    -h|--help)
      usage; exit 0 ;;
    *)
      echo "Unknown option: $1" >&2
      usage
      exit 1 ;;
  esac
done

if [[ -z "$NAMESPACE" ]]; then
  echo "Missing required namespace. Use -n <namespace> or set NAMESPACE." >&2
  usage
  exit 1
fi

if [[ -z "$SERVICE_INSTANCE" ]]; then
  SERVICE_INSTANCE="hello-world-xsuaa-${NAMESPACE}"
fi

if [[ -z "$BINDING_SECRET" ]]; then
  BINDING_SECRET="hello-world-xsuaa-binding-${NAMESPACE}"
fi

require_cmd() {
  command -v "$1" >/dev/null 2>&1 || { echo "Missing command: $1" >&2; exit 1; }
}

require_cmd kubectl
require_cmd curl
require_cmd jq
require_cmd python3

discover_gateway_domain() {
  local gateway_host
  gateway_host="$(kubectl -n kyma-system get gateway kyma-gateway -o jsonpath='{.spec.servers[0].hosts[0]}' 2>/dev/null || true)"
  if [[ -z "$gateway_host" ]]; then
    return 1
  fi

  gateway_host="${gateway_host#*.}"
  [[ -n "$gateway_host" ]] || return 1
  printf '%s' "$gateway_host"
}

discover_app_url() {
  local apirule_host
  local fqdn
  local lb_ip

  fqdn=""

  if [[ -n "$APP_URL" ]]; then
    return 0
  fi

  apirule_host="$(kubectl -n "$NAMESPACE" get apirule "$APIRULE_NAME" -o jsonpath='{.spec.hosts[0]}' 2>/dev/null || true)"
  if [[ -z "$apirule_host" ]]; then
    apirule_host="$(kubectl -n "$NAMESPACE" get apirule "$APIRULE_NAME" -o jsonpath='{.spec.host}' 2>/dev/null || true)"
  fi
  if [[ -n "$apirule_host" ]]; then
    if [[ "$apirule_host" == *.* ]]; then
      fqdn="$apirule_host"
    else
      if [[ -z "$KYMA_DOMAIN" ]]; then
        KYMA_DOMAIN="$(discover_gateway_domain || true)"
      fi
      if [[ -n "$KYMA_DOMAIN" ]]; then
        fqdn="${apirule_host}.${KYMA_DOMAIN}"
      fi
    fi

    if [[ -n "$fqdn" ]]; then
      APP_URL="https://${fqdn}"
      APP_URL_SOURCE="apirule"
      return 0
    fi
  fi

  lb_ip="$(kubectl -n "$NAMESPACE" get svc "$SERVICE_NAME" -o jsonpath='{.status.loadBalancer.ingress[0].ip}' 2>/dev/null || true)"
  if [[ -n "$lb_ip" ]]; then
    APP_URL="http://${lb_ip}:8080"
    APP_URL_SOURCE="loadbalancer"
    return 0
  fi

  APP_URL="http://localhost:8080"
  APP_URL_SOURCE="localhost"
}

request_token() {
  local scope="$1"
  local payload="grant_type=client_credentials&client_id=${CLIENT_ID}&client_secret=${CLIENT_SECRET}"
  if [[ -n "$scope" ]]; then
    payload+="&scope=${scope}"
  fi

  curl -sS -X POST "${XSUAA_URL}/oauth/token" \
    -H "Content-Type: application/x-www-form-urlencoded" \
    -d "$payload"
}

cleanup() {
  if [[ -n "${PF_PID:-}" ]]; then
    kill "$PF_PID" >/dev/null 2>&1 || true
    wait "$PF_PID" 2>/dev/null || true
  fi
}
trap cleanup EXIT

if [[ "$AUTO_PORT_FORWARD" == "true" ]]; then
  echo "Starting port-forward: service/${SERVICE_NAME} in namespace ${NAMESPACE} -> localhost:8080"
  kubectl -n "$NAMESPACE" port-forward "service/${SERVICE_NAME}" 8080:8080 >/tmp/test-xsuaa-port-forward.log 2>&1 &
  PF_PID=$!
  sleep 2
fi

discover_app_url
echo "Using app URL: ${APP_URL}"

if [[ "$REQUIRE_APIRULE" == "true" && "$APP_URL_SOURCE" != "apirule" ]]; then
  echo "Expected APIRule-based URL discovery, but resolved source was '${APP_URL_SOURCE}'" >&2
  exit 1
fi

if [[ "$REQUIRE_HTTPS" == "true" && "$APP_URL" != https://* ]]; then
  echo "Expected HTTPS app URL, but resolved '${APP_URL}'" >&2
  exit 1
fi

echo "Reading XSUAA wiring from namespace '${NAMESPACE}'"
XSAPPNAME="$(kubectl -n "$NAMESPACE" get serviceinstance "$SERVICE_INSTANCE" -o jsonpath='{.spec.parameters.xsappname}')"
XSUAA_URL="$(kubectl -n "$NAMESPACE" get secret "$BINDING_SECRET" -o jsonpath='{.data.url}' | base64 -d)"
CLIENT_ID="$(kubectl -n "$NAMESPACE" get secret "$BINDING_SECRET" -o jsonpath='{.data.clientid}' | base64 -d)"
CLIENT_SECRET="$(kubectl -n "$NAMESPACE" get secret "$BINDING_SECRET" -o jsonpath='{.data.clientsecret}' | base64 -d)"

[[ -n "$XSAPPNAME" ]] || { echo "xsappname not found" >&2; exit 1; }
[[ -n "$XSUAA_URL" ]] || { echo "XSUAA URL missing" >&2; exit 1; }
[[ -n "$CLIENT_ID" ]] || { echo "clientid missing" >&2; exit 1; }
[[ -n "$CLIENT_SECRET" ]] || { echo "clientsecret missing" >&2; exit 1; }

SCOPE_READ="${XSAPPNAME}.Read"
SCOPE_WRITE="${XSAPPNAME}.Write"

echo "Requesting read token with scope: ${SCOPE_READ}"
READ_TOKEN_RESPONSE="$(request_token "${SCOPE_READ}")"
TOKEN_READ="$(printf '%s' "$READ_TOKEN_RESPONSE" | jq -r '.access_token // empty')"

if [[ -z "$TOKEN_READ" || "$TOKEN_READ" == "null" ]]; then
  if [[ "$STRICT_SCOPES" == "true" ]]; then
    echo "[INFO] Scoped read token request was rejected; retrying with default client_credentials token and validating tenant-qualified scopes afterwards"
  else
    echo "[WARN] Scoped read token unavailable; falling back to unscoped token for authentication-only checks"
  fi
  TOKEN_READ_RESPONSE_FALLBACK="$(request_token "")"
  TOKEN_READ="$(printf '%s' "$TOKEN_READ_RESPONSE_FALLBACK" | jq -r '.access_token // empty')"
  [[ -n "$TOKEN_READ" && "$TOKEN_READ" != "null" ]] || {
    echo "Failed to obtain fallback read token" >&2
    echo "OAuth response: $TOKEN_READ_RESPONSE_FALLBACK" >&2
    exit 1
  }
fi

echo "Requesting write token with scopes: ${SCOPE_READ} ${SCOPE_WRITE}"
WRITE_TOKEN_RESPONSE="$(request_token "${SCOPE_READ} ${SCOPE_WRITE}")"
TOKEN_WRITE="$(printf '%s' "$WRITE_TOKEN_RESPONSE" | jq -r '.access_token // empty')"

if [[ -z "$TOKEN_WRITE" || "$TOKEN_WRITE" == "null" ]]; then
  if [[ "$STRICT_SCOPES" == "true" ]]; then
    echo "[INFO] Scoped write token request was rejected; retrying with default client_credentials token and validating tenant-qualified scopes afterwards"
  else
    echo "[WARN] Scoped write token unavailable; falling back to unscoped token for authentication-only checks"
  fi
  TOKEN_WRITE_RESPONSE_FALLBACK="$(request_token "")"
  TOKEN_WRITE="$(printf '%s' "$TOKEN_WRITE_RESPONSE_FALLBACK" | jq -r '.access_token // empty')"
  [[ -n "$TOKEN_WRITE" && "$TOKEN_WRITE" != "null" ]] || {
    echo "Failed to obtain fallback write token" >&2
    echo "OAuth response: $TOKEN_WRITE_RESPONSE_FALLBACK" >&2
    exit 1
  }
fi

show_token_scopes() {
  local token="$1"
  TOKEN_VALUE="$token" python3 - <<'PY'
import base64
import json
import os

t = os.environ["TOKEN_VALUE"].split(".")[1]
t += "=" * (-len(t) % 4)
payload = json.loads(base64.urlsafe_b64decode(t.encode()).decode())
print(payload.get("scope", []))
PY
}

token_has_scope() {
  local token="$1"
  local expected_scope="$2"
  TOKEN_VALUE="$token" EXPECTED_SCOPE="$expected_scope" python3 - <<'PY'
import base64
import json
import os
import re
import sys

t = os.environ["TOKEN_VALUE"].split(".")[1]
t += "=" * (-len(t) % 4)
payload = json.loads(base64.urlsafe_b64decode(t.encode()).decode())
scopes = payload.get("scope", [])
if isinstance(scopes, str):
    scopes = scopes.split()
expected = os.environ["EXPECTED_SCOPE"]

def matches(scope: str, wanted: str) -> bool:
    if scope == wanted:
        return True
    if "." not in wanted:
        return False
    prefix, suffix = wanted.rsplit(".", 1)
    pattern = rf"^{re.escape(prefix)}![^.]+\.{re.escape(suffix)}$"
    return re.fullmatch(pattern, scope) is not None

sys.exit(0 if any(matches(scope, expected) for scope in scopes) else 1)
PY
}

echo "Token read scopes: $(show_token_scopes "$TOKEN_READ")"
echo "Token write scopes: $(show_token_scopes "$TOKEN_WRITE")"

read_scope_present="false"
write_scope_present="false"
if token_has_scope "$TOKEN_READ" "$SCOPE_READ"; then
  read_scope_present="true"
fi
if token_has_scope "$TOKEN_WRITE" "$SCOPE_WRITE"; then
  write_scope_present="true"
fi

if [[ "$read_scope_present" != "true" || "$write_scope_present" != "true" ]]; then
  echo "[WARN] Token does not include expected app scopes (${SCOPE_READ}, ${SCOPE_WRITE})."
  echo "[WARN] Continuing with authentication-only validation. Use --strict-scopes to fail here."
  if [[ "$STRICT_SCOPES" == "true" ]]; then
    echo "Strict scope mode enabled and required scopes are missing." >&2
    exit 1
  fi
fi

read_status="$(curl -sS -o /tmp/test-xsuaa-read-body.json -w "%{http_code}" -X POST "${APP_URL}${READ_PATH}" \
  -H "Authorization: Bearer ${TOKEN_READ}" \
  -H "Content-Type: application/json" \
  -d '{"message":"xsuaa read check"}')"

echo "Read endpoint status: ${read_status}"
cat /tmp/test-xsuaa-read-body.json || true
echo
if [[ "$read_scope_present" == "true" ]]; then
  if [[ "$read_status" != "200" && "$read_status" != "429" ]]; then
    echo "Read endpoint expected HTTP 200 or 429 with scope ${SCOPE_READ}" >&2
    exit 1
  fi
else
  if [[ "$read_status" != "200" && "$read_status" != "403" && "$read_status" != "429" ]]; then
    echo "Read endpoint expected HTTP 200, 403, or 429 during authentication-only validation" >&2
    exit 1
  fi
fi

write_status="$(curl -sS -o /tmp/test-xsuaa-write-body.json -w "%{http_code}" -X POST "${APP_URL}${WRITE_PATH}" \
  -H "Authorization: Bearer ${TOKEN_WRITE}" \
  -H "Content-Type: application/json" \
  -d '{"rateLimit":{"requestsPerMinute":20}}')"

echo "Write endpoint status: ${write_status}"
cat /tmp/test-xsuaa-write-body.json || true
echo
if [[ "$write_scope_present" == "true" ]]; then
  if [[ "$write_status" != "200" && "$write_status" != "429" ]]; then
    echo "Write endpoint expected HTTP 200 or 429 with scope ${SCOPE_WRITE}" >&2
    exit 1
  fi
else
  if [[ "$write_status" != "200" && "$write_status" != "403" && "$write_status" != "429" ]]; then
    echo "Write endpoint expected HTTP 200, 403, or 429 during authentication-only validation" >&2
    exit 1
  fi
fi

no_token_status="$(curl -sS -o /tmp/test-xsuaa-no-token-body.json -w "%{http_code}" -X POST "${APP_URL}${READ_PATH}" \
  -H "Content-Type: application/json" \
  -d '{"message":"no token"}')"

echo "No-token endpoint status: ${no_token_status}"
cat /tmp/test-xsuaa-no-token-body.json || true
echo
if [[ "$no_token_status" != "401" && "$no_token_status" != "403" ]]; then
  echo "No-token call expected HTTP 401 or 403" >&2
  exit 1
fi

echo "[OK] XSUAA auth smoke test passed"




