#!/usr/bin/env bash
set -euo pipefail

# Proves the application allows properly scoped users to read and write.
# This runs the existing Spring Security test suite for the XSUAA-protected endpoints.

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
if REPO_ROOT="$(git -C "$SCRIPT_DIR" rev-parse --show-toplevel 2>/dev/null)"; then
  :
else
  REPO_ROOT="$(cd "$SCRIPT_DIR/../../../../.." && pwd)"
fi

cd "$REPO_ROOT"

echo "Running scoped-user authorization tests"
./gradlew test --tests com.sap.gtlc.security.security.XsuaaSecurityTest --no-daemon

echo "[OK] Scoped-user authorization success path verified"



