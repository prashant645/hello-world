# XSUAA Test Guide

Use this guide to test XSUAA behavior for `hello-world-service` after the backend is already deployed.

This guide separates three concerns:

1. deployed auth enforcement
2. properly scoped success-path proof
3. client-credentials caller enablement and verification

## Prerequisites

- `hello-world-service` is already deployed in namespace `dev`
- `ServiceInstance/hello-world-xsuaa-dev` exists and is `Ready`
- `ServiceBinding/hello-world-xsuaa-binding-dev` exists and its secret exists
- `kubectl` points to the correct cluster/context
- local tools available:
  - `kubectl`
  - `curl`
  - `jq`
  - `python3`

Quick checks:

```bash
kubectl -n dev get deploy hello-world-service
kubectl -n dev get serviceinstance hello-world-xsuaa-dev
kubectl -n dev get servicebinding hello-world-xsuaa-binding-dev
kubectl -n dev get secret hello-world-xsuaa-binding-dev
```

## Test 1: deployed auth enforcement test

Purpose:
- proves the deployed backend is protected by XSUAA
- proves unauthenticated requests are rejected
- proves insufficiently scoped tokens are rejected

Run:

```bash
bash platform-ops/k8s/xsuaa/test/scripts/test-xsuaa-auth.sh -n dev --port-forward
```

Pass criteria:
- script ends with `[OK] XSUAA auth smoke test passed`
- no-token call returns `401` or `403`
- tokened requests may return `200`, `403`, or `429` depending on token scopes and runtime rate limiting

What this proves:
- token retrieval works
- the deployed app validates bearer tokens
- the deployed app enforces authorization on protected endpoints

What this does **not** prove:
- that the tested client can obtain `hello-world-service-dev.Read`
- that the tested client can obtain `hello-world-service-dev.Write`
- that a fully authorized principal can successfully perform read/write end-to-end

## Test 2: properly scoped success-path proof

Purpose:
- proves the application allows a properly scoped principal to read and write
- proves the controller authorization rules are correct

Run:

```bash
bash platform-ops/k8s/xsuaa/test/scripts/test-scoped-user-local.sh
```

Pass criteria:
- Gradle ends with `BUILD SUCCESSFUL`
- the `XsuaaSecurityTest` suite passes

What the underlying test proves:
- `Read` authority -> `POST /api/v1/greetings` returns `200`
- `Write` authority -> `POST /api/v1/greetings/update` returns `200`
- `Read` only -> `POST /api/v1/greetings/update` returns `403`

Important:
- this is the supported proof that a correctly scoped principal **can** read and write
- this is a local application-level success-path proof, not a live end-user browser flow

## Optional diagnostic: strict client-scope test

Use this only when you want to check whether the currently bound client can directly request app scopes.

Run:

```bash
bash platform-ops/k8s/xsuaa/test/scripts/test-xsuaa-auth.sh -n dev --port-forward --strict-scopes
```

Interpretation:
- pass -> current client can request app scopes and the deployed app should allow authorized calls
- fail with `invalid_scope` and token scope only `uaa.resource` -> deployment can still be healthy; this only means that specific client is not granted app scopes

## Service-to-service test through port-forward

Port-forward does **not** bypass authentication.
It only gives the caller a local network path to the already deployed backend.

The caller still must:
1. have an XSUAA client identity
2. have `clientid` / `clientsecret`
3. exchange those credentials for a token
4. receive the required app scopes in the token
5. call the API with that bearer token

### Port-forward the service

```bash
kubectl -n dev port-forward svc/hello-world-service 8080:8080
```

Keep that terminal open.

### Extract credentials from the current binding secret

```bash
XSUAA_URL="$(kubectl -n dev get secret hello-world-xsuaa-binding-dev -o jsonpath='{.data.url}' | base64 -d)"
CLIENT_ID="$(kubectl -n dev get secret hello-world-xsuaa-binding-dev -o jsonpath='{.data.clientid}' | base64 -d)"
CLIENT_SECRET="$(kubectl -n dev get secret hello-world-xsuaa-binding-dev -o jsonpath='{.data.clientsecret}' | base64 -d)"
XSAPPNAME="$(kubectl -n dev get serviceinstance hello-world-xsuaa-dev -o jsonpath='{.spec.parameters.xsappname}')"
```

### Request a token

Unscoped token:

```bash
TOKEN="$(curl -sS -X POST "${XSUAA_URL}/oauth/token" \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -d "grant_type=client_credentials" \
  -d "client_id=${CLIENT_ID}" \
  -d "client_secret=${CLIENT_SECRET}" | jq -r '.access_token')"
```

Scoped token request:

```bash
SCOPED_TOKEN="$(curl -sS -X POST "${XSUAA_URL}/oauth/token" \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -d "grant_type=client_credentials" \
  -d "client_id=${CLIENT_ID}" \
  -d "client_secret=${CLIENT_SECRET}" \
  -d "scope=${XSAPPNAME}.Read ${XSAPPNAME}.Write" | jq -r '.access_token // empty')"
```

### Inspect scopes in the token

```bash
TOKEN_VALUE="$TOKEN" python3 - <<'PY'
import base64, json, os
payload = os.environ["TOKEN_VALUE"].split(".")[1]
payload += "=" * (-len(payload) % 4)
print(json.dumps(json.loads(base64.urlsafe_b64decode(payload.encode()).decode()), indent=2))
PY
```

### Call the API through localhost

No token:

```bash
curl -i -X POST "http://localhost:8080/api/v1/greetings" \
  -H "Content-Type: application/json" \
  -d '{"message":"no token"}'
```

With token:

```bash
curl -i -X POST "http://localhost:8080/api/v1/greetings" \
  -H "Authorization: Bearer ${TOKEN}" \
  -H "Content-Type: application/json" \
  -d '{"message":"service-to-service test"}'
```

Write endpoint:

```bash
curl -i -X POST "http://localhost:8080/api/v1/greetings/update" \
  -H "Authorization: Bearer ${TOKEN}" \
  -H "Content-Type: application/json" \
  -d '{"rateLimit":{"requestsPerMinute":20}}'
```

Interpretation with the current default binding:
- `401` or `403` without token -> expected
- `403` with token -> authenticated but not authorized for app scope
- `429` -> rate limiting triggered
- `200` -> authorized success path

## Enable a new client-credentials caller

Use this when you want a **new** service-to-service caller identity for the already deployed backend.

This is additive:
- does not change the running app deployment
- does not replace `hello-world-xsuaa-binding-dev`
- creates a new client identity and new secret

### Step 1: confirm the app scope prefix

```bash
kubectl -n dev get serviceinstance hello-world-xsuaa-dev -o jsonpath='{.spec.parameters.xsappname}'; echo
```

Expected:

```text
hello-world-service-dev
```

Effective app scopes:
- `hello-world-service-dev.Read`
- `hello-world-service-dev.Write`

### Step 2: create a new Read/Write caller binding

```bash
CLIENT_BINDING_NAME="hello-world-xsuaa-client-rw-dev"
CLIENT_SECRET_NAME="hello-world-xsuaa-client-rw-dev"
XSAPPNAME="hello-world-service-dev"

cat <<EOF | kubectl -n dev apply -f -
apiVersion: services.cloud.sap.com/v1
kind: ServiceBinding
metadata:
  name: ${CLIENT_BINDING_NAME}
spec:
  serviceInstanceName: hello-world-xsuaa-dev
  secretName: ${CLIENT_SECRET_NAME}
  externalName: ${CLIENT_BINDING_NAME}
  parameters:
    credential-type: binding-secret
    authorities:
      - "${XSAPPNAME}.Read"
      - "${XSAPPNAME}.Write"
EOF
```

Read-only variant:

```bash
CLIENT_BINDING_NAME="hello-world-xsuaa-client-read-dev"
CLIENT_SECRET_NAME="hello-world-xsuaa-client-read-dev"
XSAPPNAME="hello-world-service-dev"

cat <<EOF | kubectl -n dev apply -f -
apiVersion: services.cloud.sap.com/v1
kind: ServiceBinding
metadata:
  name: ${CLIENT_BINDING_NAME}
spec:
  serviceInstanceName: hello-world-xsuaa-dev
  secretName: ${CLIENT_SECRET_NAME}
  externalName: ${CLIENT_BINDING_NAME}
  parameters:
    credential-type: binding-secret
    authorities:
      - "${XSAPPNAME}.Read"
EOF
```

### Step 3: verify the new binding is ready (without blocking wait)

```bash
kubectl -n dev get servicebinding hello-world-xsuaa-client-rw-dev -o wide
kubectl -n dev get secret hello-world-xsuaa-client-rw-dev
kubectl -n dev describe servicebinding hello-world-xsuaa-client-rw-dev
```

Optional bounded poll (always returns):

```bash
for i in {1..24}; do
  kubectl -n dev get servicebinding hello-world-xsuaa-client-rw-dev \
    -o jsonpath='{.status.ready}{" | "}{.status.conditions[?(@.type=="Ready")].message}{"\n"}'
  sleep 5
done
```

### Step 4: extract the new client credentials

```bash
XSUAA_URL="$(kubectl -n dev get secret hello-world-xsuaa-client-rw-dev -o jsonpath='{.data.url}' | base64 -d)"
CLIENT_ID="$(kubectl -n dev get secret hello-world-xsuaa-client-rw-dev -o jsonpath='{.data.clientid}' | base64 -d)"
CLIENT_SECRET="$(kubectl -n dev get secret hello-world-xsuaa-client-rw-dev -o jsonpath='{.data.clientsecret}' | base64 -d)"
```

### Step 5: request a token (recommended: unscoped first)

Recommended working request:

```bash
RAW="$(curl -sS -X POST "${XSUAA_URL}/oauth/token" \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -d "grant_type=client_credentials" \
  -d "client_id=${CLIENT_ID}" \
  -d "client_secret=${CLIENT_SECRET}")"

echo "${RAW}" | jq .
TOKEN="$(echo "${RAW}" | jq -r '.access_token')"
```

Why this is recommended:
- this landscape issues effective technical-client scopes as suffixed values like `hello-world-service-dev!t381064.Read`
- requesting non-suffixed `hello-world-service-dev.Read` can fail with `invalid_scope`

Optional explicit scoped request (use suffixed scopes from token claims):

```bash
TOKEN_VALUE="$TOKEN" python3 - <<'PY'
import base64, json, os
payload = os.environ["TOKEN_VALUE"].split(".")[1]
payload += "=" * (-len(payload) % 4)
claims = json.loads(base64.urlsafe_b64decode(payload.encode()).decode())
scopes = claims.get("scope", [])
if isinstance(scopes, str):
    scopes = scopes.split()
wanted = [s for s in scopes if s.endswith(".Read") or s.endswith(".Write")]
print(" ".join(wanted))
PY
```

Copy the printed scope string, then:

```bash
TOKEN="$(curl -sS -X POST "${XSUAA_URL}/oauth/token" \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -d "grant_type=client_credentials" \
  -d "client_id=${CLIENT_ID}" \
  -d "client_secret=${CLIENT_SECRET}" \
  -d 'scope=<PASTE_SUFFIXED_SCOPES_HERE>' | jq -r '.access_token')"
```

### Step 6: verify the token contains app scopes

```bash
TOKEN_VALUE="$TOKEN" python3 - <<'PY'
import base64, json, os
payload = os.environ["TOKEN_VALUE"].split(".")[1]
payload += "=" * (-len(payload) % 4)
claims = json.loads(base64.urlsafe_b64decode(payload.encode()).decode())
print(json.dumps({
    "client_id": claims.get("client_id"),
    "scope": claims.get("scope"),
    "authorities": claims.get("authorities")
}, indent=2))
PY
```

Expected scope/authorities include suffix scopes similar to:
- `hello-world-service-dev!t381064.Read`
- `hello-world-service-dev!t381064.Write`

### Step 7: verify read and write against the deployed backend

In one terminal:

```bash
kubectl -n dev port-forward svc/hello-world-service 8080:8080
```

In another terminal:

```bash
curl -i -X POST "http://localhost:8080/api/v1/greetings" \
  -H "Authorization: Bearer ${TOKEN}" \
  -H "Content-Type: application/json" \
  -d '{"message":"hello from new client"}'
```

```bash
curl -i -X POST "http://localhost:8080/api/v1/greetings/update" \
  -H "Authorization: Bearer ${TOKEN}" \
  -H "Content-Type: application/json" \
  -d '{"rateLimit":{"requestsPerMinute":20}}'
```

Expected:
- read endpoint -> `200`
- write endpoint -> `200` (or `429` if you trigger rate limiting after authorization already succeeded)

### Step 8: verify with the helper script

```bash
bash platform-ops/k8s/xsuaa/test/scripts/test-xsuaa-auth.sh \
  -n dev \
  --port-forward \
  --binding-secret hello-world-xsuaa-client-rw-dev
```

Use `--strict-scopes` only if you intentionally validate strict scope request semantics.

## Bruno test flow (same scenario as curl)

Use Bruno when you prefer repeatable request collections over shell commands.

### Prepare test values from Kubernetes

```bash
XSUAA_URL="$(kubectl -n dev get secret hello-world-xsuaa-client-rw-dev -o jsonpath='{.data.url}' | base64 -d)"
CLIENT_ID="$(kubectl -n dev get secret hello-world-xsuaa-client-rw-dev -o jsonpath='{.data.clientid}' | base64 -d)"
CLIENT_SECRET="$(kubectl -n dev get secret hello-world-xsuaa-client-rw-dev -o jsonpath='{.data.clientsecret}' | base64 -d)"
echo "$XSUAA_URL"
echo "$CLIENT_ID"
```

### 1) Start port-forward

```bash
kubectl -n dev port-forward svc/hello-world-service 8080:8080
```

### 2) Create a Bruno collection

In Bruno:
- create collection `hello-world-xsuaa-dev`
- create environment `dev` with variables:
  - `xsuaa_url` = value of `XSUAA_URL`
  - `client_id` = value of `CLIENT_ID`
  - `client_secret` = value of `CLIENT_SECRET`
  - `base_url` = `http://localhost:8080`
  - `token` = empty (will set after request)

### 3) Request token (client credentials)

Create request `01-token`:
- Method: `POST`
- URL: `{{xsuaa_url}}/oauth/token`
- Headers:
  - `Content-Type: application/x-www-form-urlencoded`
- Body (form-urlencoded):
  - `grant_type=client_credentials`
  - `client_id={{client_id}}`
  - `client_secret={{client_secret}}`

Run request and copy `access_token` into environment variable `token`.

### 4) Call Read endpoint

Create request `02-greetings-read`:
- Method: `POST`
- URL: `{{base_url}}/api/v1/greetings`
- Headers:
  - `Authorization: Bearer {{token}}`
  - `Content-Type: application/json`
- Body (JSON):

```json
{"message":"hello from bruno"}
```

Expected: `200`.

### 5) Call Write endpoint

Create request `03-greetings-update`:
- Method: `POST`
- URL: `{{base_url}}/api/v1/greetings/update`
- Headers:
  - `Authorization: Bearer {{token}}`
  - `Content-Type: application/json`
- Body (JSON):

```json
{"rateLimit":{"requestsPerMinute":20}}
```

Expected:
- `200` (authorized + update applied), or
- `429` (authorized but rate limit filter triggered)

### 6) Negative checks in Bruno

- Clone `02-greetings-read`, remove `Authorization` header -> expect `401`
- Clone `03-greetings-update`, remove `Authorization` header -> expect `401`

This proves token enforcement remains active while technical-client authorization works.

## Do you need Cockpit role assignment?

For `client_credentials`: **no**.

You do not need to assign your user to a role collection in BTP Cockpit for service-to-service client testing.

Role collections are relevant for:
- browser login
- user-token flows
- Authorization Code flows

For service-to-service callers, the control points are:
- app scopes defined in the `ServiceInstance`
- client authorities defined in the new `ServiceBinding`
- client credentials issued in the new binding secret


