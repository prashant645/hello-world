#!/usr/bin/env bash
set -euo pipefail

# Force-cleanup helper for orphaned BTP service instances/bindings in Service Manager.
# Use only when cockpit actions are unavailable or Kubernetes owners are already gone.

SECRET_NAMESPACE="${SECRET_NAMESPACE:-sap-btp-operator}"
SECRET_NAME="${SECRET_NAME:-sap-btp-service-operator-credentials}"
NAME_PATTERN=""
DELETE_MODE="false"
INSECURE_TLS="true"

usage() {
  cat <<'EOF'
Usage:
  cleanup-service-manager-instances.sh --name-pattern <regex> [--delete] [--secure-tls]

Options:
  --name-pattern <regex>  Python regex matched against ServiceInstance and ServiceBinding names.
  --delete                Execute deletion (default is list-only dry run).
  --secure-tls            Verify TLS certificates (default uses -k due corporate trust chains).
  -h, --help              Show help.

Environment overrides:
  SECRET_NAMESPACE        Namespace holding Service Manager credential secret (default: sap-btp-operator)
  SECRET_NAME             Secret name (default: sap-btp-service-operator-credentials)
EOF
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --name-pattern)
      NAME_PATTERN="${2:-}"
      shift 2
      ;;
    --delete)
      DELETE_MODE="true"
      shift
      ;;
    --secure-tls)
      INSECURE_TLS="false"
      shift
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      echo "Unknown argument: $1" >&2
      usage
      exit 1
      ;;
  esac
done

if [[ -z "$NAME_PATTERN" ]]; then
  echo "Missing required --name-pattern" >&2
  usage
  exit 1
fi

curl_flags=("-sS" "--fail")
if [[ "$INSECURE_TLS" == "true" ]]; then
  curl_flags=("-k" "${curl_flags[@]}")
fi

CLIENT_ID="$(kubectl get secret "$SECRET_NAME" -n "$SECRET_NAMESPACE" -o jsonpath='{.data.clientid}' | base64 -d)"
CLIENT_SECRET="$(kubectl get secret "$SECRET_NAME" -n "$SECRET_NAMESPACE" -o jsonpath='{.data.clientsecret}' | base64 -d)"
TOKEN_URL="$(kubectl get secret "$SECRET_NAME" -n "$SECRET_NAMESPACE" -o jsonpath='{.data.tokenurl}' | base64 -d)"
SM_URL="$(kubectl get secret "$SECRET_NAME" -n "$SECRET_NAMESPACE" -o jsonpath='{.data.sm_url}' | base64 -d)"

TOKEN="$(curl "${curl_flags[@]}" -u "$CLIENT_ID:$CLIENT_SECRET" -d grant_type=client_credentials "$TOKEN_URL" | python3 -c 'import sys,json; print(json.load(sys.stdin)["access_token"])')"

INSTANCES_JSON="$(curl "${curl_flags[@]}" -H "Authorization: Bearer $TOKEN" "$SM_URL/v1/service_instances")"
BINDINGS_JSON="$(curl "${curl_flags[@]}" -H "Authorization: Bearer $TOKEN" "$SM_URL/v1/service_bindings")"

export INSTANCES_JSON BINDINGS_JSON NAME_PATTERN

echo "Matched resources (pattern: $NAME_PATTERN):"
python3 - <<'PY'
import json, os, re
inst = json.loads(os.environ['INSTANCES_JSON']).get('items', [])
bind = json.loads(os.environ['BINDINGS_JSON']).get('items', [])
pat = re.compile(os.environ['NAME_PATTERN'])

matched_instances = [i for i in inst if pat.search(i.get('name') or '')]
matched_instance_ids = {i.get('id') for i in matched_instances if i.get('id')}
matched_bindings = [
    b for b in bind
    if pat.search(b.get('name') or '') or (b.get('service_instance_id') in matched_instance_ids)
]

print(f"  instances: {len(matched_instances)}")
for i in matched_instances:
    print(f"    - {i.get('id')}\t{i.get('name')}")

print(f"  bindings: {len(matched_bindings)}")
for b in matched_bindings:
    print(f"    - {b.get('id')}\t{b.get('name')}\tinstance={b.get('service_instance_id')}")
PY

if [[ "$DELETE_MODE" != "true" ]]; then
  echo "Dry-run only. Re-run with --delete to remove matched resources."
  exit 0
fi

MATCHED_BINDING_IDS=()
while IFS= read -r line; do
  [[ -n "$line" ]] && MATCHED_BINDING_IDS+=("$line")
done < <(python3 - <<'PY'
import json, os, re
inst = json.loads(os.environ['INSTANCES_JSON']).get('items', [])
bind = json.loads(os.environ['BINDINGS_JSON']).get('items', [])
pat = re.compile(os.environ['NAME_PATTERN'])
matched_instances = [i for i in inst if pat.search(i.get('name') or '')]
matched_instance_ids = {i.get('id') for i in matched_instances if i.get('id')}
matched_bindings = [
    b for b in bind
    if pat.search(b.get('name') or '') or (b.get('service_instance_id') in matched_instance_ids)
]
for b in matched_bindings:
    if b.get('id'):
        print(b['id'])
PY
)

MATCHED_INSTANCE_IDS=()
while IFS= read -r line; do
  [[ -n "$line" ]] && MATCHED_INSTANCE_IDS+=("$line")
done < <(python3 - <<'PY'
import json, os, re
inst = json.loads(os.environ['INSTANCES_JSON']).get('items', [])
pat = re.compile(os.environ['NAME_PATTERN'])
for i in inst:
    if pat.search(i.get('name') or '') and i.get('id'):
        print(i['id'])
PY
)

for binding_id in "${MATCHED_BINDING_IDS[@]:-}"; do
  [[ -n "$binding_id" ]] || continue
  echo "Deleting binding $binding_id"
  curl "${curl_flags[@]}" -X DELETE -H "Authorization: Bearer $TOKEN" \
    "$SM_URL/v1/service_bindings/$binding_id?accepts_incomplete=true" >/dev/null
  echo "  -> requested"
done

for instance_id in "${MATCHED_INSTANCE_IDS[@]:-}"; do
  [[ -n "$instance_id" ]] || continue
  echo "Deleting instance $instance_id"
  curl "${curl_flags[@]}" -X DELETE -H "Authorization: Bearer $TOKEN" \
    "$SM_URL/v1/service_instances/$instance_id?accepts_incomplete=true" >/dev/null
  echo "  -> requested"
done

echo "Delete requests submitted. Re-run in dry-run mode to verify zero matches."


