#!/usr/bin/env bash
set -euo pipefail

NAMESPACE="${NAMESPACE:-dev}"
APP_NAME="${APP_NAME:-hello-world-service}"
OPERATOR_NAMESPACE="${OPERATOR_NAMESPACE:-sap-btp-operator}"
NAMESPACE_SECRET="${NAMESPACE_SECRET:-sap-btp-service-operator}"
OPERATOR_SECRET="${OPERATOR_SECRET:-sap-btp-service-operator-credentials}"
HELM_CHART_PATH="${HELM_CHART_PATH:-helm/hello-world-service}"
HELM_VALUES_FILE="${HELM_VALUES_FILE:-helm/hello-world-service/values-${NAMESPACE}.yaml}"
SERVICE_INSTANCE_NAME="${SERVICE_INSTANCE_NAME:-hello-world-xsuaa-${NAMESPACE}}"
SERVICE_BINDING_NAME="${SERVICE_BINDING_NAME:-hello-world-xsuaa-binding-${NAMESPACE}}"
XSUAA_EXTERNAL_NAME="${XSUAA_EXTERNAL_NAME:-hello-world-xsuaa-${NAMESPACE}}"
XSUAA_XSAPPNAME="${XSUAA_XSAPPNAME:-${APP_NAME}-${NAMESPACE}}"
EXPECTED_SM_URL="${EXPECTED_SM_URL:-https://service-manager.cfapps.sap.hana.ondemand.com}"
EXPECTED_TOKEN_URL="${EXPECTED_TOKEN_URL:-}"
MANIFEST_DIR="${MANIFEST_DIR:-platform-ops/k8s/xsuaa/namespaces/${NAMESPACE}/apps/${APP_NAME}}"
TOKEN_URL_REGEX='^https://[^[:space:]]+/oauth/token$'

fail() {
  echo "[FAIL] $*" >&2
  exit 1
}

pass() {
  echo "[OK] $*"
}

require_cmd() {
  command -v "$1" >/dev/null 2>&1 || fail "Required command not found: $1"
}

get_secret_field() {
  local ns="$1" secret="$2" field="$3"
  kubectl get secret "$secret" -n "$ns" -o "jsonpath={.data.${field}}" | base64 -d
}

require_cmd kubectl
require_cmd curl
require_cmd jq
require_cmd python3
require_cmd helm

namespace_label_output="$(kubectl get namespace "$NAMESPACE" -o jsonpath='{.metadata.labels.btp-operator}' 2>&1 || true)"
if [[ -n "$namespace_label_output" && "$namespace_label_output" != *"forbidden"* && "$namespace_label_output" != *"not found"* ]]; then
  [[ "$namespace_label_output" == "enabled" ]] || fail "Namespace '$NAMESPACE' is not labeled btp-operator=enabled"
  pass "Namespace '$NAMESPACE' exists and label btp-operator=enabled is set"
else
  # Namespace-scoped kubeconfigs usually cannot read cluster-scope Namespace objects.
  if [[ "$namespace_label_output" == *"forbidden"* ]]; then
    echo "[WARN] Cannot read Namespace '$NAMESPACE' metadata with current RBAC; skipping namespace label check"
  else
    fail "Namespace '$NAMESPACE' does not exist"
  fi
fi

operator_ready_output="$(kubectl get pods -n "$OPERATOR_NAMESPACE" -l app=sap-btp-operator --no-headers 2>&1 || true)"
operator_secret_accessible="true"
if [[ "$operator_ready_output" == *"forbidden"* ]]; then
  operator_secret_accessible="false"
  echo "[WARN] Cannot read operator pods in namespace '$OPERATOR_NAMESPACE' with current RBAC; skipping operator health check"
else
  operator_ready=$(printf '%s\n' "$operator_ready_output" | awk '$2 ~ /^2\/2$/ && $3 == "Running" {count++} END {print count+0}')
  [[ "$operator_ready" -ge 1 ]] || fail "BTP operator is not healthy in namespace '$OPERATOR_NAMESPACE'"
  pass "BTP operator has healthy running pod(s)"
fi


kubectl get secret "$NAMESPACE_SECRET" -n "$NAMESPACE" >/dev/null 2>&1 || fail "Secret '$NAMESPACE_SECRET' missing in namespace '$NAMESPACE'"

operator_secret_check_output="$(kubectl get secret "$OPERATOR_SECRET" -n "$OPERATOR_NAMESPACE" 2>&1 || true)"
if [[ "$operator_secret_check_output" == *"forbidden"* ]]; then
  operator_secret_accessible="false"
  echo "[WARN] Cannot read operator secret '$OPERATOR_SECRET' in namespace '$OPERATOR_NAMESPACE'; skipping operator secret parity checks"
elif [[ "$operator_secret_check_output" == *"not found"* ]]; then
  fail "Secret '$OPERATOR_SECRET' missing in namespace '$OPERATOR_NAMESPACE'"
fi

if [[ "$operator_secret_accessible" == "true" ]]; then
  pass "Namespace and operator credentials secrets exist"
else
  pass "Namespace credentials secret exists"
fi

ns_sm_url=$(get_secret_field "$NAMESPACE" "$NAMESPACE_SECRET" sm_url)
ns_token_url=$(get_secret_field "$NAMESPACE" "$NAMESPACE_SECRET" tokenurl)
ns_clientid=$(get_secret_field "$NAMESPACE" "$NAMESPACE_SECRET" clientid)
ns_clientsecret=$(get_secret_field "$NAMESPACE" "$NAMESPACE_SECRET" clientsecret)

if [[ "$operator_secret_accessible" == "true" ]]; then
  op_sm_url=$(get_secret_field "$OPERATOR_NAMESPACE" "$OPERATOR_SECRET" sm_url)
  op_token_url=$(get_secret_field "$OPERATOR_NAMESPACE" "$OPERATOR_SECRET" tokenurl)
  op_clientid=$(get_secret_field "$OPERATOR_NAMESPACE" "$OPERATOR_SECRET" clientid)
  op_clientsecret=$(get_secret_field "$OPERATOR_NAMESPACE" "$OPERATOR_SECRET" clientsecret)
fi

[[ "$ns_sm_url" == "$EXPECTED_SM_URL" ]] || fail "Namespace sm_url mismatch: '$ns_sm_url'"
[[ "$ns_token_url" =~ $TOKEN_URL_REGEX ]] || fail "Namespace tokenurl must match https://<auth-domain>/oauth/token, got: '$ns_token_url'"
if [[ -n "$EXPECTED_TOKEN_URL" ]]; then
  [[ "$ns_token_url" == "$EXPECTED_TOKEN_URL" ]] || fail "Namespace tokenurl mismatch: '$ns_token_url'"
fi

if [[ "$operator_secret_accessible" == "true" ]]; then
  [[ "$op_token_url" =~ $TOKEN_URL_REGEX ]] || fail "Operator tokenurl must match https://<auth-domain>/oauth/token, got: '$op_token_url'"
  [[ "$ns_sm_url" == "$op_sm_url" ]] || fail "Namespace sm_url differs from operator secret"
  [[ "$ns_token_url" == "$op_token_url" ]] || fail "Namespace tokenurl differs from operator secret"
  [[ "$ns_clientid" == "$op_clientid" ]] || fail "Namespace clientid differs from operator secret"
  [[ "$ns_clientsecret" == "$op_clientsecret" ]] || fail "Namespace clientsecret differs from operator secret"
  pass "Namespace credentials use valid endpoints and match operator source secret"
else
  pass "Namespace credentials use valid endpoints"
fi

access_token=$(curl -sS -u "$ns_clientid:$ns_clientsecret" -d 'grant_type=client_credentials' "$ns_token_url" | jq -r '.access_token // empty')
[[ -n "$access_token" ]] || fail "Failed to obtain Service Manager access token"
pass "Service Manager token retrieval succeeded"

existing_si_ready=$(kubectl get serviceinstance "$SERVICE_INSTANCE_NAME" -n "$NAMESPACE" -o jsonpath='{.status.ready}' 2>/dev/null || true)
[[ -n "$existing_si_ready" ]] || fail "Required pre-provisioned ServiceInstance '$SERVICE_INSTANCE_NAME' is missing in namespace '$NAMESPACE'. Provision XSUAA before pipeline run."
[[ "$(printf '%s' "$existing_si_ready" | tr '[:upper:]' '[:lower:]')" == "true" ]] || fail "Existing ServiceInstance '$SERVICE_INSTANCE_NAME' is present but not Ready. Reset or finish provisioning before pipeline run."

existing_sb_ready=$(kubectl get servicebinding "$SERVICE_BINDING_NAME" -n "$NAMESPACE" -o jsonpath='{.status.ready}' 2>/dev/null || true)
[[ -n "$existing_sb_ready" ]] || fail "Required pre-provisioned ServiceBinding '$SERVICE_BINDING_NAME' is missing in namespace '$NAMESPACE'. Provision XSUAA binding before pipeline run."
[[ "$(printf '%s' "$existing_sb_ready" | tr '[:upper:]' '[:lower:]')" == "true" ]] || fail "Existing ServiceBinding '$SERVICE_BINDING_NAME' is present but not Ready. Reset or finish provisioning before pipeline run."
pass "Pre-provisioned ServiceInstance and ServiceBinding exist and are Ready"

kubectl get secret "$SERVICE_BINDING_NAME" -n "$NAMESPACE" >/dev/null 2>&1 || fail "Binding secret '$SERVICE_BINDING_NAME' is missing in namespace '$NAMESPACE'. Ensure ServiceBinding completed successfully before pipeline run."
pass "Pre-created binding secret '$SERVICE_BINDING_NAME' exists"

kubectl apply --dry-run=server -f "${MANIFEST_DIR}/serviceinstance.yaml" >/dev/null
kubectl apply --dry-run=server -f "${MANIFEST_DIR}/servicebinding.yaml" >/dev/null
pass "App-specific XSUAA manifests pass server-side validation"

rendered_file=$(mktemp)
helm template "$APP_NAME" "$HELM_CHART_PATH" --namespace "$NAMESPACE" -f "$HELM_VALUES_FILE" > "$rendered_file"

render_summary=$(python3 - <<'PY' "$rendered_file"
import json, re, sys
path = sys.argv[1]
with open(path, 'r', encoding='utf-8') as f:
    content = f.read()

docs = [doc for doc in re.split(r'^---\s*$', content, flags=re.M) if doc.strip()]
summary = {
    "vcap_services_present": False,
    "deployment_secret_name": None,
    "service_binding_names": [],
}

for doc in docs:
    kind_match = re.search(r'^kind:\s+(\S+)\s*$', doc, flags=re.M)
    kind = kind_match.group(1) if kind_match else ""

    if kind == 'Deployment':
        if 'VCAP_SERVICES' in doc:
            summary['vcap_services_present'] = True
        m = re.search(r'^\s*secretName:\s*"?([^"\n]+)"?\s*$', doc, flags=re.M)
        if m:
            summary['deployment_secret_name'] = m.group(1)
    elif kind == 'ServiceBinding':
        m = re.search(r'^\s*name:\s*"?([^"\n]+)"?\s*$', doc, flags=re.M)
        if m:
            summary['service_binding_names'].append(m.group(1))

print(json.dumps(summary))
PY
)

vcap_present=$(python3 - <<'PY' "$render_summary"
import json, sys
print(str(json.loads(sys.argv[1])["vcap_services_present"]).lower())
PY
)
[[ "$vcap_present" == "false" ]] || fail "Rendered Helm Deployment still contains legacy VCAP_SERVICES wiring"

rendered_si_name=$(python3 - <<'PY' "$render_summary"
import json, sys
print(json.loads(sys.argv[1])["deployment_secret_name"] or "")
PY
)

[[ -n "$rendered_si_name" ]] || fail "Failed to determine rendered Deployment secretName from Helm chart"
[[ "$rendered_si_name" == "$SERVICE_BINDING_NAME" ]] || fail "Rendered Deployment mounts secret '$rendered_si_name' but expected pre-created binding secret '$SERVICE_BINDING_NAME'"

rendered_sb_names=$(python3 - <<'PY' "$render_summary"
import json, sys
print("\n".join(json.loads(sys.argv[1])["service_binding_names"]))
PY
)

if printf '%s\n' "$rendered_sb_names" | grep -Fxq "$SERVICE_BINDING_NAME"; then
  fail "Rendered Helm chart still includes ServiceBinding '$SERVICE_BINDING_NAME'. For pre-created binding flow set xsuaa.createServiceBinding=false (or xsuaa.createResources=false) in Helm values before running pipeline."
fi

pass "Rendered Helm XSUAA wiring is consistent and free of legacy VCAP_SERVICES usage"

rm -f "$rendered_file"

cat <<EOF
[OK] XSUAA preflight passed for namespace '$NAMESPACE'
     ServiceInstance: $SERVICE_INSTANCE_NAME
     ServiceBinding:  $SERVICE_BINDING_NAME
     externalName:    $XSUAA_EXTERNAL_NAME
     xsappname:       $XSUAA_XSAPPNAME
EOF


