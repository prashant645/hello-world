# QA Namespace Secret Binding Prerequisites

This folder documents the **one-time namespace secret setup** required before app-specific XSUAA provisioning in `qa`.

It is intentionally separate from the app XSUAA lifecycle under `platform-ops/k8s/xsuaa/README.md`.

## Why this exists

These steps are environment/namespace prerequisites, not app XSUAA provisioning itself:

- copy the Service Manager credentials secret into `qa`
- ensure the namespace is labeled for operator scope
- verify the namespace secret matches the operator secret source
- confirm the namespace is ready before creating app `ServiceInstance`/`ServiceBinding`

## One-time setup steps

1. Verify the BTP operator is healthy:

```bash
kubectl get pods -n sap-btp-operator
```

2. Copy credentials from the operator namespace into `qa`:

```bash
./platform-ops/k8s/btp-operator/copy-credentials.sh qa
```

3. Label the namespace for operator webhook scope:

```bash
kubectl label namespace qa btp-operator=enabled --overwrite
```

4. Verify the namespace label:

```bash
kubectl get namespace qa -o jsonpath='{.metadata.labels.btp-operator}'; echo
```

5. Verify the namespace secret matches the operator secret source:

```bash
kubectl get secret sap-btp-service-operator -n qa -o jsonpath='{.data.sm_url}' | base64 -d; echo
kubectl get secret sap-btp-service-operator -n qa -o jsonpath='{.data.tokenurl}' | base64 -d; echo
kubectl get secret sap-btp-service-operator -n qa -o jsonpath='{.data.clientid}' | base64 -d; echo
kubectl get secret sap-btp-service-operator -n qa -o jsonpath='{.data.clientsecret}' | base64 -d; echo
```

Expected:
- `sm_url` = `https://service-manager.cfapps.sap.hana.ondemand.com`
- `tokenurl` = `https://hello-kyma-cfw6mbbu.authentication.sap.hana.ondemand.com/oauth/token`
- `clientid` and `clientsecret` exactly match `platform-ops/k8s/btp-operator/1-operator-secret.yaml`

## What this is not

This folder does **not** create app-specific XSUAA resources.

Those resources still live under:

- `platform-ops/k8s/xsuaa/namespaces/qa/apps/hello-world-service/serviceinstance.yaml`
- `platform-ops/k8s/xsuaa/namespaces/qa/apps/hello-world-service/servicebinding.yaml`

## Related verification

After the one-time secret binding setup, run the main XSUAA preflight before a deployable pipeline run:

```bash
bash platform-ops/k8s/xsuaa/namespaces/qa/scripts/preflight-xsuaa.sh
```

Note:
- `status.ready` may appear as `True` or `true`; the preflight normalizes the value before checking it.

