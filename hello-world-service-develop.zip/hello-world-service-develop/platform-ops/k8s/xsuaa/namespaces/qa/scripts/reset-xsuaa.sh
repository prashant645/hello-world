#!/usr/bin/env bash
set -euo pipefail

NAMESPACE="${1:-qa}"
SERVICE_INSTANCE="hello-world-xsuaa-qa"
SERVICE_BINDING="hello-world-xsuaa-binding-qa"
WAIT_SECONDS="${WAIT_SECONDS:-45}"

echo "Resetting XSUAA resources in namespace: ${NAMESPACE}"

wait_gone() {
  local kind="$1"
  local name="$2"
  kubectl wait --for=delete "${kind}/${name}" -n "${NAMESPACE}" --timeout="${WAIT_SECONDS}s" >/dev/null 2>&1
}

force_delete_if_stuck() {
  local kind="$1"
  local name="$2"
  if kubectl get "${kind}" "${name}" -n "${NAMESPACE}" >/dev/null 2>&1; then
    echo "${kind}/${name} still present, removing finalizers"
    kubectl patch "${kind}" "${name}" -n "${NAMESPACE}" --type merge -p '{"metadata":{"finalizers":[]}}' >/dev/null 2>&1 || true
    kubectl delete "${kind}" "${name}" -n "${NAMESPACE}" --ignore-not-found >/dev/null 2>&1 || true
    wait_gone "${kind}" "${name}" || true
  fi
}

# Try graceful deletion first so operator can clean backend resources.
kubectl delete servicebinding "${SERVICE_BINDING}" -n "${NAMESPACE}" --ignore-not-found --wait=false
kubectl delete serviceinstance "${SERVICE_INSTANCE}" -n "${NAMESPACE}" --ignore-not-found --wait=false
wait_gone servicebinding "${SERVICE_BINDING}" || true
wait_gone serviceinstance "${SERVICE_INSTANCE}" || true

# If finalizers block delete, force-remove them.
force_delete_if_stuck servicebinding "${SERVICE_BINDING}"
force_delete_if_stuck serviceinstance "${SERVICE_INSTANCE}"

if kubectl get servicebinding "${SERVICE_BINDING}" -n "${NAMESPACE}" >/dev/null 2>&1; then
  echo "ERROR: servicebinding/${SERVICE_BINDING} still exists after reset" >&2
  exit 1
fi

if kubectl get serviceinstance "${SERVICE_INSTANCE}" -n "${NAMESPACE}" >/dev/null 2>&1; then
  echo "ERROR: serviceinstance/${SERVICE_INSTANCE} still exists after reset" >&2
  exit 1
fi

echo ""
echo "Post-reset verification:"
kubectl get serviceinstances.services.cloud.sap.com -n "${NAMESPACE}" || true
kubectl get servicebindings.services.cloud.sap.com -n "${NAMESPACE}" || true

echo ""
echo "If you had to force-remove finalizers, verify BTP cockpit has no lingering backend XSUAA instance"
echo "for xsappname=hello-world-service-qa before redeploy."


