# XSUAA Deployment (Kyma) - Namespace Bootstrap and Operations Guide

Use this guide for one-time XSUAA setup in `dev`, `qa`, `prod`, day-2 verification, and clean reset when `ServiceInstance`/`ServiceBinding` gets stuck.

This guide applies to namespace bootstrap in `dev`, `qa`, `prod`, and additional namespaces following the same pattern under `platform-ops/k8s/xsuaa/namespaces/<namespace>/`.
Before the first deployable pipeline run in a namespace, create the namespace-specific XSUAA `ServiceInstance`, `ServiceBinding`, and binding secret there too.

The legacy standalone `platform-ops/XSUAA-DEPLOYMENT.md` content is now consolidated into this guide and the sibling `platform-ops/k8s/xsuaa/test/README.md`.

This directory does **not** install the operator. It assumes `platform-ops/k8s/btp-operator` is already installed and healthy.

## Mandatory rule

If an app will use XSUAA, then **XSUAA resources for that app must be deployed first as a distinct procedure before any app deployment or pipeline run uses those XSUAA resources**.

For this repo that means:
- first install the BTP operator
- then prepare the namespace
- then deploy the app-specific XSUAA `ServiceInstance` and `ServiceBinding`
- wait until the binding secret exists and all XSUAA resources are `Ready`
- only then run the app deployment pipeline

This is **not optional** for the first deployment of an app in a namespace when the app depends on XSUAA.

This requirement applies only to **deployable** pipeline runs.
It does **not** apply to PR workflows that build/test only and do not deploy the app.

## What must happen before a Kyma pipeline run

### Mandatory before the first pipeline run in a namespace

1. Install the BTP operator once per cluster using `platform-ops/k8s/btp-operator/README.md`.
2. Complete the one-time namespace secret-binding prerequisites for the target namespace.
   - Current repo example: `platform-ops/k8s/xsuaa/namespaces/dev/secret-binding/README.md`
   - For `qa` and `prod`, mirror the same pattern in each namespace before first deploy
3. Provision the app-specific XSUAA resources once for that namespace/app:
   - create the app `ServiceInstance`
   - create the app `ServiceBinding`
   - wait until the binding secret exists and all XSUAA resources are `Ready`

The app deployment pipeline must not be used as the mechanism to discover whether XSUAA exists. XSUAA readiness is a prerequisite, not a side effect of app deployment.

## Production bootstrap (first deploy in `prod`)

Use this exact sequence before the first deployable app run in `prod`.

1. Verify operator source secret exists:

```bash
kubectl get secret sap-btp-service-operator-credentials -n sap-btp-operator
```

2. Copy credentials into `prod` and label namespace:

```bash
./platform-ops/k8s/btp-operator/copy-credentials.sh prod
kubectl label namespace prod btp-operator=enabled --overwrite
kubectl get secret sap-btp-service-operator -n prod
```

3. Apply app XSUAA resources in `prod`:

```bash
kubectl apply -f platform-ops/k8s/xsuaa/namespaces/prod/apps/hello-world-service/serviceinstance.yaml
kubectl apply -f platform-ops/k8s/xsuaa/namespaces/prod/apps/hello-world-service/servicebinding.yaml
```

4. Wait for readiness and verify binding secret:

```bash
kubectl wait --for=jsonpath='{.status.ready}'=true serviceinstance/hello-world-xsuaa-prod -n prod --timeout=8m
kubectl wait --for=jsonpath='{.status.ready}'=true servicebinding/hello-world-xsuaa-binding-prod -n prod --timeout=8m
kubectl get secret hello-world-xsuaa-binding-prod -n prod
```

5. Run preflight:

```bash
bash platform-ops/k8s/xsuaa/namespaces/prod/scripts/preflight-xsuaa.sh
```

### Recommended before any manual retry

Run the namespace preflight:

```bash
bash platform-ops/k8s/xsuaa/namespaces/dev/scripts/preflight-xsuaa.sh
```

For QA:

```bash
bash platform-ops/k8s/xsuaa/namespaces/qa/scripts/preflight-xsuaa.sh
```

For production:

```bash
bash platform-ops/k8s/xsuaa/namespaces/prod/scripts/preflight-xsuaa.sh
```

`preflight-xsuaa.sh` is reusable across namespaces. By default it verifies:
- `sm_url` matches the expected Service Manager endpoint
- `tokenurl` matches `https://<auth-domain>/oauth/token`
- namespace secret values match operator source secret values

If you need strict host pinning in a specific landscape, set `EXPECTED_TOKEN_URL` explicitly:

```bash
EXPECTED_TOKEN_URL="https://<your-auth-domain>/oauth/token" bash platform-ops/k8s/xsuaa/namespaces/qa/scripts/preflight-xsuaa.sh
```

If the namespace secret-binding prerequisites need repair, use:

- `platform-ops/k8s/xsuaa/namespaces/dev/secret-binding/README.md`

This fails fast on the common problems that otherwise surface only after a long Helm wait:
- operator not healthy
- wrong or stale namespace secret binding
- namespace label missing
- missing or not-ready pre-provisioned `ServiceInstance` / `ServiceBinding`
- missing pre-created binding secret
- invalid app-specific manifests
- rendered Helm XSUAA wiring mismatch (Deployment secret mount vs ServiceBinding secret)
- accidental legacy `VCAP_SERVICES` usage in the active Kyma Deployment template

### Not mandatory before every pipeline run

- You do **not** need to recreate the app `ServiceInstance` and `ServiceBinding` before each pipeline run if they already exist and are `Ready`.
- In this repo, the Kyma pipeline now assumes XSUAA is already provisioned.
- Helm deploys the app and mounts the pre-created binding secret; it does not create XSUAA resources during normal app deployment.
- The Helm chart still has an `xsuaa.createResources` switch for special/manual cases, but the default for deployable app pipelines is `false`.
- The current deployable Kyma workflows assume XSUAA is already pre-provisioned.
- The current `dev` workflow now adds API Gateway/APIRule preflight and post-deploy HTTPS/auth verification, but it does **not** currently invoke `preflight-xsuaa.sh` as a dedicated GitHub Actions job.
- Run `platform-ops/k8s/xsuaa/namespaces/dev/scripts/preflight-xsuaa.sh` manually before first deploy, before namespace recovery work, or anytime you want a fail-fast XSUAA readiness check.

### Use the manifests in this folder when

- you want a manual bootstrap or manual recovery
- you want to test XSUAA provisioning without running the full app pipeline
- you need to clean reset and recreate XSUAA resources explicitly

## Directory layout

- `README.md` - this guide (cluster-global documentation)
- `namespaces/dev/secret-binding/README.md` - one-time dev namespace secret prerequisites
- `namespaces/qa/secret-binding/README.md` - one-time qa namespace secret prerequisites
- `namespaces/prod/secret-binding/README.md` - one-time prod namespace secret prerequisites
- `namespaces/dev/scripts/preflight-xsuaa.sh` - fail-fast dev namespace preflight (defaults to namespace `dev`)
- `namespaces/qa/scripts/preflight-xsuaa.sh` - fail-fast qa namespace preflight (defaults to namespace `qa`)
- `namespaces/prod/scripts/preflight-xsuaa.sh` - fail-fast prod namespace preflight (defaults to namespace `prod`)
- `namespaces/dev/rbac-kyma-deployer.yaml` - optional RBAC if the `kyma-deployer` service account in `dev` needs permission to manage `ServiceInstance` and `ServiceBinding` resources
- `../kyma/qa/kyma-deployer-namespace-rbac.yaml` - optional RBAC if the `kyma-deployer` service account in `qa` needs permission to manage Kyma deployment, verification, and XSUAA-related resources in namespace `qa`
- `namespaces/prod/rbac-kyma-deployer.yaml` - optional RBAC if the `kyma-deployer` service account in `prod` needs permission to manage `ServiceInstance` and `ServiceBinding` resources
- `namespaces/dev/scripts/reset-xsuaa.sh` - dev reset helper script (defaults to namespace `dev`)
- `namespaces/qa/scripts/reset-xsuaa.sh` - qa reset helper script (defaults to namespace `qa`)
- `namespaces/prod/scripts/reset-xsuaa.sh` - prod reset helper script (defaults to namespace `prod`)
- `scripts/cleanup-service-manager-instances.sh` - force-clean orphan backend Service Manager instances/bindings by name pattern
- `test/README.md` - dedicated XSUAA test guide for deployed auth checks, scoped success-path proof, and client-credentials caller setup
- `test/scripts/test-xsuaa-auth.sh` - namespace-agnostic deployed auth smoke test (pass `-n <namespace>`)
- `test/scripts/test-scoped-user-local.sh` - local scoped-user success-path proof (`XsuaaSecurityTest`)
- `namespaces/dev/apps/hello-world-service/serviceinstance.yaml` - app-specific dev ServiceInstance
- `namespaces/dev/apps/hello-world-service/servicebinding.yaml` - app-specific dev ServiceBinding
- `namespaces/qa/apps/hello-world-service/serviceinstance.yaml` - app-specific qa ServiceInstance
- `namespaces/qa/apps/hello-world-service/servicebinding.yaml` - app-specific qa ServiceBinding
- `namespaces/prod/apps/hello-world-service/serviceinstance.yaml` - app-specific prod ServiceInstance
- `namespaces/prod/apps/hello-world-service/servicebinding.yaml` - app-specific prod ServiceBinding
- `namespaces/` can be extended for additional namespaces using the same bootstrap/preflight structure
- `archive/hello-world-service/xsuaa-binding.legacy.yaml` - legacy hello-world namespace variant
- `archive/hello-world-service/deployment.legacy.yaml` - old standalone app Deployment/Service manifest (Helm now owns app deployment)

## What this manages

- Kubernetes `ServiceInstance` per namespace: `hello-world-xsuaa-<namespace>`
- Kubernetes `ServiceBinding` per namespace: `hello-world-xsuaa-binding-<namespace>`
- BTP backend XSUAA instance via `externalName`: `hello-world-xsuaa-<namespace>`

## Namespace policy (recommended)

- Use **one XSUAA ServiceInstance per app**, even when multiple apps run in the same namespace.
- Reason: isolates scopes/roles and avoids cross-app impact during auth changes.
- Reusing one XSUAA across multiple apps is technically possible, but not the default for this repo.

When onboarding a new app in any namespace:
- Create a new `ServiceInstance` with a unique `externalName` and `xsappname`.
- Create a new `ServiceBinding` with its own namespace-aware `secretName`.
- Mount that app-specific binding secret in the app Deployment.

For `hello-world-service`, the expected binding secret name format is `hello-world-xsuaa-binding-<namespace>`.

## One-time XSUAA setup example (`dev`)

This section is mandatory before the first app pipeline run for `hello-world-service` in `dev`.

You can also use it later for manual recovery.


Fresh setup must start from clean app XSUAA resources in the namespace.

Run the reset helper first (safe to run repeatedly, includes stuck-delete handling):

```bash
bash platform-ops/k8s/xsuaa/namespaces/dev/scripts/reset-xsuaa.sh dev
```

Important:
- `reset-xsuaa.sh` cleans Kubernetes resources in `dev` only.
- It does not delete backend Service Manager instances/bindings shown in BTP cockpit.
- If old backend entries still exist, clean them using section **E** before re-create.

If you do it manually, use this robust delete sequence:

```bash
kubectl delete servicebinding hello-world-xsuaa-binding-dev -n dev --ignore-not-found --wait=false
kubectl delete serviceinstance hello-world-xsuaa-dev -n dev --ignore-not-found --wait=false
kubectl wait --for=delete servicebinding/hello-world-xsuaa-binding-dev -n dev --timeout=45s || true
kubectl wait --for=delete serviceinstance/hello-world-xsuaa-dev -n dev --timeout=45s || true
kubectl patch servicebinding hello-world-xsuaa-binding-dev -n dev --type merge -p '{"metadata":{"finalizers":[]}}' 2>/dev/null || true
kubectl patch serviceinstance hello-world-xsuaa-dev -n dev --type merge -p '{"metadata":{"finalizers":[]}}' 2>/dev/null || true
kubectl delete servicebinding hello-world-xsuaa-binding-dev -n dev --ignore-not-found --wait=false
kubectl delete serviceinstance hello-world-xsuaa-dev -n dev --ignore-not-found --wait=false
```

Then apply these manifests in order:

```bash
kubectl apply -f platform-ops/k8s/xsuaa/namespaces/dev/apps/hello-world-service/serviceinstance.yaml
kubectl apply -f platform-ops/k8s/xsuaa/namespaces/dev/apps/hello-world-service/servicebinding.yaml
```

Wait until ready:

```bash
kubectl wait --for=jsonpath='{.status.ready}'=true serviceinstance/hello-world-xsuaa-dev -n dev --timeout=8m
kubectl wait --for=jsonpath='{.status.ready}'=true servicebinding/hello-world-xsuaa-binding-dev -n dev --timeout=8m
kubectl get serviceinstance hello-world-xsuaa-dev -n dev
kubectl get servicebinding hello-world-xsuaa-binding-dev -n dev
```

Note:
- `kubectl get` may show `STATUS=Created` even after provisioning succeeds.
- Treat `READY=True` / `status.ready: true` as the real success signal.
- The CLI status column does not always change from `Created` to `Ready` for these resources.
- `kubectl get ... -w` can be misleading because it keeps showing the last CLI status while the real readiness may already be `true`.
- `status.ready` may be returned as `True` or `true`; the preflight normalizes case before checking it.

Success criteria:
- `ServiceInstance`: `STATUS=Created`, `READY=True`
- `ServiceBinding`: `STATUS=Created`, `READY=True`
- Secret exists for app mount:

```bash
kubectl get secret hello-world-xsuaa-binding-dev -n dev
```

## Clean reset example (`dev`)

Use when resources are stuck, or to restart from clean state.

### A) Preferred: reset helper script

```bash
bash platform-ops/k8s/xsuaa/namespaces/dev/scripts/reset-xsuaa.sh
# or with explicit namespace
bash platform-ops/k8s/xsuaa/namespaces/dev/scripts/reset-xsuaa.sh dev
```

### B) Advanced/manual fallback only

Use this only if you cannot run the helper script.

1) Normal delete first:

```bash
kubectl delete servicebinding hello-world-xsuaa-binding-dev -n dev --ignore-not-found --wait=false
kubectl delete serviceinstance hello-world-xsuaa-dev -n dev --ignore-not-found --wait=false
```

2) If stuck on finalizers:

```bash
kubectl patch servicebinding hello-world-xsuaa-binding-dev -n dev --type merge -p '{"metadata":{"finalizers":[]}}' 2>/dev/null || true
kubectl patch serviceinstance hello-world-xsuaa-dev -n dev --type merge -p '{"metadata":{"finalizers":[]}}' 2>/dev/null || true
kubectl delete servicebinding hello-world-xsuaa-binding-dev -n dev --ignore-not-found --wait=false
kubectl delete serviceinstance hello-world-xsuaa-dev -n dev --ignore-not-found --wait=false
```

### C) Verify clean namespace state

```bash
kubectl get serviceinstances.services.cloud.sap.com -n dev
kubectl get servicebindings.services.cloud.sap.com -n dev
```


### D) Delete lingering backend XSUAA in BTP cockpit

If you force-remove finalizers, backend resources may remain in BTP.

In BTP Cockpit (subaccount `hello-kyma`):
- Open **Instances and Subscriptions**
- Delete binding(s) for the stale XSUAA
- Delete stale XSUAA instance with:
  - instance name: `hello-world-xsuaa-dev` (or prior name)
  - `xsappname`: `hello-world-service-dev`

Lessons learned in this repo:
- Old non-namespaced instances like `hello-world-xsuaa` can remain for a long time and block clean re-provisioning.
- Cockpit binding delete can be greyed out for old Kyma-managed artifacts.
- In that case, use section **E** to clean backend objects directly in Service Manager.

### E) Force backend cleanup via Service Manager API (when cockpit delete is disabled)

Sometimes old Kyma-managed backend instances/bindings remain but cockpit actions are greyed out.
In that case, use this repo tool to clean up by name pattern directly in Service Manager.

Tool location:
- `platform-ops/k8s/xsuaa/scripts/cleanup-service-manager-instances.sh`

Examples:

```bash
# Dry run: list matching instances + bindings only
bash platform-ops/k8s/xsuaa/scripts/cleanup-service-manager-instances.sh --name-pattern '^hello-world-xsuaa$'

# Delete all matches (bindings first, then instances)
bash platform-ops/k8s/xsuaa/scripts/cleanup-service-manager-instances.sh --name-pattern '^hello-world-xsuaa$' --delete
```

Notes:
- Preferred path is still deleting Kubernetes `ServiceInstance`/`ServiceBinding` first.
- Use this tool for orphan backend cleanup when Kubernetes owners are already gone.
- The tool reads credentials from `sap-btp-operator/sap-btp-service-operator-credentials` by default.
- Always run dry-run first and keep the regex specific (for example `^hello-world-xsuaa$`).
- Deletion order is bindings first, then instances.

## Final verification before pipeline run

Use this quick checklist after cleanup/recreate:

```bash
NAMESPACE=dev
kubectl get serviceinstance "hello-world-xsuaa-${NAMESPACE}" -n "$NAMESPACE"
kubectl get servicebinding "hello-world-xsuaa-binding-${NAMESPACE}" -n "$NAMESPACE"
kubectl get secret "hello-world-xsuaa-binding-${NAMESPACE}" -n "$NAMESPACE"
bash "platform-ops/k8s/xsuaa/namespaces/${NAMESPACE}/scripts/preflight-xsuaa.sh"
```

For production:

```bash
NAMESPACE=prod
kubectl get serviceinstance "hello-world-xsuaa-${NAMESPACE}" -n "$NAMESPACE"
kubectl get servicebinding "hello-world-xsuaa-binding-${NAMESPACE}" -n "$NAMESPACE"
kubectl get secret "hello-world-xsuaa-binding-${NAMESPACE}" -n "$NAMESPACE"
bash "platform-ops/k8s/xsuaa/namespaces/${NAMESPACE}/scripts/preflight-xsuaa.sh"
```

Expected:
- ServiceInstance `STATUS=Created`, `READY=True`
- ServiceBinding `STATUS=Created`, `READY=True`
- Binding secret exists in the target namespace
- preflight exits successfully

For endpoint and HTTPS/auth verification after deployment, continue with:

```text
platform-ops/k8s/apiRule/README.md
```

## XSUAA testing guide

All XSUAA test procedures were moved to the dedicated guide:

```text
platform-ops/k8s/xsuaa/test/README.md
```

Use that guide for:
- deployed auth enforcement testing
- properly scoped success-path testing
- service-to-service testing through port-forward
- enabling a new client-credentials caller

## External exposure and APIRule verification

The current deployment model in this repo uses Kyma `APIRule` for public HTTPS exposure when the cluster supports the API Gateway path.

Use the dedicated guide for:
- APIRule/API Gateway readiness checks
- namespace-specific public URL and OAuth token URL reference
- client-side HTTPS testing
- one-command post-deploy verification scripts

```text
platform-ops/k8s/apiRule/README.md
```

If a target cluster does not expose the `APIRule` CRD, continue using the service-to-service port-forward flow in `platform-ops/k8s/xsuaa/test/README.md` for manual testing and troubleshooting.
For this repository's automated Kyma pipeline path, the current expectation is APIRule-based public HTTPS verification.

## Runtime verification after deploy

After the backend is already deployed, use these checks before investigating authentication issues:

```bash
NAMESPACE=prod  # or dev / qa
kubectl -n "$NAMESPACE" get deploy,pod,svc,apirule | cat
kubectl -n "$NAMESPACE" rollout status deploy/hello-world-service --timeout=180s
kubectl -n "$NAMESPACE" logs -l app.kubernetes.io/name=hello-world-service --tail=50
kubectl -n "$NAMESPACE" get serviceinstance "hello-world-xsuaa-${NAMESPACE}"
kubectl -n "$NAMESPACE" get servicebinding "hello-world-xsuaa-binding-${NAMESPACE}"
kubectl -n "$NAMESPACE" get secret "hello-world-xsuaa-binding-${NAMESPACE}"
```

Expected:
- deployment rolled out successfully
- pod is `Running`
- `APIRule` is present and becomes `Ready` when the cluster supports API Gateway exposure
- `ServiceInstance` and `ServiceBinding` show `READY=True`
- binding secret exists in the target namespace

For auth and client-credential tests, continue with `platform-ops/k8s/xsuaa/test/README.md`.
For public HTTPS/auth verification of the deployed endpoint, continue with `platform-ops/k8s/apiRule/README.md`.

## Common failure symptoms

1. `error parsing response body ... /login ... invalid character '<'`
- Usually wrong `sm_url` or bad credentials in namespace secret.
- Re-copy credentials to the target namespace:

```bash
./platform-ops/k8s/btp-operator/copy-credentials.sh <namespace>
```

1b. `Secret "sap-btp-service-operator" not found`
- The namespace bootstrap secret is missing in the target namespace.
- Fix sequence:

```bash
NAMESPACE=prod
kubectl get secret sap-btp-service-operator-credentials -n sap-btp-operator
./platform-ops/k8s/btp-operator/copy-credentials.sh "$NAMESPACE"
kubectl label namespace "$NAMESPACE" btp-operator=enabled --overwrite
kubectl get secret sap-btp-service-operator -n "$NAMESPACE"
```

- If the `ServiceInstance` was already created and failed, check whether it self-recovers after secret creation:

```bash
kubectl wait --for=jsonpath='{.status.ready}'=true serviceinstance/hello-world-xsuaa-prod -n prod --timeout=8m
```

- If it does not recover, delete and recreate the failed resource:

```bash
kubectl delete serviceinstance hello-world-xsuaa-prod -n prod --ignore-not-found --wait=false
kubectl apply -f platform-ops/k8s/xsuaa/namespaces/prod/apps/hello-world-service/serviceinstance.yaml
kubectl wait --for=jsonpath='{.status.ready}'=true serviceinstance/hello-world-xsuaa-prod -n prod --timeout=8m
```

2. `"invalid_client" "Bad credentials"`
- `clientid`/`clientsecret` typo in namespace secret.
- Compare character-by-character to `platform-ops/k8s/btp-operator/1-operator-secret.yaml`.

3. `xsappname ... already exists`
- Backend XSUAA with same `xsappname` already exists in BTP.
- Delete old backend in BTP cockpit or use a different `xsappname`.

4. `ServiceBinding Blocked`
- Parent `ServiceInstance` is not ready.
- Fix ServiceInstance first.

5. XSUAA binding secret not found in the pod namespace
- Verify the secret exists:

```bash
NAMESPACE=prod  # or dev / qa
kubectl get secret "hello-world-xsuaa-binding-${NAMESPACE}" -n "$NAMESPACE"
kubectl describe secret "hello-world-xsuaa-binding-${NAMESPACE}" -n "$NAMESPACE"
```

- Expected keys include `url`, `clientid`, and `clientsecret`.

6. Application health checks fail
- Inspect probes and startup logs:

```bash
NAMESPACE=prod  # or dev / qa
kubectl describe pod -l app.kubernetes.io/name=hello-world-service -n "$NAMESPACE" | grep -A 5 "Liveness\|Readiness"
kubectl logs -l app.kubernetes.io/name=hello-world-service -n "$NAMESPACE" | head -100
```

- If startup is slow, consider increasing `initialDelaySeconds` in `helm/hello-world-service/values.yaml`.

7. External access test fails
- If using `APIRule`, verify the rule and gateway status and re-run the checks in `platform-ops/k8s/apiRule/README.md`.
- For manual troubleshooting, if `APIRule` is unavailable in the cluster, use port-forward instead.

## Collecting logs for support

When reporting issues, collect the following diagnostics:

```bash
NAMESPACE=prod  # or dev / qa

# XSUAA resource status
kubectl get serviceinstance,servicebinding -n "$NAMESPACE" -o wide
kubectl describe serviceinstance "hello-world-xsuaa-${NAMESPACE}" -n "$NAMESPACE"
kubectl describe servicebinding "hello-world-xsuaa-binding-${NAMESPACE}" -n "$NAMESPACE"

# Pod status and logs
kubectl get pods -l app.kubernetes.io/name=hello-world-service -n "$NAMESPACE"
kubectl describe pod -l app.kubernetes.io/name=hello-world-service -n "$NAMESPACE"
kubectl logs -l app.kubernetes.io/name=hello-world-service -n "$NAMESPACE" --tail=100
kubectl logs -l app.kubernetes.io/name=hello-world-service -n "$NAMESPACE" --previous

# Helm release status
helm status hello-world-service -n "$NAMESPACE"
helm history hello-world-service -n "$NAMESPACE"

# Secret verification
kubectl get secret "hello-world-xsuaa-binding-${NAMESPACE}" -n "$NAMESPACE" -o yaml

# Operator logs
kubectl logs -n sap-btp-operator -l app=sap-btp-operator -c manager --tail=100
```

## App wiring reminder

The app deployment mounts `Secret/hello-world-xsuaa-binding-<namespace>` at `/bindings/xsuaa` and uses `SERVICE_BINDING_ROOT=/bindings`.
For each namespace, keep the binding secret name consistent between:
- `platform-ops/k8s/xsuaa/namespaces/<namespace>/apps/hello-world-service/servicebinding.yaml`
- the rendered Helm `Deployment` secret mount for that namespace

Example secret names:
- `dev`: `hello-world-xsuaa-binding-dev`
- `qa`: `hello-world-xsuaa-binding-qa`
- `prod`: `hello-world-xsuaa-binding-prod`

Do not rename the binding secret unless you also update the Deployment mount configuration or Helm values consistently.

