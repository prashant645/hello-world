#!/usr/bin/env bash
#
# Kyma Deployment Drift Detection
#
# Verifies that cluster state matches repository bootstrap contracts.
# Intended to run before release/prod deployments to catch configuration drift.
#
# Usage:
#   ./drift-detection.sh <environment> <namespace> <service-name> <xsuaa-instance> <xsuaa-binding> [xsuaa-secret]
#   ./drift-detection.sh dev dev hello-world-service hello-world-xsuaa-dev hello-world-xsuaa-binding-dev
#   ./drift-detection.sh prod prod hello-world-service hello-world-xsuaa-prod hello-world-xsuaa-binding-prod

set -e

# Color output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Config
ENVIRONMENT="${1:-dev}"
NAMESPACE="${2:-$ENVIRONMENT}"
SERVICE_NAME="${3:-hello-world-service}"
RUNTIME_SA_NAME="${SERVICE_NAME}-${ENVIRONMENT}"
XSUAA_INSTANCE="${4:-}"
XSUAA_BINDING="${5:-}"
XSUAA_SECRET="${6:-$XSUAA_BINDING}"

if [ -z "$XSUAA_INSTANCE" ] || [ -z "$XSUAA_BINDING" ]; then
  echo "Usage error: XSUAA instance and binding names must be provided explicitly."
  echo "Example: ./drift-detection.sh dev dev hello-world-service hello-world-xsuaa-dev hello-world-xsuaa-binding-dev"
  exit 2
fi

# Global state
CHECKS_PASSED=0
CHECKS_FAILED=0
CHECKS_WARNINGS=0

check_pass() {
  echo -e "${GREEN}✅ PASS:${NC} $1"
  ((++CHECKS_PASSED))
}

check_fail() {
  echo -e "${RED}❌ FAIL:${NC} $1"
  ((++CHECKS_FAILED))
}

check_warn() {
  echo -e "${YELLOW}⚠️  WARN:${NC} $1"
  ((++CHECKS_WARNINGS))
}

echo -e "${BLUE}═══════════════════════════════════════════════════════════════${NC}"
echo -e "${BLUE}Kyma Deployment Drift Detection${NC}"
echo -e "${BLUE}Environment: ${ENVIRONMENT} | Namespace: ${NAMESPACE} | Service: ${SERVICE_NAME}${NC}"
echo -e "${BLUE}═══════════════════════════════════════════════════════════════${NC}"
echo

# =============================================================================
# 1. Kubernetes Cluster Connectivity
# =============================================================================
echo -e "${BLUE}[1/7] Cluster Connectivity${NC}"

if kubectl cluster-info &>/dev/null; then
  check_pass "Cluster is reachable"
else
  check_fail "Cluster is not reachable"
  exit 1
fi

# =============================================================================
# 2. Namespace Existence and Labels
# =============================================================================
echo -e "\n${BLUE}[2/7] Namespace Bootstrap${NC}"

if kubectl get namespace "$NAMESPACE" &>/dev/null; then
  check_pass "Namespace '$NAMESPACE' exists"
else
  check_fail "Namespace '$NAMESPACE' does not exist"
  exit 1
fi

# Check for bootstrap label (indicates bootstrap was run)
BOOTSTRAP_LABEL=$(kubectl get namespace "$NAMESPACE" -o jsonpath='{.metadata.labels.gtlc\.io/bootstrap}' 2>/dev/null || echo "")
if [ -n "$BOOTSTRAP_LABEL" ]; then
  check_pass "Namespace has bootstrap label: $BOOTSTRAP_LABEL"
else
  check_warn "Namespace is missing gtlc.io/bootstrap label"
fi

# =============================================================================
# 3. Deployer ServiceAccount
# =============================================================================
echo -e "\n${BLUE}[3/7] Deployer Identity${NC}"

DEPLOYER_SA="kyma-deployer"
if kubectl get serviceaccount "$DEPLOYER_SA" -n "$NAMESPACE" &>/dev/null; then
  check_pass "Deployer ServiceAccount '$DEPLOYER_SA' exists"

  # Check RBAC for deployer
  if kubectl auth can-i get deployments --as=system:serviceaccount:$NAMESPACE:$DEPLOYER_SA -n "$NAMESPACE" &>/dev/null; then
    check_pass "Deployer can read deployments in namespace"
  else
    check_warn "Deployer may lack read permission for deployments"
  fi
else
  check_fail "Deployer ServiceAccount '$DEPLOYER_SA' not found"
fi

# =============================================================================
# 4. Runtime ServiceAccount (Precreated)
# =============================================================================
echo -e "\n${BLUE}[4/7] Runtime ServiceAccount (Bootstrap-Owned)${NC}"

if kubectl get serviceaccount "$RUNTIME_SA_NAME" -n "$NAMESPACE" &>/dev/null; then
  check_pass "Runtime ServiceAccount '$RUNTIME_SA_NAME' exists"

  # Check automountServiceAccountToken setting
  AUTOMOUNT=$(kubectl get serviceaccount "$RUNTIME_SA_NAME" -n "$NAMESPACE" -o jsonpath='{.automountServiceAccountToken}')
  if [ "$AUTOMOUNT" = "false" ]; then
    check_pass "Runtime SA has automountServiceAccountToken=false (secure default)"
  else
    check_warn "Runtime SA has automountServiceAccountToken=$AUTOMOUNT (expected false)"
  fi
else
  check_fail "Runtime ServiceAccount '$RUNTIME_SA_NAME' not found - bootstrap procedure required"
fi

# =============================================================================
# 5. XSUAA Service Instance & Binding
# =============================================================================
echo -e "\n${BLUE}[5/7] XSUAA Integration${NC}"

# XSUAA names are passed explicitly by caller to avoid service-specific assumptions.

# Check ServiceInstance
if kubectl get serviceinstance "$XSUAA_INSTANCE" -n "$NAMESPACE" &>/dev/null; then
  check_pass "XSUAA ServiceInstance '$XSUAA_INSTANCE' exists"

  # Check if ready
  READY=$(kubectl get serviceinstance "$XSUAA_INSTANCE" -n "$NAMESPACE" -o jsonpath='{.status.ready}' 2>/dev/null || echo "unknown")
  if [ "$READY" = "true" ]; then
    check_pass "XSUAA ServiceInstance is ready"
  else
    check_warn "XSUAA ServiceInstance may not be ready (status: $READY)"
  fi
else
  check_warn "XSUAA ServiceInstance '$XSUAA_INSTANCE' not found - may be precreated externally"
fi

# Check ServiceBinding
if kubectl get servicebinding "$XSUAA_BINDING" -n "$NAMESPACE" &>/dev/null; then
  check_pass "XSUAA ServiceBinding '$XSUAA_BINDING' exists"
else
  check_warn "XSUAA ServiceBinding '$XSUAA_BINDING' not found - may be precreated externally"
fi

# Check binding secret
if kubectl get secret "$XSUAA_SECRET" -n "$NAMESPACE" &>/dev/null; then
  check_pass "XSUAA binding secret '$XSUAA_SECRET' exists"

  # Check for required fields in binding secret
  HAS_BINDING=$(kubectl get secret "$XSUAA_SECRET" -n "$NAMESPACE" -o jsonpath='{.data.binding}' 2>/dev/null || echo "")
  if [ -n "$HAS_BINDING" ]; then
    check_pass "XSUAA binding secret contains binding data"
  else
    check_warn "XSUAA binding secret may be missing binding data"
  fi
else
  check_warn "XSUAA binding secret '$XSUAA_SECRET' not found"
fi

# =============================================================================
# 6. Application Deployment State
# =============================================================================
echo -e "\n${BLUE}[6/7] Application Deployment${NC}"

DEPLOYMENT_NAME="$SERVICE_NAME"
if kubectl get deployment "$DEPLOYMENT_NAME" -n "$NAMESPACE" &>/dev/null; then
  check_pass "Deployment '$DEPLOYMENT_NAME' exists"

  # Check if it uses the precreated SA
  DEPLOYMENT_SA=$(kubectl get deployment "$DEPLOYMENT_NAME" -n "$NAMESPACE" -o jsonpath='{.spec.template.spec.serviceAccountName}')
  if [[ "$DEPLOYMENT_SA" == "$RUNTIME_SA_NAME" || ( "$DEPLOYMENT_SA" == "default" && -z "$RUNTIME_SA_NAME" ) ]]; then
    check_pass "Deployment uses expected ServiceAccount: $DEPLOYMENT_SA"
  else
    check_warn "Deployment uses ServiceAccount: $DEPLOYMENT_SA (expected: $RUNTIME_SA_NAME)"
  fi

  # Check replica readiness
  READY_REPLICAS=$(kubectl get deployment "$DEPLOYMENT_NAME" -n "$NAMESPACE" -o jsonpath='{.status.readyReplicas}' 2>/dev/null || echo "0")
  DESIRED_REPLICAS=$(kubectl get deployment "$DEPLOYMENT_NAME" -n "$NAMESPACE" -o jsonpath='{.spec.replicas}' 2>/dev/null || echo "0")
  if [ "$READY_REPLICAS" = "$DESIRED_REPLICAS" ] && [ "$DESIRED_REPLICAS" != "0" ]; then
    check_pass "Deployment has all replicas ready ($READY_REPLICAS/$DESIRED_REPLICAS)"
  else
    check_warn "Deployment replica status: $READY_REPLICAS/$DESIRED_REPLICAS"
  fi
else
  check_warn "Deployment '$DEPLOYMENT_NAME' not found - may not be deployed yet"
fi

# =============================================================================
# 7. APIRule Exposure (if applicable)
# =============================================================================
echo -e "\n${BLUE}[7/7] APIRule Exposure (Optional)${NC}"

APIRULE_NAME="$SERVICE_NAME"
if kubectl get apirule "$APIRULE_NAME" -n "$NAMESPACE" &>/dev/null; then
  check_pass "APIRule '$APIRULE_NAME' exists"

  # Check status
  APIRULE_STATUS=$(kubectl get apirule "$APIRULE_NAME" -n "$NAMESPACE" -o jsonpath='{.status.state}' 2>/dev/null || echo "unknown")
  if [ "$APIRULE_STATUS" = "Ready" ]; then
    check_pass "APIRule is Ready"
  else
    check_warn "APIRule status: $APIRULE_STATUS (expected: Ready)"
  fi
else
  check_warn "APIRule '$APIRULE_NAME' not found (this may be expected if not enabled)"
fi

# =============================================================================
# Summary
# =============================================================================
echo
echo -e "${BLUE}═══════════════════════════════════════════════════════════════${NC}"
echo -e "${BLUE}Drift Detection Summary${NC}"
echo -e "${BLUE}═══════════════════════════════════════════════════════════════${NC}"
echo -e "Passed: ${GREEN}${CHECKS_PASSED}${NC}"
echo -e "Warnings: ${YELLOW}${CHECKS_WARNINGS}${NC}"
echo -e "Failed: ${RED}${CHECKS_FAILED}${NC}"
echo

if [ "$CHECKS_FAILED" -gt 0 ]; then
  echo -e "${RED}❌ DRIFT DETECTION FAILED${NC}"
  echo "Critical issues must be resolved before proceeding with release/prod deployment."
  echo "See: platform-ops/k8s/kyma/${ENVIRONMENT}/SETUP.md"
  exit 1
elif [ "$CHECKS_WARNINGS" -gt 0 ]; then
  echo -e "${YELLOW}⚠️  DRIFT DETECTION PASSED WITH WARNINGS${NC}"
  echo "Please review warnings above. Consider addressing them before release."
  exit 0
else
  echo -e "${GREEN}✅ DRIFT DETECTION PASSED${NC}"
  echo "Cluster state matches repository bootstrap contracts. Safe to proceed."
  exit 0
fi

