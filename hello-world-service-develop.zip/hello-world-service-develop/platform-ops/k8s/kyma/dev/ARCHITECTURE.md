# Dev Namespace - Architecture & Status Summary

Complete overview of the dev environment setup for hello-world-service on Kyma.

> Documentation note: dev namespace guides are maintained under `platform-ops/k8s/kyma/dev/`.
> Historical root-level `DEV-*.md` copies were removed after consolidation so architecture and operational guidance stay in one place.

---

## Architecture Diagram

```
┌─────────────────────────────────────────────────────────────────────┐
│                         Kyma Cluster                                 │
├─────────────────────────────────────────────────────────────────────┤
│                                                                      │
│  ┌──────────────────────────────────────────────────────────────┐  │
│  │                   Dev Namespace                               │  │
│  ├──────────────────────────────────────────────────────────────┤  │
│  │                                                                │  │
│  │  ┌─────────────────────────────────────────────────────────┐ │  │
│  │  │  Kubernetes Deployment (Helm)                           │ │  │
│  │  │  - hello-world-service                                  │ │  │
│  │  │  - Replicas: 1                                          │ │  │
│  │  │  - Containers: app + Istio sidecar                      │ │  │
│  │  │  - Env: SERVICE_BINDING_ROOT=/bindings                 │ │  │
│  │  │  - Env: SPRING_PROFILES_ACTIVE=cloud                   │ │  │
│  │  │  - ServiceAccount: hello-world-service-dev (precreated) │ │  │
│  │  │  - Mount: Secret hello-world-xsuaa-binding-dev          │ │  │
│  │  │           at /bindings/xsuaa                            │ │  │
│  │  └─────────────────────────────────────────────────────────┘ │  │
│  │                            │                                  │  │
│  │                            ▼                                  │  │
│  │  ┌─────────────────────────────────────────────────────────┐ │  │
│  │  │  Kubernetes Service (ClusterIP)                         │ │  │
│  │  │  - hello-world-service:8080 → Pod:8080                 │ │  │
│  │  │  - Internal only (no external IP)                       │ │  │
│  │  └─────────────────────────────────────────────────────────┘ │  │
│  │                            │                                  │  │
│  │                            ▼                                  │  │
│  │  ┌─────────────────────────────────────────────────────────┐ │  │
│  │  │  Kyma APIRule                                           │ │  │
│  │  │  - Hostname: hello-world-service-dev                   │ │  │
│  │  │  - Gateway: kyma-gateway                               │ │  │
│  │  │  - Access: allow (any request)                         │ │  │
│  │  │  - Public URL: https://hello-world-service-dev.*.com   │ │  │
│  │  │  - Routes to: Service hello-world-service:8080         │ │  │
│  │  └─────────────────────────────────────────────────────────┘ │  │
│  │                            │                                  │  │
│  │  ┌─────────────────────────────────────────────────────────┐ │  │
│  │  │  XSUAA & Secrets                                        │ │  │
│  │  │  ┌───────────────────────────────────────────────────┐  │ │  │
│  │  │  │ ServiceInstance: hello-world-xsuaa-dev            │  │ │  │
│  │  │  │  - Backing Service: XSUAA (BTP)                  │  │ │  │
│  │  │  │  - Config: xsappname=hello-world-service-dev     │  │ │  │
│  │  │  │  - Status: Ready=true                            │  │ │  │
│  │  │  └───────────────────────────────────────────────────┘  │ │  │
│  │  │                                                           │ │  │
│  │  │  ┌───────────────────────────────────────────────────┐  │ │  │
│  │  │  │ ServiceBinding: hello-world-xsuaa-binding-dev     │  │ │  │
│  │  │  │  - Binds to: ServiceInstance above               │  │ │  │
│  │  │  │  - Creates: Secret hello-world-xsuaa-binding-dev │  │ │  │
│  │  │  │  - Status: Ready=true                            │  │ │  │
│  │  │  └───────────────────────────────────────────────────┘  │ │  │
│  │  │                                                           │ │  │
│  │  │  ┌───────────────────────────────────────────────────┐  │ │  │
│  │  │  │ Secret: hello-world-xsuaa-binding-dev            │  │ │  │
│  │  │  │  - url: XSUAA endpoint                            │  │ │  │
│  │  │  │  - clientid: Service user                         │  │ │  │
│  │  │  │  - clientsecret: Service user password            │  │ │  │
│  │  │  │  - xsappname: hello-world-service-dev            │  │ │  │
│  │  │  └───────────────────────────────────────────────────┘  │ │  │
│  │  │                                                           │ │  │
│  │  │  ┌───────────────────────────────────────────────────┐  │ │  │
│  │  │  │ Secret: docker-registry-secret                   │  │ │  │
│  │  │  │  - Credentials for gtlc-docker registry          │  │ │  │
│  │  │  │  - Used by: Pod imagePullSecrets                 │  │ │  │
│  │  │  └───────────────────────────────────────────────────┘  │ │  │
│  │  └─────────────────────────────────────────────────────────┘ │  │
│  │                                                                │  │
│  └──────────────────────────────────────────────────────────────┘  │
│                                                                      │
│  ┌──────────────────────────────────────────────────────────────┐  │
│  │            sap-btp-operator Namespace (Cluster)               │  │
│  │  - ServiceInstance/ServiceBinding controllers                 │  │
│  │  - Webhook for namespace label validation                    │  │
│  │  - Secret: sap-btp-service-operator-credentials              │  │
│  │    (copied to dev as sap-btp-service-operator)               │  │
│  └──────────────────────────────────────────────────────────────┘  │
│                                                                      │
│  ┌──────────────────────────────────────────────────────────────┐  │
│  │                 kyma-system Namespace                         │  │
│  │  - kyma-gateway: Routes APIRule to public internet            │  │
│  │  - Ingress controller                                         │  │
│  └──────────────────────────────────────────────────────────────┘  │
│                                                                      │
└─────────────────────────────────────────────────────────────────────┘
                                  │
                                  ▼
                    ┌──────────────────────────┐
                    │   Public Internet        │
                    │  (HTTPS Access)          │
                    │  hello-world-service-dev │
                    └──────────────────────────┘
```

---

## Component Status Checklist

### ✅ Implemented & Ready
- **Helm Chart** 
  - `helm/hello-world-service/Chart.yaml` - metadata
  - `helm/hello-world-service/values.yaml` - defaults
  - `helm/hello-world-service/values-dev.yaml` - dev overrides
  - `helm/hello-world-service/templates/deployment.yaml` - app deployment
  - `helm/hello-world-service/templates/service.yaml` - ClusterIP service
  - `helm/hello-world-service/templates/apirule.yaml` - **NEW: Internet exposure**

- **XSUAA Configuration**
  - `platform-ops/k8s/xsuaa/namespaces/dev/apps/hello-world-service/serviceinstance.yaml`
  - `platform-ops/k8s/xsuaa/namespaces/dev/apps/hello-world-service/servicebinding.yaml`
  - Preflight validation script

- **Namespace Setup Scripts**
  - BTP operator copy credentials script
  - XSUAA reset helper
  - Comprehensive preflight checks

- **Documentation**
  - Full Kyma.md guide with APIRule section (updated)
  - SETUP.md - comprehensive step-by-step guide
  - CHECKLIST.md - quick copy-paste checklist
  - This architecture summary

### ⏳ Prerequisites Required
- ✅ Kyma cluster with kubeconfig (ServiceAccount auth, not OIDC)
- ✅ BTP operator installed (`platform-ops/k8s/btp-operator/`)
- ✅ Docker registry credentials in Vault
- ⏳ ServiceAccount credentials for CI/CD (from Kyma.md)

### 🚀 Next Steps (User Action Required)
1. **Choose starting point:**
   - Fresh dev setup → Start with `CHECKLIST.md` Phase 1
   - Redeployment → Jump to `CHECKLIST.md` Phase 6
   - Troubleshooting → See `SETUP.md` troubleshooting section

2. **Follow the checklist** for actual deployment

3. **Test the public endpoint** once deployed (see DEV-CHECKLIST Phase 10)

---

## File Structure

```
hello-world-service/
├── helm/hello-world-service/
│   ├── Chart.yaml
│   ├── values.yaml                    # Base values
│   ├── values-dev.yaml                # ✅ Dev overrides (APIRule enabled)
│   ├── values-qa.yaml                 # QA overrides (APIRule enabled)
│   ├── values-prod.yaml               # Prod overrides (APIRule disabled)
│   └── templates/
│       ├── deployment.yaml            # App deployment + XSUAA mount
│       ├── service.yaml               # ClusterIP service
│       └── apirule.yaml               # ✅ NEW: Internet exposure via Kyma APIRule
│
├── platform-ops/k8s/xsuaa/
│   ├── README.md                      # Main XSUAA guide
│   ├── namespaces/dev/
│   │   ├── apps/hello-world-service/
│   │   │   ├── serviceinstance.yaml   # XSUAA backend service
│   │   │   ├── servicebinding.yaml    # XSUAA binding
│   │   │   └── servicebinding-client-rw.yaml  # Optional namespace-specific client RW manifest
│   │   ├── scripts/
│   │   │   ├── preflight-xsuaa.sh     # Validation before deploy
│   │   │   └── reset-xsuaa.sh         # Clean reset helper
│   │   ├── secret-binding/
│   │   │   └── README.md              # Namespace secret setup
│   ├── qa/
│   │   ├── kyma-deployer-namespace-rbac.yaml    # QA namespace RBAC for kyma-deployer
│   │   └── kyma-deployer-cross-namespace-rbac.yaml  # QA-only cross-namespace RBAC
│   ├── scripts/
│   │   └── cleanup-service-manager-instances.sh  # Shared Service Manager orphan cleanup helper
│   └── test/
│       ├── README.md                    # Canonical inline client-binding flow for tests
│       └── scripts/
│           ├── test-xsuaa-auth.sh       # Shared namespace-agnostic auth smoke test (use -n <namespace>)
│           └── test-scoped-user-local.sh # Shared local scoped-user success-path test
│
├── platform-ops/superpowers/
│   └── Kyma.md                        # ✅ Updated with APIRule section
│
├── platform-ops/k8s/kyma/dev/SETUP.md         # ✅ Comprehensive dev guide
├── platform-ops/k8s/kyma/dev/CHECKLIST.md     # ✅ Quick checklist
└── ...
```

---

## Key Configurations for Dev

### values-dev.yaml

```yaml
replicaCount: 1
image:
  tag: ""  # Set by CI/CD pipeline

resources:
  limits:
    cpu: 500m
    memory: 512Mi
  requests:
    cpu: 250m
    memory: 256Mi

# XSUAA - Pre-provisioned
xsuaa:
  createServiceInstance: false
  createServiceBinding: false
  externalName: hello-world-xsuaa-dev
  xsappname: hello-world-service-dev
  bindingSecretName: hello-world-xsuaa-binding-dev
  bindingExternalName: hello-world-xsuaa-binding-dev

# Internet Exposure - ENABLED for Dev
apirule:
  enabled: true
  gateway: kyma-gateway
  host: hello-world-service-dev
  methods: [GET, POST, PUT, DELETE, PATCH]
  accessStrategies:
    - handler: allow
```

### Environment Variables in Pod

| Variable | Value | Purpose |
|----------|-------|---------|
| `SERVICE_BINDING_ROOT` | `/bindings` | Where service bindings are mounted |
| `SPRING_PROFILES_ACTIVE` | `cloud` | Spring Cloud configuration |
| `VCAP_SERVICES` | (from secret) | Service binding credentials (env var) |

---

## Access Patterns

### Internal (Within Kubernetes)

```bash
# Pod-to-pod (service DNS)
curl http://hello-world-service.dev.svc.cluster.local:8080/actuator/health

# Port-forward from your machine
kubectl port-forward -n dev svc/hello-world-service 8080:8080
curl http://localhost:8080/actuator/health
```

### External (From Internet)

```bash
# Public URL (via APIRule)
# https://hello-world-service-dev.<kyma-cluster-domain>/...

# Example for BTP trial cluster
# https://hello-world-service-dev.c-1a2b3c4d.kyma.ondemand.com/actuator/health

# With authentication (using XSUAA credentials)
curl -k -H "Authorization: Bearer $TOKEN" \
  https://hello-world-service-dev.<kyma-cluster-domain>/greet?name=Kyma
```

---

## Deployment Flow

```
User Action
    │
    ▼
┌─────────────────────────────────┐
│ 1. Run DEV-CHECKLIST Phases 1-5 │ (Setup + XSUAA provisioning)
│    (One-time, ~30 min)          │
└─────────────────────────────────┘
    │
    ▼
┌─────────────────────────────────┐
│ 2. Run DEV-CHECKLIST Phase 6     │ (Deploy app with Helm)
│    (Repeatable, ~2 min)         │
└─────────────────────────────────┘
    │
    ▼
┌─────────────────────────────────┐
│ 3. Run DEV-CHECKLIST Phases 7-11 │ (Verify + test)
│    (Validation, ~5 min)         │
└─────────────────────────────────┘
    │
    ▼
✅ Dev Namespace Ready
```

---

## Troubleshooting Quick Reference

| Issue | Check | Command |
|-------|-------|---------|
| Pod not starting | Image pull error | `kubectl describe pod -n dev` |
| Pod crash | Health check failure | `kubectl logs -n dev -l app=hello-world-service` |
| XSUAA stuck | ServiceInstance/Binding status | `kubectl get serviceinstance,servicebinding -n dev` |
| No public URL | APIRule status | `kubectl get apirule hello-world-service -n dev` |
| Preflight failing | XSUAA resources | `bash platform-ops/k8s/xsuaa/namespaces/dev/scripts/preflight-xsuaa.sh` |

---

## Security Notes

### ✅ Implemented
- XSUAA for authentication (OAuth2)
- Kubernetes RBAC for cluster access
- Secret-based credentials (not in code)
- Service account for CI/CD (token-based)
- HTTPS via Kyma gateway (TLS termination)

### ⚠️ Manual Configuration Required
- Docker registry credentials (from Vault)
- XSUAA client credentials (stored in Kubernetes Secret)
- API access control (currently set to `allow`, can be restricted with `oauth2_introspection`)

### 🔒 For Production (values-prod.yaml)
- APIRule is **disabled by default** - enable only when ready
- Consider adding OAuth2 handler to `accessStrategies`
- Increase replicas to 3 (high availability)
- Consider adding rate limiting via API Management

---

## Next Actions

**Ready to deploy?** → Go to `CHECKLIST.md`

**Need detailed explanation?** → Read `SETUP.md`

**Want to understand more?** → See `platform-ops/superpowers/Kyma.md`

---

## Performance Targets (Dev)

| Metric | Target | Current |
|--------|--------|---------|
| Pod startup time | < 30s | ~10-15s |
| Health check response | < 100ms | ~50ms |
| Readiness probe timeout | 10s | 5s |
| Deployment timeout | 5m | ~1-2m |
| XSUAA provisioning | 8m | 3-5m |

---

**Created:** September 7, 2026  
**Last Updated:** September 7, 2026  
**Status:** Ready for deployment ✅


