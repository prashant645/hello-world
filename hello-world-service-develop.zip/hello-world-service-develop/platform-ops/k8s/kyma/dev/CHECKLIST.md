# Dev Namespace - Quick Deployment Checklist

Copy-paste this checklist into your terminal for quick dev setup and deployment.

---

## Phase 1: Prerequisites Verification (5 min)

```bash
# Check kubeconfig is set
kubectl cluster-info
kubectl get namespace dev || echo "Dev namespace doesn't exist yet"

# Check BTP operator is healthy
kubectl get pods -n sap-btp-operator -l app=sap-btp-operator
# Expected: At least one pod showing "2/2 Running"
```

---

## Phase 2: Namespace Setup (5 min, one-time only)

```bash
# Create namespace
kubectl create namespace dev --dry-run=client -o yaml | kubectl apply -f -

# Copy BTP credentials to dev
./platform-ops/k8s/btp-operator/copy-credentials.sh dev

# Label namespace
kubectl label namespace dev btp-operator=enabled --overwrite

# Verify label
kubectl get namespace dev -o jsonpath='{.metadata.labels.btp-operator}'; echo
```

---

## Phase 3: Docker Registry Secret (5 min, one-time only)

```bash
# Create docker registry secret
# Replace YOUR_USERNAME, YOUR_PASSWORD with actual Vault credentials
kubectl create secret docker-registry docker-registry-secret \
  --docker-server=gtlc-docker.common.repositories.cloud.sap \
  --docker-username=YOUR_USERNAME \
  --docker-password=YOUR_PASSWORD \
  --docker-email=ignored@example.com \
  -n dev \
  --dry-run=client -o yaml | kubectl apply -f -

# Verify
kubectl get secret docker-registry-secret -n dev
```

---

## Phase 4: XSUAA Provisioning (10 min, one-time only)

```bash
# Reset (clean start - optional if restarting)
bash platform-ops/k8s/xsuaa/namespaces/dev/scripts/reset-xsuaa.sh dev

# Provision XSUAA ServiceInstance
kubectl apply -f platform-ops/k8s/xsuaa/namespaces/dev/apps/hello-world-service/serviceinstance.yaml

# Wait for ServiceInstance ready (usually 3-5 min)
kubectl wait --for=jsonpath='{.status.ready}'=true \
  serviceinstance/hello-world-xsuaa-dev -n dev --timeout=8m

# Provision XSUAA ServiceBinding
kubectl apply -f platform-ops/k8s/xsuaa/namespaces/dev/apps/hello-world-service/servicebinding.yaml

# Wait for ServiceBinding ready (usually 3-5 min)
kubectl wait --for=jsonpath='{.status.ready}'=true \
  servicebinding/hello-world-xsuaa-binding-dev -n dev --timeout=8m

# Verify binding secret exists
kubectl get secret hello-world-xsuaa-binding-dev -n dev
```

---

## Phase 5: Pre-Deployment Validation (2 min)

```bash
# Run comprehensive preflight check
bash platform-ops/k8s/xsuaa/namespaces/dev/scripts/preflight-xsuaa.sh

# Expected output: [OK] XSUAA preflight passed for namespace 'dev'
```

**If preflight fails:** Stop here and fix errors before continuing.

---

## Phase 6: Deploy Application (2 min)

```bash
# Deploy with Helm
helm upgrade --install hello-world-service helm/hello-world-service \
  -f helm/hello-world-service/values-dev.yaml \
  --namespace dev \
  --create-namespace \
  --wait \
  --timeout 5m

# Expected output: release name: hello-world-service deployed
```

---

## Phase 7: Verify Deployment (2 min)

```bash
# Check rollout status
kubectl rollout status deployment/hello-world-service -n dev --timeout=5m

# Check pods are running
kubectl get pods -n dev -l app.kubernetes.io/name=hello-world-service

# Check service exists
kubectl get svc hello-world-service -n dev

# Check APIRule exists (internet exposure)
kubectl get apirule hello-world-service -n dev
```

**Expected:**
- Deployment showing "successfully rolled out"
- Pods showing `2/2 Running` (app + Istio sidecar)
- Service with `8080` port
- APIRule with hostname `hello-world-service-dev`

---

## Phase 8: Test Internal Access (1 min)

```bash
# Port-forward to service
kubectl port-forward -n dev svc/hello-world-service 8080:8080 &
sleep 2

# Test health endpoint
curl http://localhost:8080/actuator/health

# Expected: {"status":"UP"}

# Stop port-forward
kill %1
```

---

## Phase 9: Get Public URL (1 min)

```bash
# Get APIRule host (v2 preferred, v1beta1 fallback)
APIRULE_HOST=$(kubectl get apirule hello-world-service -n dev -o jsonpath='{.spec.hosts[0]}' 2>/dev/null || true)
if [ -z "$APIRULE_HOST" ]; then
  APIRULE_HOST=$(kubectl get apirule hello-world-service -n dev -o jsonpath='{.spec.host}' 2>/dev/null || true)
fi
echo "Public hostname: $APIRULE_HOST"
echo "Full URL: https://$APIRULE_HOST"
```

---

## Phase 10: Test Public Endpoint (2 min)

```bash
# Resolve APIRule host
APIRULE_HOST=$(kubectl get apirule hello-world-service -n dev -o jsonpath='{.spec.hosts[0]}' 2>/dev/null || true)
if [ -z "$APIRULE_HOST" ]; then
  APIRULE_HOST=$(kubectl get apirule hello-world-service -n dev -o jsonpath='{.spec.host}' 2>/dev/null || true)
fi
ENDPOINT="https://$APIRULE_HOST"

# Test health (public)
curl -k $ENDPOINT/actuator/health

# Test greetings endpoint - requires XSUAA token
CLIENT_ID=$(kubectl get secret hello-world-xsuaa-binding-dev -n dev -o jsonpath='{.data.clientid}' | base64 -d)
CLIENT_SECRET=$(kubectl get secret hello-world-xsuaa-binding-dev -n dev -o jsonpath='{.data.clientsecret}' | base64 -d)
XSUAA_URL=$(kubectl get secret hello-world-xsuaa-binding-dev -n dev -o jsonpath='{.data.url}' | base64 -d)

TOKEN=$(curl -s -u "$CLIENT_ID:$CLIENT_SECRET" \
  -d "grant_type=client_credentials" \
  "$XSUAA_URL/oauth/token" | jq -r '.access_token')

curl -k -H "Authorization: Bearer $TOKEN" "$ENDPOINT/greet?name=Dev"

# Expected: JSON response with greeting
```

---

## Phase 11: View Logs (anytime)

```bash
# Real-time logs
kubectl logs -f -n dev -l app.kubernetes.io/name=hello-world-service

# Recent logs (last 50 lines)
kubectl logs -n dev -l app.kubernetes.io/name=hello-world-service --tail=50
```

---

## Status Check (anytime)

```bash
echo "=== Deployment Status ===" && \
kubectl get deployment -n dev && \
echo "" && \
echo "=== Pod Status ===" && \
kubectl get pods -n dev && \
echo "" && \
echo "=== Service & APIRule ===" && \
kubectl get svc,apirule -n dev && \
echo "" && \
echo "=== XSUAA Status ===" && \
kubectl get serviceinstance,servicebinding -n dev
```

---

## Troubleshooting Quick Fixes

### Pod not starting
```bash
kubectl describe pod -l app.kubernetes.io/name=hello-world-service -n dev
kubectl logs -n dev -l app.kubernetes.io/name=hello-world-service
```

### XSUAA stuck
```bash
bash platform-ops/k8s/xsuaa/namespaces/dev/scripts/reset-xsuaa.sh dev
# Then re-run Phase 4
```

### APIRule not ready
```bash
kubectl delete apirule hello-world-service -n dev
helm upgrade --install hello-world-service helm/hello-world-service \
  -f helm/hello-world-service/values-dev.yaml \
  --namespace dev --wait
```

### Full redeployment (clean slate)
```bash
# Delete everything
helm uninstall hello-world-service -n dev
kubectl delete apirule,servicebinding,serviceinstance -n dev --all

# Wait a moment
sleep 10

# Start from Phase 4 (XSUAA Provisioning)
```

---

## Estimated Total Time
- **First time setup:** 30-45 minutes (XSUAA provisioning takes time)
- **Subsequent redeployments:** 5-10 minutes (skip phases 1-5)
- **Simple rollback:** 1 minute (`helm rollback hello-world-service -n dev`)

---

## Success Criteria ✅

All of these should be true:
- [ ] BTP operator healthy in cluster
- [ ] Dev namespace exists and labeled
- [ ] Docker registry secret exists in dev
- [ ] XSUAA ServiceInstance ready
- [ ] XSUAA ServiceBinding ready
- [ ] Binding secret exists and has credentials
- [ ] Preflight check passes
- [ ] Helm deployment rolled out successfully
- [ ] Pods running with 2/2 containers
- [ ] Service exists on port 8080
- [ ] APIRule created with public hostname
- [ ] Health check responds (internal port-forward)
- [ ] Public endpoint responds with auth token
- [ ] Logs show no errors

🎉 **When all complete, dev is ready for testing!**


