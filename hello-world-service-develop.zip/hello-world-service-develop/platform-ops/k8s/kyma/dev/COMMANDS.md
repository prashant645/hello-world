# Dev Namespace - Quick Command Reference

Save this file and use it for quick lookups while working with dev namespace.

---

## Status Checks

### Overall Status
```bash
kubectl get all -n dev
kubectl get namespace,pvc,secret -n dev
```

### Application Status
```bash
# Deployment
kubectl get deployment -n dev
kubectl describe deployment hello-world-service -n dev
kubectl rollout status deployment/hello-world-service -n dev

# Pods
kubectl get pods -n dev
kubectl get pods -n dev -l app.kubernetes.io/name=hello-world-service
kubectl describe pod -n dev -l app.kubernetes.io/name=hello-world-service

# Service
kubectl get svc -n dev
kubectl endpoints hello-world-service -n dev
```

### XSUAA Status
```bash
# ServiceInstance
kubectl get serviceinstance -n dev
kubectl describe serviceinstance hello-world-xsuaa-dev -n dev

# ServiceBinding
kubectl get servicebinding -n dev
kubectl describe servicebinding hello-world-xsuaa-binding-dev -n dev

# Binding Secret
kubectl get secret hello-world-xsuaa-binding-dev -n dev
kubectl describe secret hello-world-xsuaa-binding-dev -n dev
```

### APIRule Status (Internet Exposure)
```bash
# APIRule
kubectl get apirule -n dev
kubectl describe apirule hello-world-service -n dev

# Get public hostname (v2 preferred, v1beta1 fallback)
kubectl get apirule hello-world-service -n dev -o jsonpath='{.spec.hosts[0]}' 2>/dev/null || \
kubectl get apirule hello-world-service -n dev -o jsonpath='{.spec.host}'

# Check APIRule readiness/state
kubectl get apirule hello-world-service -n dev -o jsonpath='{.status.state}' 2>/dev/null || \
kubectl get apirule hello-world-service -n dev -o yaml
```

### Logs

```bash
# Recent logs (tail)
kubectl logs -n dev -l app.kubernetes.io/name=hello-world-service --tail=50

# Follow logs (real-time)
kubectl logs -n dev -l app.kubernetes.io/name=hello-world-service -f

# Previous pod logs (if crashed)
kubectl logs -n dev -l app.kubernetes.io/name=hello-world-service --previous

# Logs from specific pod
kubectl logs -n dev <pod-name>

# All containers in pod (including Istio sidecar)
kubectl logs -n dev <pod-name> -c hello-world-service
kubectl logs -n dev <pod-name> -c istio-proxy
```

---

## Deployment

### Deploy/Update
```bash
# Deploy (create or update)
helm upgrade --install hello-world-service helm/hello-world-service \
  -f helm/hello-world-service/values-dev.yaml \
  -n dev --create-namespace --wait

# Deploy with custom image tag
helm upgrade --install hello-world-service helm/hello-world-service \
  -f helm/hello-world-service/values-dev.yaml \
  --set image.tag=v1.2.3 \
  -n dev --wait

# Dry-run (preview changes)
helm upgrade --install hello-world-service helm/hello-world-service \
  -f helm/hello-world-service/values-dev.yaml \
  -n dev --dry-run --debug
```

### Rollback
```bash
# List previous releases
helm history hello-world-service -n dev

# Rollback to previous version
helm rollback hello-world-service -n dev

# Rollback to specific revision
helm rollback hello-world-service 3 -n dev  # revision 3
```

### Uninstall
```bash
# Delete deployment but keep persistent data
helm uninstall hello-world-service -n dev

# Then manually clean up resources
kubectl delete apirule hello-world-service -n dev
kubectl delete svc hello-world-service -n dev
```

---

## Testing

### Internal Access (from your machine)
```bash
# Port-forward to service
kubectl port-forward -n dev svc/hello-world-service 8080:8080 &

# Test health
curl http://localhost:8080/actuator/health

# Test greeting
curl "http://localhost:8080/greet?name=Dev"

# Kill port-forward
kill %1
```

### External Access (Public URL)
```bash
# Preferred: APIRule HTTPS FQDN (APIRule v2)
HOST=$(kubectl get apirule hello-world-service -n dev -o jsonpath='{.spec.hosts[0]}' 2>/dev/null || true)
if [ -z "$HOST" ]; then
  HOST=$(kubectl get apirule hello-world-service -n dev -o jsonpath='{.spec.host}' 2>/dev/null || true)
fi

# Test public health endpoint
curl -k "https://${HOST}/actuator/health"

# End-to-end auth smoke test (auto-discovers HTTPS APIRule, falls back if unavailable)
bash platform-ops/k8s/xsuaa/test/scripts/test-xsuaa-auth.sh -n dev

# Strict pipeline-style validation
bash platform-ops/k8s/xsuaa/test/scripts/test-xsuaa-auth.sh \
  -n dev \
  --strict-scopes --require-https --require-apirule

# Optional explicit URL override
bash platform-ops/k8s/xsuaa/test/scripts/test-xsuaa-auth.sh \
  -n dev \
  --app-url "https://${HOST}"
```

---

## XSUAA Management

### Provision (One-time)
```bash
# Apply ServiceInstance
kubectl apply -f platform-ops/k8s/xsuaa/namespaces/dev/apps/hello-world-service/serviceinstance.yaml

# Wait for ready
kubectl wait --for=jsonpath='{.status.ready}'=true \
  serviceinstance/hello-world-xsuaa-dev -n dev --timeout=8m

# Apply ServiceBinding
kubectl apply -f platform-ops/k8s/xsuaa/namespaces/dev/apps/hello-world-service/servicebinding.yaml

# Wait for ready
kubectl wait --for=jsonpath='{.status.ready}'=true \
  servicebinding/hello-world-xsuaa-binding-dev -n dev --timeout=8m
```

### Reset
```bash
# Clean reset (handles stuck resources)
bash platform-ops/k8s/xsuaa/namespaces/dev/scripts/reset-xsuaa.sh dev

# Manual delete (if script fails)
kubectl delete servicebinding hello-world-xsuaa-binding-dev -n dev --ignore-not-found --wait=false
kubectl delete serviceinstance hello-world-xsuaa-dev -n dev --ignore-not-found --wait=false
kubectl wait --for=delete servicebinding/hello-world-xsuaa-binding-dev -n dev --timeout=45s || true
kubectl wait --for=delete serviceinstance/hello-world-xsuaa-dev -n dev --timeout=45s || true
```

### Get Credentials
```bash
# XSUAA URL
kubectl get secret hello-world-xsuaa-binding-dev -n dev -o jsonpath='{.data.url}' | base64 -d; echo

# Client ID
kubectl get secret hello-world-xsuaa-binding-dev -n dev -o jsonpath='{.data.clientid}' | base64 -d; echo

# Client Secret
kubectl get secret hello-world-xsuaa-binding-dev -n dev -o jsonpath='{.data.clientsecret}' | base64 -d; echo

# xsappname
kubectl get secret hello-world-xsuaa-binding-dev -n dev -o jsonpath='{.data.xsappname}' | base64 -d; echo
```

### Get OAuth Token
```bash
CLIENT_ID=$(kubectl get secret hello-world-xsuaa-binding-dev -n dev -o jsonpath='{.data.clientid}' | base64 -d)
CLIENT_SECRET=$(kubectl get secret hello-world-xsuaa-binding-dev -n dev -o jsonpath='{.data.clientsecret}' | base64 -d)
XSUAA_URL=$(kubectl get secret hello-world-xsuaa-binding-dev -n dev -o jsonpath='{.data.url}' | base64 -d)

curl -s -k -u "$CLIENT_ID:$CLIENT_SECRET" \
  -d "grant_type=client_credentials" \
  "$XSUAA_URL/oauth/token" | jq '.'
```

---

## Validation

### Preflight Check
```bash
# Complete validation before deployment
bash platform-ops/k8s/xsuaa/namespaces/dev/scripts/preflight-xsuaa.sh

# With custom namespace (if testing elsewhere)
NAMESPACE=qa bash platform-ops/k8s/xsuaa/namespaces/dev/scripts/preflight-xsuaa.sh
```

### Helm Validation
```bash
# Validate Helm chart syntax
helm lint helm/hello-world-service

# Render templates (see what will be deployed)
helm template hello-world-service helm/hello-world-service \
  -f helm/hello-world-service/values-dev.yaml \
  -n dev

# Validate against cluster API
helm upgrade --install hello-world-service helm/hello-world-service \
  -f helm/hello-world-service/values-dev.yaml \
  -n dev --dry-run=server
```

### Resource Validation
```bash
# Check resources exist
kubectl get ns dev
kubectl get secret docker-registry-secret -n dev
kubectl get secret sap-btp-service-operator -n dev
kubectl get secret hello-world-xsuaa-binding-dev -n dev
```

---

## Debugging

### Pod Debugging
```bash
# Exec into pod (bash shell)
kubectl exec -it -n dev <pod-name> -- bash

# View pod details
kubectl describe pod -n dev <pod-name>

# Check resource usage
kubectl top pod -n dev
kubectl top pod -n dev --containers

# Port-forward to specific pod
kubectl port-forward -n dev <pod-name> 8080:8080
```

### Event Logs
```bash
# Recent events in namespace
kubectl get events -n dev --sort-by='.lastTimestamp'

# Watch events (real-time)
kubectl get events -n dev -w
```

### YAML Inspection
```bash
# Get resource YAML
kubectl get deployment hello-world-service -n dev -o yaml
kubectl get pod <pod-name> -n dev -o yaml
kubectl get apirule hello-world-service -n dev -o yaml

# Compare deployed vs helm template
kubectl get deployment hello-world-service -n dev -o yaml > deployed.yaml
helm template hello-world-service helm/hello-world-service \
  -f helm/hello-world-service/values-dev.yaml -n dev > template.yaml
diff -u template.yaml deployed.yaml
```

---

## Namespace Management

### Setup
```bash
# Create namespace
kubectl create namespace dev

# Label for BTP operator
kubectl label namespace dev btp-operator=enabled --overwrite

# Copy BTP credentials
./platform-ops/k8s/btp-operator/copy-credentials.sh dev

# Create docker registry secret
kubectl create secret docker-registry docker-registry-secret \
  --docker-server=gtlc-docker.common.repositories.cloud.sap \
  --docker-username=<username> \
  --docker-password=<password> \
  -n dev
```

### Cleanup
```bash
# Delete all resources in namespace (but keep namespace)
kubectl delete all --all -n dev

# Delete namespace (all resources deleted)
kubectl delete namespace dev

# Delete specific resource types
kubectl delete deployment -n dev --all
kubectl delete servicebinding -n dev --all
kubectl delete serviceinstance -n dev --all
kubectl delete apirule -n dev --all
```

---

## Useful Aliases (Add to .bashrc or .zshrc)

```bash
alias k=kubectl
alias knd='kubectl -n dev'
alias kgp='kubectl get pods'
alias kgpd='kubectl get pods -n dev'
alias kdl='kubectl delete'
alias kl='kubectl logs'
alias klf='kubectl logs -f'
alias klnd='kubectl logs -n dev -f -l app.kubernetes.io/name=hello-world-service'
alias kex='kubectl exec -it'
alias kpf='kubectl port-forward'
alias kpfd='kubectl port-forward -n dev svc/hello-world-service 8080:8080'
alias kgh='kubectl get secret hello-world-xsuaa-binding-dev -n dev'
```

Usage:
```bash
kgpd                    # Get pods in dev
klnd                    # Follow logs in dev
kpfd &                  # Port-forward to dev
kgh -o yaml             # View XSUAA secret
```

---

## Common Workflows

### Full Redeployment
```bash
# 1. Uninstall previous version
helm uninstall hello-world-service -n dev

# 2. Delete resources
kubectl delete all --all -n dev

# 3. Redeploy
helm upgrade --install hello-world-service helm/hello-world-service \
  -f helm/hello-world-service/values-dev.yaml \
  -n dev --create-namespace --wait

# 4. Verify
kubectl rollout status deployment/hello-world-service -n dev
```

### Emergency Rollback
```bash
# Get previous working release
helm history hello-world-service -n dev

# Rollback immediately
helm rollback hello-world-service -n dev

# Verify rollout
kubectl rollout status deployment/hello-world-service -n dev
```

### Scale Deployment
```bash
# Scale replicas manually
kubectl scale deployment hello-world-service --replicas=3 -n dev

# Or edit values and redeploy
helm upgrade hello-world-service helm/hello-world-service \
  -f helm/hello-world-service/values-dev.yaml \
  --set replicaCount=3 -n dev --wait
```

---

## Performance Monitoring

### Resource Usage
```bash
# Current usage
kubectl top nodes
kubectl top pod -n dev

# Watch usage (real-time)
kubectl top pod -n dev --containers -w
```

### Metrics Query
```bash
# If Prometheus is available
# CPU usage
kubectl get --raw /apis/custom.metrics.k8s.io/v1beta1/namespaces/dev/pods/*/cpu_usage_seconds_total

# Memory usage
kubectl get --raw /apis/custom.metrics.k8s.io/v1beta1/namespaces/dev/pods/*/memory_working_set_bytes
```

---

## Common Issues Quick Fix

| Issue | Quick Command |
|-------|---------------|
| Pod not starting | `kubectl describe pod -n dev` |
| Image pull error | `kubectl get secret docker-registry-secret -n dev` |
| Pod crash | `kubectl logs -n dev <pod-name>` |
| XSUAA stuck | `bash platform-ops/k8s/xsuaa/namespaces/dev/scripts/reset-xsuaa.sh dev` |
| API not responding | `kubectl logs -n dev -l app.kubernetes.io/name=hello-world-service` |
| Can't access from outside | `kubectl get apirule hello-world-service -n dev` |
| Preflight failing | `bash platform-ops/k8s/xsuaa/namespaces/dev/scripts/preflight-xsuaa.sh` |

---

## Environment Info

```bash
# Current kubectl context
kubectl config current-context

# Cluster info
kubectl cluster-info

# Kyma version (if available)
kubectl get apiserver -o jsonpath='{.items[0].status.conditions[?(@.type=="Available")].message}'

# Node info
kubectl get nodes -o wide
```

---

**Quick Navigation:**
- 📋 Full setup guide → `SETUP.md`
- ✅ Step-by-step checklist → `CHECKLIST.md`
- 🏗️ Architecture details → `ARCHITECTURE.md`
- 📖 Kyma guide → `platform-ops/superpowers/Kyma.md`
- 📚 XSUAA guide → `platform-ops/k8s/xsuaa/README.md`


