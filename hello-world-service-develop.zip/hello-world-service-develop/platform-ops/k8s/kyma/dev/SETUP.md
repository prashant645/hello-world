# Dev Namespace Setup & Deployment Guide

Complete step-by-step guide to deploy `hello-world-service` to Kyma dev namespace with internet exposure via APIRule.

## Prerequisites

### Required
- `kubectl` configured with Kyma kubeconfig (token-based, not OIDC)
- `helm` 3.x installed
- `curl`, `jq` installed (for validation scripts)
- Access to BTP cockpit (for XSUAA backend verification)

### Expected to be Done
- ✅ BTP operator installed in cluster (via `platform-ops/k8s/btp-operator/README.md`)
- ✅ Kyma kubeconfig with ServiceAccount authentication (from `platform-ops/superpowers/Kyma.md`)
- ✅ Docker registry credentials in Vault (`piper/data/.../docker-config`)
- ✅ Helm chart with APIRule support (already added in this repo)

---

## Phase 1: Namespace Prerequisites (One-time Setup)

### Step 1.1: Create Dev Namespace

```bash
kubectl create namespace dev --dry-run=client -o yaml | kubectl apply -f -
```

### Step 1.2: Verify BTP Operator is Healthy

```bash
kubectl get pods -n sap-btp-operator
```

Expected: At least one pod with `2/2 Running` (manager + webhook).

**If not running:**
```bash
cd platform-ops/k8s/btp-operator
bash README.md  # Follow the setup guide
```

### Step 1.3: Copy BTP Credentials to Dev Namespace

This copies Service Manager credentials from the operator namespace into `dev`:

```bash
./platform-ops/k8s/btp-operator/copy-credentials.sh dev
```

### Step 1.4: Label Dev Namespace for Operator Webhook

```bash
kubectl label namespace dev btp-operator=enabled --overwrite
```

Verify:

```bash
kubectl get namespace dev -o jsonpath='{.metadata.labels.btp-operator}'; echo
# Expected: enabled
```

### Step 1.5: Create Docker Registry Secret in Dev

```bash
# Assuming docker-config is in Vault at:
# piper/data/sap-project-gtlcinfra-poc-1/hello-world-service/docker-config

# Get the base64-encoded docker-config from Vault and apply:
kubectl create secret docker-registry docker-registry-secret \
  --docker-server=gtlc-docker.common.repositories.cloud.sap \
  --docker-username=YOUR_USERNAME \
  --docker-password=YOUR_PASSWORD \
  --docker-email=ignored@example.com \
  -n dev

# Or if you have docker-config.json file:
kubectl create secret generic docker-registry-secret \
  --from-file=.dockerconfigjson=docker-config.json \
  --type=kubernetes.io/dockercfg \
  -n dev
```

### Step 1.6: Verify Namespace Credentials

```bash
kubectl get secret sap-btp-service-operator -n dev -o jsonpath='{.data.sm_url}' | base64 -d; echo
kubectl get secret sap-btp-service-operator -n dev -o jsonpath='{.data.clientid}' | base64 -d; echo
```

Expected outputs:
- `sm_url`: `https://service-manager.cfapps.sap.hana.ondemand.com`
- `clientid`: Should match operator secret

### Step 1.7: Apply Precreated Runtime ServiceAccounts

```bash
kubectl apply -f platform-ops/k8s/kyma/dev/hello-world-service-serviceaccount.yaml
```

This dev runtime ServiceAccount is referenced by the Kyma Helm values and should exist before app deployment.
Apply the QA and prod ServiceAccount manifests from their respective environment setup procedures.

---

## Phase 2: XSUAA Setup (One-time Setup)

XSUAA must be provisioned **before** app deployment. This happens once and persists.

### Step 2.1: Clean Reset (if restarting)

```bash
bash platform-ops/k8s/xsuaa/namespaces/dev/scripts/reset-xsuaa.sh dev
```

### Step 2.2: Provision XSUAA ServiceInstance

```bash
kubectl apply -f platform-ops/k8s/xsuaa/namespaces/dev/apps/hello-world-service/serviceinstance.yaml
```

Check status:

```bash
kubectl get serviceinstance hello-world-xsuaa-dev -n dev
kubectl wait --for=jsonpath='{.status.ready}'=true serviceinstance/hello-world-xsuaa-dev -n dev --timeout=8m
```

Expected: `READY=True`

### Step 2.3: Provision XSUAA ServiceBinding

```bash
kubectl apply -f platform-ops/k8s/xsuaa/namespaces/dev/apps/hello-world-service/servicebinding.yaml
```

Check status:

```bash
kubectl get servicebinding hello-world-xsuaa-binding-dev -n dev
kubectl wait --for=jsonpath='{.status.ready}'=true servicebinding/hello-world-xsuaa-binding-dev -n dev --timeout=8m
```

Expected: `READY=True`

### Step 2.4: Verify Binding Secret

```bash
kubectl get secret hello-world-xsuaa-binding-dev -n dev
```

Expected: Secret exists with keys: `url`, `clientid`, `clientsecret`, `xsappname`, etc.

---

## Phase 3: Deployment Validation Preflight

Before deploying the app, run comprehensive validation:

```bash
bash platform-ops/k8s/xsuaa/namespaces/dev/scripts/preflight-xsuaa.sh
```

This checks:
- ✅ Namespace exists
- ✅ BTP operator is healthy
- ✅ Namespace labeled correctly
- ✅ Credentials secrets exist and match
- ✅ ServiceInstance and ServiceBinding are Ready
- ✅ Binding secret exists
- ✅ Helm manifests are valid
- ✅ Helm XSUAA wiring is correct

**Must pass before proceeding to deployment.**

---

## Phase 4: Deploy Application

### Step 4.1: Deploy Hello World Service with Helm

```bash
helm upgrade --install hello-world-service helm/hello-world-service \
  -f helm/hello-world-service/values-dev.yaml \
  --namespace dev \
  --create-namespace \
  --wait \
  --timeout 5m
```

### Step 4.2: Wait for Deployment to Be Ready

```bash
kubectl rollout status deployment/hello-world-service -n dev --timeout=5m
```

Expected: `deployment "hello-world-service" successfully rolled out`

### Step 4.3: Verify Pod is Running

```bash
kubectl get pods -n dev -l app.kubernetes.io/name=hello-world-service
```

Expected: Pods in `Running` state with `2/2` (app + Istio sidecar)

### Step 4.4: Check Service and APIRule

```bash
kubectl get svc hello-world-service -n dev
kubectl get apirule hello-world-service -n dev
```

Expected:
- Service: `ClusterIP` on port `8080`
- APIRule: Should exist with hostname `hello-world-service-dev`

---

## Phase 5: Verify Deployment

### Step 5.1: Check Application Health (Internal)

```bash
kubectl port-forward -n dev svc/hello-world-service 8080:8080 &
sleep 2
curl http://localhost:8080/actuator/health
kill %1  # Stop port-forward
```

Expected: `{"status":"UP"}`

### Step 5.2: Get Public URL (Internet-Facing)

```bash
# Get the APIRule host (v2 preferred, v1beta1 fallback)
APIRULE_HOST=$(kubectl get apirule hello-world-service -n dev -o jsonpath='{.spec.hosts[0]}' 2>/dev/null || true)
if [ -z "$APIRULE_HOST" ]; then
  APIRULE_HOST=$(kubectl get apirule hello-world-service -n dev -o jsonpath='{.spec.host}' 2>/dev/null || true)
fi
echo "Endpoint host: $APIRULE_HOST"
```

Full URL: `https://$APIRULE_HOST`

Example: `https://hello-world-service-dev.c-1282d6a.stage.kyma.ondemand.com`

### Step 5.3: Test Public Endpoint

```bash
# Health endpoint (public)
curl -k "https://$APIRULE_HOST/actuator/health"

# Greeting endpoint
curl -k "https://$APIRULE_HOST/greet?name=TestUser"
```

Expected: 
- Health: `{"status":"UP"}`
- Greeting: Authenticated response (requires valid token from XSUAA)

---

## Phase 6: Access Application with Authentication

### Step 6.1: Get XSUAA Credentials from Binding Secret

```bash
XSUAA_URL=$(kubectl get secret hello-world-xsuaa-binding-dev -n dev -o jsonpath='{.data.url}' | base64 -d)
CLIENT_ID=$(kubectl get secret hello-world-xsuaa-binding-dev -n dev -o jsonpath='{.data.clientid}' | base64 -d)
CLIENT_SECRET=$(kubectl get secret hello-world-xsuaa-binding-dev -n dev -o jsonpath='{.data.clientsecret}' | base64 -d)

echo "XSUAA URL: $XSUAA_URL"
echo "Client ID: $CLIENT_ID"
```

### Step 6.2: Obtain Access Token

```bash
TOKEN=$(curl -s -u "$CLIENT_ID:$CLIENT_SECRET" \
  -d "grant_type=client_credentials" \
  "$XSUAA_URL/oauth/token" | jq -r '.access_token')

echo "Token obtained: ${TOKEN:0:20}..."
```

### Step 6.3: Call API with Token

```bash
APIRULE_HOST=$(kubectl get apirule hello-world-service -n dev -o jsonpath='{.spec.hosts[0]}' 2>/dev/null || true)
if [ -z "$APIRULE_HOST" ]; then
  APIRULE_HOST=$(kubectl get apirule hello-world-service -n dev -o jsonpath='{.spec.host}' 2>/dev/null || true)
fi
ENDPOINT="https://$APIRULE_HOST/greet?name=Kyma"

curl -k -H "Authorization: Bearer $TOKEN" "$ENDPOINT"
```

Expected: 
```json
{
  "greeting": "Hello Kyma!",
  "timestamp": "...",
  "user": "..."
}
```

---

## Phase 7: View Logs

### Application Logs

```bash
kubectl logs -n dev -l app.kubernetes.io/name=hello-world-service --tail=100
```

### Follow Logs in Real-Time

```bash
kubectl logs -n dev -l app.kubernetes.io/name=hello-world-service -f
```

### Previous Pod Logs (if pod crashed)

```bash
kubectl logs -n dev -l app.kubernetes.io/name=hello-world-service --previous
```

---

## Troubleshooting

### Pod Not Starting - ImagePullBackOff

```bash
kubectl describe pod -l app.kubernetes.io/name=hello-world-service -n dev

# Check docker registry secret exists
kubectl get secret docker-registry-secret -n dev

# Verify image tag exists in registry
# (Check with your docker registry credentials)
```

**Fix:**
- Verify docker credentials in Vault
- Ensure image tag is correct in `helm/hello-world-service/values-dev.yaml`
- Verify docker registry secret is in `dev` namespace

### Pod Crash - Health Check Failing

```bash
kubectl describe pod -l app.kubernetes.io/name=hello-world-service -n dev | grep -A 5 "Liveness\|Readiness"
```

**Fix:**
- Increase `initialDelaySeconds` in `helm/hello-world-service/values.yaml` if app startup is slow
- Verify health endpoint: `kubectl port-forward -n dev svc/hello-world-service 8080:8080` then `curl http://localhost:8080/actuator/health`

### XSUAA ServiceInstance/Binding Stuck

```bash
# Delete and reset
bash platform-ops/k8s/xsuaa/namespaces/dev/scripts/reset-xsuaa.sh dev

# Reapply
kubectl apply -f platform-ops/k8s/xsuaa/namespaces/dev/apps/hello-world-service/serviceinstance.yaml
kubectl apply -f platform-ops/k8s/xsuaa/namespaces/dev/apps/hello-world-service/servicebinding.yaml

# Wait for ready
kubectl wait --for=jsonpath='{.status.ready}'=true serviceinstance/hello-world-xsuaa-dev -n dev --timeout=8m
```

### APIRule Not Getting Public URL

```bash
# Check APIRule status
kubectl describe apirule hello-world-service -n dev

# Verify kyma-gateway exists
kubectl get gateway kyma-gateway -n kyma-system

# Verify service exists
kubectl get svc hello-world-service -n dev
```

**Fix:**
- Delete and redeploy:
  ```bash
  kubectl delete apirule hello-world-service -n dev
  helm upgrade --install hello-world-service helm/hello-world-service \
    -f helm/hello-world-service/values-dev.yaml \
    --namespace dev --wait
  ```

---

## Quick Status Check

Run this anytime to check overall health:

```bash
echo "=== Namespace ==="
kubectl get namespace dev

echo "=== XSUAA Resources ==="
kubectl get serviceinstance,servicebinding -n dev

echo "=== Application ==="
kubectl get deployment,pod,svc -n dev

echo "=== APIRule (Internet Exposure) ==="
kubectl get apirule -n dev

echo "=== Preflight Check ==="
bash platform-ops/k8s/xsuaa/namespaces/dev/scripts/preflight-xsuaa.sh
```

---

## Next Steps

1. ✅ Complete all phases above
2. ✅ Verify public endpoint is accessible
3. 📝 Note the public URL (save for QA/Prod reference)
4. 🔄 Test via GitHub Actions: Push to `develop` branch to trigger automated deployment
5. 📊 Monitor logs: `kubectl logs -f -n dev -l app.kubernetes.io/name=hello-world-service`


