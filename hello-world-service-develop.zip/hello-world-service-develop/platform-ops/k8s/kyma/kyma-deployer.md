Create kyma-deployer Service Account for each namespace

0. create namespaces
1. create kyma-deployer service account in each namespace
```
kubectl create serviceaccount kyma-deployer -n dev --dry-run=client -o yaml | kubectl apply -f -
kubectl create serviceaccount kyma-deployer -n qa --dry-run=client -o yaml | kubectl apply -f -
kubectl create serviceaccount kyma-deployer -n prod --dry-run=client -o yaml | kubectl apply -f -
```
(Using --dry-run=client | kubectl apply -f - is idempotent, so it is safe even if already exists.)

If you are migrating a runtime ServiceAccount from Helm-managed to bootstrap-owned, perform a one-time Helm upgrade first with `serviceAccount.create=true` plus annotation `helm.sh/resource-policy: keep`, then switch the chart back to `serviceAccount.create=false`. This prevents Helm from deleting the now-bootstrap-owned ServiceAccount during the ownership handoff.

2) Apply existing RBAC manifests
```
kubectl apply -f /Users/I819791/IdeaProjects/GTLCInfra/hello-world-service/platform-ops/k8s/xsuaa/namespaces/dev/rbac-kyma-deployer.yaml
kubectl apply -f /Users/I819791/IdeaProjects/GTLCInfra/hello-world-service/platform-ops/k8s/kyma/qa/kyma-deployer-namespace-rbac.yaml
kubectl apply -f /Users/I819791/IdeaProjects/GTLCInfra/hello-world-service/platform-ops/k8s/xsuaa/namespaces/prod/rbac-kyma-deployer.yaml
```
These namespace roles grant read-only access to runtime `serviceaccounts` so the pipeline can verify bootstrap-owned identities without creating, updating, or deleting them.

2.1) Apply shared discovery RBAC for reusable deploy workflow checks
```
kubectl apply -f /Users/I819791/IdeaProjects/GTLCInfra/hello-world-service/platform-ops/k8s/kyma/kyma-deployer-cluster-discovery-rbac.yaml
```
This grants minimal read access required by template checks:
- `kubectl get namespaces`
- `kubectl cluster-info` (reads `kube-system` services)
It also grants namespace create/patch for idempotent workflow command:
- `kubectl create namespace <ns> --dry-run=client -o yaml | kubectl apply -f -`

2.2) Apply dev/QA/prod cross-namespace RBAC for extended verification checks
```
kubectl apply -f /Users/I819791/IdeaProjects/GTLCInfra/hello-world-service/platform-ops/k8s/kyma/dev/kyma-deployer-cross-namespace-rbac.yaml
kubectl apply -f /Users/I819791/IdeaProjects/GTLCInfra/hello-world-service/platform-ops/k8s/kyma/qa/kyma-deployer-cross-namespace-rbac.yaml
kubectl apply -f /Users/I819791/IdeaProjects/GTLCInfra/hello-world-service/platform-ops/k8s/kyma/prod/kyma-deployer-cross-namespace-rbac.yaml
```
This grants environment-specific read access required by extended verification flows:
- `kubectl get gateway kyma-gateway -n kyma-system`
- `kubectl get pods -n sap-btp-operator -l app=sap-btp-operator`
- `kubectl get secret sap-btp-service-operator-credentials -n sap-btp-operator`

3) Create token secret per namespace
```
kubectl apply -f - <<'EOF'
apiVersion: v1
kind: Secret
metadata:
  name: kyma-deployer-token
  namespace: dev
  annotations:
    kubernetes.io/service-account.name: kyma-deployer
type: kubernetes.io/service-account-token
EOF

kubectl apply -f - <<'EOF'
apiVersion: v1
kind: Secret
metadata:
  name: kyma-deployer-token
  namespace: qa
  annotations:
    kubernetes.io/service-account.name: kyma-deployer
type: kubernetes.io/service-account-token
EOF

kubectl apply -f - <<'EOF'
apiVersion: v1
kind: Secret
metadata:
  name: kyma-deployer-token
  namespace: prod
  annotations:
    kubernetes.io/service-account.name: kyma-deployer
type: kubernetes.io/service-account-token
EOF

sleep 5
```
4) Generate the 3 kubeconfigs
```
mkdir -p kyma-kubeconfigs

CLUSTER_NAME="$(kubectl config view --minify -o jsonpath='{.clusters[0].name}')"
CLUSTER_SERVER="$(kubectl config view --minify -o jsonpath='{.clusters[0].cluster.server}')"
CLUSTER_CA="$(kubectl config view --minify --raw -o jsonpath='{.clusters[0].cluster.certificate-authority-data}')"

for ns in dev qa prod; do
  TOKEN="$(kubectl get secret kyma-deployer-token -n "$ns" -o jsonpath='{.data.token}' | base64 -d)"
  cat > "kyma-kubeconfigs/kubeconfig-${ns}.yaml" <<EOF
apiVersion: v1
kind: Config
clusters:
- cluster:
    certificate-authority-data: ${CLUSTER_CA}
    server: ${CLUSTER_SERVER}
  name: ${CLUSTER_NAME}
contexts:
- context:
    cluster: ${CLUSTER_NAME}
    namespace: ${ns}
    user: kyma-deployer-${ns}
  name: ${ns}
current-context: ${ns}
users:
- name: kyma-deployer-${ns}
  user:
    token: ${TOKEN}
EOF
done
```
5) Verify identity is namespace-specific
```
KUBECONFIG=kyma-kubeconfigs/kubeconfig-dev.yaml kubectl auth whoami
KUBECONFIG=kyma-kubeconfigs/kubeconfig-qa.yaml kubectl auth whoami
KUBECONFIG=kyma-kubeconfigs/kubeconfig-prod.yaml kubectl auth whoami
```
Expected:
```
system:serviceaccount:dev:kyma-deployer
system:serviceaccount:qa:kyma-deployer
system:serviceaccount:prod:kyma-deployer
```
6) Encode and upload to GitHub secrets
```
base64 -i kyma-kubeconfigs/kubeconfig-dev.yaml | tr -d '\n' > kyma-kubeconfigs/kubeconfig-dev.b64
base64 -i kyma-kubeconfigs/kubeconfig-qa.yaml | tr -d '\n' > kyma-kubeconfigs/kubeconfig-qa.b64
base64 -i kyma-kubeconfigs/kubeconfig-prod.yaml | tr -d '\n' > kyma-kubeconfigs/kubeconfig-prod.b64
```
Upload to:
```
KYMA_KUBECONFIG_DEV
KYMA_KUBECONFIG_QA
KYMA_KUBECONFIG_PROD
```
at https://github.tools.sap/GTLCInfra/hello-world-service/settings/secrets/actions.

