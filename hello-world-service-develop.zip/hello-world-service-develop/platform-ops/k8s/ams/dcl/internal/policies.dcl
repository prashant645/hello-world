POLICY readers {
  GRANT read ON DataResource;
}

POLICY writers {
  GRANT read ON DataResource;
  GRANT write ON DataResource;
}

POLICY admins {
  GRANT read ON DataResource;
  GRANT write ON DataResource;
  GRANT admin ON ConfigResource;
}


