Instead of manually copying DCL content into the ConfigMap YAML, use kubectl to generate it from the actual .dcl files:
```
dcl/> kubectl create configmap ams-dcl-files \
--from-file=./schema.dcl \
--from-file=./internal/policies.dcl \
--dry-run=client -o yaml > ./ams-dcl-configmap.yml
```
You will need to regenerate the configmap each time when modify the dcl files.
```bash
kubectl apply -f ./ams-dcl-configmap.yml -n dev
```
Do the same for qa and prod.
