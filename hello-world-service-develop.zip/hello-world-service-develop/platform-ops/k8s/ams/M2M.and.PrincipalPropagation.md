# Use Case 2: M2M + Human Principal Propagation

## Summary

The MCP server acts on behalf of a specific human user. The human authenticates to IAS (via
Joule's PKCE flow), and the MCP server exchanges that user token for a backend-scoped token
via RFC 8693. The resulting JWT carries both the MCP server's `ias_apis` claim and the human
user's `user_uuid`. The backend detects the `user_uuid`, enters the AMS two-tier resolution
path, and uses the human user's AMS policy assignment as the primary authorization decision.
The MCP server's `ias_apis` is the fallback only if the user has no AMS policy at all.

---

## Token Flow

```
Human user
    │
    │  1. Joule authenticates the human (PKCE / SSO — Joule's business)
    │     Joule obtains: user access token (aud = MCP server's clientid)
    ▼
MCP server
    │
    │  2. RFC 8693 token exchange (OBO)
    │     POST /oauth2/token
    │     grant_type=urn:ietf:params:oauth:grant-type:token-exchange
    │     subject_token=<user's id_token or access_token>
    │     resource=urn:sap:identity:application:provider:name:scope
    ▼
IAS tenant (a3enmtmdf.accounts400.ondemand.com)
    │
    │  3. issues OBO JWT with:
    │     aud:       [c76f51d5-8c27-4590-a972-070921dbff8c]  ← backend's clientid
    │     user_uuid: 9ae37bbf-fb04-46ed-a833-79c6b88ee45e   ← human user's identity
    │     ias_apis:  [writers]                               ← MCP's dependency permission
    │     sub:       jeffrey.shi@sap.com
    ▼
Backend (hello-world-service)
    │
    │  4. NimbusJwtDecoder validates: signature, expiry, issuer, audience
    │  5. iasJwtAuthenticationConverter:
    │       — extracts ias_apis → authority "writers"
    │       — detects user_uuid → injects authority "principal-propagation"
    │       — wraps in AuthenticationToken (principal = SapIdToken)
    │  6. JavaSecurityContextHolderStrategy.setContext()
    │       — SapIdToken instanceof Token → SecurityContext.setToken(sapIdToken)
    │  7. @PreAuthorize("hasAnyAuthority('writers','admins','principal-propagation')")
    │       → "principal-propagation" matches → passes gate
    │  8. isHumanUserToken() → true (user_uuid present) → enters OBO resolution
    ▼
resolveOboAuthorization()  [two-tier resolution — see below]
```

---

## Two-Tier Authorization Resolution

```
Step 1: AMS available?
    No  → 403 (fail-closed — AMS is required for all OBO requests)
    Yes → continue

Step 2: AMS grants the requested action for this user?
    Yes → 200 (user's AMS policy is the sole authority; ias_apis ignored)
    No  → continue

Step 3: Does the user have ANY AMS policy binding?
    Probe all known privilege pairs:
      read  / DataResource
      write / DataResource
      admin / ConfigResource

    BOUND   → at least one probe granted (user has a policy, just not enough for this action)
              → 403 (AMS is sole authority; no ias_apis fallback)

    ERROR   → at least one probe threw an exception, none were granted
              (AMS unavailable, bundle not downloaded, transient failure)
              → 403 (fail-closed)

    UNBOUND → all probes denied cleanly, no exceptions
              (user has an IAS account but no AMS policy assigned)
              → continue to Step 4

Step 4: No AMS policy → inherit MCP server's ias_apis as effective permission
    ias_apis absent or empty             → 403
    ias_apis present but insufficient    → 403
      (e.g. ias_apis=[readers] on a write endpoint)
    ias_apis qualifies for this action   → 200
```

---

## Authorization per Endpoint

| Endpoint | Action checked | Qualifying `ias_apis` for fallback |
|----------|----------------|------------------------------------|
| `POST /api/v1/greetings` | `read` on `DataResource` | `readers`, `writers`, `admins` |
| `GET /api/v1/greetings/config` | `read` on `DataResource` | `readers`, `writers`, `admins` |
| `POST /api/v1/greetings/update` | `write` on `DataResource` | `writers`, `admins` |

For AMS-bound users: the AMS policy grant/deny is final regardless of `ias_apis`.
For unbound users: `ias_apis` from the MCP server's dependency permission is inherited.

---

## Human User's IAS Account

The human user must have an account in the IAS tenant for Joule's authentication step to
succeed (Step 1). If the user has no IAS account, the PKCE flow fails at the IAS login page
— no token is issued and the backend is never reached.

Once the OBO token reaches the backend, the `user_uuid` claim is the user's identifier. The
backend does not care how Joule authenticated the user.

---

## AMS Policy Assignment

Users are assigned to AMS policies in IAS Admin Console:

IAS Admin Console → Applications → `ias-dev` → Authorization Policies → `readers` →
Members → Add User.

| AMS policy | Grants | Effect in two-tier resolution |
|------------|--------|-------------------------------|
| `readers` | `read` on `DataResource` | read endpoints allowed; write denied |
| `writers` | `read` + `write` on `DataResource` | read and write endpoints allowed |
| `admins` | `read` + `write` on `DataResource`, `admin` on `ConfigResource` | all endpoints allowed |
| _(none)_ | nothing | UNBOUND → `ias_apis` fallback applies |

Assignment takes effect on the next token issued. Existing tokens are not invalidated.

---

## Key Distinction from Pure M2M

| | M2M | M2M + Principal Propagation |
|--|-----|-----------------------------|
| Token carries `user_uuid` | No | Yes |
| AMS consulted | No | Yes (fail-closed) |
| Authorization source | MCP's `ias_apis` | User's AMS policy (primary), MCP's `ias_apis` (fallback if unbound) |
| Human IAS account required | No | Yes (for Joule's auth step) |
| AMS policy assignment required | No | No (falls back to `ias_apis` if unbound) |

---

## Diagnosing OBO Failures

**Token exchange fails (no OBO token issued):**
- User has no IAS account → Joule's PKCE flow fails before the backend is involved
- `resource` URN does not match backend's `provided-apis.name` → IAS rejects the exchange
- MCP app has no dependency configured on the backend in IAS

**401 Unauthorized at backend:**
- `aud` mismatch: `IAS_CLIENT_ID` in pod does not match `clientid` in `ias-secret`
- Token expired or wrong issuer

**403 on every OBO request, AMS available:**
- `user_uuid` present but AMS returning `denied` → check AMS policy assignment in IAS
- Use `scripts/ias-obo-token-exchange.sh` to confirm `user_uuid` is in the exchanged token
  (ensure `REDIRECT_URI` port matches what is registered in the MCP app in IAS — see Token Inspection section below)
- Check pod logs for the AMS privilege decision line:
  ```
  kubectl logs -n dev -l app.kubernetes.io/name=hello-world-service | grep "AMS privilege decision"
  ```
  `granted=false, denied=true` with `available=true` → user is BOUND to a policy that
  doesn't cover this action, or the SAP SecurityContext is not being populated (see Bug 3
  in `README.md`)

**403 on OBO, AMS unavailable:**
- `AMS initialised: available=false` → `authorization_bundle_url` missing from `ias-secret`
  → ServiceInstance created without `authorization: enabled: true`
- AMS is fail-closed for all OBO requests; M2M requests are unaffected

---

## Token Inspection: `scripts/ias-obo-token-exchange.sh`

Run this script from your local machine to obtain a real OBO token for a human user and
inspect its claims before it reaches the backend. It performs the full PKCE authorization-code
flow + RFC 8693 token exchange and prints key claims from the resulting JWT.

**Important:** The `REDIRECT_URI` port must exactly match one of the redirect URIs registered
in the MCP app's OpenID Connect Configuration in IAS Admin Console. The script default is
`http://localhost:18766/mcp-callback`. If you registered a different port, override it:

```bash
# Default port (18766 must be registered in IAS for the MCP app)
MCP_CLIENT_SECRET=<your-mcp-client-secret> \
  bash scripts/ias-obo-token-exchange.sh

# Different port (e.g. 18767)
REDIRECT_URI=http://localhost:18767/mcp-callback \
MCP_CLIENT_SECRET=<your-mcp-client-secret> \
  bash scripts/ias-obo-token-exchange.sh
```

What to check in the output (exchanged backend token claims):

```json
{
  "ias_apis":  ["writers"],                                  ← must match required permission
  "aud":       ["c76f51d5-8c27-4590-a972-070921dbff8c"],    ← must match IAS_CLIENT_ID in pod
  "user_uuid": "9ae37bbf-fb04-46ed-a833-79c6b88ee45e"       ← must be present for OBO path
}
```

If `user_uuid` is absent: the subject token passed to IAS was not a user token (it was a
client credentials token). Joule must supply a user identity token as `subject_token`.

If `user_uuid` is present but AMS returns `denied`: check the user's AMS policy assignment
in IAS Admin Console → Applications → `ias-dev` → Authorization Policies → `readers` →
Members. If the user has no policy assigned (UNBOUND), the `ias_apis` fallback applies.

If `aud` does not contain the backend's `clientid`: the `resource` URN used in the token
exchange does not match `provided-apis.name` in the backend's ServiceInstance.

See `README.md` for full script environment variable reference.
