# Spring Boot + IAS + AMS: End-to-End Implementation Guide

This section documents the complete, working implementation and the non-obvious bugs that were
found and fixed during bring-up. Read this before touching the security stack.

---

## How It Works End-to-End

The full request flow from an incoming JWT to an AMS privilege decision has five layers. Every
layer must be wired correctly — a silent failure in any one of them causes AMS to deny all
requests with no useful error message.

```
HTTP request with Bearer token
        │
        ▼
1. NimbusJwtDecoder          (SecurityConfig.jwtDecoder)
   — validates signature, expiry, issuer, audience
   — produces Spring Jwt object
        │
        ▼
2. iasJwtAuthenticationConverter  (SecurityConfig.iasJwtAuthenticationConverter)
   — extracts Spring GrantedAuthority list from ias_apis / scope / groups claims
   — wraps result in SAP AuthenticationToken(jwt, authorities)
   — AuthenticationToken.getPrincipal() returns SapIdToken (implements SAP Token)
        │
        ▼
3. JavaSecurityContextHolderStrategy.setContext()   (installed by HybridIdentityServicesAutoConfiguration)
   — called by Spring Security after authentication
   — checks: authentication.getPrincipal() instanceof com.sap.cloud.security.token.Token
   — if true → SecurityContext.setToken(sapIdToken)   ← populates SAP thread-local
        │
        ▼
4. AmsAuthorizationService.checkPrivilege(action, resource)
   — calls Authorizations.checkPrivilege() from spring-boot-starter-ams
   — internally calls Principal.fromSecurityContext()
   — reads com.sap.cloud.security.token.SecurityContext.getToken()  ← SAP thread-local
   — resolves user_uuid from SapIdToken → looks up AMS policy assignment
        │
        ▼
5. DCL policy evaluation
   — POLICY readers { GRANT read ON DataResource; }
   — user assigned to "readers" group in IAS → granted=true
```

---

## Correct Source Code Implementation

### 1. `application-cloud.yml` — auto-configuration exclusions

`HybridIdentityServicesAutoConfiguration` **must NOT be excluded**. It installs
`JavaSecurityContextHolderStrategy` as the active `SecurityContextHolderStrategy`. Without it,
step 3 above never runs and the SAP `SecurityContext` thread-local is never populated.

Only exclude `XsuaaTokenFlowAutoConfiguration` (no XSUAA binding is present):

```yaml
spring:
  autoconfigure:
    exclude:
      - com.sap.cloud.security.spring.autoconfig.XsuaaTokenFlowAutoConfiguration
```

### 2. `SecurityConfig.java` — three required beans

#### `jwtDecoder()` — explicit bean, not auto-configured

Both Spring Boot and the SAP starter use `@ConditionalOnMissingBean(JwtDecoder.class)`. When
both are on the classpath the winner is non-deterministic — whichever auto-configuration runs
first wins. Fix: declare an explicit `@Bean` so neither auto-configuration fires.

```java
@Bean
public JwtDecoder jwtDecoder() {
    NimbusJwtDecoder decoder = JwtDecoders.fromIssuerLocation(issuerUri);
    List<OAuth2TokenValidator<Jwt>> validators = new ArrayList<>();
    validators.add(JwtValidators.createDefaultWithIssuer(issuerUri));
    if (!clientId.isBlank()) {
        validators.add(token -> token.getAudience().contains(clientId)
            ? OAuth2TokenValidatorResult.success()
            : OAuth2TokenValidatorResult.failure(new OAuth2Error("invalid_token",
                "Token audience does not include client ID " + clientId, null)));
    }
    decoder.setJwtValidator(new DelegatingOAuth2TokenValidator<>(validators));
    return decoder;
}
```

`IAS_CLIENT_ID` is sourced from the IAS secret in `deployment.yaml`:
```yaml
- name: IAS_CLIENT_ID
  valueFrom:
    secretKeyRef:
      name: {{ .Values.ias.bindingSecretName }}
      key: clientid
```

#### `iasJwtAuthenticationConverter()` — must return `AuthenticationToken`, not `JwtAuthenticationToken`

This is the most critical wiring point. Spring's `JwtAuthenticationConverter` returns
`JwtAuthenticationToken`, whose `getPrincipal()` returns a Spring `Jwt` object. The SAP
`JavaSecurityContextHolderStrategy.setContext()` checks
`authentication.getPrincipal() instanceof com.sap.cloud.security.token.Token` — a Spring `Jwt`
is not a SAP `Token`, so `SecurityContext.setToken()` is never called, and AMS sees no user.

Fix: return SAP's `AuthenticationToken` instead. Its constructor calls
`Token.create(jwt.getTokenValue())` which uses `HybridTokenFactory` (registered via
`ServiceLoader` in `java-security-4.1.2.jar`) to produce a `SapIdToken`. Its `getPrincipal()`
returns the `SapIdToken`, passing the `instanceof Token` check.

```java
@Bean
public Converter<Jwt, ? extends AbstractAuthenticationToken> iasJwtAuthenticationConverter() {
    JwtGrantedAuthoritiesConverter defaults = new JwtGrantedAuthoritiesConverter();
    return jwt -> {
        Set<GrantedAuthority> authorities = new LinkedHashSet<>(defaults.convert(jwt));
        for (String shortAuthority : extractShortAuthorities(jwt)) {
            authorities.add(new SimpleGrantedAuthority(shortAuthority));
        }
        for (String shortAuthority : extractConfiguredClientAuthorities(jwt, readClientIds, writeClientIds)) {
            authorities.add(new SimpleGrantedAuthority(shortAuthority));
        }
        return new AuthenticationToken(jwt, authorities);  // ← SAP subclass, not Spring's
    };
}
```

Required import: `com.sap.cloud.security.spring.token.authentication.AuthenticationToken`

#### `amsAuthorizationService()` — lazy ApplicationContext lookup

`SecurityConfig` is initialized before AMS auto-configuration runs. If
`SciAuthorizationsProvider` is resolved eagerly in the constructor it will always be `null`.
Pass `ApplicationContext` and resolve lazily on the first request:

```java
@Bean
public AmsAuthorizationService amsAuthorizationService(ApplicationContext applicationContext) {
    return new AmsAuthorizationService(applicationContext);
}
```

### 3. Controller — do not use `@AuthenticationPrincipal Jwt`

After the converter change, `authentication.getPrincipal()` returns a `SapIdToken`, not a
`Jwt`. Spring's `@AuthenticationPrincipal` injects whatever `getPrincipal()` returns, so
`@AuthenticationPrincipal Jwt jwt` will inject `null`.

Extract the `Jwt` from the `Authentication` directly — `AuthenticationToken` extends
`JwtAuthenticationToken`, so `getToken()` always returns the original `Jwt`:

```java
// ✗ broken after AuthenticationToken change
public ResponseEntity<?> updateConfiguration(@AuthenticationPrincipal Jwt jwt, Authentication authentication)

// ✓ correct
public ResponseEntity<?> updateConfiguration(Authentication authentication) {
    Jwt jwt = authentication instanceof JwtAuthenticationToken jat ? (Jwt) jat.getToken() : null;
    ...
}
```

### 4. DCL policies — names must match IAS API permission group names exactly

The policy name in `policies.dcl` must match the group name assigned in IAS exactly, including
case. The IAS API permission group is named `readers` (lowercase) and the DCL policy must also
be `readers`:

```
POLICY readers {
  GRANT read ON DataResource;
}
```

Assigning a user to the `readers` group in IAS → `user_uuid` claim is present in the token →
`SapIdToken.getPrincipal()` resolves the user → AMS evaluates the `GRANT read` → `granted=true`.

---

## Bugs Found and Fixed

### Bug 1 — `HybridIdentityServicesAutoConfiguration` was excluded

**Symptom:** AMS reports `available=true` but every `checkPrivilege()` returns `granted=false,
denied=true` regardless of IAS policy assignment. No error in logs.

**Root cause:** `application-cloud.yml` excluded `HybridIdentityServicesAutoConfiguration`.
This auto-configuration installs `JavaSecurityContextHolderStrategy` as the active Spring
`SecurityContextHolderStrategy`. Without it, `SecurityContext.setToken()` is never called on
any request, so `Principal.fromSecurityContext()` returns `null`, and AMS evaluates every
privilege check against an anonymous/unknown identity.

**Fix:** Remove `HybridIdentityServicesAutoConfiguration` from the exclusion list. The `IasJwtDecoder`
it would register is suppressed by `@ConditionalOnMissingBean(JwtDecoder.class)` once the
explicit `jwtDecoder()` bean is present (Bug 2 fix), so there is no decoder conflict.

---

### Bug 2 — Non-deterministic `JwtDecoder` selection

**Symptom:** Works in some deployments, fails in others. Spring Boot's
`spring.security.oauth2.resourceserver.jwt.issuer-uri` auto-configuration and the SAP starter
both use `@ConditionalOnMissingBean(JwtDecoder.class)`. The one that runs first wins — the
order depends on classpath scan order, which is not guaranteed.

**Fix:** Declare an explicit `@Bean public JwtDecoder jwtDecoder()` in `SecurityConfig`. Both
auto-configurations detect the bean and back off. The explicit bean also adds audience
validation against `IAS_CLIENT_ID`.

---

### Bug 3 — `JwtAuthenticationConverter` breaks the SAP SecurityContext bridge

**Symptom:** Same as Bug 1 — `granted=false` for all AMS checks — even after Bug 1 is fixed.
`HybridIdentityServicesAutoConfiguration` is active, `JavaSecurityContextHolderStrategy` is
installed, but the SAP `SecurityContext` thread-local is still never populated.

**Root cause:** `JavaSecurityContextHolderStrategy.setContext()` contains this check (confirmed
by bytecode inspection of `spring-security-3-4.1.2.jar`):

```java
Object principal = context.getAuthentication().getPrincipal();
if (principal instanceof com.sap.cloud.security.token.Token) {
    SecurityContext.setToken((Token) principal);
}
```

Spring's `JwtAuthenticationConverter` returns `JwtAuthenticationToken`. Its `getPrincipal()`
returns a Spring `Jwt` object. `Jwt` does not implement SAP's `Token` interface — the
`instanceof` check fails, `setToken()` is never called, and `Principal.fromSecurityContext()`
returns `null` on every request.

**Fix:** Replace `JwtAuthenticationConverter` with a converter that returns SAP's
`AuthenticationToken`. The constructor `new AuthenticationToken(jwt, authorities)` calls
`Token.create(jwt.getTokenValue())`, which uses `HybridTokenFactory` (registered via
`ServiceLoader` in `java-security-4.1.2.jar`) to detect IAS tokens (absence of `ext_attr` /
`"zid":"uaa"` in the payload) and produce a `SapIdToken`. `AuthenticationToken.getPrincipal()`
returns that `SapIdToken`, which implements `Token` — the `instanceof` check passes,
`SecurityContext.setToken()` is called, and AMS resolves the correct user identity.

---

### Bug 4 — `@AuthenticationPrincipal Jwt jwt` injects `null` after Bug 3 fix

**Symptom:** `resolveUsername()` always returns `"unknown"` for the `updateConfiguration`
endpoint after deploying the Bug 3 fix.

**Root cause:** `@AuthenticationPrincipal` injects `authentication.getPrincipal()`. After the
Bug 3 fix, `getPrincipal()` returns a `SapIdToken`, not a `Jwt`. Spring's argument resolver
attempts to cast it to `Jwt` and injects `null` instead.

**Fix:** Remove `@AuthenticationPrincipal Jwt jwt` from the method signature. Extract the `Jwt`
from the `Authentication` object — `AuthenticationToken extends JwtAuthenticationToken`, so
`((JwtAuthenticationToken) authentication).getToken()` always returns the original `Jwt`
regardless of what `getPrincipal()` returns.

---

## Confirmed Working Log Output

After all four fixes are deployed, a human OBO request produces:

```
AMS initialised: available=true
AMS privilege decision [action=read, resource=DataResource, granted=true, denied=false, conditional=false, attrs=[]]
```

---

## IAS and AMS Configuration

This section documents every configuration knob that connects IAS, AMS, the backend service,
and the MCP client. Each knob is cross-referenced to where it lives in this repository and
where it must be set in the IAS admin console.

### Overview: what talks to what

```
IAS tenant (a3enmtmdf.accounts400.ondemand.com)
│
├── Application: ias-dev  (hello-world-service, ServiceInstance / BTP app registration in IAS)
│   ├── provided-apis: hello-world-service-iasams-dev   ← backend declares its API
│   ├── authorization: enabled: true                    ← activates AMS for this app
│   ├── Authorization Policies: readers / writers / admins  ← from DCL, assigned to users
│   └── ServiceBinding: ias-secret  (X.509)             ← mounted into the backend pod
│
├── Application: hello-world-mcp-iasams-dev (hello-world-mcp, MCP Server app entry in IAS)
│   └── consumed-apis:
│         dependency-name: scope                        ← matches IAS_CLIENT_DEPENDENCY_NAME
│         api-name: hello-world-service-iasams-dev      ← must match provided-apis.name above
│         ← IAS injects ias_apis: [<policy>] into exchanged tokens
│
└── Users: e.g. jeffrey.shi@sap.com
    └── assigned to Authorization Policy "readers" in IAS admin console
```

---

### IAS ServiceInstance

File: `platform-ops/k8s/ams/one-time/<env>/ias.serviceinstance.yml`

```yaml
spec:
  serviceOfferingName: identity
  servicePlanName: application
  externalName: ias-dev           # the app name visible in IAS admin console
  parameters:
    display-name: "ias-dev"
    authorization:
      enabled: true               # REQUIRED — activates AMS; omitting this means no AMS bundle
    provided-apis:
      - name: hello-world-service-iasams-dev   # logical API name
        description: "Hello World Service with IAS and AMS"
```

**`authorization.enabled: true`** is the single switch that provisions the AMS instance and
links it to this IAS application. Without it the secret will be missing
`authorization_bundle_url` and `authorization_instance_id`, and
`AMS initialised: available=false` at startup.

**`provided-apis.name`** is the identifier the MCP client references in its `consumed-apis`
dependency. This name also appears in the `resource` URN for RFC 8693 token exchange:
`urn:sap:identity:application:provider:name:<provided-apis.name>`.

| Env | `externalName` / IAS app name | `provided-apis.name` |
|-----|-------------------------------|----------------------|
| dev | `ias-dev` | `hello-world-service-iasams-dev` |
| qa | `ias-qa` | `hello-world-service-iasams-qa` |
| prod | `ias-prod` | `hello-world-service-iasams-prod` |

---

### IAS ServiceBinding — runtime (backend pod)

File: `platform-ops/k8s/ams/one-time/<env>/ias.servicebinding.yml`

```yaml
spec:
  serviceInstanceName: ias-dev
  secretName: ias-secret          # mounted into the pod at /bindings/ias-secret
  parameters:
    credential-type: X509_GENERATED
    validity: 365
    validity-type: DAYS
```

The generated secret `ias-secret` contains:

| Key | Purpose |
|-----|---------|
| `clientid` | Backend's IAS client ID — injected as `IAS_CLIENT_ID` in the pod for audience validation |
| `certificate` / `key` | X.509 mTLS credential used by the AMS bundle downloader |
| `authorization_bundle_url` | URL the AMS SDK polls to download the policy bundle |
| `authorization_instance_id` | AMS instance identifier |
| `url` | IAS tenant base URL |

The `deployment.yaml` mounts this secret both as a volume (for AMS bundle loading via
`SERVICE_BINDING_ROOT`) and as individual env vars:

```yaml
env:
  - name: SERVICE_BINDING_ROOT
    value: "/bindings"
  - name: IAS_ISSUER_URI
    value: {{ .Values.ias.issuerUri }}        # https://a3enmtmdf.accounts400.ondemand.com
  - name: IAS_CLIENT_ID
    valueFrom:
      secretKeyRef:
        name: {{ .Values.ias.bindingSecretName }}   # ias-secret
        key: clientid
volumeMounts:
  - name: ias-binding
    mountPath: /bindings/{{ .Values.ias.bindingSecretName }}   # /bindings/ias-secret
```

`SERVICE_BINDING_ROOT=/bindings` is the SAP convention. The AMS SDK scans subdirectories
under this path for service bindings. The binding must be at
`/bindings/<secretName>/` — the volume mount path must match the secret name exactly.

---

### IAS ServiceBinding — DCL deployer (one-time job)

File: `platform-ops/k8s/ams/one-time/<env>/ias-<env>-deployer-binding.yml`

```yaml
spec:
  serviceInstanceName: ias-dev    # same ServiceInstance as the runtime binding
  secretName: ias-dev-deployer-secret
  parameters:
    credential-type: X509_GENERATED
    validity: 365
    validity-type: DAYS
```

A separate binding from the same ServiceInstance, used only by the DCL deployer job. Keeping
it separate means the deployer credential can be rotated or revoked independently of the
runtime credential. The deployer job mounts it at `/bindings/ias-dev-deployer-secret`.

---

### AMS DCL policies

File: `platform-ops/k8s/ams/dcl/internal/policies.dcl`

```
POLICY readers {
  GRANT read ON DataResource;
}

POLICY writers {
  GRANT read ON DataResource;
  GRANT write ON DataResource;
}

POLICY admins {
  GRANT read ON DataResource;
  GRANT write ON DataResource;
  GRANT admin ON ConfigResource;
}
```

Policy names (`readers`, `writers`, `admins`) must match the IAS Authorization Policy names
exactly — case-sensitive. IAS admin console shows these as the policy names under
Authorization Policies after the DCL deployer job runs. Users are assigned to policies in IAS
directly (not in code).

The `DataResource` and `ConfigResource` names and the `read` / `write` / `admin` actions must
match the strings passed to `amsAuthorizationService.checkPrivilege(action, resource)` in the
backend code.

---

### IAS admin console — manual steps

These steps cannot be done via Kubernetes manifests and must be performed in the IAS admin
console after the ServiceInstance and DCL deployer job are complete.

**1. Assign users to Authorization Policies**

IAS Admin Console → Applications → `ias-dev` → Authorization Policies → `readers` →
Members → Add User.

The user must exist in the IAS tenant. Search by email or `user_uuid`. Assignment takes effect
on the next token issued — existing sessions are not updated.

**2. Configure the MCP client's dependency on the backend**

IAS Admin Console → Applications → `<MCP server app>` → Dependencies → Add:

| Field | Value |
|-------|-------|
| Dependency Name | `scope` |
| Application | `ias-dev` (the backend IAS app) |
| API | `hello-world-service-iasams-dev` |

The **Dependency Name** (`scope`) must match `IAS_CLIENT_DEPENDENCY_NAME` in the backend's
`deployment.yaml` (via `values.yaml: clientDependencyName: scope`). IAS injects
`ias_apis: [<policy>]` into the exchanged token based on the MCP client's API permission
level for this dependency.

**3. Set the API permission level on the dependency**

After adding the dependency, set the API permission level (e.g. `writers`) for the MCP
application. This controls the maximum `ias_apis` value IAS will inject — it caps what the
MCP server can request, regardless of what the individual user is assigned to.

---

### Backend environment variables reference

Set in `helm/hello-world-service/templates/deployment.yaml`, sourced from `values.yaml` and
the IAS secret.

| Variable | Source | Purpose |
|----------|--------|---------|
| `SERVICE_BINDING_ROOT` | hardcoded `/bindings` | Tells SAP SDK where to find service bindings |
| `SPRING_PROFILES_ACTIVE` | hardcoded `cloud` | Activates `application-cloud.yml` |
| `IAS_ISSUER_URI` | `values.yaml: ias.issuerUri` | JWT issuer for `NimbusJwtDecoder` and `SecurityConfig` |
| `IAS_CLIENT_ID` | `ias-secret: clientid` | Audience claim expected in incoming JWTs |
| `SAP_AMS_ENABLED` | hardcoded `true` | Enables AMS SDK |
| `SAP_SECURITY_SERVICES_IDENTITY_DOMAIN` | `values.yaml: ias.domain` | IAS domain for SAP SDK |
| `SAP_SECURITY_SERVICES_IDENTITY_DOMAINS` | `values.yaml: ias.domains` | Trusted IAS domains |
| `IAS_CLIENT_DEPENDENCY_NAME` | `values.yaml: ias.clientDependencyName` (`scope`) | Must match the MCP client's dependency name in IAS |
| `IAS_READ_CLIENT_IDS` | `values.yaml: ias.readClientIds` | M2M client IDs granted read without `ias_apis` |
| `IAS_WRITE_CLIENT_IDS` | `values.yaml: ias.writeClientIds` | M2M client IDs granted write without `ias_apis` |

---

## Troubleshooting

Most AMS failures are silent: the application starts cleanly, IAS authentication succeeds, but
every privilege check returns `granted=false`. Use the checklist and tools below to isolate
which layer is broken.

### Diagnostic checklist

**Step 1 — confirm the token contains `user_uuid`**

AMS resolves the user from the `user_uuid` claim. If it is absent, AMS sees an anonymous
caller and denies everything. Use the script below to inspect token claims before the token
even reaches the backend.

**Step 2 — confirm AMS is available in the pod**

```
kubectl logs -n dev -l app.kubernetes.io/name=hello-world-service | grep "AMS initialised"
```

Expected: `AMS initialised: available=true`

If `available=false`: the IAS binding secret is missing `authorization_bundle_url` or
`authorization_instance_id`. Verify:
```bash
kubectl get secret <ias-binding-secret> -n dev -o json | jq '.data | keys'
```
Both keys must be present. If absent, the IAS ServiceInstance was created without
`authorization: enabled: true` — re-create it.

**Step 3 — confirm the privilege decision log line**

```
kubectl logs -n dev -l app.kubernetes.io/name=hello-world-service | grep "AMS privilege decision"
```

`granted=true` → working.
`granted=false, denied=true` with no error → the user identity is not reaching AMS. The most
likely causes are Bug 1 or Bug 3 from the implementation section above (missing
`HybridIdentityServicesAutoConfiguration`, or wrong authentication token type).

**Step 4 — confirm DCL policies are deployed and named correctly**

In IAS Admin Console → your application → Authorization Policies, the policies listed must
match the names in `policies.dcl` exactly (case-sensitive: `readers`, not `ReadersPolicy`).
If the table is empty, the DCL deployer job has not run successfully — check its logs:
```bash
kubectl logs job/ams-dcl-deployer -n dev -c deployer
```

**Step 5 — confirm the user is assigned to the policy in IAS**

IAS Admin Console → your application → Authorization Policies → `readers` → Members. The user
must appear there. Assignment is by IAS user, not by email — search for the `user_uuid` value
from the token if the display name is ambiguous.

---

### `scripts/ias-obo-token-exchange.sh` — end-to-end token inspector

This script performs the complete human-user flow from your local machine:

1. PKCE authorization-code flow → IAS login page in your browser
2. Exchanges the authorization-code for an IAS user token
3. RFC 8693 token exchange (OBO) → backend-scoped access token
4. Prints key claims from both tokens
5. Optionally calls the backend with the exchanged token and shows the HTTP response

It is the fastest way to verify that the token reaching the backend actually contains the
claims AMS needs, without having to deploy anything.

**Prerequisites:** `curl`, `jq`, `openssl`, `python3`

**Usage:**

```bash
# Minimal — uses defaults for this tenant
MCP_CLIENT_SECRET=<your-mcp-client-secret> \
  bash scripts/ias-obo-token-exchange.sh

# With backend call
MCP_CLIENT_SECRET=<secret> \
BACKEND_URL=https://hello-world-service-dev.cfapps.eu01-canary.hana.ondemand.com \
  bash scripts/ias-obo-token-exchange.sh
```

The script opens the IAS login URL in your browser automatically (macOS). On other platforms
copy and open it manually. After you sign in the callback is captured on the port parsed from
`REDIRECT_URI` (default `18766`) and the script continues without further input.

**Important:** The port in `REDIRECT_URI` must exactly match one of the redirect URIs
registered in the MCP app's OpenID Connect Configuration in IAS Admin Console. The script
derives its callback listener port from `REDIRECT_URI`, so overriding the variable is
sufficient — no other change is needed:
```bash
REDIRECT_URI=http://localhost:18767/mcp-callback \
MCP_CLIENT_SECRET=<secret> \
  bash scripts/ias-obo-token-exchange.sh
```

**What to look for in the output:**

```json
// Authorization-code token claims (MCP-scoped, pre-exchange):
{
  "sub": "jeffrey.shi@sap.com",
  "user_uuid": "9ae37bbf-fb04-46ed-a833-79c6b88ee45e",   ← must be present
  "sap_id_type": "user",
  "ias_apis": null,                                        ← expected: MCP token has no ias_apis
  "aud": ["32e0450f-44a1-40ec-a4f4-292777d52eca"]
}

// Exchanged backend token claims (backend-scoped, post-exchange):
{
  "sub": "jeffrey.shi@sap.com",
  "user_uuid": "9ae37bbf-fb04-46ed-a833-79c6b88ee45e",   ← must be present
  "sap_id_type": "user",
  "ias_apis": ["writers"],                                 ← reflects MCP's dependency on the backend
  "aud": ["c76f51d5-8c27-4590-a972-070921dbff8c"]         ← must match IAS_CLIENT_ID
}
```

If `user_uuid` is absent in the exchanged token: the IAS application's token exchange policy
is not propagating the user identity — check the IAS application's "Subject Name Identifier"
configuration.

If `aud` does not match `IAS_CLIENT_ID`: the `resource` URN in the exchange request does not
match the IAS application's provider name — check `RESOURCE_URN` in the script against the
IAS application's "Provider Name" field.

If `ias_apis` is absent or wrong: the MCP client's dependency on the backend is not configured
in IAS, or the dependency's name does not match `IAS_CLIENT_DEPENDENCY_NAME`.

**Environment overrides** (all optional — defaults match this project):

| Variable | Default | Purpose |
|---|---|---|
| `IAS_HOST` | `https://a3enmtmdf.accounts400.ondemand.com` | IAS tenant |
| `MCP_CLIENT_ID` | `32e0450f-44a1-40ec-a4f4-292777d52eca` | MCP server's IAS client ID |
| `MCP_CLIENT_SECRET` | _(prompted)_ | MCP server's IAS client secret |
| `REDIRECT_URI` | `http://localhost:18766/mcp-callback` | Must match IAS redirect URI allowlist |
| `RESOURCE_URN` | `urn:sap:identity:application:provider:name:scope` | Backend provider URN for OBO exchange |
| `BACKEND_URL` | _(empty — skips API call)_ | Set to call the backend with the exchanged token |

---

---

# Layout

Policy definition:
```
platform-ops/k8s/ams/dcl/
├── schema.dcl
└── internal/
    └── policies.dcl
```

Setup configuration:
```
platform-ops/k8s/ams/one-time/
├── dev/
│   ├── ias.serviceinstance.yml
│   ├── ias.servicebinding.yml
│   ├── ias-dev-deployer-binding.yml
│   └── ams-dcl-deployer-job.yml
├── qa/   (same structure)
└── prod/ (same structure)
```

# Apply in Order

0. Apply Kyma objects (`platform-ops/k8s/ams/one-time/dev/`):
```bash
kubectl apply -f platform-ops/k8s/ams/one-time/dev/ias.serviceinstance.yml -n dev
kubectl apply -f platform-ops/k8s/ams/one-time/dev/ias.servicebinding.yml -n dev
kubectl apply -f platform-ops/k8s/ams/one-time/dev/ias-dev-deployer-binding.yml -n dev
```

1. Apply DCL ConfigMap:
```bash
kubectl apply -f platform-ops/k8s/ams/dcl/ams-dcl-configmap.yml -n dev
```

2. Run the DCL deployer job:
```bash
kubectl apply -f platform-ops/k8s/ams/one-time/dev/ams-dcl-deployer-job.yml -n dev
```

3. Watch it run:
```bash
kubectl logs -f job/ams-dcl-deployer -n dev -c deployer
```

Expected successful output:
```
=== DCL structure ===
/dcl/schema.dcl
/dcl/internal/policies.dcl
...
Successfully deployed DCL policies to AMS.
```

## What Each Part Does

```
ams-dcl-configmap.yml
└── ConfigMap holding DCL files (schema.dcl, policies.dcl)

ams-dcl-deployer-job.yml
└── Kubernetes Job (runs once, then stops)
    ├── initContainer: busybox — copies DCL files from ConfigMap into /dcl/internal/
    ├── container: node:20-alpine — runs: npx --yes --package=@sap/ams deploy-dcl -d /dcl
    ├── /dcl                      — emptyDir populated by initContainer
    └── /bindings/ias-dev-deployer-secret — X.509 deployer secret (auth to AMS)
```

The deployer uses `npx` to fetch and run `@sap/ams` at job time — no custom Docker image is
needed.

# After the Job Succeeds

Go to IAS Admin Console → your app → Authorization Policies.

The policies `readers`, `writers`, and `admins` will appear. The "Create Restriction" button
becomes active. Users can now be assigned to these policies.

## Re-running After DCL Changes

```bash
# Delete completed job (Jobs are immutable once run)
kubectl delete job ams-dcl-deployer -n dev --ignore-not-found

# Update ConfigMap with new DCL content
kubectl apply -f platform-ops/k8s/ams/dcl/ams-dcl-configmap.yml -n dev

# Re-run the job
kubectl apply -f platform-ops/k8s/ams/one-time/dev/ams-dcl-deployer-job.yml -n dev

# Monitor
kubectl logs -f job/ams-dcl-deployer -n dev -c deployer
```

## Summary: What Secret, Where

| Component | Secret | Credential type | Why |
|-----------|--------|-----------------|-----|
| Spring Boot pod (runtime) | `ias-secret` | `X509_GENERATED` | AMS bundle download + runtime privilege checks |
| DCL deployer Job | `ias-dev-deployer-secret` | `X509_GENERATED` | Writing DCL policies to AMS requires mTLS |

One ServiceInstance (`ias-dev`), two ServiceBindings, both X.509, used by different components.

