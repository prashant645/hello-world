# APIRule Test Guide

This guide documents the Kyma APIRule + API Gateway verification flow for the `dev` namespace and the one-command test script.

For environment-agnostic APIRule setup and prerequisite diagnostics (`dev`/`qa`/`prod`), use:

- `platform-ops/k8s/apiRule/PREREQUISITES-AND-CONFIG.md`

## Prerequisites

- `kubectl` configured for the target Kyma cluster
- Access to namespace `dev`
- `gh` authenticated (only needed for pipeline trigger/watch steps)
- From repo root: `/Users/I819791/IdeaProjects/GTLCInfra/hello-world-service`

## Current dev endpoint quick reference

Verified from the current cluster state:

- Deployed public dev URL: `https://hello-world-service-dev.c-1282d6a.stage.kyma.ondemand.com`
- XSUAA auth base URL: `https://hello-kyma-cfw6mbbu.authentication.sap.hana.ondemand.com`
- OAuth token URL: `https://hello-kyma-cfw6mbbu.authentication.sap.hana.ondemand.com/oauth/token`

Important:
- Request OAuth tokens from the XSUAA URL, not from the APIRule/application URL.
- Call the deployed API on the public dev URL after you obtain a bearer token.

## Platform prerequisites and ownership model

The APIRule path depends on both **cluster-level platform components** and **application-level manifests**.

### Cluster-level, one-time platform prerequisites

These are typically enabled once per cluster by the platform/operator team and are **not** deployed by this application's Helm chart:

- API Gateway module enabled for the cluster
- APIRule CRDs installed in the cluster API
- `kyma-gateway` available in namespace `kyma-system`
- API Gateway / Istio controller pods healthy in `kyma-system`

In this repository, we only **verify** those prerequisites at runtime. We do not manage cluster-wide installation of API Gateway, Istio, or CRDs from app Helm values.

If you need a single checklist with setup expectations plus copy-paste verification commands, see:

- `platform-ops/k8s/apiRule/PREREQUISITES-AND-CONFIG.md`

### Application-level manifests in this repo

This repository does manage the application-facing APIRule resource and its configuration:

- `helm/hello-world-service/templates/apirule.yaml`
- `helm/hello-world-service/values-dev.yaml`
- `helm/hello-world-service/values-qa.yaml`
- `helm/hello-world-service/values-prod.yaml`

## API Gateway module installation / enablement

### What is expected

For APIRule-based public HTTPS exposure to work, the cluster must have the Kyma API Gateway module enabled.

### How to verify in the cluster

```bash
kubectl get apigateway -A
kubectl get apigateway -A -o yaml
```

Expected live state in the current dev cluster:

```yaml
apiVersion: operator.kyma-project.io/v1alpha1
kind: APIGateway
metadata:
  name: default
spec:
  enableKymaGateway: true
status:
  state: Ready
```

Interpretation:
- `enableKymaGateway: true` means the Kyma gateway path is enabled
- `status.state: Ready` means the module reconciled successfully

### Is the installation YAML stored in this repo?

No cluster-scoped API Gateway module installation manifest is currently stored in this repo.

That is intentional:
- module enablement is a **cluster/platform concern**
- this repo assumes the module already exists and is healthy
- the pipeline preflight only checks capability/readiness before app deployment

## APIRule CRD availability and version handling

### Why this matters

The app Helm chart only renders an APIRule when the required CRD version exists in the cluster API.

### How to verify CRD/API availability

```bash
kubectl api-resources | grep -E '^apirules[[:space:]]'
kubectl api-versions | grep 'gateway.kyma-project.io/'
```

### How the Helm chart handles versions

File: `helm/hello-world-service/templates/apirule.yaml`

The template checks for:
- `gateway.kyma-project.io/v2/APIRule`
- `gateway.kyma-project.io/v1beta1/APIRule`

Behavior:
- if `v2` exists, render a `v2` APIRule
- otherwise if `v1beta1` exists, render a `v1beta1` APIRule
- otherwise render nothing, preventing invalid deployment output

This means the repo is compatible with clusters exposing either supported APIRule version.

## Istio / kyma-gateway dependency

### What APIRule routes through

The APIRule does not expose traffic by itself. It routes through the cluster gateway, which in this setup is `kyma-system/kyma-gateway`.

### How to verify gateway and controllers

```bash
kubectl get gateway -n kyma-system kyma-gateway
kubectl get pods -n kyma-system | grep -Ei 'api-gateway|istio'
```

Expected indicators:
- `gateway/kyma-gateway` exists
- `api-gateway-controller-manager` pod is `Running`
- `istio-controller-manager` pod is `Running`

### Is the gateway YAML stored in this repo?

No. The `kyma-gateway` resource and the supporting controller installation are cluster-managed, not app-managed.

This repo references that gateway from app config but does not create it.

## Application APIRule YAMLs and configuration in this repo

### 1) APIRule template

File: `helm/hello-world-service/templates/apirule.yaml`

What it does:
- creates the `APIRule` resource when `apirule.enabled: true`
- selects `v2` or `v1beta1` automatically based on cluster API support
- points the APIRule to the service `hello-world-service:8080`
- binds the route to the configured gateway
- configures path and allowed HTTP methods

### 2) Dev environment values

File: `helm/hello-world-service/values-dev.yaml`

Current relevant dev values:

```yaml
apirule:
  enabled: true
  gatewayNamespace: kyma-system
  gateway: kyma-gateway
  host: hello-world-service-dev.c-1282d6a.stage.kyma.ondemand.com
  path: /{**}
  methods:
    - GET
    - POST
    - PUT
    - DELETE
    - PATCH
  noAuth: true
  accessStrategies:
    - handler: allow
```

Important note:
- `noAuth: true` / `accessStrategies: allow` is **gateway-level route behavior** in the APIRule
- the application itself is still protected by Spring Security/XSUAA, which is why token-based auth is still required by the backend endpoints

### 3) Environment-specific toggles

Also check:
- `helm/hello-world-service/values-qa.yaml`
- `helm/hello-world-service/values-prod.yaml`

These files control whether APIRule exposure is enabled per environment.

## Repo YAMLs vs platform YAMLs

Use this rule of thumb when deciding where a change belongs.

### Repo-managed YAMLs in this application repository

These are versioned here and should be changed in this repo when you want to modify app exposure behavior:

- `helm/hello-world-service/templates/apirule.yaml`
- `helm/hello-world-service/values-dev.yaml`
- `helm/hello-world-service/values-qa.yaml`
- `helm/hello-world-service/values-prod.yaml`

Typical repo-managed changes:
- enable or disable `apirule.enabled`
- change host/path/methods
- switch gateway reference values used by the app chart
- update app-level documentation and verification steps

### Platform-managed YAMLs or resources not versioned here

These are cluster-scoped or platform-scoped concerns and are not currently stored in this application repo:

- API Gateway module installation/enablement manifests
- APIRule CRD installation manifests
- `kyma-system/kyma-gateway` creation manifests
- Istio / API Gateway controller installation manifests

Typical platform-managed changes:
- enabling the API Gateway module for the cluster
- installing or upgrading APIRule CRDs
- provisioning or changing shared ingress/gateway resources
- managing controller lifecycle in `kyma-system`

### Practical impact

If the problem is:
- **APIRule host/path/routing for this app** -> change repo YAMLs
- **APIRule CRD missing / gateway missing / module not ready** -> fix cluster platform configuration outside this repo

## What this repo does not install

To avoid confusion, the following are **not** installed by this repo's application chart:

- API Gateway module itself
- APIRule CRDs
- `kyma-system/kyma-gateway`
- Istio/API Gateway controller deployment in `kyma-system`

Those are expected to be present already in the target cluster.

## Verification commands for the full prerequisite chain

Run these before or after deployment when debugging APIRule platform issues:

```bash
kubectl get apigateway -A
kubectl api-resources | grep -E '^apirules[[:space:]]'
kubectl api-versions | grep 'gateway.kyma-project.io/'
kubectl get gateway -n kyma-system kyma-gateway
kubectl get pods -n kyma-system | grep -Ei 'api-gateway|istio'
kubectl get apirule -n dev hello-world-service -o wide
kubectl describe apirule -n dev hello-world-service
```

For `qa`/`prod` variants and RBAC-specific checks (including `pods/portforward`), use:

- `platform-ops/k8s/apiRule/PREREQUISITES-AND-CONFIG.md`

## 5-step test flow

### 1) Check APIRule/Gateway readiness

```bash
kubectl get apirule -n dev hello-world-service -o wide
kubectl get gateway -n kyma-system kyma-gateway
kubectl get apigateway -A
kubectl get pods -n kyma-system | grep -Ei 'api-gateway|istio'
```

Pass criteria:
- APIRule state is `Ready`
- APIGateway state is `Ready`
- API gateway and Istio controller pods are `Running`

### 2) Run HTTPS + XSUAA smoke test

```bash
bash platform-ops/k8s/xsuaa/test/scripts/test-xsuaa-auth.sh -n dev --strict-scopes --require-https --require-apirule
```

Pass criteria:
- Script ends with `[OK] XSUAA auth smoke test passed`

### 3) Run local Java tests

```bash
./gradlew test
```

Pass criteria:
- Gradle test task succeeds

### 4) Trigger Kyma dev pipeline

```bash
gh workflow run wfk-kyma-dev.yml --ref develop
gh run list --workflow wfk-kyma-dev.yml --branch develop --limit 1
```

Pass criteria:
- New run ID appears for workflow `wfk-kyma-dev.yml`

### 5) Watch run and inspect failures if any

```bash
gh run watch <RUN_ID> --interval 10
gh run view <RUN_ID> --log-failed
```

Pass criteria:
- Workflow conclusion is `success`
- Post-deploy job `verify_kyma_dev_https_auth` succeeds

## Client-side testing through the public APIRule

Use this section when you want to test the deployed service as an external client, not just as a pipeline or deployment verifier.

This proves what a real caller sees over public HTTPS:
- unauthenticated requests are rejected
- tokens must be obtained from XSUAA, not from the app URL
- authenticated clients can call the protected API when they have the required scopes

### 1) Resolve the public API base URL

```bash
APP_HOST="$(kubectl -n dev get apirule hello-world-service -o jsonpath='{.spec.hosts[0]}')"
APP_URL="https://${APP_HOST}"
echo "$APP_URL"
```

### 2) Important: token endpoint is not the APIRule URL

Do **not** request tokens from the application host:

```text
https://<apirule-host>/oauth/token
```

That host serves the protected application.

Instead, get the XSUAA issuer URL from the binding secret and request the token there:

```bash
XSUAA_URL="$(kubectl -n dev get secret hello-world-xsuaa-binding-dev -o jsonpath='{.data.url}' | base64 -d)"
echo "$XSUAA_URL"
```

Token endpoint:

```text
${XSUAA_URL}/oauth/token
```

### 3) Quick black-box client check

This simulates an external caller with no token.

```bash
curl -i -X POST "${APP_URL}/api/v1/greetings" \
  -H "Content-Type: application/json" \
  -d '{"message":"no token"}'
```

Expected:
- `401` or `403`

### 4) Authenticated client test using a dedicated Read/Write client

Use the dedicated client binding for client-side tests that must include write permission:
- Binding resource: `hello-world-xsuaa-client-rw-dev`
- Secret: `hello-world-xsuaa-client-rw-dev`

If it does not exist yet, create it first using the inline, parameterized flow in:

- `platform-ops/k8s/xsuaa/test/README.md` (section: **Enable a new client-credentials caller**, Step 2)

Then verify:

```bash
kubectl -n dev get servicebinding hello-world-xsuaa-client-rw-dev -o wide
kubectl -n dev get secret hello-world-xsuaa-client-rw-dev
```

Extract credentials from the dedicated Read/Write client binding:

```bash
XSUAA_URL="$(kubectl -n dev get secret hello-world-xsuaa-client-rw-dev -o jsonpath='{.data.url}' | base64 -d)"
CLIENT_ID="$(kubectl -n dev get secret hello-world-xsuaa-client-rw-dev -o jsonpath='{.data.clientid}' | base64 -d)"
CLIENT_SECRET="$(kubectl -n dev get secret hello-world-xsuaa-client-rw-dev -o jsonpath='{.data.clientsecret}' | base64 -d)"
```

Request a token:

```bash
RAW="$(curl -sS -X POST "${XSUAA_URL}/oauth/token" \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -d "grant_type=client_credentials" \
  -d "client_id=${CLIENT_ID}" \
  -d "client_secret=${CLIENT_SECRET}")"

echo "$RAW" | jq .
TOKEN="$(echo "$RAW" | jq -r '.access_token')"
```

Optional scope inspection:

```bash
TOKEN_VALUE="$TOKEN" python3 - <<'PY'
import base64, json, os
payload = os.environ["TOKEN_VALUE"].split(".")[1]
payload += "=" * (-len(payload) % 4)
claims = json.loads(base64.urlsafe_b64decode(payload.encode()).decode())
print(json.dumps({
	"client_id": claims.get("client_id"),
	"scope": claims.get("scope"),
	"authorities": claims.get("authorities")
}, indent=2))
PY
```

Call the public HTTPS endpoint:

```bash
curl -i -X POST "${APP_URL}/api/v1/greetings" \
  -H "Authorization: Bearer ${TOKEN}" \
  -H "Content-Type: application/json" \
  -d '{"message":"hello from client"}'
```

```bash
curl -i -X POST "${APP_URL}/api/v1/greetings/update" \
  -H "Authorization: Bearer ${TOKEN}" \
  -H "Content-Type: application/json" \
  -d '{"rateLimit":{"requestsPerMinute":20}}'
```

Interpretation for the dedicated Read/Write client:
- `200` -> authorized success
- `429` -> authorized call hit rate limiting
- `403` -> unexpected for this client; inspect binding readiness and token scopes
- `401` -> missing or invalid token

### 5) Optional: compare with the app's current binding

The app binding `hello-world-xsuaa-binding-dev` is primarily for the deployed workload.
For client-side testing, prefer `hello-world-xsuaa-client-rw-dev` because it is explicitly documented as the reusable Read/Write caller identity.

If you still want to inspect the app binding token, you can do so with:

```bash
XSUAA_URL="$(kubectl -n dev get secret hello-world-xsuaa-binding-dev -o jsonpath='{.data.url}' | base64 -d)"
CLIENT_ID="$(kubectl -n dev get secret hello-world-xsuaa-binding-dev -o jsonpath='{.data.clientid}' | base64 -d)"
CLIENT_SECRET="$(kubectl -n dev get secret hello-world-xsuaa-binding-dev -o jsonpath='{.data.clientsecret}' | base64 -d)"
```

### 6) Dedicated client creation reference

For a cleaner service-to-service test, create a dedicated Read/Write client instead of reusing the app's current binding.

Use the canonical inline creation steps in:
- `platform-ops/k8s/xsuaa/test/README.md` (section: **Enable a new client-credentials caller**, Step 2)

Verify it is ready:

```bash
kubectl -n dev get servicebinding hello-world-xsuaa-client-rw-dev -o wide
kubectl -n dev get secret hello-world-xsuaa-client-rw-dev
kubectl -n dev describe servicebinding hello-world-xsuaa-client-rw-dev
```

Get the dedicated client credentials:

```bash
XSUAA_URL="$(kubectl -n dev get secret hello-world-xsuaa-client-rw-dev -o jsonpath='{.data.url}' | base64 -d)"
CLIENT_ID="$(kubectl -n dev get secret hello-world-xsuaa-client-rw-dev -o jsonpath='{.data.clientid}' | base64 -d)"
CLIENT_SECRET="$(kubectl -n dev get secret hello-world-xsuaa-client-rw-dev -o jsonpath='{.data.clientsecret}' | base64 -d)"
```

Then request a token and call the same public HTTPS endpoints shown above.

### 7) Reuse the helper script for client-style verification

Dedicated Read/Write client binding:

```bash
bash platform-ops/k8s/xsuaa/test/scripts/test-xsuaa-auth.sh \
  -n dev \
  --binding-secret hello-world-xsuaa-client-rw-dev \
  --strict-scopes \
  --require-https \
  --require-apirule
```

App binding (optional comparison only):

```bash
bash platform-ops/k8s/xsuaa/test/scripts/test-xsuaa-auth.sh \
  -n dev \
  --strict-scopes \
  --require-https \
  --require-apirule
```

For deeper XSUAA client-credentials scenarios, see:
- `platform-ops/k8s/xsuaa/test/README.md`

## One-command all-test script

Script path: `platform-ops/k8s/apiRule/scripts/test-kyma-dev-e2e.sh`

Default behavior:
- Step 1 cluster checks
- Step 2 HTTPS/XSUAA smoke test

Quick run:

```bash
bash platform-ops/k8s/apiRule/scripts/test-kyma-dev-e2e.sh
```

### Common usage

Run with local unit/integration tests:

```bash
bash platform-ops/k8s/apiRule/scripts/test-kyma-dev-e2e.sh --with-gradle
```

Trigger and watch a new pipeline run:

```bash
bash platform-ops/k8s/apiRule/scripts/test-kyma-dev-e2e.sh --trigger-pipeline --watch
```

Watch an existing run:

```bash
bash platform-ops/k8s/apiRule/scripts/test-kyma-dev-e2e.sh --run-id 50773637
```

Skip smoke test (cluster check only):

```bash
bash platform-ops/k8s/apiRule/scripts/test-kyma-dev-e2e.sh --skip-smoke
```

Show all flags:

```bash
bash platform-ops/k8s/apiRule/scripts/test-kyma-dev-e2e.sh --help
```
