#!/usr/bin/env bash
set -euo pipefail

# One-command verifier for Kyma dev rollout health:
# - Cluster/APIRule readiness
# - HTTPS + IAS smoke test (same script used by pipeline)
# - Optional local Gradle tests
# - Optional workflow trigger/watch

NAMESPACE="${NAMESPACE:-dev}"
APIRULE_NAME="${APIRULE_NAME:-hello-world-service}"
SERVICE_NAME="${SERVICE_NAME:-hello-world-service}"
WORKFLOW="${WORKFLOW:-wfk-kyma-dev.yml}"
BRANCH="${BRANCH:-ams}"
WATCH_INTERVAL="${WATCH_INTERVAL:-10}"

DO_CLUSTER=true
DO_SMOKE=true
DO_GRADLE=false
TRIGGER_PIPELINE=false
WATCH_PIPELINE=false
RUN_ID=""

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../../.." && pwd)"
SMOKE_SCRIPT="${ROOT_DIR}/scripts/test-ias-auth.sh"

usage() {
  cat <<'EOF'
Usage: platform-ops/k8s/apiRule/scripts/test-kyma-dev-e2e.sh [options]

Options:
  --namespace <ns>          Kubernetes namespace (default: dev)
  --apirule <name>          APIRule name (default: hello-world-service)
  --service <name>          Service name for display only (default: hello-world-service)

  --skip-cluster            Skip cluster readiness checks
  --skip-smoke              Skip HTTPS/IAS smoke test
  --with-gradle             Run ./gradlew test

  --trigger-pipeline        Trigger workflow (default workflow/branch below)
  --watch                   Watch workflow run to completion
  --run-id <id>             Watch this existing run id (implies --watch)
  --workflow <file>         Workflow file (default: wfk-kyma-dev.yml)
  --branch <name>           Workflow ref branch (default: ias)
  --watch-interval <sec>    gh watch polling interval (default: 10)

Environment for IAS smoke test:
  IAS_CLIENT_ID             Required IAS client id
  IAS_CLIENT_SECRET         Required IAS client secret
  IAS_CLIENT_DEPENDENCY_NAME Optional; defaults to scope
  EXPECTED_IAS_API          Optional; defaults to readers
  IAS_HOST                  Optional; defaults to a3enmtmdf.accounts400.ondemand.com

Examples:
  IAS_CLIENT_ID=... IAS_CLIENT_SECRET=... bash platform-ops/k8s/apiRule/scripts/test-kyma-dev-e2e.sh
  IAS_CLIENT_ID=... IAS_CLIENT_SECRET=... bash platform-ops/k8s/apiRule/scripts/test-kyma-dev-e2e.sh --with-gradle
  gh auth login
  IAS_CLIENT_ID=... IAS_CLIENT_SECRET=... bash platform-ops/k8s/apiRule/scripts/test-kyma-dev-e2e.sh --trigger-pipeline --watch
EOF
}

require_cmd() {
  command -v "$1" >/dev/null 2>&1 || {
    echo "Missing command: $1" >&2
    exit 1
  }
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --namespace)
      NAMESPACE="$2"; shift 2 ;;
    --apirule)
      APIRULE_NAME="$2"; shift 2 ;;
    --service)
      SERVICE_NAME="$2"; shift 2 ;;
    --skip-cluster)
      DO_CLUSTER=false; shift ;;
    --skip-smoke)
      DO_SMOKE=false; shift ;;
    --with-gradle)
      DO_GRADLE=true; shift ;;
    --trigger-pipeline)
      TRIGGER_PIPELINE=true; shift ;;
    --watch)
      WATCH_PIPELINE=true; shift ;;
    --run-id)
      RUN_ID="$2"; WATCH_PIPELINE=true; shift 2 ;;
    --workflow)
      WORKFLOW="$2"; shift 2 ;;
    --branch)
      BRANCH="$2"; shift 2 ;;
    --watch-interval)
      WATCH_INTERVAL="$2"; shift 2 ;;
    -h|--help)
      usage
      exit 0 ;;
    *)
      echo "Unknown option: $1" >&2
      usage
      exit 1 ;;
  esac
done

if [[ "$DO_CLUSTER" == true || "$DO_SMOKE" == true ]]; then
  require_cmd kubectl
fi
if [[ "$DO_SMOKE" == true ]]; then
  [[ -f "$SMOKE_SCRIPT" ]] || {
    echo "Smoke script not found: $SMOKE_SCRIPT" >&2
    exit 1
  }
fi
if [[ "$DO_GRADLE" == true ]]; then
  [[ -x "${ROOT_DIR}/gradlew" ]] || {
    echo "Gradle wrapper not executable: ${ROOT_DIR}/gradlew" >&2
    exit 1
  }
fi
if [[ "$TRIGGER_PIPELINE" == true || "$WATCH_PIPELINE" == true || -n "$RUN_ID" ]]; then
  require_cmd gh
fi

if [[ "$DO_CLUSTER" == true ]]; then
  echo "[1/4] Cluster readiness checks for ${SERVICE_NAME}"
  kubectl get apirule -n "$NAMESPACE" "$APIRULE_NAME" -o wide
  kubectl get gateway -n kyma-system kyma-gateway
  kubectl get apigateway -A
  kubectl get pods -n kyma-system | grep -Ei 'api-gateway|istio' || true

  apirule_state="$(kubectl -n "$NAMESPACE" get apirule "$APIRULE_NAME" -o jsonpath='{.status.state}' 2>/dev/null || true)"
  if [[ "$apirule_state" != "Ready" ]]; then
    echo "APIRule ${NAMESPACE}/${APIRULE_NAME} is not Ready (state=${apirule_state:-<empty>})" >&2
    exit 1
  fi
fi

if [[ "$DO_SMOKE" == true ]]; then
  echo "[2/4] HTTPS + IAS smoke test"
  (
    cd "$ROOT_DIR"
    NAMESPACE="$NAMESPACE" APIRULE_NAME="$APIRULE_NAME" bash "$SMOKE_SCRIPT"
  )
fi

if [[ "$DO_GRADLE" == true ]]; then
  echo "[3/4] Local Gradle tests"
  (
    cd "$ROOT_DIR"
    ./gradlew test
  )
fi

if [[ "$TRIGGER_PIPELINE" == true ]]; then
  echo "[4/4] Trigger workflow ${WORKFLOW} on ${BRANCH}"
  (
    cd "$ROOT_DIR"
    gh workflow run "$WORKFLOW" --ref "$BRANCH"
  )

  sleep 3
  if [[ -z "$RUN_ID" ]]; then
    RUN_ID="$(gh run list --workflow "$WORKFLOW" --branch "$BRANCH" --limit 1 --json databaseId --jq '.[0].databaseId')"
  fi
  echo "Triggered run id: $RUN_ID"
fi

if [[ "$WATCH_PIPELINE" == true ]]; then
  if [[ -z "$RUN_ID" ]]; then
    RUN_ID="$(gh run list --workflow "$WORKFLOW" --branch "$BRANCH" --limit 1 --json databaseId --jq '.[0].databaseId')"
  fi
  echo "Watching run id: $RUN_ID"
  gh run watch "$RUN_ID" --interval "$WATCH_INTERVAL"
fi

echo "Done."

