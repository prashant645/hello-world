# APIRule Prerequisites and Configuration (All Environments)

Use this guide to answer two questions quickly:

1. Is APIRule configured correctly in this repo for `dev` / `qa` / `prod`?
2. Does the target cluster have the platform prerequisites required to make APIRule work?

## 1) Repo-managed APIRule configuration

These files are owned by this repository and control app-level APIRule behavior:

- `helm/hello-world-service/templates/apirule.yaml`
- `helm/hello-world-service/values-dev.yaml`
- `helm/hello-world-service/values-qa.yaml`
- `helm/hello-world-service/values-prod.yaml`

### Required values per environment

At minimum, set:

```yaml
apirule:
  enabled: true
  gatewayNamespace: kyma-system
  gateway: kyma-gateway
  host: <env-specific-host>
  path: /{**}
```

Current expected hosts in this repo:

- `dev`: `hello-world-service-dev.c-1282d6a.stage.kyma.ondemand.com`
- `qa`: `hello-world-service-qa`
- `prod`: `hello-world-service-prod.c-1282d6a.stage.kyma.ondemand.com`

## 2) Cluster/platform prerequisites (outside this repo)

These are cluster-scoped prerequisites that are not installed by this app chart:

- APIRule CRD/API support (`gateway.kyma-project.io/v2` or `v1beta1`)
- API Gateway module/controller availability
- Shared gateway resource `kyma-system/kyma-gateway`

If one of these is missing, setting `apirule.enabled: true` is not enough.

## 3) Verification commands

Run these checks against the target cluster/context.

### A) Confirm cluster context

```bash
kubectl config current-context
kubectl cluster-info
```

### B) APIRule CRD/API availability

```bash
kubectl get crd | grep -E 'apirules\.gateway\.kyma-project\.io' || true
kubectl api-versions | grep -E '^gateway\.kyma-project\.io/' || true
kubectl api-resources | grep -E '^apirules[[:space:]]' || true
```

Optional explicit version checks:

```bash
kubectl explain apirule --api-version=gateway.kyma-project.io/v2 >/dev/null && echo "APIRule v2 available" || echo "APIRule v2 not available"
kubectl explain apirule --api-version=gateway.kyma-project.io/v1beta1 >/dev/null && echo "APIRule v1beta1 available" || echo "APIRule v1beta1 not available"
```

### C) API Gateway module/controller health

```bash
kubectl get apigateway -A
kubectl get apigateway -A -o yaml
kubectl get deploy -A | grep -Ei 'api-gateway|gateway.*controller|apirule' || true
kubectl get pods -A | grep -Ei 'api-gateway|gateway.*controller|apirule' || true
```

### D) Shared gateway existence

```bash
kubectl -n kyma-system get gateway kyma-gateway -o yaml
kubectl -n kyma-system get gateway kyma-gateway -o jsonpath='{.spec.servers[0].hosts[0]}'; echo
```

### E) App APIRule in namespace

```bash
NAMESPACE=prod
kubectl -n "$NAMESPACE" get apirule hello-world-service -o yaml
kubectl -n "$NAMESPACE" get apirule hello-world-service -o jsonpath='{.status.state}'; echo
```

### F) RBAC capability checks (current identity)

```bash
kubectl auth can-i get apirules.gateway.kyma-project.io -n prod
kubectl auth can-i create apirules.gateway.kyma-project.io -n prod
kubectl auth can-i get gateway -n kyma-system
kubectl auth can-i create pods/portforward -n prod
```

## 4) How APIRule rendering is decided by Helm

`helm/hello-world-service/templates/apirule.yaml` renders APIRule only when both are true:

- `apirule.enabled: true`
- cluster exposes APIRule API capability (`v2` or `v1beta1`)

Quick local render simulation:

```bash
helm template hello-world-service helm/hello-world-service \
  -f helm/hello-world-service/values-prod.yaml \
  --api-versions gateway.kyma-project.io/v2/APIRule \
  | grep -E '^apiVersion: gateway.kyma-project.io/|^kind: APIRule$'
```

## 5) If a check fails, where to change it

- `apirule.enabled`, host/path/methods wrong -> update `helm/hello-world-service/values-<env>.yaml` in this repo.
- APIRule CRD/API missing -> platform team must install/repair APIRule CRDs in the cluster.
- API Gateway module not ready -> platform team must repair API Gateway module/controller.
- `kyma-system/kyma-gateway` missing -> platform team must create/restore shared gateway.
- RBAC denies `pods/portforward` or APIRule access -> grant permissions for the CI identity in target namespace.

