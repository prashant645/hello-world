# Kubernetes guides

Use the documents in this folder based on what you need to do:

- `btp-operator/README.md` - install and maintain the SAP BTP operator prerequisites
- `xsuaa/README.md` - provision, preflight, reset, verify, and troubleshoot XSUAA resources for Kyma namespaces
- `xsuaa/test/README.md` - test deployed XSUAA behavior, scoped success paths, and client-credentials callers
- `apiRule/README.md` - run the APIRule/API Gateway 5-step verification flow and the all-test script
