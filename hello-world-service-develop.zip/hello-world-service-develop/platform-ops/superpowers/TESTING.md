# Kyma Generalization Implementation - Testing & Validation Guide

**Date:** 2026-09-10  
**Status:** Ready for Testing  
**Branch:** `xsuaa/kyma/generalization`

---

## Quick Start - Test the Implementation

### Option 1: Trigger via GitHub Actions (Recommended)

**1. Make a test commit:**
```bash
cd hello-world-service
git checkout xsuaa/kyma/generalization
git pull origin xsuaa/kyma/generalization

# Make a small change to trigger the workflow
echo "# Test commit for Kyma generalization validation" >> VERSION
git add VERSION
git commit -m "test: validate Kyma generalization implementation"
git push origin HEAD:xsuaa/kyma/generalization
```

**2. Watch the workflow:**
- Go to https://github.com/GTLCInfra/hello-world-service/actions
- Look for "Kyma Pipeline - dev" workflow
- Click on the latest run

**3. Observe the jobs:**
```
✅ preflight_kyma_dev_https
   ├─ Setup kubeconfig and kubectl
   └─ Verify XSUAA and Kyma API Gateway prerequisites

✅ build_kyma_dev (calls pipeline-unified.yml@v4.0.0)
   ├─ Checkout code
   ├─ Parse manifest
   │  └─ Reads .pipeline/gtlc.yml
   │  └─ Parses serviceAccount contract from Helm values ✨ NEW
   ├─ Build stage (gradle, docker)
   ├─ Deploy stage
   │  ├─ Download CPE artifact
   │  ├─ Setup tools (vault, kubectl, helm)
   │  ├─ Verify cluster connection
   │  ├─ Preflight - Validate runtime ServiceAccount contract ✨ NEW
   │  │  └─ Checks that precreated SA exists in cluster
   │  ├─ Create namespace
   │  ├─ Setup secrets (docker-registry)
   │  └─ Helm upgrade/install
   │     └─ References precreated ServiceAccount (create: false)
   └─ Verify deployment

✅ verify_kyma_dev_https_auth
   ├─ Wait for APIRule to become ready
   └─ Smoke-test HTTPS XSUAA auth via APIRule
```

### Option 2: Run Drift Detection Manually

**1. Get kubeconfig:**
```bash
# Ensure kubeconfig is set up for dev cluster
export KUBECONFIG=/path/to/kubeconfig-dev
kubectl cluster-info
```

**2. Run drift detection script:**
```bash
cd hello-world-service
bash platform-ops/k8s/kyma/drift-detection.sh dev dev hello-world-service hello-world-xsuaa-dev hello-world-xsuaa-binding-dev
```

**Expected output:**
```
═══════════════════════════════════════════════════════════════
Kyma Deployment Drift Detection
Environment: dev | Namespace: dev | Service: hello-world-service
═══════════════════════════════════════════════════════════════

[1/7] Cluster Connectivity
✅ PASS: Cluster is reachable

[2/7] Namespace Bootstrap
✅ PASS: Namespace 'dev' exists
⚠️  WARN: Namespace is missing gtlc.io/bootstrap label

[3/7] Deployer Identity
✅ PASS: Deployer ServiceAccount 'kyma-deployer' exists
✅ PASS: Deployer can read deployments in namespace

[4/7] Runtime ServiceAccount (Bootstrap-Owned)
✅ PASS: Runtime ServiceAccount 'hello-world-service-dev' exists
✅ PASS: Runtime SA has automountServiceAccountToken=false (secure default)

[5/7] XSUAA Integration
✅ PASS: XSUAA ServiceInstance 'hello-world-xsuaa-dev' exists
✅ PASS: XSUAA ServiceInstance is ready
✅ PASS: XSUAA ServiceBinding 'hello-world-xsuaa-binding-dev' exists
✅ PASS: XSUAA binding secret 'hello-world-xsuaa-binding-dev' exists
✅ PASS: XSUAA binding secret contains binding data

[6/7] Application Deployment
✅ PASS: Deployment 'hello-world-service' exists
✅ PASS: Deployment uses expected ServiceAccount: hello-world-service-dev
✅ PASS: Deployment has all replicas ready (1/1)

[7/7] APIRule Exposure (Optional)
✅ PASS: APIRule 'hello-world-service' exists
✅ PASS: APIRule is Ready

═══════════════════════════════════════════════════════════════
Drift Detection Summary
═══════════════════════════════════════════════════════════════
Passed: 13
Warnings: 1
Failed: 0

✅ DRIFT DETECTION PASSED WITH WARNINGS
Please review warnings above. Consider addressing them before release.
```

---

## Detailed Validation Tests

### Test 1: ServiceAccount Contract Parsing

**Objective:** Verify that pipeline-unified.yml correctly parses the runtime ServiceAccount contract from Helm values

**Steps:**

1. Check pipeline logs for "Parse manifest" job:
   ```bash
   # In GitHub Actions workflow logs, look for:
   # "kyma-runtime-service-account-name=hello-world-service-dev"
   # "kyma-runtime-service-account-managed=false"
   # "✅ Runtime ServiceAccount contract: name=hello-world-service-dev, managed=false"
   ```

2. Verify Helm values are being read:
   ```bash
   # Check that wfk-kyma-dev.yml passes correct manifest path
   cat .pipeline/gtlc.yml | grep -A 2 "helm-values:"
   # Should show: helm/hello-world-service/values-dev.yaml
   ```

**Expected Behavior:**
- Contract is parsed from `helm/hello-world-service/values-dev.yaml`
- `serviceAccount.create: false` is detected
- `serviceAccount.name: hello-world-service-dev` is extracted
- Validation passes (name is not empty)

### Test 2: Preflight Validation

**Objective:** Verify that pipeline-kyma.yml validates precreated ServiceAccount exists before Helm deploy

**Steps:**

1. Introduce a test failure (temporarily):
   ```bash
   cd hello-world-service
   git checkout xsuaa/kyma/generalization
   
   # Temporarily rename the precreated SA manifest to break it
   mv platform-ops/k8s/kyma/dev/hello-world-service-serviceaccount.yaml \
      platform-ops/k8s/kyma/dev/hello-world-service-serviceaccount.yaml.bak
   
   git add -A
   git commit -m "test: intentionally break precreated SA to test preflight validation"
   git push origin HEAD:xsuaa/kyma/generalization
   ```

2. Watch the workflow fail:
   ```
   ❌ deploy-kyma job fails in "Preflight - Validate runtime ServiceAccount contract" step
   
   Error:
   "❌ PREFLIGHT FAILED: Precreated runtime ServiceAccount 'hello-world-service-dev' not found in namespace dev"
   ```

3. Restore the file and verify it works:
   ```bash
   mv platform-ops/k8s/kyma/dev/hello-world-service-serviceaccount.yaml.bak \
      platform-ops/k8s/kyma/dev/hello-world-service-serviceaccount.yaml
   
   git add -A
   git commit -m "test: restore precreated SA, verify preflight validation passes"
   git push origin HEAD:xsuaa/kyma/generalization
   ```

4. Watch the workflow succeed:
   ```
   ✅ deploy-kyma job succeeds
   ✅ Preflight - Validate runtime ServiceAccount contract step output:
      "✅ Precreated runtime ServiceAccount 'hello-world-service-dev' verified"
   ```

**Expected Behavior:**
- If ServiceAccount doesn't exist: workflow fails with clear error message (preventing orphaned workload)
- If ServiceAccount exists: preflight passes and Helm deploy proceeds
- Error message guides user to SETUP.md for remediation

### Test 3: Helm Deployment with Precreated SA

**Objective:** Verify that Helm references the precreated ServiceAccount and doesn't create a new one

**Steps:**

1. After successful deployment, verify the pod uses the precreated SA:
   ```bash
   kubectl get pod -n dev -o jsonpath='{.items[0].spec.serviceAccountName}'
   # Should output: hello-world-service-dev
   ```

2. Verify no additional ServiceAccount was created:
   ```bash
   kubectl get serviceaccount -n dev | grep hello-world
   # Should show exactly ONE:
   # hello-world-service-dev   (precreated)
   ```

3. Verify Deployment spec uses the precreated SA:
   ```bash
   kubectl get deployment hello-world-service -n dev -o jsonpath='{.spec.template.spec.serviceAccountName}'
   # Should output: hello-world-service-dev
   ```

4. Check Helm release values:
   ```bash
   helm get values hello-world-service -n dev | grep -A 2 "serviceAccount:"
   # Should show:
   # serviceAccount:
   #   create: false
   #   name: hello-world-service-dev
   ```

**Expected Behavior:**
- Pod runs with the precreated ServiceAccount (hello-world-service-dev)
- Helm did NOT create a new ServiceAccount (serviceAccount.create: false)
- Deployment is running and ready

### Test 4: Separation of Concerns (No Branch Pollution)

**Objective:** Verify that changes are isolated to xsuaa/kyma/generalization branch and don't pollute develop/main

**Steps:**

1. Check branch history:
   ```bash
   cd hello-world-service
   
   # Show commits on xsuaa/kyma/generalization
   git log --oneline xsuaa/kyma/generalization | head -5
   
   # Show commits on develop
   git log --oneline develop | head -5
   
   # Should be completely different histories
   ```

2. Verify develop is unchanged:
   ```bash
   git checkout develop
   git status
   # Should be: "nothing to commit, working tree clean"
   ```

3. Verify main is unchanged:
   ```bash
   git checkout main
   git status
   # Should be: "nothing to commit, working tree clean"
   ```

**Expected Behavior:**
- Only `xsuaa/kyma/generalization` branch has the new commits
- `develop` and `main` are completely unaffected
- Clean separation of concerns

### Test 5: Drift Detection Workflow (Optional)

**Objective:** Verify that drift detection can be manually triggered and provides actionable output

**Steps:**

1. Trigger via GitHub Actions:
   - Go to Actions → "Kyma Drift Detection & Pre-Release Validation"
   - Click "Run workflow"
   - Select environment: "prod"
   - Click "Run workflow"

2. Wait for completion and review output:
   ```
   [1/7] Cluster Connectivity: ✅
   [2/7] Namespace Bootstrap: ✅
   [3/7] Deployer Identity: ✅
   [4/7] Runtime ServiceAccount: ✅
   [5/7] XSUAA Integration: ✅
   [6/7] Application Deployment: ✅
   [7/7] APIRule Exposure: ✅
   
   ✅ DRIFT DETECTION PASSED
   ```

3. If any checks fail, artifact is uploaded for investigation

**Expected Behavior:**
- All checks pass
- Output clearly indicates which resources are verified
- Helps catch issues before release promotions

---

## Architecture Validation

### Contract Flow Verification

**Trace the complete flow:**

```
1. Developer pushes to xsuaa/kyma/generalization
   ↓
2. GitHub Actions triggers wfk-kyma-dev.yml
   ↓
3. preflight_kyma_dev_https job runs
   └─ Verifies XSUAA and API Gateway ready
   ↓
4. build_kyma_dev job calls pipeline-unified.yml@v4.0.0
   ├─ parse-manifest job:
   │  └─ Reads .pipeline/gtlc.yml
   │  └─ Extracts: manifest-path, target (kyma), environment (dev)
   │  └─ Finds pipeline config, then environment config
   │  └─ Reads namespace: dev
   │  └─ Reads helm-chart-path: helm/hello-world-service
   │  └─ Reads helm-values-file: helm/hello-world-service/values-dev.yaml ✨
   │  └─ Reads helm-release-name: hello-world-service
   │  └─ Parses Helm values for serviceAccount ✨
   │     └─ Extracts: create=false, name=hello-world-service-dev ✨
   │  └─ Outputs: kyma-runtime-service-account-name=hello-world-service-dev ✨
   │  └─ Outputs: kyma-runtime-service-account-managed=false ✨
   ├─ build jobs (gradle, docker)
   ├─ deploy-kyma job:
   │  └─ Receives inputs from parse-manifest ✨
   │  └─ Preflight validation ✨
   │     └─ Checks: runtime-service-account-managed=false ✨
   │     └─ Checks: runtime-service-account-name is not empty ✨
   │     └─ Checks: kubectl get sa hello-world-service-dev -n dev ✨
   │  └─ Helm deploy:
   │     └─ helm upgrade --install hello-world-service helm/hello-world-service \
   │            -f helm/hello-world-service/values-dev.yaml \
   │            --set image.tag=<CPE_VERSION> \
   │            -n dev
   │     └─ Helm reads values: serviceAccount.create: false ✨
   │     └─ Helm templates skip ServiceAccount creation ✨
   │     └─ Helm templates use name: hello-world-service-dev ✨
   │  └─ Pod launches with serviceAccountName: hello-world-service-dev ✨
   │  └─ Rollout verification
   ↓
5. verify_kyma_dev_https_auth job runs
   └─ Waits for APIRule ready
   └─ Runs OAuth2 smoke test
```

### Key Validation Points

- [ ] **parse-manifest** extracts serviceAccount contract from Helm values
- [ ] **deploy-kyma** receives runtime ServiceAccount inputs
- [ ] **Preflight** validates precreated ServiceAccount exists
- [ ] **Helm** deploys with serviceAccount.create: false
- [ ] **Pod** runs with precreated ServiceAccount (hello-world-service-dev)
- [ ] **No new** ServiceAccount is created by Helm

---

## Success Criteria

### Must Have ✅

- [ ] Workflow triggers on `xsuaa/kyma/generalization` branch push
- [ ] parse-manifest job reads Helm values successfully
- [ ] ServiceAccount contract is parsed (create: false, name: hello-world-service-dev)
- [ ] Preflight validation verifies precreated SA exists
- [ ] Helm deploy uses precreated SA (no creation)
- [ ] Pod runs with precreated ServiceAccount
- [ ] Deployment is ready and healthy
- [ ] Only `xsuaa/kyma/generalization` branch is affected (no pollution to develop/main)

### Should Have 🟡

- [ ] Drift detection script runs successfully
- [ ] Drift detection catches missing precreated SAs (test by temporarily removing SA)
- [ ] OAuth2 smoke tests pass (verify-kyma-dev-https-auth job)
- [ ] No errors in workflow logs related to ServiceAccount

### Nice to Have 💡

- [ ] All checks in drift detection pass (13+ checks)
- [ ] Clear actionable error messages if something fails
- [ ] Documentation is clear and helpful

---

## Troubleshooting

### Issue: Workflow doesn't trigger on xsuaa/kyma/generalization

**Diagnosis:**
```bash
cd hello-world-service
git log --oneline -5
# Should show your recent commits

# Check that you're on the right branch
git branch -v | grep xsuaa
# Should show: xsuaa/kyma/generalization <commit> <message>
```

**Solution:**
- Ensure you pushed to the correct branch: `git push origin HEAD:xsuaa/kyma/generalization`
- Check GitHub for branch protection rules (shouldn't be blocking this branch)
- Verify the workflow file has `branches: [xsuaa/kyma/generalization]`

### Issue: Preflight fails with "ServiceAccount not found"

**Diagnosis:**
```bash
kubectl get serviceaccount hello-world-service-dev -n dev
# Should succeed without errors
```

**Solution:**
- Create the precreated ServiceAccount:
  ```bash
  kubectl apply -f platform-ops/k8s/kyma/dev/hello-world-service-serviceaccount.yaml
  ```
- Verify it was created:
  ```bash
  kubectl get serviceaccount hello-world-service-dev -n dev -o yaml
  ```

### Issue: Helm deploy fails but preflight passed

**Diagnosis:**
```bash
# Check Helm values
helm get values hello-world-service -n dev | grep -A 3 serviceAccount

# Check deployment spec
kubectl get deployment hello-world-service -n dev -o yaml | grep serviceAccountName
```

**Solution:**
- Verify `serviceAccount.create: false` in values-dev.yaml
- Verify `serviceAccount.name: hello-world-service-dev` in values-dev.yaml
- Check Helm chart _helpers.tpl has correct serviceAccountName logic

### Issue: Pod runs with "default" ServiceAccount instead of precreated

**Diagnosis:**
```bash
kubectl get pod <pod-name> -n dev -o jsonpath='{.spec.serviceAccountName}'
# Should output: hello-world-service-dev
# If it outputs: default, something is wrong
```

**Solution:**
- Check Helm values `serviceAccount.name` is set (not empty)
- Check Deployment template uses: `{{ include "<service>.serviceAccountName" . }}`
- Re-run Helm deploy with explicit values:
  ```bash
  helm upgrade hello-world-service helm/hello-world-service \
    -f helm/hello-world-service/values-dev.yaml \
    --set serviceAccount.name=hello-world-service-dev \
    --set serviceAccount.create=false \
    -n dev
  ```

---

## Next Steps After Successful Testing

1. ✅ **Implementation complete** → Validated on dev
2. 📋 **Documentation complete** → See EPIC-SUMMARY.md and ONBOARDING.md
3. 🔄 **Ready for code review** → PR from xsuaa/kyma/generalization to main
4. 📦 **Release phase** → After merge to main, version and tag release
5. 🚀 **Onboard first service** → Use ONBOARDING.md guide for next service

---

## Test Execution Checklist

Use this checklist to track your testing progress:

```
Workflow Testing
  [ ] Workflow triggers on xsuaa/kyma/generalization push
  [ ] preflight_kyma_dev_https passes
  [ ] parse-manifest succeeds
  [ ] ServiceAccount contract parsed correctly
  [ ] build stage completes
  [ ] Preflight validation passes
  [ ] Helm deploy succeeds
  [ ] Deployment is ready
  [ ] verify_kyma_dev_https_auth passes

Contract Validation
  [ ] Helm values have serviceAccount.create: false
  [ ] Helm values have serviceAccount.name: hello-world-service-dev
  [ ] Pod uses precreated ServiceAccount
  [ ] No new ServiceAccount created
  [ ] Deployment references precreated SA

Drift Detection
  [ ] Drift detection script runs
  [ ] All 7 categories checked
  [ ] Precreated SA is verified
  [ ] XSUAA resources are verified

Branch Isolation
  [ ] Only xsuaa/kyma/generalization has new commits
  [ ] develop branch is untouched
  [ ] main branch is untouched

Failure Scenarios (Optional)
  [ ] Preflight fails if SA doesn't exist
  [ ] Helm fails with clear error if create!=false
  [ ] Error messages are actionable
```

---

## Support & Questions

For issues with testing or validation:

1. **Check workflow logs:**
   - GitHub Actions → Actions → Kyma Pipeline - dev → Run details
   
2. **Check pod/deployment status:**
   ```bash
   kubectl describe deployment hello-world-service -n dev
   kubectl logs <pod-name> -n dev
   ```

3. **Review documentation:**
   - EPIC-SUMMARY.md - Architecture overview
   - ONBOARDING.md - Adoption guide
   - Kyma-Generalization.md - Design rationale

4. **Contact platform team** for issues with cluster/XSUAA/RBAC

---

**Ready to test? 🎉 Make a small commit and push to `xsuaa/kyma/generalization` to get started!**


