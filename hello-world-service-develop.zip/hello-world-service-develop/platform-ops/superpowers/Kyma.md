# Task

Come up with a plan to deploy hello-world-service to kyma cluster in namespace dev.

---

## 📚 Quick Navigation

**📖 For step-by-step dev namespace deployment guide:**
→ See `platform-ops/k8s/kyma/dev/` directory with comprehensive documentation:
  - **CHECKLIST.md** - Quick copy-paste deployment commands
  - **SETUP.md** - Detailed setup guide with all 7 phases
  - **ARCHITECTURE.md** - System design and architecture
  - **COMMANDS.md** - Command reference for everyday operations
  - **README.md** - Documentation index and navigation

---

## Current Github action pipeline 
- Use piper library to build and deploy the application to BTP CF.
- The current setup has 
  - a build job that compile the gradle application and build a docker image and publish it to a custom docker registry.
  - validate the build and 
  - deploy to BTP CF.
- The current setup uses templates from gh-action-template repo.
- All docs are in gh-action-template repo under docs.
- You must reuse build and validate jobs from the current setup and come up with a new job to deploy to kyma cluster.

## Vault
- docker-config has "username:password" base64 encoded credential for docker registry to retrieve docker image for deployment.
- **kyma secret** (for Kubernetes/Kyma deployment):
  - **Path**: `piper/data/sap-project-gtlcinfra-poc-1/hello-world-service/kyma`
  - **Format** (stored as JSON in Vault):
    ```json
    {
      "kubeconfig": "<base64-encoded-kubeconfig-file-content>"
    }
    ```
  - **How to create**:
    1. Download kubeconfig: `curl -o kubeconfig.yaml https://kyma-env-broker.cp.stage.kyma.cloud.sap/kubeconfig/<YOUR_KYMA_ENVIRONMENT_ID>`
    2. Base64 encode: `base64 -i kubeconfig.yaml | tr -d '\n'`
    3. Store in Vault at the path above with key `kubeconfig`
  - **Retrieval**: Piper automatically retrieves using `PIPER_VAULTAPPROLEID` and `PIPER_VAULTAPPROLESECRETID`
  - **Note**: Replace `<YOUR_KYMA_ENVIRONMENT_ID>` with your actual Kyma environment UUID (available from BTP cockpit)

## ServiceAccount-Based Authentication for CI/CD

**Problem**: The kubeconfig downloaded from Kyma broker uses interactive OIDC authentication (browser-based), which doesn't work in CI/CD pipelines.

**Solution**: Create a Kubernetes ServiceAccount with a token-based kubeconfig for automation.

### One-Time Setup: Create ServiceAccount and CI/CD Kubeconfig

Run these commands once to set up CI/CD authentication:

#### Step 1: Set up your local kubeconfig

```bash
# Download the kubeconfig (if you haven't already)
# Replace <YOUR_KYMA_ENVIRONMENT_ID> with your actual environment UUID from BTP cockpit
curl -o kubeconfig.yaml https://kyma-env-broker.cp.stage.kyma.cloud.sap/kubeconfig/<YOUR_KYMA_ENVIRONMENT_ID>

# Set it as your kubeconfig
export KUBECONFIG=$(pwd)/kubeconfig.yaml

# Test it works (this will open browser for authentication)
kubectl get namespaces
```

#### Step 2: Create ServiceAccount and permissions

```bash
# Create dev namespace
kubectl create namespace dev --dry-run=client -o yaml | kubectl apply -f -

# Create ServiceAccount
kubectl create serviceaccount kyma-deployer -n dev

# Create ClusterRole with deployment permissions
kubectl create clusterrole kyma-deployer \
  --verb=get,list,watch,create,update,patch,delete \
  --resource=deployments,services,pods,secrets,configmaps,namespaces,replicasets

# Bind the ClusterRole to the ServiceAccount
kubectl create clusterrolebinding kyma-deployer \
  --clusterrole=kyma-deployer \
  --serviceaccount=dev:kyma-deployer
```

#### Step 3: Create Secret with long-lived token

```bash
kubectl apply -f - <<EOF
apiVersion: v1
kind: Secret
metadata:
  name: kyma-deployer-token
  namespace: dev
  annotations:
    kubernetes.io/service-account.name: kyma-deployer
type: kubernetes.io/service-account-token
EOF

# Wait a moment for the token to be generated
sleep 5
```

#### Step 4: Generate CI/CD kubeconfig

```bash
# Extract token
TOKEN=$(kubectl get secret kyma-deployer-token -n dev -o jsonpath='{.data.token}' | base64 -d)

# Get cluster info
CLUSTER_NAME=$(kubectl config view --minify -o jsonpath='{.clusters[0].name}')
CLUSTER_SERVER=$(kubectl config view --minify -o jsonpath='{.clusters[0].cluster.server}')
CLUSTER_CA=$(kubectl config view --minify --raw -o jsonpath='{.clusters[0].cluster.certificate-authority-data}')

# Create CI/CD kubeconfig
cat > kubeconfig-cicd.yaml <<EOF
apiVersion: v1
kind: Config
clusters:
- cluster:
    certificate-authority-data: ${CLUSTER_CA}
    server: ${CLUSTER_SERVER}
  name: ${CLUSTER_NAME}
contexts:
- context:
    cluster: ${CLUSTER_NAME}
    user: kyma-deployer
  name: default
current-context: default
users:
- name: kyma-deployer
  user:
    token: ${TOKEN}
EOF

echo "✓ CI/CD kubeconfig created: kubeconfig-cicd.yaml"
```

#### Step 5: Test the CI/CD kubeconfig

```bash
# Test it works WITHOUT browser authentication
KUBECONFIG=kubeconfig-cicd.yaml kubectl get namespaces

# Should list namespaces without any browser prompt
```

#### Step 6: Base64 encode for GitHub Secret

```bash
# Encode the kubeconfig
base64 -i kubeconfig-cicd.yaml | tr -d '\n' > kubeconfig-cicd.b64

echo ""
echo "✓ Base64 encoded kubeconfig saved to: kubeconfig-cicd.b64"
echo ""
echo "Now update the environment-specific GitHub secret with the contents of kubeconfig-cicd.b64"
echo ""

# Copy command (cross-platform)
if command -v pbcopy &> /dev/null; then
  echo "Copy to clipboard: cat kubeconfig-cicd.b64 | pbcopy"
elif command -v xclip &> /dev/null; then
  echo "Copy to clipboard: cat kubeconfig-cicd.b64 | xclip -selection clipboard"
else
  echo "View contents: cat kubeconfig-cicd.b64"
fi
```

#### Step 7: Update GitHub Secret

After running the commands above, update the GitHub Actions secrets for the matching namespace:

1. Go to: https://github.tools.sap/GTLCInfra/hello-world-service/settings/secrets/actions
2. Create or edit one of:
   - `KYMA_KUBECONFIG_DEV`
   - `KYMA_KUBECONFIG_QA`
   - `KYMA_KUBECONFIG_PROD`
3. Paste the contents from `kubeconfig-cicd.b64`
4. Save
5. Repeat for each namespace with that namespace's service-account kubeconfig

### Why ServiceAccount Instead of OIDC?

According to [Kyma CI/CD documentation](https://github.tools.sap/kyma/documentation/blob/main/docs/sap-related-guides/26-internal-teams-kyma-ci-cd.md):

> Using Piper, you can configure the kubernetesDeploy step in the Hyperspace pipeline. To do so, you must provide your Kubeconfig, which is used to deploy the configurations to the Kyma runtime.

The kubeconfig from Kyma broker uses:
- **OIDC with `kubectl-oidc_login`** - requires browser authentication
- **Not suitable for CI/CD** - cannot open browser in GitHub Actions

The ServiceAccount approach:
- ✅ Uses token-based authentication (no browser required)
- ✅ Follows Kubernetes RBAC best practices
- ✅ Works in any automation environment
- ✅ Token doesn't expire (unless Secret is deleted)

## Deploying to Kyma

### Overview

The hello-world-service is deployed to Kyma cluster using a fully automated CI/CD pipeline with Helm charts and GitHub Actions workflows. The pipeline builds the Docker image, validates it, and deploys to Kyma - all without manual intervention.

### Complete CI/CD Pipeline

**Pipeline Stages:**
1. **Build** - Compile Gradle application and build Docker image using Piper
2. **Validate** - Verify Docker image exists in registry
3. **Deploy** - Deploy to Kyma namespace using Helm with the versioned image

**Key Features:**
- ✅ Fully automated - no manual steps required
- ✅ ServiceAccount authentication - no browser interaction
- ✅ Vault integration for credentials (same as CF deployment)
- ✅ Version-tagged images from Piper build
- ✅ Helm deployment with health checks and rollback support

### Prerequisites

1. ServiceAccount kubeconfig setup complete (see "ServiceAccount-Based Authentication" section above)
2. GitHub secrets contain base64-encoded token-based kubeconfigs:
   - `KYMA_KUBECONFIG_DEV`
   - `KYMA_KUBECONFIG_QA`
   - `KYMA_KUBECONFIG_PROD`
3. Docker registry credentials in Vault at `piper/data/sap-project-gtlcinfra-poc-1/hello-world-service/docker-config`
   - Field name: `dockerConfigJSON` (standard Docker config.json format)
4. Helm chart in `helm/hello-world-service/` directory

### Environments

| Environment | Namespace | Replicas | Image Tag | Resources (CPU/Memory) |
|-------------|-----------|----------|-----------|------------------------|
| Dev         | dev       | 1        | From CPE  | 250m/256Mi - 500m/512Mi |
| QA          | qa        | 2        | From CPE  | 375m/384Mi - 750m/768Mi |
| Prod        | prod      | 3        | From CPE  | 500m/512Mi - 1000m/1Gi |

**Note:** Image tags are automatically determined from Piper's Common Pipeline Environment (CPE) artifact, using semantic versioning with timestamps (e.g., `1.0.4-20260824210033_e3e5b44`).

### GitHub Actions Workflows

**Dev Environment:**
- **Workflow:** `.github/workflows/deploy-kyma-dev.yml`
- **Trigger:** Automatic on push to `develop` branch OR manual dispatch
- **Namespace:** `dev`
- **Values:** `helm/hello-world-service/values-dev.yaml`

**QA Environment:**
- **Workflow:** `.github/workflows/deploy-kyma-qa.yml`
- **Trigger:** Automatic on push to `main` branch OR manual dispatch
- **Namespace:** `qa`
- **Values:** `helm/hello-world-service/values-qa.yaml`

**Prod Environment:**
- **Workflow:** `.github/workflows/deploy-kyma-prod.yml`
- **Trigger:** Manual dispatch ONLY
- **Namespace:** `prod`
- **Values:** `helm/hello-world-service/values-prod.yaml`

### Manual Deployment

To trigger a manual deployment via GitHub Actions UI:

1. Go to repository: https://github.tools.sap/GTLCInfra/hello-world-service/actions
2. Select the workflow: "Deploy to Kyma Dev/QA/Prod"
3. Click "Run workflow"
4. Select branch (typically the default)
5. Click green "Run workflow" button

### Local Deployment (for testing)

**Prerequisites:**
- kubectl configured with Kyma kubeconfig
- Helm 3 installed

**Deploy to dev namespace:**
```bash
# From repository root
helm upgrade --install hello-world-service helm/hello-world-service \
  -f helm/hello-world-service/values-dev.yaml \
  --namespace dev \
  --create-namespace \
  --wait \
  --timeout 5m
```

**Check deployment status:**
```bash
kubectl get deployments -n dev
kubectl get pods -n dev
kubectl get services -n dev
kubectl rollout status deployment/hello-world-service -n dev
```

**View application logs:**
```bash
kubectl logs -n dev -l app.kubernetes.io/name=hello-world-service --tail=100 -f
```

**Port-forward for local testing:**
```bash
kubectl port-forward -n dev svc/hello-world-service 8080:8080
curl http://localhost:8080/actuator/health
curl http://localhost:8080/greet?name=TestUser
```

### Deployment Validation

After a successful deployment, validate the service is running correctly:

**1. Check deployment status:**
```bash
kubectl get deployment hello-world-service -n dev
# Expected: 1/1 READY, 1 UP-TO-DATE, 1 AVAILABLE
```

**2. Check pod health:**
```bash
kubectl get pods -n dev -l app.kubernetes.io/name=hello-world-service
# Expected: 2/2 Running (application + Istio sidecar)
```

**3. Verify image version:**
```bash
kubectl get deployment hello-world-service -n dev -o jsonpath='{.spec.template.spec.containers[0].image}'
# Expected: gtlc-docker.common.repositories.cloud.sap/hello-world-service:<version-tag>
```

**4. Check service endpoint:**
```bash
kubectl get svc hello-world-service -n dev
# Expected: ClusterIP service on port 8080
```

**5. Test health endpoint:**
```bash
kubectl port-forward -n dev svc/hello-world-service 8080:8080 &
curl http://localhost:8080/actuator/health
# Expected: {"status":"UP"}
```

**6. View recent logs:**
```bash
kubectl logs -n dev -l app.kubernetes.io/name=hello-world-service --tail=50
# Expected: No errors, application started successfully
```

### Troubleshooting Deployments

**Pod not starting (ImagePullBackOff):**
- Check docker-registry-secret exists: `kubectl get secret docker-registry-secret -n dev`
- Verify Vault docker-config credentials are correct
- Verify image tag exists in registry

**Pod not ready (CrashLoopBackOff):**
- Check pod logs: `kubectl logs -n dev <pod-name>`
- Check events: `kubectl describe pod -n dev <pod-name>`
- Verify health check endpoint responds: `/actuator/health`

**Helm deployment timeout:**
- Check pod status: `kubectl get pods -n dev`
- Increase timeout: `helm upgrade --timeout 10m ...`
- Check resource constraints in namespace

**Pipeline authentication failure:**
- Verify ServiceAccount token is still valid
- Check if ServiceAccount has proper RBAC permissions
- Verify the namespace-specific GitHub secret is set correctly (`KYMA_KUBECONFIG_DEV`, `KYMA_KUBECONFIG_QA`, or `KYMA_KUBECONFIG_PROD`)

## One kubeconfig per namespace migration

Target state:

- `dev` workflow uses `KYMA_KUBECONFIG_DEV` authenticated as `system:serviceaccount:dev:kyma-deployer`
- `qa` workflow uses `KYMA_KUBECONFIG_QA` authenticated as `system:serviceaccount:qa:kyma-deployer`
- `prod` workflow uses `KYMA_KUBECONFIG_PROD` authenticated as `system:serviceaccount:prod:kyma-deployer`

Required steps:

1. Create one service-account kubeconfig per namespace.
2. Base64-encode each kubeconfig.
3. Store each one in the GitHub Actions secret with the matching environment name.
4. Trigger each Kyma workflow once and confirm `kubectl auth whoami` shows the expected namespace-specific service account.
5. After verification, remove cross-namespace fallback subjects from `qa` and `prod` RoleBindings so each namespace binds only its own `kyma-deployer` service account.

### Rollback

**Using Helm:**
```bash
# List release history
helm history hello-world-service -n dev

# Rollback to previous version
helm rollback hello-world-service -n dev

# Rollback to specific revision
helm rollback hello-world-service <revision> -n dev
```

**Using kubectl:**
```bash
# Rollback to previous deployment revision
kubectl rollout undo deployment/hello-world-service -n dev
```

### Helm Chart Structure

The Helm chart is located at `helm/hello-world-service/` with the following structure:

```
helm/hello-world-service/
├── Chart.yaml              # Chart metadata
├── values.yaml             # Default values
├── values-dev.yaml         # Dev environment overrides
├── values-qa.yaml          # QA environment overrides
├── values-prod.yaml        # Prod environment overrides
└── templates/
    ├── _helpers.tpl        # Template helpers
    ├── deployment.yaml     # Kubernetes Deployment
    └── service.yaml        # Kubernetes Service
```

### Modifying Deployment Configuration

**Change replica count:**
Edit `values-<env>.yaml` and update `replicaCount`.

**Change resource limits:**
Edit `values-<env>.yaml` and update `resources.limits` and `resources.requests`.

**Change health check timings:**
Edit `values.yaml` and update `livenessProbe` and `readinessProbe` settings.

After making changes, commit and push to trigger automatic deployment (dev/qa) or manually trigger (prod).

## Internet-Facing Endpoint

### Overview

This repo supports two external exposure patterns depending on what the target cluster provides:

- **Kyma APIRule** - current default for `dev`/`qa` HTTPS exposure when API Gateway module and APIRule CRDs are installed
- **LoadBalancer Service** - fallback only for clusters that do not support APIRule exposure

### Environment URLs

| Environment | Exposure pattern | Enabled | Access |
|-------------|------------------|---------|--------|
| Dev         | APIRule | ✅ Yes | HTTPS host via APIRule |
| QA          | APIRule | ✅ Yes | HTTPS host via APIRule |
| Prod        | APIRule-capable config in values | ❌ No* | Enable only if cluster supports it |

*Prod is disabled by default for safety. Enable by setting `apirule.enabled: true` in `values-prod.yaml`.

### Get Endpoint URL

After deployment, retrieve the public URL:

```bash
# Preferred: APIRule host (v2 then v1beta1 shape fallback)
HOST=$(kubectl get apirule hello-world-service -n dev -o jsonpath='{.spec.hosts[0]}' 2>/dev/null || true)
if [ -z "$HOST" ]; then
  HOST=$(kubectl get apirule hello-world-service -n dev -o jsonpath='{.spec.host}' 2>/dev/null || true)
fi
echo "https://$HOST"

# Fallback (clusters without APIRule support):
# EXTERNAL_IP=$(kubectl get svc hello-world-service -n dev -o jsonpath='{.status.loadBalancer.ingress[0].ip}')
# echo "http://$EXTERNAL_IP:8080"
```

### Test the Endpoint

```bash
# Health check
curl http://$EXTERNAL_IP:8080/actuator/health

# Greeting endpoint (public access)
curl "http://$EXTERNAL_IP:8080/greet?name=World"
```

### Modify External Exposure

#### Enable for Prod

Edit `helm/hello-world-service/values-prod.yaml`:

```yaml
apirule:
  enabled: true
  # ... rest stays the same
```

#### Change Methods/Access Strategy

Edit the appropriate `values-<env>.yaml`:

```yaml
apirule:
  enabled: true
  methods:
    - GET
    - POST
  accessStrategies:
    # Example: require OAuth token (if XSUAA auth is configured)
    - handler: oauth2_introspection
      config:
        requiredScopes: ["read"]
```

#### Disable External Access

Set `apirule.enabled: false` in the environment's `values-<env>.yaml` file.

### Troubleshooting APIRule

**APIRule stuck in "Error" state:**

```bash
# Check the APIRule status
kubectl describe apirule hello-world-service -n dev

# Common issues:
# 1. Service not found - verify hello-world-service Service exists
kubectl get svc hello-world-service -n dev

# 2. Gateway not found - verify kyma-gateway exists
kubectl get gateway kyma-gateway -n kyma-system

# 3. Delete and redeploy
kubectl delete apirule hello-world-service -n dev
helm upgrade --install hello-world-service helm/hello-world-service \
  -f helm/hello-world-service/values-dev.yaml \
  --namespace dev \
  --wait
```

**Cannot reach the endpoint:**

```bash
# Verify APIRule is ready
kubectl get apirule hello-world-service -n dev -o jsonpath='{.status.apiRuleStatus}'

# Check if Service is receiving traffic
kubectl port-forward -n dev svc/hello-world-service 8080:8080 &
curl http://localhost:8080/actuator/health
```

## BTP Kyma

**Note**: The actual cluster identifiers are stored in team-internal documentation and should not be committed to source control.

- APIServerURL : `https://api.<cluster-id>.stage.kyma.ondemand.com/`
- kubeConfigURL : `https://kyma-env-broker.cp.stage.kyma.cloud.sap/kubeconfig/<YOUR_KYMA_ENVIRONMENT_ID>`
- Kubernetes dashboard: `https://dashboard.stage.kyma.cloud.sap/?kubeconfigID=<YOUR_KYMA_ENVIRONMENT_ID>`
- kubernetes name: `<your-kyma-cluster-name>`

**To get your actual values**: Check BTP Cockpit → Kyma Environment → Overview

## Access kyma cluster
```bash
alias k="kubectl --kubeconfig=./canary/hello-kyma.kubeconfig.yaml"
```

# Piper  
consult [piper codebased and docs](https://github.tools.sap/GTLCInfra/gh-action-template/blob/main/docs/Piper.md#official-piper-resources) for all piper specific command options and syntax


## CI/CD & Piper section

- When working with Piper CI/CD pipelines, always read the official Piper documentation BEFORE suggesting fixes. Never guess at parameter names, Vault secret structures, or configuration options.

- For Vault credential configurations: Always ask the user to confirm the exact Vault path structure and secret names before making changes. Never assume secret naming conventions (e.g., docker-config vs docker).

- Before making configuration changes, wait for user to finish explaining their requirements. Do not start implementing until the full context is provided.

- When copying files or configurations between repositories, preserve the exact directory structure unless explicitly told otherwise.

- For Docker image tags in SAP/Piper pipelines: Verify exact tag formats from existing working configs (e.g., 'ppiper/cf-cli:v23' not 'v1.58.0'). Never invent version numbers.

 
# Autonomous CI/CD Pipeline Debugging Agent

I need you to autonomously fix my failing Piper pipeline. Here's your workflow: 
1) Fetch the latest failed GitHub Actions run logs using gh CLI, 
2) Analyze the error and identify root cause (check Vault paths, Docker configs, credential names), 
3) Read the relevant Piper documentation before proposing fixes, 
4) Make the fix and push to a test branch,
5) Monitor the new run and iterate if it fails again. Keep going until the pipeline passes or you hit a blocker requiring my input. Document each iteration's hypothesis and result.

 
# Self-Healing Configuration Documentation Generator

Create comprehensive, accurate documentation for my Piper CI/CD setup by autonomously exploring my codebase:
1) Glob for all .pipeline/*.yaml, .github/workflows/*.yml, and **/config.yml files, 
2) Extract actual Vault secret paths, Docker registry URLs, and credential names currently in use, 
3) WebFetch the official Piper documentation for each step type I'm using, 
4) Cross-reference my configs against the docs to identify any misconfigurations, 
5) Generate a PIPER_REFERENCE.md with: working examples from my repo, correct parameter names, common pitfalls I've hit, and troubleshooting steps. Update this doc whenever you notice my configs diverge from it.


