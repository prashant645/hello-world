# Kyma Generalization Implementation Plan

> **Scope note:** This is a planning/backlog document only. It does **not** implement the solution. It translates `platform-ops/superpowers/Kyma-Generalization.md` into phased work items for `gh-action-template`, platform bootstrap, and client repositories.

**Goal:** Generalize the current Kyma + APIRule + XSUAA deployment pattern into reusable building blocks that can live in `gh-action-template`, while preserving strict separation between platform bootstrap and normal app delivery.

**Primary outcome:** A Kyma-first reusable deployment architecture that later extends to Cloud Foundry + XSUAA through the same `target` + `auth-provider` abstractions.

**Refined ownership model:**
- cluster bootstrap is centralized
- namespace/app bootstrap framework is standardized centrally
- namespace/app bootstrap instances remain in each project repo

**Out of scope for initial implementation:**
- actual Cloud Foundry XSUAA delivery implementation
- full GitOps adoption
- replacing all existing repo-local docs immediately

---

## Executive Summary

The work should be split into six epics:

1. **Define the cross-target contract** (`target`, `exposure`, `auth-provider`, verification model)
2. **Create a Kyma-only reusable app deployment workflow** in `gh-action-template`
3. **Create a bootstrap package** for namespace/deployer/runtime-SA onboarding
4. **Separate privileged setup ownership from app deployment ownership**
5. **Add drift detection and privileged-change safeguards**
6. **Migrate pilot service repos** (starting with `hello-world-service`)

The most important architectural rule is:

> Normal app deployment workflows must not own privileged bootstrap resources.

The second most important rule is:

> Project repos may own bootstrap inputs and app-scoped bootstrap instances, but they should not invent their own bootstrap model.

---

## ✅ Summarized Architecture Decisions

| Decision Area | Resolution |
|---|---|
| **Bootstrap Framework Location** | General files in `gh-action-template` repo; project-specific files in hello-world-service |
| **Manifest Storage** | Project-specific bootstrap manifests in project repo; general ones in `gh-action-template` |
| **XSUAA Resources** | Strictly precreated (not pipeline-managed) |
| **Runtime ServiceAccounts** | Precreated with manifests stored in project repo |
| **Drift Detection** | Mandatory for release/prod environments |

---

## Success Criteria

The generalized solution is considered successful when:

- a service repo can onboard to Kyma with a thin workflow wrapper and a documented bootstrap procedure
- normal Kyma app runs no longer show irrelevant CF branches in the job graph
- deployer RBAC, cross-namespace RBAC, namespace labels, and runtime identity setup are clearly bootstrap-owned
- runtime auth verification over public HTTPS is reusable and standardized
- the design allows a later Cloud Foundry adapter without redesigning the auth contract
- drift between git and cluster RBAC can be detected before a release fails

---

## Workstreams / Epics

## Epic 1: Define the generalized contract

**Owner suggestion:** template maintainers + platform maintainers

### Deliverables
- contract document for reusable deployment inputs
- contract document for bootstrap inputs/outputs
- chart capability contract for service repos
- contract for project-local namespace/app bootstrap specs layered on central platform defaults

### Required decisions
- `target`: `kyma` now, later `cf`
- `auth-provider`: `xsuaa` now, later extensible
- `exposure-mode`: `apirule` now, later `route`
- `runtime-service-account-managed`: default `false`
- whether app-specific XSUAA resources are pre-created vs pipeline-created

### Backlog
- [ ] Define canonical workflow inputs for app deployment
- [ ] Define canonical bootstrap inputs for namespace setup
- [ ] Define platform blueprint vs service overlay layering model
- [ ] Define expected Helm chart fields:
  - `serviceAccount`
  - `apirule`
  - `xsuaa`
- [ ] Define preflight and post-deploy verification interface
- [ ] Define future Cloud Foundry mapping for the same abstractions

### Acceptance Criteria
- there is a documented contract that a second service repo could implement without reverse-engineering `hello-world-service`
- contract does not hardcode Kyma-only assumptions into XSUAA behavior

---

## Epic 2: Create a Kyma-only reusable deployment workflow in `gh-action-template`

**Problem solved:** current unified workflow renders confusing CF nodes for Kyma runs.

### Deliverables
- new Kyma-only reusable workflow in `gh-action-template`
- clear job graph for Kyma runs
- reusable Kyma validation/deploy/verify stages

### Suggested workflow responsibilities
- manifest parse / config synthesis
- Build & Test reuse
- Validation reuse
- Deploy to Kyma
- APIRule readiness wait
- public HTTPS/XSUAA verification

### Suggested inputs
- `target=kyma`
- `environment`
- `namespace`
- `helm-chart-path`
- `helm-values-file`
- `release-name`
- `skip-validation`
- `auth-provider`
- `exposure-mode`
- `runtime-service-account-name`
- `runtime-service-account-managed=false`
- flags for:
  - preflight
  - APIRule wait
  - post-deploy auth test

### Backlog
- [ ] Design new Kyma-only reusable workflow
- [ ] Reuse existing build/validation building blocks where possible
- [ ] Factor deploy-to-Kyma logic into Kyma-only path
- [ ] Factor auth verification into reusable Kyma post-deploy path
- [ ] Ensure no CF jobs appear in Kyma graph
- [ ] Define backwards-compatibility or migration strategy from `pipeline-unified.yml`

### Acceptance Criteria
- a Kyma run graph contains only Kyma-relevant jobs
- a Kyma service repo can call the workflow with a thin wrapper
- QA/prod auth verification behavior is standardized

---

## Epic 3: Create a bootstrap package / procedure

**Problem solved:** one-time and privileged setup is currently mixed with app delivery understanding.

### Deliverables
- centralized cluster bootstrap assets
- centralized namespace/app bootstrap contract and tooling
- project-local namespace/app bootstrap spec pattern
- bootstrap verification procedure
- onboarding doc

### Bootstrap scope

#### Cluster bootstrap scope (centralized)
- cluster prerequisites
- shared gateway/operator assumptions
- cluster discovery RBAC
- common policy defaults

#### Namespace/app bootstrap scope (project-local instances, centrally standardized)
- namespace setup
- deployer ServiceAccount creation
- kubeconfig generation guidance
- namespace RBAC
- cross-namespace RBAC
- namespace labels
- service manager credential bootstrap
- runtime ServiceAccount creation/verification

### Backlog
- [ ] Define centralized cluster bootstrap asset layout
- [ ] Define centrally standardized namespace/app bootstrap spec layout for project repos
- [ ] Define whether the shared bootstrap framework lives in `gh-action-template`, a platform repo, or both
- [ ] Define bootstrap execution mode:
  - manual workflow
  - shell wrapper
  - platform automation
- [ ] Define how project repos provide concrete values to the shared bootstrap framework
- [ ] Make all bootstrap manifests idempotent
- [ ] Add verification checklist / script
- [ ] Add re-run safety guidance

### Acceptance Criteria
- a new namespace/app can be onboarded by supplying project-specific inputs to a codified, repeatable bootstrap procedure
- bootstrap can be rerun safely without breaking app deployment
- privileged resources are clearly separated from app release resources

---

## Epic 4: Enforce ownership boundaries

**Problem solved:** accidental overwrite of privileged resources.

### Ownership model to enforce

#### Bootstrap-owned centrally or via centrally defined bootstrap framework
- deployer ServiceAccount
- deployer RBAC
- cross-namespace RBAC
- namespace labels
- bootstrap credentials secret setup
- runtime ServiceAccount (default)
- runtime SA security-sensitive annotations / bindings

#### App-deployment-owned
- Deployment
- Service
- APIRule
- rollout verification
- public HTTPS auth verification
- image tag changes
- app-scoped configuration intentionally owned by the release

### Backlog
- [ ] Document ownership matrix per resource type
- [ ] Ensure reusable deploy workflow defaults to **referencing**, not creating, runtime SA
- [ ] Define opt-in mode if teams want app-managed runtime SA
- [ ] Review Helm contracts for resources that must not be app-owned by default
- [ ] Review repo protections / CODEOWNERS for privileged manifests
- [ ] Define which bootstrap artifacts stay central and which stay in each project repo

### Acceptance Criteria
- there is no ambiguity about whether a given resource is bootstrap-owned or pipeline-owned
- normal deploy workflow identity cannot mutate privileged bootstrap resources

---

## Epic 5: Add drift detection and safeguards

**Problem solved:** cluster state can silently diverge from repo state.

### Deliverables
- read-only drift detection script/workflow
- pre-release verification checks
- operational procedure for fixing drift

### Recommended drift checks
- deployer can read required resources (`serviceaccounts`, `pods`, etc.)
- runtime ServiceAccount exists
- namespace has required labels
- cross-namespace RoleBindings exist
- XSUAA bootstrap secret exists and matches expected source
- app-specific binding secret exists when required

### Backlog
- [ ] Define minimum required checks per environment
- [ ] Create read-only validation mode reusable by pipelines or operators
- [ ] Add scheduled or pre-release drift audit option
- [ ] Add failure messages with direct remediation commands
- [ ] Decide whether drift checks block prod/release runs by default

### Acceptance Criteria
- RBAC drift like the QA `serviceaccounts` failure is detected before deploy
- remediation path is deterministic and documented

---

## Epic 6: Pilot migration and rollout

**Target pilot:** `hello-world-service`

### Deliverables
- migrated service repo using new Kyma-only template
- bootstrap procedure validated in dev/qa/prod
- migration lessons documented

### Backlog
- [ ] Migrate `hello-world-service` wrappers to new template workflow
- [ ] Validate dev namespace using bootstrap + deploy separation
- [ ] Validate qa namespace using bootstrap + deploy separation
- [ ] Validate prod namespace using bootstrap + deploy separation
- [ ] Record migration deltas required for other services
- [ ] Produce “onboard another service” checklist

### Acceptance Criteria
- the pilot service runs successfully across dev/qa/prod with the generalized approach
- follow-up services have a documented path to adoption

---

## Proposed Repository Placement

## In `gh-action-template`

### New reusable workflow(s)
- Kyma-only app deploy workflow
- optional shared preflight/auth verification steps
- optional bootstrap workflow wrapper if the template repo is the right home

### Shared bootstrap framework assets
- cluster bootstrap blueprint(s)
- namespace/app bootstrap schema or contract
- reusable generators/helpers
- shared validation logic

### Shared scripts/actions
- APIRule wait logic
- auth smoke-test logic
- generic preflight helpers
- drift detection helpers

---

## In client repos such as `hello-world-service`

### Keep
- Helm chart
- env-specific values
- app-specific XSUAA manifests
- namespace/app bootstrap spec or values
- rendered or source app-scoped bootstrap manifests following the shared contract
- thin workflow wrappers

### Reduce/remove over time
- duplicated deployment logic
- duplicated auth verification logic
- duplicated RBAC reasoning

---

## In a platform repo or bootstrap package

If bootstrap governance is more sensitive than app delivery, consider moving privileged manifests to a platform-owned repo.

That repo would own:
- deployer identities
- RBAC
- namespace onboarding procedures
- drift remediation automation

If that route is chosen, `gh-action-template` can still own the reusable deployment workflow and the shared bootstrap contract while the platform repo owns the most privileged manifests and apply path.

This is preferable if the organization wants strong separation of duties.

---

## Risks and Mitigations

## Risk 1: Overfitting to `hello-world-service`
**Mitigation:** define contracts first; keep service-specific naming/config as inputs.

## Risk 2: Runtime SA still gets accidentally owned by app chart
**Mitigation:** default `runtime-service-account-managed=false`; fail fast if missing.

## Risk 3: Bootstrap remains partly manual and drifts again
**Mitigation:** codify bootstrap, add read-only drift detection, prefer platform-owned apply path.

## Risk 4: Kyma-only design blocks CF later
**Mitigation:** design around `target`, `auth-provider`, and `exposure-mode` abstractions now.

## Risk 5: Template migration breaks existing services
**Mitigation:** pilot with one service, maintain compatibility or phased adoption path.

---

## Recommended Sequencing

### Phase 1: Contract and design stabilization
- finalize architecture contract
- finalize ownership model
- finalize runtime SA default policy

### Phase 2: Build Kyma-only reusable workflow
- remove unified graph confusion
- standardize deployment and verification path

### Phase 3: Bootstrap codification
- create manifests, workflow/script, and procedure
- validate onboarding/reapply behavior

### Phase 4: Drift detection
- add read-only checks
- add release safety checks

### Phase 5: Pilot migration
- move `hello-world-service`
- validate all three environments

### Phase 6: Prepare CF extension
- define adapter points
- reuse XSUAA abstractions

---

## Open Questions

- Should bootstrap manifests live in `gh-action-template`, a platform repo, or both?
- Should runtime ServiceAccount ever be app-managed outside sandbox/dev use cases?
- Should app-specific XSUAA resources be pre-created by bootstrap or allowed during normal deploy?
- Should drift detection run:
  - before every deploy?
  - only before release/prod?
  - on schedule?
- Should bootstrap execution require environment approval and restricted GitHub environments?

---

## Recommended Immediate Next Decisions

1. Approve the **resource ownership model**
2. Approve **runtime ServiceAccount bootstrap-owned by default**
3. Approve **Kyma-only reusable workflow** as the next template direction
4. Approve **centralized cluster bootstrap + centrally standardized, project-local namespace/app bootstrap instances**
5. Decide where the **shared bootstrap framework** will live
6. Decide whether the pilot includes only `hello-world-service` initially

---

## Bottom Line

This work should proceed as a structured platform initiative, not as ad hoc copy-paste between service repos.

The implementation path is:
- define the reusable contract
- separate cluster/bootstrap framework from deploy
- keep namespace/app bootstrap instances local to each project under the shared model
- centralize Kyma-only deploy behavior in `gh-action-template`
- keep privileged resources bootstrap-owned
- add drift detection
- then pilot on `hello-world-service`

That delivers a safer, clearer, and CF-extensible architecture without prematurely implementing Cloud Foundry support now.

