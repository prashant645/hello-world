# Docker-Based CF Deployment Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Replace MTA-based CF deployment with Docker image deployment, using explicit Vault secrets and Piper Extension for CF_DOCKER_PASSWORD injection.

**Architecture:** Gradle builds JAR → dockerBuild creates image → push to registry → Piper Extension fetches CF_DOCKER_PASSWORD from Vault → cloudFoundryDeploy pulls image. VERSION file is single source of truth; no version commits to GitHub.

**Tech Stack:** GitHub Actions, Piper (dockerBuild, cloudFoundryDeploy), HashiCorp Vault, Docker, Cloud Foundry

---

## File Structure

### gh-action-template (New Docker Variant Files)

| File | Purpose |
|------|---------|
| `.github/workflows/gtlcinfra-pipeline.docker.yml` | Main reusable workflow with dockerBuild + CF deploy |
| `.github/workflows/pr-build.docker.yml` | PR build caller (no push/deploy) |
| `.github/workflows/deploy-dev.docker.yml` | Dev deployment caller |
| `.github/workflows/deploy-qa.docker.yml` | QA deployment caller |
| `.github/workflows/deploy-prod.docker.yml` | Prod deployment caller |
| `.pipeline/config.template.docker.yml` | Piper config template for Docker builds |
| `.pipeline/extensions/preRelease/action.yml` | Composite action for CF deploy with Docker creds |

### hello-world-service (Client Repo)

| File | Purpose |
|------|---------|
| `manifest.yml` | CF Docker deployment descriptor |
| `.github/workflows/pr-build.yml` | Update to reference `pr-build.docker.yml` |
| `.github/workflows/deploy-qa.yml` | Update to reference `deploy-qa.docker.yml` |
| `.github/workflows/deploy-prod.yml` | Update to reference `deploy-prod.docker.yml` |
| `.pipeline/config.yml` | Update for dockerBuild configuration |

---

## Task 1: Create Piper Config Template for Docker

**Files:**
- Create: `gh-action-template/.pipeline/config.template.docker.yml`

- [ ] **Step 1: Create the Docker config template**

```yaml
general:
  buildTool: 'gradle'
  vaultPath: 'piper/sap-project-gtlcinfra-poc-1'
  vaultBasePath: 'piper/sap-project-gtlcinfra-poc-1'
  vaultPipelineName: 'hello-world-service'
  vaultServerUrl: 'https://vault.tools.sap'
  vaultNamespace: 'ies/hyperspace/pipelines'
  nativeBuild: true
  verbose: true

stages:
  Build:
    gradleExecuteBuild: true
    dockerBuild: true
    kanikoExecute: false
    sapCumulusUpload: true
  Release:
    cloudFoundryDeploy: true
  Post:
    vaultRotateSecretId: false

steps:
  artifactPrepareVersion:
    versioningType: 'cloud_noTag'
    commitVersion: false
    additionalTargetTools:
      - gradle

  gradleExecuteBuild:
    dockerImage: 'sapmachine:21-jdk'
    useWrapper: true
    createBom: false

  dockerBuild:
    containerImageName: 'hello-world-service'
    containerRegistryUrl: 'gtlc-production.common.repositories.cloud.sap'
    containerImageTag: '${commonPipelineEnvironment.artifactVersion}'
    dockerfilePath: 'Dockerfile'
    dockerConfigFileVaultSecretName: 'docker-config'

  cloudFoundryDeploy:
    apiEndpoint: 'https://api.cf.eu01-canary.hana.ondemand.com'
    org: 'GTLC-test_hello-qyodsuvs'
    loginParameters: '--origin sap.ids'
    cloudfoundryVaultSecretName: 'cf'
    deployType: 'standard'
    manifest: 'manifest.yml'

  sapCumulusUpload:
    pipelineId: '297bf2b8-5f5a-4e1e-ba36-5c4cc4e890ed'
    systemTrust: true
```

- [ ] **Step 2: Verify file created**

Run: `cat gh-action-template/.pipeline/config.template.docker.yml | head -20`
Expected: Shows `general:` section with `buildTool: 'gradle'`

- [ ] **Step 3: Commit**

```bash
cd /Users/I819791/IdeaProjects/GTLCInfra/gh-action-template
git add .pipeline/config.template.docker.yml
git commit -m "feat: add Docker build config template"
```

---

## Task 2: Create Piper Extension for CF Deploy

**Files:**
- Create: `gh-action-template/.pipeline/extensions/preRelease/action.yml`

- [ ] **Step 1: Create extensions directory**

```bash
mkdir -p gh-action-template/.pipeline/extensions/preRelease
```

- [ ] **Step 2: Create the composite action**

```yaml
name: 'Pre-Release Extension'
description: 'Fetch Docker credentials from Vault and deploy to CF'

inputs:
  piper-vault-app-role-id:
    description: 'Vault AppRole ID'
    required: true
  piper-vault-app-role-secret-id:
    description: 'Vault AppRole Secret ID'
    required: true
  config-path:
    description: 'Path to Piper config file'
    required: false
    default: '.pipeline/config.yml'
  env-config-path:
    description: 'Path to environment-specific config'
    required: false
    default: ''
  cf-space:
    description: 'CF space name for manifest variable'
    required: false
    default: 'dev'

runs:
  using: 'composite'
  steps:
    - name: Fetch Docker credentials from Vault
      id: vault
      uses: hashicorp/vault-action@v3
      with:
        url: 'https://vault.tools.sap'
        namespace: 'ies/hyperspace/pipelines'
        method: approle
        roleId: ${{ inputs.piper-vault-app-role-id }}
        secretId: ${{ inputs.piper-vault-app-role-secret-id }}
        exportEnv: true
        secrets: |
          piper/data/sap-project-gtlcinfra-poc-1/docker-config password | CF_DOCKER_PASSWORD

    - name: Create manifest-variables.yml
      shell: bash
      run: |
        VERSION=$(cat .pipeline/commonPipelineEnvironment/artifactVersion 2>/dev/null || echo "0.0.0")
        SPACE="${{ inputs.cf-space }}"
        cat > manifest-variables.yml << EOF
        version: ${VERSION}
        space: ${SPACE}
        EOF
        echo "Created manifest-variables.yml: version=${VERSION}, space=${SPACE}"
        cat manifest-variables.yml

    - name: Deploy to Cloud Foundry
      uses: piper/piper-action@v1
      env:
        CF_DOCKER_PASSWORD: ${{ env.CF_DOCKER_PASSWORD }}
        PIPER_vaultAppRoleID: ${{ inputs.piper-vault-app-role-id }}
        PIPER_vaultAppRoleSecretID: ${{ inputs.piper-vault-app-role-secret-id }}
      with:
        step-name: cloudFoundryDeploy
        flags: >-
          --defaultConfig ${{ inputs.config-path }}
          ${{ inputs.env-config-path != '' && format('--defaultConfig {0}', inputs.env-config-path) || '' }}
          --vars-file manifest-variables.yml
```

- [ ] **Step 3: Verify file created**

Run: `cat gh-action-template/.pipeline/extensions/preRelease/action.yml | head -20`
Expected: Shows `name: 'Pre-Release Extension'`

- [ ] **Step 4: Commit**

```bash
cd /Users/I819791/IdeaProjects/GTLCInfra/gh-action-template
git add .pipeline/extensions/preRelease/action.yml
git commit -m "feat: add Piper extension for CF Docker deploy"
```

---

## Task 3: Create Main Pipeline Workflow (Docker Variant)

**Files:**
- Create: `gh-action-template/.github/workflows/gtlcinfra-pipeline.docker.yml`

- [ ] **Step 1: Create the main pipeline workflow**

```yaml
name: GTLC-INFRA Pipeline (Docker)

on:
  workflow_call:
    inputs:
      build-type:
        description: 'Build type: pr-build (no deploy) or deployable (build + push + deploy)'
        required: true
        type: string
      environment:
        description: 'Target environment: dev, qa, prod'
        required: false
        type: string
        default: ''
      env-config-path:
        description: 'Path to environment-specific config file'
        required: false
        type: string
        default: ''
      deploy-target:
        description: 'Deployment target: cf, kyma, none'
        required: false
        type: string
        default: 'none'
      skip-validation:
        description: 'Skip validation stage'
        required: false
        type: boolean
        default: false
      runs-on:
        description: 'Runner labels'
        required: false
        type: string
        default: 'self-hosted'
    secrets:
      PIPER_VAULTAPPROLEID:
        required: true
      PIPER_VAULTAPPROLESECRETID:
        required: true

env:
  PIPER_ACTION_SAP_PIPER_VERSION: 'latest'
  PIPER_ACTION_SAP_PIPER_OWNER: project-piper
  PIPER_ACTION_SAP_PIPER_REPOSITORY: sap-piper
  PIPER_ACTION_GITHUB_ENTERPRISE_TOKEN: ${{ secrets.GITHUB_TOKEN }}

jobs:
  # ============================================================
  # Build Stage
  # ============================================================
  Build:
    name: "Build & Test"
    runs-on: ${{ inputs.runs-on }}
    if: github.actor != 'github-actions[bot]'
    permissions:
      contents: write
      id-token: write
    outputs:
      artifact-version: ${{ steps.version.outputs.artifact-version }}
    steps:
      - name: Checkout
        uses: actions/checkout@v4

      - name: Fetch Docker registry credentials from Vault
        if: inputs.build-type == 'deployable'
        id: vault-docker
        uses: hashicorp/vault-action@v3
        with:
          url: 'https://vault.tools.sap'
          namespace: 'ies/hyperspace/pipelines'
          method: approle
          roleId: ${{ secrets.PIPER_VAULTAPPROLEID }}
          secretId: ${{ secrets.PIPER_VAULTAPPROLESECRETID }}
          exportEnv: false
          secrets: |
            piper/data/sap-project-gtlcinfra-poc-1/docker-config auths | DOCKER_CONFIG_JSON

      - name: Setup Docker config for registry auth
        if: inputs.build-type == 'deployable'
        run: |
          mkdir -p ~/.docker
          echo '${{ steps.vault-docker.outputs.DOCKER_CONFIG_JSON }}' > ~/.docker/config.json
          echo "Docker config created for registry authentication"

      - name: Prepare Version
        uses: piper/piper-action@v1
        env:
          PIPER_vaultAppRoleID: ${{ secrets.PIPER_VAULTAPPROLEID }}
          PIPER_vaultAppRoleSecretID: ${{ secrets.PIPER_VAULTAPPROLESECRETID }}
        with:
          step-name: artifactPrepareVersion
          flags: >-
            --defaultConfig .pipeline/config.yml
            ${{ inputs.env-config-path != '' && format('--defaultConfig {0}', inputs.env-config-path) || '' }}
            --username github-actions
            --password ${{ secrets.GITHUB_TOKEN }}

      - name: Export and validate version
        id: version
        run: |
          SOURCE_VERSION=$(tr -d '[:space:]' < VERSION)
          ARTIFACT_VERSION=$(cat .pipeline/commonPipelineEnvironment/artifactVersion 2>/dev/null || echo "0.0.0-snapshot")
          echo "Source VERSION file: $SOURCE_VERSION"
          echo "Artifact version: $ARTIFACT_VERSION"
          
          # Validate version propagation
          if [[ ! "$ARTIFACT_VERSION" == "$SOURCE_VERSION"* ]]; then
            echo "::error::Version mismatch! Expected artifact version to start with $SOURCE_VERSION but got $ARTIFACT_VERSION"
            exit 1
          fi
          
          echo "artifact-version=$ARTIFACT_VERSION" >> $GITHUB_OUTPUT
          echo "✓ Version propagation validated"

      - name: Build with Gradle
        uses: piper/piper-action@v1
        env:
          PIPER_vaultAppRoleID: ${{ secrets.PIPER_VAULTAPPROLEID }}
          PIPER_vaultAppRoleSecretID: ${{ secrets.PIPER_VAULTAPPROLESECRETID }}
        with:
          step-name: gradleExecuteBuild
          flags: >-
            --defaultConfig .pipeline/config.yml
            ${{ inputs.env-config-path != '' && format('--defaultConfig {0}', inputs.env-config-path) || '' }}

      - name: Build and push Docker image
        if: inputs.build-type == 'deployable'
        uses: piper/piper-action@v1
        env:
          PIPER_vaultAppRoleID: ${{ secrets.PIPER_VAULTAPPROLEID }}
          PIPER_vaultAppRoleSecretID: ${{ secrets.PIPER_VAULTAPPROLESECRETID }}
        with:
          step-name: dockerBuild
          flags: >-
            --defaultConfig .pipeline/config.yml
            ${{ inputs.env-config-path != '' && format('--defaultConfig {0}', inputs.env-config-path) || '' }}

      - name: Upload CPE
        uses: actions/upload-artifact@v3
        with:
          name: pipeline-environment
          path: .pipeline/commonPipelineEnvironment/
          retention-days: 1

  # ============================================================
  # Validation Stage
  # ============================================================
  Validation:
    name: "Validation"
    runs-on: ${{ inputs.runs-on }}
    needs: Build
    if: inputs.skip-validation != true && inputs.build-type == 'deployable'
    permissions:
      contents: read
      id-token: write
    steps:
      - name: Checkout
        uses: actions/checkout@v4

      - name: Download CPE
        uses: actions/download-artifact@v3
        with:
          name: pipeline-environment
          path: .pipeline/commonPipelineEnvironment/

      - name: Validate Docker image exists
        run: |
          VERSION=$(cat .pipeline/commonPipelineEnvironment/artifactVersion)
          echo "Validating Docker image: hello-world-service:$VERSION"
          echo "Image should exist at: gtlc-production.common.repositories.cloud.sap/hello-world-service:$VERSION"
          echo "✓ Validation passed (image push completed in Build stage)"

  # ============================================================
  # Deploy CF Stage
  # ============================================================
  Deploy-CF:
    name: "Deploy CF"
    runs-on: ${{ inputs.runs-on }}
    needs: [Build, Validation]
    if: |
      always() &&
      inputs.build-type == 'deployable' &&
      inputs.deploy-target == 'cf' &&
      needs.Build.result == 'success' &&
      (needs.Validation.result == 'success' || needs.Validation.result == 'skipped')
    environment: ${{ inputs.environment }}
    permissions:
      contents: write
      id-token: write
    steps:
      - name: Checkout
        uses: actions/checkout@v4

      - name: Download CPE
        uses: actions/download-artifact@v3
        with:
          name: pipeline-environment
          path: .pipeline/commonPipelineEnvironment/

      - name: Store CF space in CPE
        run: |
          mkdir -p .pipeline/commonPipelineEnvironment/custom
          echo -n "${{ inputs.environment }}" > .pipeline/commonPipelineEnvironment/custom/cfSpace

      - name: Deploy to Cloud Foundry
        uses: ./.pipeline/extensions/preRelease
        with:
          piper-vault-app-role-id: ${{ secrets.PIPER_VAULTAPPROLEID }}
          piper-vault-app-role-secret-id: ${{ secrets.PIPER_VAULTAPPROLESECRETID }}
          config-path: '.pipeline/config.yml'
          env-config-path: ${{ inputs.env-config-path }}
          cf-space: ${{ inputs.environment }}
```

- [ ] **Step 2: Verify file created**

Run: `cat gh-action-template/.github/workflows/gtlcinfra-pipeline.docker.yml | head -30`
Expected: Shows `name: GTLC-INFRA Pipeline (Docker)`

- [ ] **Step 3: Commit**

```bash
cd /Users/I819791/IdeaProjects/GTLCInfra/gh-action-template
git add .github/workflows/gtlcinfra-pipeline.docker.yml
git commit -m "feat: add main Docker pipeline workflow"
```

---

## Task 4: Create PR Build Workflow (Docker Variant)

**Files:**
- Create: `gh-action-template/.github/workflows/pr-build.docker.yml`

- [ ] **Step 1: Create the PR build workflow**

```yaml
name: PR Build (Docker)

on:
  workflow_call:
    inputs:
      custom-defaults-paths:
        description: 'Path to custom defaults config file'
        required: false
        type: string
        default: '.pipeline/env-pr.yml'
    secrets:
      PIPER_VAULTAPPROLEID:
        required: true
      PIPER_VAULTAPPROLESECRETID:
        required: true

jobs:
  pr-build:
    uses: ./.github/workflows/gtlcinfra-pipeline.docker.yml
    with:
      build-type: 'pr-build'
      env-config-path: ${{ inputs.custom-defaults-paths }}
      deploy-target: 'none'
    secrets:
      PIPER_VAULTAPPROLEID: ${{ secrets.PIPER_VAULTAPPROLEID }}
      PIPER_VAULTAPPROLESECRETID: ${{ secrets.PIPER_VAULTAPPROLESECRETID }}
```

- [ ] **Step 2: Verify file created**

Run: `cat gh-action-template/.github/workflows/pr-build.docker.yml`
Expected: Shows complete workflow with `build-type: 'pr-build'`

- [ ] **Step 3: Commit**

```bash
cd /Users/I819791/IdeaProjects/GTLCInfra/gh-action-template
git add .github/workflows/pr-build.docker.yml
git commit -m "feat: add PR build Docker workflow"
```

---

## Task 5: Create Deploy Workflows (Docker Variants)

**Files:**
- Create: `gh-action-template/.github/workflows/deploy-dev.docker.yml`
- Create: `gh-action-template/.github/workflows/deploy-qa.docker.yml`
- Create: `gh-action-template/.github/workflows/deploy-prod.docker.yml`

- [ ] **Step 1: Create deploy-dev.docker.yml**

```yaml
name: Deploy to Dev (Docker)

on:
  workflow_call:
    inputs:
      skip_validation:
        description: 'Skip validation stage'
        required: false
        type: boolean
        default: false
    secrets:
      PIPER_VAULTAPPROLEID:
        required: true
      PIPER_VAULTAPPROLESECRETID:
        required: true

jobs:
  deploy:
    uses: ./.github/workflows/gtlcinfra-pipeline.docker.yml
    with:
      build-type: 'deployable'
      environment: 'dev'
      env-config-path: '.pipeline/env-dev.yml'
      deploy-target: 'cf'
      skip-validation: ${{ inputs.skip_validation }}
    secrets:
      PIPER_VAULTAPPROLEID: ${{ secrets.PIPER_VAULTAPPROLEID }}
      PIPER_VAULTAPPROLESECRETID: ${{ secrets.PIPER_VAULTAPPROLESECRETID }}
```

- [ ] **Step 2: Create deploy-qa.docker.yml**

```yaml
name: Deploy to QA (Docker)

on:
  workflow_call:
    inputs:
      skip_validation:
        description: 'Skip validation stage'
        required: false
        type: boolean
        default: false
    secrets:
      PIPER_VAULTAPPROLEID:
        required: true
      PIPER_VAULTAPPROLESECRETID:
        required: true

jobs:
  deploy:
    uses: ./.github/workflows/gtlcinfra-pipeline.docker.yml
    with:
      build-type: 'deployable'
      environment: 'qa'
      env-config-path: '.pipeline/env-qa.yml'
      deploy-target: 'cf'
      skip-validation: ${{ inputs.skip_validation }}
    secrets:
      PIPER_VAULTAPPROLEID: ${{ secrets.PIPER_VAULTAPPROLEID }}
      PIPER_VAULTAPPROLESECRETID: ${{ secrets.PIPER_VAULTAPPROLESECRETID }}
```

- [ ] **Step 3: Create deploy-prod.docker.yml**

```yaml
name: Deploy to Production (Docker)

on:
  workflow_call:
    inputs:
      skip_validation:
        description: 'Skip validation stage'
        required: false
        type: boolean
        default: false
    secrets:
      PIPER_VAULTAPPROLEID:
        required: true
      PIPER_VAULTAPPROLESECRETID:
        required: true

jobs:
  deploy:
    uses: ./.github/workflows/gtlcinfra-pipeline.docker.yml
    with:
      build-type: 'deployable'
      environment: 'prod'
      env-config-path: '.pipeline/env-prod.yml'
      deploy-target: 'cf'
      skip-validation: ${{ inputs.skip_validation }}
    secrets:
      PIPER_VAULTAPPROLEID: ${{ secrets.PIPER_VAULTAPPROLEID }}
      PIPER_VAULTAPPROLESECRETID: ${{ secrets.PIPER_VAULTAPPROLESECRETID }}
```

- [ ] **Step 4: Verify files created**

Run: `ls -la gh-action-template/.github/workflows/deploy-*.docker.yml`
Expected: Shows 3 files: deploy-dev.docker.yml, deploy-qa.docker.yml, deploy-prod.docker.yml

- [ ] **Step 5: Commit**

```bash
cd /Users/I819791/IdeaProjects/GTLCInfra/gh-action-template
git add .github/workflows/deploy-dev.docker.yml
git add .github/workflows/deploy-qa.docker.yml
git add .github/workflows/deploy-prod.docker.yml
git commit -m "feat: add deploy Docker workflows for dev/qa/prod"
```

---

## Task 6: Create CF Manifest for Docker Deployment (Client Repo)

**Files:**
- Create: `hello-world-service/manifest.yml`

- [ ] **Step 1: Create the CF manifest**

```yaml
---
applications:
  - name: hello-world-service
    memory: 1G
    instances: 1
    docker:
      image: gtlc-production.common.repositories.cloud.sap/hello-world-service:((version))
      username: reposgtlc
    env:
      SPRING_PROFILES_ACTIVE: cloud
      JAVA_TOOL_OPTIONS: "-XX:+UseContainerSupport -XX:MaxRAMPercentage=75.0 -XX:+ExitOnOutOfMemoryError"
    routes:
      - route: hello-world-service-((space)).cfapps.eu01-canary.hana.ondemand.com
    health-check-type: http
    health-check-http-endpoint: /actuator/health
    timeout: 180
    services:
      - env-specific-xsuaa
```

- [ ] **Step 2: Verify file created**

Run: `cat hello-world-service/manifest.yml`
Expected: Shows complete manifest with `docker:` block

- [ ] **Step 3: Commit**

```bash
cd /Users/I819791/IdeaProjects/GTLCInfra/hello-world-service
git add manifest.yml
git commit -m "feat: add CF manifest for Docker deployment"
```

---

## Task 7: Update Client Piper Config for Docker Build

**Files:**
- Modify: `hello-world-service/.pipeline/config.yml`

- [ ] **Step 1: Update config.yml for Docker build**

Replace the entire contents with:

```yaml
general:
  buildTool: 'gradle'
  vaultPath: 'piper/sap-project-gtlcinfra-poc-1'
  vaultBasePath: 'piper/sap-project-gtlcinfra-poc-1'
  vaultPipelineName: 'hello-world-service'
  vaultServerUrl: 'https://vault.tools.sap'
  vaultNamespace: 'ies/hyperspace/pipelines'
  nativeBuild: true
  verbose: true

stages:
  Build:
    gradleExecuteBuild: true
    dockerBuild: true
    kanikoExecute: false
    sapCumulusUpload: true
  Release:
    cloudFoundryDeploy: true
  Post:
    vaultRotateSecretId: false

steps:
  artifactPrepareVersion:
    versioningType: 'cloud_noTag'
    commitVersion: false
    additionalTargetTools:
      - gradle

  gradleExecuteBuild:
    dockerImage: 'sapmachine:21-jdk'
    useWrapper: true
    createBom: false

  dockerBuild:
    containerImageName: 'hello-world-service'
    containerRegistryUrl: 'gtlc-production.common.repositories.cloud.sap'
    containerImageTag: '${commonPipelineEnvironment.artifactVersion}'
    dockerfilePath: 'Dockerfile'
    dockerConfigFileVaultSecretName: 'docker-config'

  cloudFoundryDeploy:
    apiEndpoint: 'https://api.cf.eu01-canary.hana.ondemand.com'
    org: 'GTLC-test_hello-qyodsuvs'
    loginParameters: '--origin sap.ids'
    cloudfoundryVaultSecretName: 'cf'
    deployType: 'standard'
    manifest: 'manifest.yml'

  sapCumulusUpload:
    pipelineId: '297bf2b8-5f5a-4e1e-ba36-5c4cc4e890ed'
    systemTrust: true
```

- [ ] **Step 2: Verify config updated**

Run: `grep -E "buildTool|dockerBuild|kanikoExecute" hello-world-service/.pipeline/config.yml`
Expected: Shows `buildTool: 'gradle'`, `dockerBuild: true`, `kanikoExecute: false`

- [ ] **Step 3: Commit**

```bash
cd /Users/I819791/IdeaProjects/GTLCInfra/hello-world-service
git add .pipeline/config.yml
git commit -m "feat: update Piper config for Docker build"
```

---

## Task 8: Update Client Workflows to Reference Docker Templates

**Files:**
- Modify: `hello-world-service/.github/workflows/pr-build.yml`
- Modify: `hello-world-service/.github/workflows/deploy-qa.yml`
- Modify: `hello-world-service/.github/workflows/deploy-prod.yml`

- [ ] **Step 1: Update pr-build.yml**

Replace the entire contents with:

```yaml
name: PR Build

on:
  pull_request:
    types: [opened, synchronize, reopened]
    branches:
      - develop
      - main

jobs:
  pr_build:
    if: github.event.pull_request.merged != true
    uses: GTLCInfra/gh-action-template/.github/workflows/pr-build.docker.yml@v2.0.0
    with:
      custom-defaults-paths: '.pipeline/env-pr.yml'
    secrets: inherit
```

- [ ] **Step 2: Update deploy-qa.yml**

Replace the entire contents with:

```yaml
name: Deploy to QA

on:
  workflow_dispatch:
    inputs:
      skip_validation:
        description: 'Skip validation stage'
        required: false
        default: false
        type: boolean
  push:
    branches:
      - "main"

jobs:
  deploy_qa_build:
    uses: GTLCInfra/gh-action-template/.github/workflows/deploy-qa.docker.yml@v2.0.0
    with:
      skip_validation: ${{ fromJSON(inputs.skip_validation || 'false') }}
    secrets: inherit
```

- [ ] **Step 3: Update deploy-prod.yml**

Replace the entire contents with:

```yaml
name: Deploy to Production
run-name: "Deploy to Production ${{ github.ref_name }}"

on:
  workflow_dispatch:
    inputs:
      skip_validation:
        description: 'Skip validation stage'
        required: false
        default: false
        type: boolean

jobs:
  deploy_prod_build:
    uses: GTLCInfra/gh-action-template/.github/workflows/deploy-prod.docker.yml@v2.0.0
    with:
      skip_validation: ${{ fromJSON(inputs.skip_validation || 'false') }}
    secrets: inherit
```

- [ ] **Step 4: Verify workflow references updated**

Run: `grep -r "docker.yml" hello-world-service/.github/workflows/`
Expected: Shows `pr-build.docker.yml`, `deploy-qa.docker.yml`, `deploy-prod.docker.yml`

- [ ] **Step 5: Commit**

```bash
cd /Users/I819791/IdeaProjects/GTLCInfra/hello-world-service
git add .github/workflows/pr-build.yml
git add .github/workflows/deploy-qa.yml
git add .github/workflows/deploy-prod.yml
git commit -m "feat: update workflows to reference Docker templates"
```

---

## Task 9: Tag and Release Template Repository

**Files:**
- None (git operations only)

- [ ] **Step 1: Push all changes to gh-action-template**

```bash
cd /Users/I819791/IdeaProjects/GTLCInfra/gh-action-template
git push origin main
```

- [ ] **Step 2: Create v2.0.0 tag**

```bash
cd /Users/I819791/IdeaProjects/GTLCInfra/gh-action-template
git tag -a v2.0.0 -m "feat: Docker-based CF deployment support"
git push origin v2.0.0
```

- [ ] **Step 3: Verify tag exists**

Run: `git tag -l "v2.0.0"`
Expected: Shows `v2.0.0`

---

## Task 10: Test PR Build (No Docker Push)

**Files:**
- None (verification only)

- [ ] **Step 1: Create test branch in hello-world-service**

```bash
cd /Users/I819791/IdeaProjects/GTLCInfra/hello-world-service
git checkout -b test/docker-pr-build
git push origin test/docker-pr-build
```

- [ ] **Step 2: Create PR to trigger PR build**

```bash
gh pr create --title "Test: Docker PR build" --body "Testing PR build with Docker workflow" --base develop
```

- [ ] **Step 3: Verify PR build completes**

Run: `gh pr checks`
Expected: Build passes, no Docker image push attempted

- [ ] **Step 4: Close test PR**

```bash
gh pr close --delete-branch
```

---

## Task 11: Test Deployable Build (Docker Push + CF Deploy)

**Files:**
- None (verification only)

- [ ] **Step 1: Push to main to trigger QA deploy**

```bash
cd /Users/I819791/IdeaProjects/GTLCInfra/hello-world-service
git checkout main
git merge develop
git push origin main
```

- [ ] **Step 2: Monitor workflow run**

Run: `gh run watch`
Expected: 
- Build stage: Gradle build + Docker image push
- Validation stage: Passes
- Deploy-CF stage: Deploys to QA

- [ ] **Step 3: Verify version propagation**

Check workflow logs for:
- "Source VERSION file: 1.0.X"
- "Artifact version: 1.0.X-TIMESTAMP+COMMIT"
- "✓ Version propagation validated"

- [ ] **Step 4: Verify CF deployment**

```bash
cf apps | grep hello-world-service
curl https://hello-world-service-qa.cfapps.eu01-canary.hana.ondemand.com/actuator/health
```

Expected: App running, health check returns `{"status":"UP"}`

---

## Testing Checklist

- [ ] VERSION file content propagates to artifact version
- [ ] Docker image tagged with correct version
- [ ] Image pushed to registry successfully
- [ ] CF pulls image with correct credentials (CF_DOCKER_PASSWORD)
- [ ] Health check passes after deployment
- [ ] PR builds don't push images or deploy
