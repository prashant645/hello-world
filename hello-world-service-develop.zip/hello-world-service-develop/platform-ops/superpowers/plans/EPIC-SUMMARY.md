# Kyma Generalization Implementation - Epic Summary

**Date:** 2026-09-10  
**Status:** In Progress  
**Branch:** `xsuaa/kyma/generalization` (both repos)

---

## Overview

This epic implements the **Kyma generalization proposal** as documented in:
- `platform-ops/superpowers/Kyma-Generalization.md`
- `platform-ops/superpowers/specs/2026-09-10-kyma-bootstrap-contract-design.md`

The implementation separates **bootstrap (one-time setup)** from **application delivery (frequent runs)** using a precreated runtime ServiceAccount model.

---

## Architecture at a Glance

### Two-Layer Deployment Model

```
Layer A: Bootstrap (Platform-Owned, Infrequent)
├── Create namespace
├── Create deployer identity (kyma-deployer SA)
├── Apply namespace RBAC
├── Create runtime identity (hello-world-service-<env> SA)
├── Bootstrap XSUAA prerequisites
└── Verify all prerequisites are ready

        ↓ (precreated resources)

Layer B: Application Delivery (App-Owned, Frequent)
├── Build/retrieve image
├── Deploy Helm release
├── Update Deployment/Service/APIRule
├── Verify rollout
└── Run auth smoke tests
```

### Resource Ownership Matrix

| Resource | Owner | Lifecycle | When |
|----------|-------|-----------|------|
| **Deployer SA** | Bootstrap | Manual setup, RBAC-protected | Once per namespace |
| **Runtime SA** | Bootstrap | Precreated manifests | Once per service/env |
| **Deployment** | App | Per-run reconcile | Every push |
| **Service** | App | Per-run reconcile | Every push |
| **APIRule** | App | Per-run reconcile | Every push |
| **XSUAA Instance/Binding** | External/Manual | Precreated (not managed by pipeline) | Manual |

---

## Implementation Checklist

### ✅ Completed

- [x] Create `xsuaa/kyma/generalization` branches in both repos
- [x] Add runtime ServiceAccount contract to Helm values (`serviceAccount.create: false`, precreated names)
- [x] Create precreated runtime ServiceAccount manifests:
  - `platform-ops/k8s/kyma/dev/hello-world-service-serviceaccount.yaml`
  - `platform-ops/k8s/kyma/qa/hello-world-service-serviceaccount.yaml`
  - `platform-ops/k8s/kyma/prod/hello-world-service-serviceaccount.yaml`
- [x] Update `pipeline-unified.yml` to parse runtime ServiceAccount contract from Helm values
- [x] Update `pipeline-kyma.yml` to accept and validate runtime ServiceAccount inputs
- [x] Add preflight validation to verify precreated ServiceAccounts exist before Helm deploy
- [x] Create drift detection script (`platform-ops/k8s/kyma/drift-detection.sh`)
- [x] Create drift detection workflow for manual/scheduled runs
- [x] Update architecture documentation

### 🔄 In Progress / Next Steps

- [ ] Create bootstrap workflow for precreated identity setup (manual dispatch)
- [ ] Add optional post-deploy verification workflow (XSUAA binding checks, OAuth smoke tests)
- [ ] Create onboarding guide for new services to adopt the generalized pattern
- [ ] Test end-to-end on all three environments (dev/qa/prod) using xsuaa/kyma/generalization branch
- [ ] Validate preflight checks catch missing precreated ServiceAccounts
- [ ] Extend to Cloud Foundry (future phase)

---

## Key Contracts & Validation

### Runtime ServiceAccount Contract (Helm Values)

```yaml
serviceAccount:
  create: false                          # Bootstrap-owned (not pipeline-managed)
  name: hello-world-service-dev          # Must exist in cluster before Helm deploy
  # name is environment-specific:
  # - dev: hello-world-service-dev
  # - qa: hello-world-service-qa
  # - prod: hello-world-service-prod
```

**Validation Rules:**
- `create: false` → `name` must be provided and precreated in cluster
- `create: true` → (reserved for future opt-in, not yet supported)

### Workflow Contract

**Input Flow:**
```
service repo (values-<env>.yaml)
    ↓
pipeline-unified.yml (parses serviceAccount.create/name)
    ↓
pipeline-kyma.yml (validates precreated SA exists)
    ↓
Helm deployment (references precreated SA)
```

**Validation in pipeline-kyma.yml (Preflight Step):**
```bash
# If precreated (create=false):
# 1. ServiceAccount name must be provided
# 2. ServiceAccount must exist in target namespace
# 3. Fail fast if not found (prevents helm deploy of orphaned workload)

# If managed (create=true):
# 1. Allow Helm to create ServiceAccount
# 2. (Not yet implemented - reserved for future opt-in)
```

---

## Drift Detection

### Purpose
Verify that cluster state matches repository bootstrap contracts before:
- Release deployments (QA → Prod promotions)
- Scheduled audits (daily prod checks)

### What It Checks

1. **Connectivity:** Cluster is reachable
2. **Namespace:** Exists with bootstrap label
3. **Deployer Identity:** `kyma-deployer` SA exists with correct RBAC
4. **Runtime Identity:** `hello-world-service-<env>` SA exists and is correctly configured
5. **XSUAA:** Instance, binding, and secrets are in place
6. **Application:** Deployment is running with expected replicas
7. **Exposure:** APIRule exists and is ready (if enabled)

### Running Drift Detection

**Manual trigger:**
```bash
cd hello-world-service
bash platform-ops/k8s/kyma/drift-detection.sh dev dev hello-world-service hello-world-xsuaa-dev hello-world-xsuaa-binding-dev
bash platform-ops/k8s/kyma/drift-detection.sh qa qa hello-world-service hello-world-xsuaa-qa hello-world-xsuaa-binding-qa
bash platform-ops/k8s/kyma/drift-detection.sh prod prod hello-world-service hello-world-xsuaa-prod hello-world-xsuaa-binding-prod
```

**Via GitHub Actions:**
- Manual dispatch: Actions → "Kyma Drift Detection & Pre-Release Validation" → "Run workflow"
- Scheduled: Runs daily on prod at 6 AM UTC

**Exit Codes:**
- `0`: Passed all checks
- `1`: Failed one or more critical checks (blocks release)

---

## Deployment Procedure

### First Time (Bootstrap)

1. **Create precreated ServiceAccounts:**
   ```bash
   # Apply runtime ServiceAccount manifests
   kubectl apply -f platform-ops/k8s/kyma/dev/hello-world-service-serviceaccount.yaml
   kubectl apply -f platform-ops/k8s/kyma/qa/hello-world-service-serviceaccount.yaml
   kubectl apply -f platform-ops/k8s/kyma/prod/hello-world-service-serviceaccount.yaml
   ```
   See: `platform-ops/k8s/kyma/<env>/SETUP.md`

2. **Configure deployer identity:**
   See: `platform-ops/k8s/kyma/kyma-deployer.md`

3. **Run drift detection to verify:**
   ```bash
   bash platform-ops/k8s/kyma/drift-detection.sh dev dev hello-world-service hello-world-xsuaa-dev hello-world-xsuaa-binding-dev
   ```

### Subsequent Deployments

1. **Push to a feature branch and merge to `develop`:**
   ```bash
   git push origin HEAD:feature/kyma-generalization
   ```
   (Validate on your PR branch, then let `develop` drive the dev workflow after merge.)

2. **Verify deployment succeeded:**
   ```bash
   kubectl get deployment hello-world-service -n dev
   kubectl get pods -n dev
   ```

3. **Before release promotion (QA → Prod):**
   ```bash
   bash platform-ops/k8s/kyma/drift-detection.sh prod prod hello-world-service hello-world-xsuaa-prod hello-world-xsuaa-binding-prod
   ```

4. **Merge to develop / Create release:**
   After successful validation, merge to `develop` and follow the repository release process from there.

---

## Testing & Validation

### Test the Implementation

1. **Create a local branch from `xsuaa/kyma/generalization`:**
   ```bash
   git checkout xsuaa/kyma/generalization
   git pull origin xsuaa/kyma/generalization
   ```

2. **Make a test change (e.g., update version or add a log line):**
   ```bash
   echo "# Test change" >> src/main/java/com/sap/gtlc/Example.java
   git add -A
   git commit -m "test: verify kyma generalization workflow"
   git push origin HEAD:feature/kyma-generalization
   ```

3. **Watch GitHub Actions:**
   - Go to `.github/workflows/wfk-kyma-dev.yml`
   - Verify it triggers on `develop` after merge
   - Observe preflight validation step output

4. **Run drift detection manually:**
   ```bash
   bash platform-ops/k8s/kyma/drift-detection.sh dev dev hello-world-service hello-world-xsuaa-dev hello-world-xsuaa-binding-dev
   ```

5. **Verify no pollution:**
   - `develop` and `main` branches remain unchanged
   - Only `xsuaa/kyma/generalization` branch received the test change

### Expected Behavior

**Successful Deployment Flow:**
```
Push to xsuaa/kyma/generalization
  ↓
GitHub Actions triggers (build & deploy jobs)
  ↓
Build image & generate CPE
  ↓
parse-manifest job reads Helm values (including serviceAccount contract)
  ↓
deploy-kyma job:
  1. Preflight: Verify runtime SA exists
  2. Helm deploy: References precreated SA (create: false)
  3. Rollout: Wait for deployment ready
  ↓
✅ Deployment successful
```

**Failed Deployment (Missing Precreated SA):**
```
Preflight validation runs
  ↓
"❌ PREFLIGHT FAILED: Precreated runtime ServiceAccount 'hello-world-service-dev' not found"
  ↓
✅ Fails fast (prevents orphaned workload)
  ↓
Developer runs bootstrap to create SA, then retries
```

---

## Documentation References

**Design & Architecture:**
- `platform-ops/superpowers/Kyma-Generalization.md` - Core proposal
- `platform-ops/superpowers/specs/2026-09-10-kyma-bootstrap-contract-design.md` - Contract details
- `platform-ops/superpowers/plans/2026-09-10-kyma-generalization-implementation-plan.md` - Implementation roadmap

**Procedures:**
- `platform-ops/k8s/kyma/kyma-deployer.md` - Deployer setup
- `platform-ops/k8s/kyma/dev/SETUP.md` - Dev namespace bootstrap
- `platform-ops/k8s/kyma/qa/SETUP.md` - QA namespace bootstrap
- `platform-ops/k8s/kyma/prod/SETUP.md` - Prod namespace bootstrap

**Workflows:**
- `gh-action-template/.github/workflows/pipeline-unified.yml` - Manifest parsing
- `gh-action-template/.github/workflows/pipeline-kyma.yml` - Kyma deployment with preflight
- `hello-world-service/.github/workflows/kyma-drift-detection.yml` - Drift detection automation

---

## Branches

### For Development & Testing
- **`xsuaa/kyma/generalization`** (both repos)
  - Implementation branch
  - Used for isolated testing
  - Keeps `develop` and `main` clean
  - Protected: requires PR review before merge to main

### For Production
- **`main`** (both repos)
  - Protected branch
  - Receives changes only via PR from `xsuaa/kyma/generalization`
  - Requires drift detection to pass before merge

---

## Known Limitations & Future Work

### Current Scope (Phase 1: Kyma-Only)

✅ **Implemented:**
- Two-layer bootstrap + deployment model
- Precreated runtime ServiceAccount pattern
- Runtime ServiceAccount contract in Helm values
- Preflight validation in pipeline
- Drift detection script

⚠️ **Not Yet:**
- Cloud Foundry target adapter (planned Phase 4)
- App-managed runtime ServiceAccount (reserved for future opt-in)
- Automated XSUAA resource management (pipeline-safe handling)
- Comprehensive OAuth2 smoke tests (documented but not in workflow yet)

### Future Phases

**Phase 2:** Bootstrap automation workflow for precreated setup  
**Phase 3:** Enhanced post-deploy verification (XSUAA binding checks, auth flows)  
**Phase 4:** Cloud Foundry support (same auth/identity abstractions)  

---

## Questions & Support

**For implementation details:**
- See design docs in `platform-ops/superpowers/`

**For bootstrap questions:**
- See `platform-ops/k8s/kyma/<env>/SETUP.md`

**For workflow changes:**
- Update `gh-action-template/.github/workflows/pipeline-*.yml`
- Remember to use v4.0.0+ tag references

**For drift detection:**
- See `bash platform-ops/k8s/kyma/drift-detection.sh --help` (manual)
- Or trigger via GitHub Actions UI

---

## Rollout Timeline

| Date | Milestone | Status |
|------|-----------|--------|
| 2026-09-10 | Design phase complete | ✅ |
| 2026-09-10 | Phase 1 implementation (this branch) | 🔄 In Progress |
| 2026-09-11 | Testing & validation on dev/qa | 📅 Pending |
| 2026-09-12 | Drift detection integration | 📅 Pending |
| 2026-09-13 | Onboarding guide creation | 📅 Pending |
| 2026-09-14 | Merge to main & release v1.0 | 📅 Pending |
| TBD | Phase 2-4 (CF extension, enhancements) | 📋 Planned |

---

## Summary

This implementation realizes the **Kyma generalization proposal** by:

1. **Separating concerns:** Bootstrap (one-time, platform-owned) vs. Delivery (frequent, app-owned)
2. **Enforcing ownership:** Precreated runtime ServiceAccounts prevent accidental overwrites
3. **Validating early:** Preflight checks catch configuration drift before deployment
4. **Detecting drift:** Scheduled audits ensure cluster state matches repository contracts
5. **Staying extensible:** Abstractions leave room for Cloud Foundry and other targets

The result is a **safer, more auditable, and more reusable** deployment model for Kyma and beyond.


