# Kyma Deployment Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Deploy hello-world-service to BTP Kyma cluster using Helm charts with multi-environment support (dev/qa/prod)

**Architecture:** Three-layer GitHub Actions → Reusable Workflow → Helm Chart. Client workflows call reusable workflow in gh-action-template repo. Reusable workflow retrieves kubeconfig from Vault, sets up kubectl/Helm, creates namespace and Docker registry secret, then deploys Helm chart.

**Tech Stack:** Helm 3, kubectl, GitHub Actions, HashiCorp Vault, BTP Kyma (Kubernetes)

---

## File Structure

### hello-world-service repo (this repo):
- Create: `helm/hello-world-service/Chart.yaml` - Helm chart metadata
- Create: `helm/hello-world-service/values.yaml` - Base configuration values
- Create: `helm/hello-world-service/values-dev.yaml` - Dev environment overrides
- Create: `helm/hello-world-service/values-qa.yaml` - QA environment overrides
- Create: `helm/hello-world-service/values-prod.yaml` - Prod environment overrides
- Create: `helm/hello-world-service/templates/_helpers.tpl` - Template helpers
- Create: `helm/hello-world-service/templates/deployment.yaml` - Kubernetes Deployment
- Create: `helm/hello-world-service/templates/service.yaml` - Kubernetes Service
- Create: `.github/workflows/deploy-kyma-dev.yml` - Dev deployment workflow
- Create: `.github/workflows/deploy-kyma-qa.yml` - QA deployment workflow
- Create: `.github/workflows/deploy-kyma-prod.yml` - Prod deployment workflow

### gh-action-template repo (external repo):
- Create: `.github/workflows/deploy-kyma-dev.yml` - Reusable workflow for Kyma deployment

---

## Task 1: Create Helm Chart Structure

**Files:**
- Create: `helm/hello-world-service/Chart.yaml`
- Create: `helm/hello-world-service/values.yaml`
- Create: `helm/hello-world-service/values-dev.yaml`
- Create: `helm/hello-world-service/values-qa.yaml`
- Create: `helm/hello-world-service/values-prod.yaml`

- [ ] **Step 1: Create Helm chart directory**

```bash
mkdir -p helm/hello-world-service/templates
```

- [ ] **Step 2: Create Chart.yaml**

File: `helm/hello-world-service/Chart.yaml`

```yaml
apiVersion: v2
name: hello-world-service
description: Secure Hello World Greeting REST API
type: application
version: 1.0.0
appVersion: "1.0.0"
```

- [ ] **Step 3: Create values.yaml (base configuration)**

File: `helm/hello-world-service/values.yaml`

```yaml
replicaCount: 1

image:
  repository: gtlc-docker.common.repositories.cloud.sap/hello-world-service
  pullPolicy: IfNotPresent
  tag: ""

imagePullSecrets:
  - name: docker-registry-secret

nameOverride: ""
fullnameOverride: ""

service:
  type: ClusterIP
  port: 8080
  targetPort: 8080

resources:
  limits:
    cpu: 500m
    memory: 512Mi
  requests:
    cpu: 250m
    memory: 256Mi

livenessProbe:
  httpGet:
    path: /actuator/health
    port: 8080
  initialDelaySeconds: 30
  periodSeconds: 10
  timeoutSeconds: 5
  failureThreshold: 3

readinessProbe:
  httpGet:
    path: /actuator/health
    port: 8080
  initialDelaySeconds: 10
  periodSeconds: 5
  timeoutSeconds: 3
  failureThreshold: 3

nodeSelector: {}

tolerations: []

affinity: {}
```

- [ ] **Step 4: Create values-dev.yaml**

File: `helm/hello-world-service/values-dev.yaml`

```yaml
replicaCount: 1

image:
  tag: "latest"

resources:
  limits:
    cpu: 500m
    memory: 512Mi
  requests:
    cpu: 250m
    memory: 256Mi
```

- [ ] **Step 5: Create values-qa.yaml**

File: `helm/hello-world-service/values-qa.yaml`

```yaml
replicaCount: 2

image:
  tag: "latest"

resources:
  limits:
    cpu: 750m
    memory: 768Mi
  requests:
    cpu: 375m
    memory: 384Mi
```

- [ ] **Step 6: Create values-prod.yaml**

File: `helm/hello-world-service/values-prod.yaml`

```yaml
replicaCount: 3

image:
  tag: "1.0.0"

resources:
  limits:
    cpu: 1000m
    memory: 1Gi
  requests:
    cpu: 500m
    memory: 512Mi
```

- [ ] **Step 7: Commit Helm chart structure**

```bash
git add helm/
git commit -m "feat(kyma): add Helm chart structure for Kyma deployment

- Chart.yaml with app metadata
- Base values.yaml with resource limits and health checks
- Environment-specific values for dev/qa/prod
- Prepares for Kubernetes deployment via Helm"
```

---

## Task 2: Create Helm Template Helpers

**Files:**
- Create: `helm/hello-world-service/templates/_helpers.tpl`

- [ ] **Step 1: Create _helpers.tpl with template functions**

File: `helm/hello-world-service/templates/_helpers.tpl`

```yaml
{{/*
Expand the name of the chart.
*/}}
{{- define "hello-world-service.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
*/}}
{{- define "hello-world-service.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "hello-world-service.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "hello-world-service.labels" -}}
helm.sh/chart: {{ include "hello-world-service.chart" . }}
{{ include "hello-world-service.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "hello-world-service.selectorLabels" -}}
app.kubernetes.io/name: {{ include "hello-world-service.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "hello-world-service.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "hello-world-service.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}
```

- [ ] **Step 2: Commit template helpers**

```bash
git add helm/hello-world-service/templates/_helpers.tpl
git commit -m "feat(kyma): add Helm template helpers

- Standardized naming functions
- Common label generators
- Selector label helpers
- Follows Helm best practices"
```

---

## Task 3: Create Kubernetes Deployment Template

**Files:**
- Create: `helm/hello-world-service/templates/deployment.yaml`

- [ ] **Step 1: Create deployment.yaml**

File: `helm/hello-world-service/templates/deployment.yaml`

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: {{ include "hello-world-service.fullname" . }}
  labels:
    {{- include "hello-world-service.labels" . | nindent 4 }}
spec:
  replicas: {{ .Values.replicaCount }}
  selector:
    matchLabels:
      {{- include "hello-world-service.selectorLabels" . | nindent 6 }}
  template:
    metadata:
      labels:
        {{- include "hello-world-service.selectorLabels" . | nindent 8 }}
    spec:
      {{- with .Values.imagePullSecrets }}
      imagePullSecrets:
        {{- toYaml . | nindent 8 }}
      {{- end }}
      containers:
      - name: {{ .Chart.Name }}
        image: "{{ .Values.image.repository }}:{{ .Values.image.tag | default .Chart.AppVersion }}"
        imagePullPolicy: {{ .Values.image.pullPolicy }}
        ports:
        - name: http
          containerPort: {{ .Values.service.targetPort }}
          protocol: TCP
        livenessProbe:
          {{- toYaml .Values.livenessProbe | nindent 10 }}
        readinessProbe:
          {{- toYaml .Values.readinessProbe | nindent 10 }}
        resources:
          {{- toYaml .Values.resources | nindent 10 }}
      {{- with .Values.nodeSelector }}
      nodeSelector:
        {{- toYaml . | nindent 8 }}
      {{- end }}
      {{- with .Values.affinity }}
      affinity:
        {{- toYaml . | nindent 8 }}
      {{- end }}
      {{- with .Values.tolerations }}
      tolerations:
        {{- toYaml . | nindent 8 }}
      {{- end }}
```

- [ ] **Step 2: Commit deployment template**

```bash
git add helm/hello-world-service/templates/deployment.yaml
git commit -m "feat(kyma): add Kubernetes Deployment template

- Pod spec with container configuration
- Configurable replicas from values
- Health probes for liveness and readiness
- Resource limits and requests
- Image pull secrets support"
```

---

## Task 4: Create Kubernetes Service Template

**Files:**
- Create: `helm/hello-world-service/templates/service.yaml`

- [ ] **Step 1: Create service.yaml**

File: `helm/hello-world-service/templates/service.yaml`

```yaml
apiVersion: v1
kind: Service
metadata:
  name: {{ include "hello-world-service.fullname" . }}
  labels:
    {{- include "hello-world-service.labels" . | nindent 4 }}
spec:
  type: {{ .Values.service.type }}
  ports:
    - port: {{ .Values.service.port }}
      targetPort: http
      protocol: TCP
      name: http
  selector:
    {{- include "hello-world-service.selectorLabels" . | nindent 4 }}
```

- [ ] **Step 2: Commit service template**

```bash
git add helm/hello-world-service/templates/service.yaml
git commit -m "feat(kyma): add Kubernetes Service template

- ClusterIP service exposing port 8080
- Selects pods using standard labels
- Named port for better Kubernetes integration"
```

---

## Task 5: Validate Helm Chart Locally

**Files:**
- Test: `helm/hello-world-service/`

- [ ] **Step 1: Run Helm lint**

Run: `helm lint helm/hello-world-service`

Expected: `1 chart(s) linted, 0 chart(s) failed`

- [ ] **Step 2: Test dry-run with dev values**

Run: `helm install --dry-run --debug hello-world-service helm/hello-world-service -f helm/hello-world-service/values-dev.yaml`

Expected: YAML output showing rendered Deployment and Service with no errors

- [ ] **Step 3: Verify deployment has 1 replica (dev)**

Check output contains: `replicas: 1`

- [ ] **Step 4: Test dry-run with qa values**

Run: `helm install --dry-run --debug hello-world-service helm/hello-world-service -f helm/hello-world-service/values-qa.yaml`

Expected: YAML output showing `replicas: 2`

- [ ] **Step 5: Test dry-run with prod values**

Run: `helm install --dry-run --debug hello-world-service helm/hello-world-service -f helm/hello-world-service/values-prod.yaml`

Expected: YAML output showing `replicas: 3` and `image.tag: "1.0.0"`

- [ ] **Step 6: Create validation documentation**

Run: `echo "Helm chart validated locally - lint passed, dry-run successful for all environments" >> helm/hello-world-service/README.md`

---

## Task 6: Create Dev Workflow for Kyma Deployment

**Files:**
- Create: `.github/workflows/deploy-kyma-dev.yml`

- [ ] **Step 1: Create deploy-kyma-dev.yml**

File: `.github/workflows/deploy-kyma-dev.yml`

```yaml
name: Deploy to Kyma Dev

on:
  workflow_dispatch:
    inputs:
      skip_validation:
        description: 'Skip validation stage'
        required: false
        default: false
        type: boolean
  push:
    branches:
      - "develop"

jobs:
  deploy_kyma_dev:
    uses: GTLCInfra/gh-action-template/.github/workflows/deploy-kyma-dev.yml@v2.1.0
    with:
      skip_validation: ${{ fromJSON(inputs.skip_validation || 'false') }}
      kyma-vault-path: 'piper/data/sap-project-gtlcinfra-poc-1/hello-world-service/kyma'
      environment: 'dev'
      namespace: 'dev'
      helm-chart-path: 'helm/hello-world-service'
      helm-values-file: 'values-dev.yaml'
    secrets:
      PIPER_VAULTAPPROLEID: ${{ secrets.PIPER_VAULTAPPROLEID }}
      PIPER_VAULTAPPROLESECRETID: ${{ secrets.PIPER_VAULTAPPROLESECRETID }}
```

- [ ] **Step 2: Commit dev workflow**

```bash
git add .github/workflows/deploy-kyma-dev.yml
git commit -m "feat(kyma): add dev deployment workflow

- Triggers on push to develop branch
- Calls reusable workflow from gh-action-template
- Deploys to dev namespace with dev-specific values
- Uses Vault for kubeconfig authentication"
```

---

## Task 7: Create QA Workflow for Kyma Deployment

**Files:**
- Create: `.github/workflows/deploy-kyma-qa.yml`

- [ ] **Step 1: Create deploy-kyma-qa.yml**

File: `.github/workflows/deploy-kyma-qa.yml`

```yaml
name: Deploy to Kyma QA

on:
  workflow_dispatch:
    inputs:
      skip_validation:
        description: 'Skip validation stage'
        required: false
        default: false
        type: boolean
  push:
    branches:
      - "main"

jobs:
  deploy_kyma_qa:
    uses: GTLCInfra/gh-action-template/.github/workflows/deploy-kyma-dev.yml@v2.1.0
    with:
      skip_validation: ${{ fromJSON(inputs.skip_validation || 'false') }}
      kyma-vault-path: 'piper/data/sap-project-gtlcinfra-poc-1/hello-world-service/kyma'
      environment: 'qa'
      namespace: 'qa'
      helm-chart-path: 'helm/hello-world-service'
      helm-values-file: 'values-qa.yaml'
    secrets:
      PIPER_VAULTAPPROLEID: ${{ secrets.PIPER_VAULTAPPROLEID }}
      PIPER_VAULTAPPROLESECRETID: ${{ secrets.PIPER_VAULTAPPROLESECRETID }}
```

- [ ] **Step 2: Commit QA workflow**

```bash
git add .github/workflows/deploy-kyma-qa.yml
git commit -m "feat(kyma): add QA deployment workflow

- Triggers on push to main branch
- Deploys to qa namespace with 2 replicas
- Higher resource limits than dev
- Uses same reusable workflow pattern"
```

---

## Task 8: Create Prod Workflow for Kyma Deployment

**Files:**
- Create: `.github/workflows/deploy-kyma-prod.yml`

- [ ] **Step 1: Create deploy-kyma-prod.yml**

File: `.github/workflows/deploy-kyma-prod.yml`

```yaml
name: Deploy to Kyma Production
run-name: "Deploy to Kyma Production ${{ github.ref_name }}"

on:
  workflow_dispatch:
    inputs:
      skip_validation:
        description: 'Skip validation stage'
        required: false
        default: false
        type: boolean

jobs:
  deploy_kyma_prod:
    uses: GTLCInfra/gh-action-template/.github/workflows/deploy-kyma-dev.yml@v2.1.0
    with:
      skip_validation: ${{ fromJSON(inputs.skip_validation || 'false') }}
      kyma-vault-path: 'piper/data/sap-project-gtlcinfra-poc-1/hello-world-service/kyma'
      environment: 'prod'
      namespace: 'prod'
      helm-chart-path: 'helm/hello-world-service'
      helm-values-file: 'values-prod.yaml'
    secrets:
      PIPER_VAULTAPPROLEID: ${{ secrets.PIPER_VAULTAPPROLEID }}
      PIPER_VAULTAPPROLESECRETID: ${{ secrets.PIPER_VAULTAPPROLESECRETID }}
```

- [ ] **Step 2: Commit prod workflow**

```bash
git add .github/workflows/deploy-kyma-prod.yml
git commit -m "feat(kyma): add production deployment workflow

- Manual trigger only for safety
- Deploys to prod namespace with 3 replicas
- Uses specific version tag, not latest
- Higher resource allocations for production"
```

---

## Task 9: Setup Vault Secret for Kubeconfig

**Files:**
- Manual: Vault configuration (external system)

- [ ] **Step 1: Download kubeconfig from Kyma**

Run: `curl -o /tmp/kubeconfig.yaml https://kyma-env-broker.cp.stage.kyma.cloud.sap/kubeconfig/ED9D876C-A50E-471A-B3C6-E9E3D1BA7A8E`

Expected: File saved to `/tmp/kubeconfig.yaml`

- [ ] **Step 2: Verify kubeconfig content**

Run: `cat /tmp/kubeconfig.yaml | head -5`

Expected: YAML starting with `apiVersion: v1` and `kind: Config`

- [ ] **Step 3: Base64 encode kubeconfig**

Run: `base64 -i /tmp/kubeconfig.yaml | tr -d '\n' > /tmp/kubeconfig.b64`

Expected: Base64 encoded string in `/tmp/kubeconfig.b64`

- [ ] **Step 4: Display encoded kubeconfig for Vault**

Run: `cat /tmp/kubeconfig.b64`

Expected: Long base64 string displayed (copy this for next step)

- [ ] **Step 5: Store in Vault (manual step)**

**Action Required:** 
1. Log into Vault at `https://vault.tools.sap`
2. Navigate to path: `piper/data/sap-project-gtlcinfra-poc-1/hello-world-service/kyma`
3. Create new secret with key `kubeconfig` and value from Step 4
4. Save the secret

Verification: Vault should show the secret exists at the specified path

- [ ] **Step 6: Verify docker-config secret exists**

**Action Required:**
1. In Vault, navigate to: `piper/data/sap-project-gtlcinfra-poc-1/hello-world-service/docker-config`
2. Verify secret exists and contains base64 encoded username:password

Expected: Secret exists (already created for CF deployment)

- [ ] **Step 7: Clean up temporary files**

Run: `rm /tmp/kubeconfig.yaml /tmp/kubeconfig.b64`

Expected: Files deleted

---

## Task 10: Create Reusable Workflow in gh-action-template

**Files:**
- Create: `../gh-action-template/.github/workflows/deploy-kyma-dev.yml` (in external repo)

**Note:** This task requires access to the `gh-action-template` repository. Steps are provided for implementation there.

- [ ] **Step 1: Clone gh-action-template repo** (if not already cloned)

Run: `git clone https://github.tools.sap/GTLCInfra/gh-action-template.git /tmp/gh-action-template || (cd /tmp/gh-action-template && git pull)`

Expected: Repository cloned or updated

- [ ] **Step 2: Create deploy-kyma-dev.yml reusable workflow**

File: `/tmp/gh-action-template/.github/workflows/deploy-kyma-dev.yml`

```yaml
name: Deploy to Kyma (Reusable)

on:
  workflow_call:
    inputs:
      skip_validation:
        description: 'Skip validation stage'
        required: false
        default: false
        type: boolean
      kyma-vault-path:
        description: 'Vault path for kubeconfig secret'
        required: true
        type: string
      environment:
        description: 'Environment name (dev/qa/prod)'
        required: true
        type: string
      namespace:
        description: 'Kubernetes namespace'
        required: true
        type: string
      helm-chart-path:
        description: 'Path to Helm chart in repo'
        required: true
        type: string
      helm-values-file:
        description: 'Helm values file name'
        required: true
        type: string
    secrets:
      PIPER_VAULTAPPROLEID:
        required: true
      PIPER_VAULTAPPROLESECRETID:
        required: true

jobs:
  deploy:
    runs-on: ubuntu-latest
    environment: ${{ inputs.environment }}
    
    steps:
      - name: Checkout code
        uses: actions/checkout@v4
      
      - name: Setup Vault CLI
        uses: hashicorp/setup-vault@v2
        with:
          version: '1.15.0'
      
      - name: Retrieve kubeconfig from Vault
        id: vault-kubeconfig
        run: |
          export VAULT_ADDR="https://vault.tools.sap"
          export VAULT_NAMESPACE="ies/hyperspace/pipelines"
          
          # Login to Vault with AppRole
          VAULT_TOKEN=$(vault write -field=token auth/approle/login \
            role_id="${{ secrets.PIPER_VAULTAPPROLEID }}" \
            secret_id="${{ secrets.PIPER_VAULTAPPROLESECRETID }}")
          export VAULT_TOKEN
          
          # Retrieve kubeconfig (base64 encoded)
          KUBECONFIG_B64=$(vault kv get -field=kubeconfig ${{ inputs.kyma-vault-path }})
          
          # Decode and save to file
          echo "$KUBECONFIG_B64" | base64 -d > /tmp/kubeconfig
          chmod 600 /tmp/kubeconfig
          
          echo "Kubeconfig retrieved and saved to /tmp/kubeconfig"
      
      - name: Retrieve docker-config from Vault
        id: vault-docker
        run: |
          export VAULT_ADDR="https://vault.tools.sap"
          export VAULT_NAMESPACE="ies/hyperspace/pipelines"
          export VAULT_TOKEN=$(vault write -field=token auth/approle/login \
            role_id="${{ secrets.PIPER_VAULTAPPROLEID }}" \
            secret_id="${{ secrets.PIPER_VAULTAPPROLESECRETID }}")
          
          # Get docker-config path by replacing last segment
          DOCKER_CONFIG_PATH=$(echo "${{ inputs.kyma-vault-path }}" | sed 's|/[^/]*$|/docker-config|')
          
          # Retrieve docker credentials (base64 encoded username:password)
          DOCKER_CREDS_B64=$(vault kv get -field=config.json "$DOCKER_CONFIG_PATH")
          DOCKER_CREDS=$(echo "$DOCKER_CREDS_B64" | base64 -d)
          
          # Extract username and password
          DOCKER_USERNAME=$(echo "$DOCKER_CREDS" | cut -d':' -f1)
          DOCKER_PASSWORD=$(echo "$DOCKER_CREDS" | cut -d':' -f2)
          
          echo "docker_username=$DOCKER_USERNAME" >> $GITHUB_OUTPUT
          echo "::add-mask::$DOCKER_PASSWORD"
          echo "docker_password=$DOCKER_PASSWORD" >> $GITHUB_OUTPUT
      
      - name: Setup kubectl
        uses: azure/setup-kubectl@v3
        with:
          version: 'v1.28.0'
      
      - name: Setup Helm
        uses: azure/setup-helm@v3
        with:
          version: 'v3.13.0'
      
      - name: Configure kubectl
        run: |
          export KUBECONFIG=/tmp/kubeconfig
          kubectl version --client
          kubectl cluster-info
      
      - name: Create namespace (idempotent)
        run: |
          export KUBECONFIG=/tmp/kubeconfig
          kubectl create namespace ${{ inputs.namespace }} --dry-run=client -o yaml | kubectl apply -f -
          echo "Namespace ${{ inputs.namespace }} ready"
      
      - name: Create Docker registry secret (idempotent)
        run: |
          export KUBECONFIG=/tmp/kubeconfig
          kubectl create secret docker-registry docker-registry-secret \
            --docker-server=gtlc-docker.common.repositories.cloud.sap \
            --docker-username="${{ steps.vault-docker.outputs.docker_username }}" \
            --docker-password="${{ steps.vault-docker.outputs.docker_password }}" \
            --namespace=${{ inputs.namespace }} \
            --dry-run=client -o yaml | kubectl apply -f -
          echo "Docker registry secret ready in namespace ${{ inputs.namespace }}"
      
      - name: Deploy with Helm
        run: |
          export KUBECONFIG=/tmp/kubeconfig
          helm upgrade --install hello-world-service \
            ${{ inputs.helm-chart-path }} \
            -f ${{ inputs.helm-chart-path }}/${{ inputs.helm-values-file }} \
            --namespace ${{ inputs.namespace }} \
            --wait \
            --timeout 5m \
            --debug
          echo "Deployment completed successfully"
      
      - name: Verify deployment
        run: |
          export KUBECONFIG=/tmp/kubeconfig
          kubectl get pods -n ${{ inputs.namespace }} -l app.kubernetes.io/name=hello-world-service
          kubectl get svc -n ${{ inputs.namespace }} hello-world-service
      
      - name: Cleanup
        if: always()
        run: |
          rm -f /tmp/kubeconfig
```

- [ ] **Step 3: Commit reusable workflow in gh-action-template**

Run in `/tmp/gh-action-template`:

```bash
cd /tmp/gh-action-template
git checkout -b feature/kyma-deployment
git add .github/workflows/deploy-kyma-dev.yml
git commit -m "feat: add reusable Kyma deployment workflow

- Retrieves kubeconfig from Vault
- Sets up kubectl and Helm CLIs
- Creates namespace and Docker registry secret idempotently
- Deploys Helm chart with environment-specific values
- Supports dev/qa/prod environments"
```

- [ ] **Step 4: Push branch and create PR**

Run:

```bash
cd /tmp/gh-action-template
git push origin feature/kyma-deployment
```

**Action Required:** Create pull request in gh-action-template repository for review

- [ ] **Step 5: Return to hello-world-service repo**

Run: `cd /Users/I819791/IdeaProjects/GTLCInfra/hello-world-service`

---

## Task 11: Update Documentation

**Files:**
- Modify: `platform-ops/superpowers/Kyma.md`

- [ ] **Step 1: Add deployment instructions to Kyma.md**

File: `platform-ops/superpowers/Kyma.md` (append to end)

```markdown

## Deployment Instructions

### Prerequisites
- Kubeconfig stored in Vault at `piper/data/sap-project-gtlcinfra-poc-1/hello-world-service/kyma`
- Docker registry credentials stored in Vault at `piper/data/sap-project-gtlcinfra-poc-1/hello-world-service/docker-config`
- GitHub secrets `PIPER_VAULTAPPROLEID` and `PIPER_VAULTAPPROLESECRETID` configured

### Manual Deployment
```bash
# Deploy to dev
gh workflow run deploy-kyma-dev.yml

# Deploy to QA
gh workflow run deploy-kyma-qa.yml

# Deploy to production
gh workflow run deploy-kyma-prod.yml
```

### Verify Deployment
```bash
# Setup kubectl alias
alias k="kubectl --kubeconfig=./canary/hello-kyma.kubeconfig.yaml"

# Check pods
k get pods -n dev

# Check service
k get svc -n dev

# View logs
k logs -n dev -l app.kubernetes.io/name=hello-world-service

# Port forward for testing
k port-forward -n dev svc/hello-world-service 8080:8080

# Test endpoints
curl http://localhost:8080/actuator/health
curl http://localhost:8080/greet?name=TestUser
```

### Troubleshooting
- **ImagePullBackOff**: Check Docker registry secret - `k get secret docker-registry-secret -n dev -o yaml`
- **CrashLoopBackOff**: Check pod logs - `k logs -n dev <pod-name>`
- **Pending pods**: Check events - `k describe pod -n dev <pod-name>`
- **Deployment fails**: Review GitHub Actions logs and Helm output

### Rollback
```bash
# List releases
helm list -n dev

# Rollback to previous version
helm rollback hello-world-service -n dev
```
```

- [ ] **Step 2: Commit documentation updates**

```bash
git add platform-ops/superpowers/Kyma.md
git commit -m "docs(kyma): add deployment and troubleshooting instructions

- Manual deployment commands
- Verification steps with kubectl
- Common troubleshooting scenarios
- Rollback procedure"
```

---

## Task 12: Test Initial Deployment to Dev

**Files:**
- Test: GitHub Actions workflow

**Note:** This task requires the reusable workflow in gh-action-template to be merged first

- [ ] **Step 1: Wait for gh-action-template PR to be merged**

**Action Required:** Ensure the reusable workflow PR in `gh-action-template` is reviewed and merged

Verification: Check that `https://github.tools.sap/GTLCInfra/gh-action-template/blob/main/.github/workflows/deploy-kyma-dev.yml` exists

- [ ] **Step 2: Push all changes to develop branch**

Run:

```bash
git push origin develop
```

Expected: Push succeeds, GitHub Actions workflow triggered automatically

- [ ] **Step 3: Monitor workflow execution**

Run: `gh run list --workflow=deploy-kyma-dev.yml --limit 1`

Expected: Workflow shows "in_progress" or "queued"

- [ ] **Step 4: Wait for workflow completion**

Run: `gh run watch`

Expected: Workflow completes successfully after ~5 minutes

- [ ] **Step 5: Download kubeconfig locally for verification**

Run: `curl -o canary/hello-kyma.kubeconfig.yaml https://kyma-env-broker.cp.stage.kyma.cloud.sap/kubeconfig/ED9D876C-A50E-471A-B3C6-E9E3D1BA7A8E`

Expected: Kubeconfig file saved

- [ ] **Step 6: Verify pods are running**

Run: `kubectl --kubeconfig=canary/hello-kyma.kubeconfig.yaml get pods -n dev`

Expected: Output shows pod in "Running" state with "1/1" ready

- [ ] **Step 7: Check deployment**

Run: `kubectl --kubeconfig=canary/hello-kyma.kubeconfig.yaml get deployment -n dev hello-world-service`

Expected: Deployment shows "1/1" ready replicas

- [ ] **Step 8: Check service**

Run: `kubectl --kubeconfig=canary/hello-kyma.kubeconfig.yaml get svc -n dev hello-world-service`

Expected: Service type "ClusterIP" with port 8080

- [ ] **Step 9: View pod logs**

Run: `kubectl --kubeconfig=canary/hello-kyma.kubeconfig.yaml logs -n dev -l app.kubernetes.io/name=hello-world-service --tail=50`

Expected: Application logs showing Spring Boot started successfully

- [ ] **Step 10: Port forward to test locally**

Run: `kubectl --kubeconfig=canary/hello-kyma.kubeconfig.yaml port-forward -n dev svc/hello-world-service 8080:8080 &`

Expected: Port forwarding started

- [ ] **Step 11: Test health endpoint**

Run: `curl http://localhost:8080/actuator/health`

Expected: JSON response with `{"status":"UP"}`

- [ ] **Step 12: Test greeting endpoint**

Run: `curl http://localhost:8080/greet?name=TestUser`

Expected: JSON response with greeting message

- [ ] **Step 13: Test rate limiting**

Run: `for i in {1..15}; do curl -s http://localhost:8080/greet?name=Test | head -1; sleep 0.5; done`

Expected: First 10 requests succeed, requests 11-15 return 429 Too Many Requests

- [ ] **Step 14: Stop port forwarding**

Run: `pkill -f "port-forward.*hello-world-service"`

Expected: Port forwarding stopped

- [ ] **Step 15: Document successful deployment**

Run: 

```bash
echo "First Kyma deployment completed successfully on $(date)" >> DEPLOYMENT_LOG.md
echo "- Pods: Running" >> DEPLOYMENT_LOG.md
echo "- Health checks: Passing" >> DEPLOYMENT_LOG.md
echo "- API endpoints: Working" >> DEPLOYMENT_LOG.md
echo "- Rate limiting: Verified" >> DEPLOYMENT_LOG.md
git add DEPLOYMENT_LOG.md
git commit -m "docs: record successful first Kyma deployment"
```

---

## Self-Review Checklist

**Spec Coverage:**
- ✓ Helm chart structure (Task 1-4)
- ✓ Multi-environment values files (Task 1)
- ✓ GitHub workflows for dev/qa/prod (Task 6-8)
- ✓ Reusable workflow in gh-action-template (Task 10)
- ✓ Vault secret setup (Task 9)
- ✓ Local validation (Task 5)
- ✓ End-to-end testing (Task 12)
- ✓ Documentation (Task 11)

**Placeholder Check:**
- No TBD, TODO, or "implement later" statements
- All code blocks are complete and runnable
- All file paths are exact
- All commands have expected output

**Type Consistency:**
- Helm chart name: `hello-world-service` (consistent across all files)
- Service selector labels: `app.kubernetes.io/name=hello-world-service` (consistent)
- Namespace: `dev`, `qa`, `prod` (matches values files and workflows)
- Values structure: `replicaCount`, `image.repository`, `image.tag`, `resources` (consistent across all values files)

---

## Execution Notes

This plan implements Kyma deployment for hello-world-service in two repositories:
1. **hello-world-service** (this repo): Helm charts and client workflows
2. **gh-action-template**: Reusable workflow for Kyma deployment

The plan follows TDD principles where applicable (Helm chart validation) and includes frequent commits after each logical unit of work. Task 10 requires working in the external `gh-action-template` repository - ensure you have access before starting.

Manual steps required:
- Task 9: Store kubeconfig in Vault (requires Vault UI access)
- Task 10, Step 4: Create PR in gh-action-template (requires repository access)
- Task 12, Step 1: Wait for PR merge (requires maintainer approval)
