# Kyma Generalization - Onboarding Guide

**For:** New services adopting the generalized Kyma deployment pattern  
**Version:** 1.0 (2026-09-10)  
**Reference:** `xsuaa/kyma/generalization` branch implementation

---

## Quick Start

To onboard a new service to use the generalized Kyma deployment model:

### Step 1: Add Runtime ServiceAccount Contract to Helm Values

Update your `helm/<service>/values.yaml`:

```yaml
# ...existing config...

serviceAccount:
  create: false
  name: ""
```

Then in each environment-specific override:

**`helm/<service>/values-dev.yaml`:**
```yaml
serviceAccount:
  create: false
  name: <service>-dev
```

**`helm/<service>/values-qa.yaml`:**
```yaml
serviceAccount:
  create: false
  name: <service>-qa
```

**`helm/<service>/values-prod.yaml`:**
```yaml
serviceAccount:
  create: false
  name: <service>-prod
```

**Important:** The `name` field must match your precreated runtime ServiceAccount name in the cluster.

### Step 2: Create Precreated Runtime ServiceAccount Manifests

Create ServiceAccount manifests in your repo under `platform-ops/k8s/kyma/`:

**`platform-ops/k8s/kyma/dev/<service>-serviceaccount.yaml`:**
```yaml
apiVersion: v1
kind: ServiceAccount
automountServiceAccountToken: false
metadata:
  name: <service>-dev
  namespace: dev
  labels:
    app.kubernetes.io/name: <service>
    app.kubernetes.io/environment: dev
```

**`platform-ops/k8s/kyma/qa/<service>-serviceaccount.yaml`:**
```yaml
apiVersion: v1
kind: ServiceAccount
automountServiceAccountToken: false
metadata:
  name: <service>-qa
  namespace: qa
  labels:
    app.kubernetes.io/name: <service>
    app.kubernetes.io/environment: qa
```

**`platform-ops/k8s/kyma/prod/<service>-serviceaccount.yaml`:**
```yaml
apiVersion: v1
kind: ServiceAccount
automountServiceAccountToken: false
metadata:
  name: <service>-prod
  namespace: prod
  labels:
    app.kubernetes.io/name: <service>
    app.kubernetes.io/environment: prod
```

### Step 3: Use the Unified Pipeline Template

Update your workflow wrapper (e.g., `.github/workflows/deploy-kyma-dev.yml`) to call the centralized template:

```yaml
name: Deploy to Kyma Dev

on:
  push:
    branches:
      - develop

jobs:
  deploy:
    uses: GTLCInfra/gh-action-template/.github/workflows/pipeline-unified.yml@v4.0.0
    with:
      manifest-path: .pipeline/gtlc.yml
      target: kyma
      environment: dev
    secrets:
      PIPER_VAULTAPPROLEID: ${{ secrets.PIPER_VAULTAPPROLEID }}
      PIPER_VAULTAPPROLESECRETID: ${{ secrets.PIPER_VAULTAPPROLESECRETID }}
      KYMA_KUBECONFIG: ${{ secrets.KYMA_KUBECONFIG }}
```

Ensure `.pipeline/gtlc.yml` includes the Helm values reference:

```yaml
pipelines:
  - target: kyma
    helm:
      chart-path: helm/<service>
      release-name: <service>
    environments:
      - name: dev
        namespace: dev
        helm-values: helm/<service>/values-dev.yaml
      - name: qa
        namespace: qa
        helm-values: helm/<service>/values-qa.yaml
      - name: prod
        namespace: prod
        helm-values: helm/<service>/values-prod.yaml
```

### Step 4: Bootstrap Precreated ServiceAccounts

**Once per environment/namespace:**

```bash
# Dev
kubectl apply -f platform-ops/k8s/kyma/dev/<service>-serviceaccount.yaml

# QA
kubectl apply -f platform-ops/k8s/kyma/qa/<service>-serviceaccount.yaml

# Prod
kubectl apply -f platform-ops/k8s/kyma/prod/<service>-serviceaccount.yaml
```

Verify they were created:

```bash
kubectl get serviceaccount <service>-dev -n dev
kubectl get serviceaccount <service>-qa -n qa
kubectl get serviceaccount <service>-prod -n prod
```

### Step 5: Test Deployment

Push to your feature branch and verify the workflow triggers:

```bash
git push origin HEAD:feature/<service>-kyma-setup
```

Watch the GitHub Actions logs. Look for:

✅ **Parse manifest job:** Reads your Helm values correctly  
✅ **Preflight validation:** Verifies precreated ServiceAccount exists  
✅ **Helm deploy:** Deploys using the precreated ServiceAccount  
✅ **Rollout verification:** Confirms deployment is ready  

### Step 6: Add Drift Detection (Optional but Recommended)

Reuse the shared drift detection script for your service:

```bash
bash platform-ops/k8s/kyma/drift-detection.sh <env> <namespace> <service> <xsuaa-instance> <xsuaa-binding> [xsuaa-secret]
```

Pass the XSUAA resource names explicitly from your environment-specific manifests or Helm values:

```bash
bash platform-ops/k8s/kyma/drift-detection.sh dev dev <service> <service>-xsuaa-dev <service>-xsuaa-binding-dev
bash platform-ops/k8s/kyma/drift-detection.sh qa qa <service> <service>-xsuaa-qa <service>-xsuaa-binding-qa
bash platform-ops/k8s/kyma/drift-detection.sh prod prod <service> <service>-xsuaa-prod <service>-xsuaa-binding-prod
```

If your binding secret uses a different name than the ServiceBinding, pass it as the optional sixth argument.

Use it before releases by sourcing the exact XSUAA names from your env-specific config rather than hardcoding assumptions into the script.

Example for `hello-world-service`:

```bash
bash platform-ops/k8s/kyma/drift-detection.sh dev dev hello-world-service hello-world-xsuaa-dev hello-world-xsuaa-binding-dev
bash platform-ops/k8s/kyma/drift-detection.sh qa qa hello-world-service hello-world-xsuaa-qa hello-world-xsuaa-binding-qa
bash platform-ops/k8s/kyma/drift-detection.sh prod prod hello-world-service hello-world-xsuaa-prod hello-world-xsuaa-binding-prod
```

---

## Understanding the Pattern

### Why Precreated ServiceAccounts?

The precreated identity model provides:

1. **Safety:** Deployment pipeline references identity, doesn't create it
2. **Auditability:** Identity lifecycle is separate from app deployment
3. **Governance:** Bootstrap team can control identity permissions independently
4. **Stability:** Pod identity doesn't change on every deployment

### Naming Convention

Use the pattern: `<service>-<environment>`

- `hello-world-service-dev`
- `hello-world-service-qa`
- `hello-world-service-prod`

This makes it clear:
- Which service the identity belongs to
- Which environment it's for
- Easy to grep/search in logs

### How the Deployment Flow Works

```
1. Push to branch → GitHub Actions trigger
2. parse-manifest job reads .pipeline/gtlc.yml
3. Extracts Helm values path (e.g., helm/<service>/values-dev.yaml)
4. Reads serviceAccount.create and serviceAccount.name
5. Outputs runtime-service-account-name and runtime-service-account-managed
6. deploy-kyma job receives these inputs
7. Preflight validation:
   - If create=false: checks that SA exists in cluster
   - Fails fast if SA not found (prevents orphaned workload)
8. Helm deploy with --set image.tag (from CPE)
9. Helm uses precreated SA (create: false means don't create)
10. Rollout verification confirms pods are running
```

### Helm Chart Compatibility

Your Helm chart must support the `serviceAccount` contract:

**In `helm/<service>/values.yaml`:**
```yaml
serviceAccount:
  create: false
  name: ""
  # Optional: if your chart supports automountServiceAccountToken
  automount: false
```

**In `helm/<service>/templates/deployment.yaml`:**
```yaml
spec:
  template:
    spec:
      serviceAccountName: {{ include "<service>.serviceAccountName" . }}
      # ... rest of pod spec
```

**In `helm/<service>/templates/_helpers.tpl`:**
```go-template
{{- define "<service>.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "<service>.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}
```

If your chart doesn't have this, the hello-world-service chart provides a template you can reference.

---

## Validation Checklist

Before considering your onboarding complete:

- [ ] Helm values have `serviceAccount.create: false` with precreated names
- [ ] ServiceAccount manifests exist in `platform-ops/k8s/kyma/<env>/`
- [ ] ServiceAccounts have been created in cluster (`kubectl get sa`)
- [ ] Workflow wrapper calls `pipeline-unified.yml@v4.0.0` or later
- [ ] `.pipeline/gtlc.yml` has correct namespace and helm-values paths
- [ ] First test deployment succeeded without "ServiceAccount not found" errors
- [ ] Pods are running with the precreated ServiceAccount name
- [ ] No changes to `develop` or `main` branches (only feature branch used)

**Verify ServiceAccount is used:**

```bash
kubectl get pods -n <env> -o jsonpath='{.items[0].spec.serviceAccountName}'
# Should output: <service>-<env>
```

---

## Troubleshooting

### Preflight Fails: "Precreated runtime ServiceAccount not found"

**Problem:** Pipeline can't find the ServiceAccount in the cluster

**Solution:**
1. Create the ServiceAccount:
   ```bash
   kubectl apply -f platform-ops/k8s/kyma/<env>/<service>-serviceaccount.yaml
   ```
2. Verify it was created:
   ```bash
   kubectl get serviceaccount <service>-<env> -n <env>
   ```
3. Retry the deployment

### Helm Deploy Fails: "ServiceAccount '<service>-<env>' not found"

**Problem:** Helm is trying to create the SA but can't (or deploy doesn't use precreated SA)

**Solution:**
1. Verify `serviceAccount.create: false` in your values file
2. Verify the Helm chart's `_helpers.tpl` has the serviceAccountName helper
3. Verify `deployment.yaml` uses the helper:
   ```yaml
   serviceAccountName: {{ include "<service>.serviceAccountName" . }}
   ```

### Pods Can't Access Secrets or XSUAA

**Problem:** Running with precreated SA but missing RBAC or binding

**Solution:**
1. Verify XSUAA binding secret exists:
   ```bash
   kubectl get secret <service>-xsuaa-binding-<env> -n <env>
   ```
2. Verify RBAC allows the SA to read secrets:
   ```bash
   kubectl auth can-i get secrets --as=system:serviceaccount:<env>:<service>-<env> -n <env>
   ```
3. Check ServiceAccount annotations for XSUAA binding:
   ```bash
   kubectl get serviceaccount <service>-<env> -n <env> -o jsonpath='{.metadata.annotations}'
   ```

### Image Tag Not Applied

**Problem:** Helm deploy uses `latest` instead of CPE version

**Solution:**
1. Verify `download-cpe-artifact: true` in pipeline-unified job
2. Verify `values.yaml` has `tag: ""` (empty, to be overridden)
3. Check pipeline logs for "Read image version from CPE" step

---

## Next Steps

1. **Complete the checklist above** to verify everything is wired correctly
2. **Test on dev environment** with a feature branch deployment
3. **Run drift detection** before promoting to QA/Prod
4. **Document your service's bootstrap procedure** (copy from hello-world-service templates)
5. **Share with your team** and get review before merging to main

---

## References

**Design & Architecture:**
- `platform-ops/superpowers/Kyma-Generalization.md` - Core proposal
- `platform-ops/superpowers/specs/2026-09-10-kyma-bootstrap-contract-design.md` - Contract details

**Example Implementation:**
- Hello-World-Service: `xsuaa/kyma/generalization` branch
  - Helm values: `helm/hello-world-service/values*.yaml`
  - Bootstrap manifests: `platform-ops/k8s/kyma/<env>/hello-world-service-serviceaccount.yaml`
  - Workflows: `.github/workflows/wfk-kyma-*.yml`

**Reusable Template:**
- `gh-action-template/.github/workflows/pipeline-unified.yml@v4.0.0`
- `gh-action-template/.github/workflows/pipeline-kyma.yml@v4.0.0`

---

## Support

For questions or issues with onboarding:

1. **Check the hello-world-service implementation** on `xsuaa/kyma/generalization` branch
2. **Review drift detection logs** for clues
3. **Contact the platform team** for bootstrap/RBAC issues
4. **File an issue** if you find improvements to this guide

---

**Good luck! 🚀**


