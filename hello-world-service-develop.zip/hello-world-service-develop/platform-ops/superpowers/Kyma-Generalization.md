# Task

Propose a generalized solution for Kyma deployments that makes applications publicly accessible on the internet while enforcing OAuth2-based authentication and authorization, using reusable workflows and procedures that can later extend to Cloud Foundry XSUAA support.

---

## 📚 Quick Summary

This proposal recommends splitting the current solution into two distinct layers:

1. **Bootstrap / platform setup**
   - infrequent, tightly controlled, environment-level setup
   - creates and governs deployer identities, runtime identities, RBAC, namespace labels, and XSUAA bootstrap prerequisites
2. **Application delivery**
   - frequent, reusable deployment workflow
   - deploys application workloads to Kyma, exposes them with `APIRule`, and validates OAuth2/XSUAA behavior over HTTPS

This split is the key to making the solution:
- reusable across many services
- safe to operate
- auditable
- extendable later to Cloud Foundry + XSUAA

In the refined ownership model:
- **cluster bootstrap** is centralized in `gh-action-template` or another platform-owned central location
- **namespace/app bootstrap instances** stay in each project repo
- the **namespace/app bootstrap model, contract, and tooling** are still standardized centrally

---

## ✅ Summarized Architecture Decisions

| Decision Area | Resolution |
|---|---|
| **Bootstrap Framework Location** | General files in `gh-action-template` repo; project-specific files in hello-world-service |
| **Manifest Storage** | Project-specific bootstrap manifests in project repo; general ones in `gh-action-template` |
| **XSUAA Resources** | Strictly precreated (not pipeline-managed) |
| **Runtime ServiceAccounts** | Precreated with manifests stored in project repo |
| **Drift Detection** | Mandatory for release/prod environments |

---

## Goals

The generalized solution should:

- support **Kyma** now
- remain extendable to **Cloud Foundry** later
- support **public internet access** for applications
- support **OAuth2 authentication and authorization** using **XSUAA**
- separate **one-time / occasional setup** from **per-run deployment**
- avoid accidental overwrites of privileged or platform-owned resources
- be suitable for centralization in `gh-action-template`

---

## Non-Goals

This proposal does **not** implement:

- full Cloud Foundry XSUAA support yet
- a full GitOps platform migration
- a cluster-wide operator installation framework
- all possible auth providers beyond XSUAA

Those can be added later, but the proposed contract must leave room for them.

---

## Design Principles

1. **Separate platform bootstrap from application deployment**
2. **Use least privilege by default**
3. **Prefer declarative, idempotent setup** over manual click-ops
4. **Do not let normal app pipelines own privileged bootstrap resources**
5. **Design around contracts and adapters**, not hardcoded Kyma-only assumptions
6. **Keep verification first-class**: preflight and post-deploy checks must be reusable

---

## Proposed Generalized Architecture

## 1) Two-layer model

### Layer A: Bootstrap / platform setup

This layer handles setup that should happen once or only occasionally per environment/namespace.

Examples:
- create namespace
- create `kyma-deployer` ServiceAccount
- generate namespace-specific CI/CD kubeconfig
- apply deployer RBAC
- apply cross-namespace RBAC (for `kyma-system`, `sap-btp-operator`, etc.)
- label namespace for BTP operator scope
- copy/bootstrap service manager credentials into namespace
- create or validate **application runtime ServiceAccounts**
- create or validate runtime Role/RoleBinding if needed
- validate bootstrap prerequisites

This layer is **platform-owned**.

Within this layer, distinguish two scopes:

#### Cluster bootstrap
Centralized and platform-owned.

Examples:
- Kyma cluster provisioning or registration
- operator / CRD prerequisites
- shared API Gateway assumptions
- cluster-wide discovery RBAC
- shared security and policy defaults

#### Namespace/app bootstrap framework
The framework is standardized centrally, but concrete app/environment instances live in each project repo.

Examples of project-local inputs:
- namespace name
- service name
- runtime ServiceAccount name
- public host / APIRule host
- XSUAA names and binding mode
- environment-specific toggles

This allows local ownership of app-specific data without every repo inventing its own bootstrap logic.

---

### Layer B: Application deployment

This layer handles normal app delivery on every run.

Examples:
- build or retrieve image tag
- deploy Helm release
- create/update Deployment, Service, APIRule
- verify rollout
- wait for APIRule readiness
- run auth smoke tests over HTTPS
- validate app-specific XSUAA bindings and secrets

This layer is **application-delivery-owned**, but must remain constrained to app-scoped resources.

---

## 2) Generalized workflow abstraction

The design should not be hardcoded as “Kyma only forever”.
Instead, it should abstract over these dimensions:

### Target platform
- `kyma`
- later: `cf`

### Exposure model
- Kyma: `apirule`
- later for CF: `route`

### Auth provider
- `xsuaa`
- later: `none` or additional providers if needed

### Verification model
- target-specific runtime verification
- auth-provider-specific token/auth checks

This allows the same overall template family to support:
- today: `target=kyma`, `auth-provider=xsuaa`, `exposure=apirule`
- later: `target=cf`, `auth-provider=xsuaa`, `exposure=route`

---

## Proposed `gh-action-template` Structure

## 1) Reusable Kyma application deployment workflow

Create a Kyma-only reusable workflow in `gh-action-template`, separate from the current unified CF/Kyma DAG.

Suggested responsibilities:
- setup kubeconfig, kubectl, helm
- read image tag / CPE
- run optional preflight modules
- deploy Helm chart
- verify deployment status
- optionally wait for APIRule readiness
- optionally run HTTPS/OAuth2 auth smoke tests

Suggested inputs:
- `target: kyma`
- `environment`
- `namespace`
- `helm-chart-path`
- `helm-values-file`
- `release-name`
- `image-tag`
- `skip-validation`
- `auth-provider`
- `exposure-mode`
- `enable-preflight`
- `enable-postdeploy-auth-check`
- `runtime-service-account-name`
- `runtime-service-account-managed` (default `false`)

This workflow should assume bootstrap prerequisites already exist.

---

## 2) Reusable bootstrap package / workflow

Create a separate bootstrap package for Kyma namespace onboarding.

It can be implemented as:
- a reusable workflow
- a set of declarative manifests
- a small wrapper script / documented procedure
- ideally all three working together

Suggested responsibilities:
- create namespace
- create deployer ServiceAccount
- apply namespace RBAC
- apply cross-namespace RBAC
- label namespace
- bootstrap operator credentials into namespace
- validate BTP operator reachability
- validate APIRule/gateway discovery access
- create or validate runtime ServiceAccounts
- optionally generate/update CI/CD kubeconfig instructions

This should be **manual**, **audited**, and **restricted**.

Recommended ownership split:
- **cluster bootstrap assets** live centrally
- **namespace/app bootstrap contract and generators** live centrally
- **namespace/app bootstrap values/specs and rendered instances** live in each project repo

---

## 3) Shared verification library

Move reusable logic into shared scripts/actions that the workflows can call.

Suggested modules:
- namespace/bootstrap preflight
- XSUAA readiness and secret validation
- APIRule readiness wait
- HTTPS + OAuth2 smoke test
- RBAC drift checks
- chart contract checks

This reduces duplication across service repos.

---

## Resource Ownership Model

## 1) Deployer ServiceAccount

Example:
- `kyma-deployer`

This is always **bootstrap-owned**.

It must **not** be owned or modified by normal application deployment runs.

Reason:
- it is a privileged CI/CD identity
- its RBAC controls what the pipeline can do
- accidental overwrite would be high risk

---

## 2) Application runtime ServiceAccount

Example:
- `hello-world-service-qa`

### Recommended default
This should also be **bootstrap-owned**.

The deployment pipeline should **reference** it, not create it by default.

Recommended chart mode:
- `serviceAccount.create: false`
- `serviceAccount.name: <precreated-name>`

Reason:
- runtime SA may carry security-sensitive annotations or bindings
- runtime SA permissions may be managed separately from the application
- repeated pipeline reconciliation can accidentally alter identity semantics

### Optional mode
Allow app-managed runtime ServiceAccounts only as an **explicit opt-in**.

Example contract:
- `runtime-service-account-managed: true | false`

Default should remain `false`.

---

## 3) Application resources that are safe for per-run reconcile

Normal deployment workflow may own:
- `Deployment`
- `Service`
- `APIRule`
- image tag changes
- rollout verification
- app-scoped secret references
- auth smoke tests

These are ordinary app delivery concerns.

---

## One-time / Occasional Setup Procedure

The following items should be treated as **bootstrap procedures**, not normal pipeline actions:

- create namespace
- create deployer ServiceAccount
- create bootstrap token / kubeconfig for CI
- apply namespace RBAC
- apply cross-namespace RBAC
- label namespace
- copy Service Manager credentials into namespace
- create or verify runtime ServiceAccount
- verify operator and gateway read access

These steps should be:
- documented
- codified
- idempotent
- restricted to designated operators/platform maintainers

---

## Codification Strategy

## Platform blueprint + service overlay model

To avoid hardcoding project-specific values into a central bootstrap, use a layered model:

### Platform blueprint
Central, reusable defaults for:
- gateway conventions
- operator namespaces
- RBAC profiles
- security defaults
- environment policies

### Service overlay
Project-local values for:
- service/app name
- namespace
- hostnames
- XSUAA names
- runtime ServiceAccount selection
- enabled modules

The bootstrap system should combine these layers into concrete namespace/app resources.

This keeps the implementation standardized while allowing each project to supply its own specific values.

## 1) Source-controlled manifests

All bootstrap resources should live in source control, for example:
- namespace RBAC
- cross-namespace RBAC
- runtime ServiceAccounts
- namespace labels (via declarative manifest or script)
- bootstrap verification scripts

Benefits:
- auditability
- repeatability
- peer review
- easier drift investigation

---

## 2) Idempotent apply model

Bootstrap should prefer:
- `kubectl apply`
- stable resource names
- deterministic labels and annotations
- explicit verification after apply

This allows safe reruns without uncontrolled duplication.

---

## 3) Thin procedure docs + executable steps

Docs should explain:
- when bootstrap must be run
- who is allowed to run it
- what is expected to change
- how to verify success
- how to recover from drift

But the actual state changes should come from code/manifests, not ad hoc instructions alone.

---

## Preventing Accidental Overwrites

This is the most important operational concern.

## 1) Separate identities

Use different identities for different concerns.

### Application deployer identity
Normal deployment workflow identity.

Can manage only:
- app Deployment
- app Service
- app APIRule
- app-scoped secrets/config that are intentionally pipeline-owned
- optional app XSUAA runtime checks

Cannot manage:
- deployer RBAC
- cross-namespace RBAC
- namespace bootstrap secrets
- cluster-scoped permissions
- bootstrap-owned runtime ServiceAccounts (by default)

### Bootstrap/platform identity
Privileged manual/bootstrap identity.

Can manage:
- deployer SA
- runtime SA
- RBAC
- namespace labels
- bootstrap secrets
- cross-namespace bindings
- other shared platform prerequisites

---

## 2) Separate workflows

### Normal deploy workflow
- frequent
- app-owned
- low blast radius
- limited identity

### Bootstrap workflow
- manual dispatch only
- restricted permissions
- environment approval recommended
- platform-owner only
- auditable logs

---

## 3) Protect bootstrap manifests

Use repo protections for files such as:
- deployer RBAC
- cross-namespace RBAC
- bootstrap procedures
- runtime ServiceAccount definitions

Recommended controls:
- CODEOWNERS
- required platform-team review
- branch protections
- no auto-merge
- manual approval for privileged changes

---

## 4) Add drift detection

The QA regression showed that git state and cluster state can diverge.

Recommended addition:
- a read-only drift detection script/workflow
- verify required permissions and resources exist
- run before release or on a schedule
- fail with actionable messages if cluster state lags behind repo state

Examples:
- can deployer `get/list serviceaccounts`?
- does runtime ServiceAccount exist?
- does namespace have required label?
- do cross-namespace RoleBindings exist?
- do XSUAA bootstrap secrets exist and match expectations?

---

## 5) Prefer GitOps for bootstrap resources when possible

Long-term, the cleanest protection is to manage bootstrap/platform resources through GitOps or a central platform pipeline.

That would:
- reduce manual drift
- reconcile expected RBAC automatically
- prevent app deploy pipelines from owning privileged setup
- improve traceability

Not required immediately, but recommended as a strategic direction.

---

## XSUAA Generalization Model

To prepare for later Cloud Foundry support, model XSUAA as a provider module rather than a Kyma-only special case.

## Shared XSUAA concerns

Reusable across targets:
- naming conventions
- credentials validation
- token endpoint checks
- auth smoke tests
- scope validation
- binding readiness checks

## Kyma-specific adapter

Current implementation scope:
- namespace secret checks
- ServiceInstance / ServiceBinding readiness
- APIRule readiness
- Deployment/Service verification
- HTTPS auth verification through public APIRule endpoint

## Future CF adapter

Later extension could add:
- CF app route checks
- bound XSUAA service verification
- CF-specific app health checks
- route-based HTTPS auth smoke tests

So the framework should be **XSUAA-capable across targets**, but **Kyma-first in implementation**.

---

## Recommended Default Contract for Service Repos

Service repos should remain thin.

They should provide:
- application source
- Dockerfile/build config
- Helm chart
- environment values
- app-specific XSUAA manifests
- namespace/app bootstrap values or spec
- thin workflow wrappers that call `gh-action-template`

They should avoid duplicating:
- complex bootstrap logic
- environment RBAC design
- APIRule/XSUAA verification machinery

In other words:
- **central repo/template** owns the bootstrap framework
- **service repo** owns the bootstrap instance data

---

## Recommended Rollout Plan

### Phase 1: Kyma-only reusable workflow
- extract the current Kyma deployment path into a Kyma-only reusable workflow
- remove confusing CF job graph for Kyma runs
- standardize inputs and output contracts

### Phase 2: Bootstrap package
- codify namespace bootstrap manifests and procedures
- separate bootstrap execution from app delivery execution
- adopt restricted ownership model

### Phase 3: Drift detection
- add a reusable read-only audit/preflight capability
- use it before releases and optionally on schedule

### Phase 4: CF extension
- add target adapters so the same architecture supports `target=cf`
- reuse the same `auth-provider=xsuaa` abstraction

---

## Final Recommendations

1. **Generalize the solution** into `gh-action-template`
2. **Split bootstrap from deployment**
3. **Centralize cluster bootstrap and the namespace/app bootstrap framework**
4. **Keep namespace/app bootstrap instances in each project repo using centrally defined contracts**
5. **Make runtime ServiceAccounts bootstrap-owned by default**
6. **Keep deployer ServiceAccounts always bootstrap-owned**
7. **Use a Kyma-only reusable workflow now** instead of a unified CF/Kyma graph
8. **Design the contracts so CF + XSUAA can plug in later**
9. **Add drift detection** so cluster state cannot silently lag behind repo state
10. **Restrict privileged setup changes** with separate identity, workflow, and review controls

---

## Bottom Line

Yes, this pattern is generalizable.

The right generalized model is:
- **platform bootstrap owns cluster-level capabilities and the shared bootstrap framework**
- **project repos own namespace/app bootstrap values and instances under the shared framework**
- **application deployment owns rollout, exposure, and verification**
- **Kyma is the first target implementation**
- **Cloud Foundry + XSUAA can be added later through the same target/auth-provider abstraction**

That gives you a reusable, safer, and more future-proof solution than embedding everything into every service repo or every pipeline run.

