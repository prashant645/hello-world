# Docker-Based CF Deployment Design

## Overview

Replace MTA-based Cloud Foundry deployment with Docker image deployment. The REST API microservice will be packaged as a Docker image, pushed to a private registry, and deployed to BTP Cloud Foundry.

## Goals

- Package build artifact as Docker image instead of MTAR
- Push to `gtlc-production.common.repositories.cloud.sap` registry
- Deploy to BTP Cloud Foundry using Docker image
- Support future Kyma deployment with same image
- Maintain VERSION file as single source of truth
- Explicit Vault secret retrieval (bypass GPP staging limitations)

## Build Type Behavior

| Build Type | Docker Image | Registry Push | CF Deploy |
|------------|--------------|---------------|-----------|
| PR Build   | No           | No            | No        |
| Dev        | Yes          | Yes           | Yes       |
| QA         | Yes          | Yes           | Yes       |
| Prod       | Yes          | Yes           | Yes       |

**How PR builds skip Docker:** The reusable workflow (`gtlcinfra-pipeline.docker.yml`) uses a conditional on the dockerBuild step:

```yaml
- name: Build and push Docker image
  if: inputs.build-type == 'deployable'  # Skipped for pr-build
  uses: piper/piper-action@v1
  with:
    step-name: dockerBuild
```

PR builds pass `build-type: 'pr-build'`, so the `if` condition is false and the step is skipped. The `dockerBuild: true` in `.pipeline/config.yml` is a stage-level enablement that the workflow conditionally invokes — it does NOT mean the step runs unconditionally.

## Architecture

### Current Flow (MTA-based)
```
VERSION → mta.yaml → mtaBuild → MTAR (JAR embedded) → cloudFoundryDeploy → CF buildpack
```

### New Flow (Docker-based)
```
VERSION → build.gradle → gradleExecuteBuild → JAR
                                               ↓
                              dockerBuild → Docker image → registry
                                                            ↓
                              cloudFoundryDeploy (extension) → CF pulls image
```

## Version Propagation

**Critical:** VERSION file content must propagate correctly to avoid `0.0.0-timestamp` regression.

### Propagation Chain
```
VERSION file (1.0.3)
    ↓ build.gradle reads: version = file('VERSION').text.trim()
Gradle build produces JAR with version
    ↓ artifactPrepareVersion appends timestamp+commit
CPE: artifactVersion = 1.0.3-20260818120000+abc123
    ↓ dockerBuild uses CPE value
Docker image: hello-world-service:1.0.3-20260818120000+abc123
    ↓ manifest.yml uses ((version)) variable
CF deployment pulls correct image tag
```

### Key Settings (No Persistence to GitHub)
```yaml
steps:
  artifactPrepareVersion:
    versioningType: 'cloud_noTag'  # No git tag
    commitVersion: false           # Don't commit changes
    additionalTargetTools:
      - gradle                     # Updates build.gradle in workspace only
```

### Validation Step
```yaml
- name: Validate version propagation
  run: |
    SOURCE_VERSION=$(tr -d '[:space:]' < VERSION)
    ARTIFACT_VERSION=$(cat .pipeline/commonPipelineEnvironment/artifactVersion)
    if [[ ! "$ARTIFACT_VERSION" == "$SOURCE_VERSION"* ]]; then
      echo "::error::Version mismatch!"
      exit 1
    fi
```

## Vault Secret Retrieval

**Approach:** Direct `hashicorp/vault-action` calls instead of GPP's automatic Vault resolution.

### Vault Credentials Source

The AppRole credentials to access Vault come from **GitHub repository secrets** (not baked into GPP):

- `PIPER_VAULTAPPROLEID` — AppRole Role ID
- `PIPER_VAULTAPPROLESECRETID` — AppRole Secret ID

These were configured during Hyperspace Portal onboarding and already exist in the repository. GPP uses the same secrets — we're just calling `hashicorp/vault-action` directly instead of letting Piper handle it opaquely.

### Why Not GPP's Built-in Vault
- Inflexible — forced to use SAP staging artifactory
- Opaque — hard to debug when secrets don't resolve
- Coupled to `sapDownloadArtifact` / `sapCallStagingService`

### Explicit Vault Retrieval
```yaml
- name: Fetch secrets from Vault
  id: vault
  uses: hashicorp/vault-action@v3
  with:
    url: 'https://vault.tools.sap'
    namespace: 'ies/hyperspace/pipelines'
    method: approle
    roleId: ${{ secrets.PIPER_VAULTAPPROLEID }}
    secretId: ${{ secrets.PIPER_VAULTAPPROLESECRETID }}
    exportEnv: true
    secrets: |
      piper/data/sap-project-gtlcinfra-poc-1/docker-config password | DOCKER_PASSWORD ;
      piper/data/sap-project-gtlcinfra-poc-1/docker-config auths | DOCKER_CONFIG_JSON ;
      piper/data/sap-project-gtlcinfra-poc-1/cf username | CF_USERNAME ;
      piper/data/sap-project-gtlcinfra-poc-1/cf password | CF_PASSWORD
```

### Vault Secret Structure

**Location:** `piper/data/sap-project-gtlcinfra-poc-1/`

#### docker-config

The `docker-config` secret contains Docker registry credentials in two formats:

1. **`password`** — Plain text registry password (used for `CF_DOCKER_PASSWORD`)
2. **`dockerConfigJSON`** — Docker config.json format (used by Piper's `dockerBuild` step)

```json
{
  "password": "your_registry_api_token",
  "dockerConfigJSON": "{\"auths\": {\"gtlc-production.common.repositories.cloud.sap\": {\"auth\": \"cmVwb3NndGxjOnlvdXJfcmVnaXN0cnlfYXBpX3Rva2Vu\"}}}"
}
```

**Important notes:**
- `dockerConfigJSON` value MUST be a JSON **string** (escaped), not a nested object
- The `auth` value is base64-encoded `username:password` (e.g., `echo -n "reposgtlc:your_token" | base64`)
- Piper's `dockerBuild` step reads `dockerConfigJSON` automatically when `dockerConfigFileVaultSecretName: 'docker-config'` is set
- CF deployment uses the `password` field directly via `CF_DOCKER_PASSWORD` environment variable

**How Piper uses it:**
```yaml
steps:
  dockerBuild:
    dockerConfigFileVaultSecretName: 'docker-config'  # Piper reads dockerConfigJSON from this secret
```

**How CF uses it (via extension):**
```yaml
- name: Fetch from Vault
  uses: hashicorp/vault-action@v3
  with:
    secrets: |
      piper/data/sap-project-gtlcinfra-poc-1/docker-config password | CF_DOCKER_PASSWORD
```

#### cf

Cloud Foundry login credentials:

```json
{
  "username": "cf_technical_user@sap.com",
  "password": "cf_password_or_token"
}
```

**How Piper uses it:**
```yaml
steps:
  cloudFoundryDeploy:
    cloudfoundryVaultSecretName: 'cf'  # Piper reads username/password from this secret
```

## File Changes

### gh-action-template (New Docker Variant Files)

| File | Purpose |
|------|---------|
| `.github/workflows/gtlcinfra-pipeline.docker.yml` | Main reusable workflow |
| `.github/workflows/pr-build.docker.yml` | PR build (no push/deploy) |
| `.github/workflows/deploy-dev.docker.yml` | Dev deployment |
| `.github/workflows/deploy-qa.docker.yml` | QA deployment |
| `.github/workflows/deploy-prod.docker.yml` | Prod deployment |
| `.pipeline/config.template.docker.yml` | Piper config template |
| `.pipeline/extensions/preRelease/action.yml` | CF deploy extension |

### hello-world-service (Client Repo)

| File | Action |
|------|--------|
| `manifest.yml` | New — CF Docker deployment descriptor |
| `.github/workflows/*.yml` | Update references to `*.docker.yml` |
| `.pipeline/config.yml` | Update for dockerBuild |
| `mta.yaml` | Keep (backward compatibility) |

## Configuration Details

### .pipeline/config.template.docker.yml

```yaml
general:
  buildTool: 'gradle'
  vaultPath: 'piper/sap-project-gtlcinfra-poc-1'
  vaultBasePath: 'piper/sap-project-gtlcinfra-poc-1'
  vaultPipelineName: 'hello-world-service'
  vaultServerUrl: 'https://vault.tools.sap'
  vaultNamespace: 'ies/hyperspace/pipelines'
  nativeBuild: true
  verbose: true

stages:
  Build:
    gradleExecuteBuild: true
    dockerBuild: true
    kanikoExecute: false
    sapCumulusUpload: true
  Release:
    cloudFoundryDeploy: true
  Post:
    vaultRotateSecretId: false

steps:
  artifactPrepareVersion:
    versioningType: 'cloud_noTag'
    commitVersion: false
    additionalTargetTools:
      - gradle

  gradleExecuteBuild:
    dockerImage: 'sapmachine:21-jdk'
    useWrapper: true
    createBom: false

  dockerBuild:
    containerImageName: 'hello-world-service'
    containerRegistryUrl: 'gtlc-production.common.repositories.cloud.sap'
    # containerImageTag omitted - Piper reads artifactVersion from CPE automatically
    dockerfilePath: 'Dockerfile'
    dockerConfigFileVaultSecretName: 'docker-config'

  cloudFoundryDeploy:
    apiEndpoint: 'https://api.cf.eu01-canary.hana.ondemand.com'
    org: 'GTLC-test_hello-qyodsuvs'
    loginParameters: '--origin sap.ids'
    cloudfoundryVaultSecretName: 'cf'
    deployType: 'standard'
    manifest: 'manifest.yml'

  sapCumulusUpload:
    pipelineId: '297bf2b8-5f5a-4e1e-ba36-5c4cc4e890ed'
    systemTrust: true
```

### manifest.yml (CF Docker Deployment)

```yaml
---
applications:
  - name: hello-world-service
    memory: 1G
    instances: 1
    docker:
      image: gtlc-production.common.repositories.cloud.sap/hello-world-service:((version))
      username: reposgtlc
    env:
      SPRING_PROFILES_ACTIVE: cloud
      JAVA_TOOL_OPTIONS: "-XX:+UseContainerSupport -XX:MaxRAMPercentage=75.0"
    routes:
      - route: hello-world-service-((space)).cfapps.eu01-canary.hana.ondemand.com
    health-check-type: http
    health-check-http-endpoint: /actuator/health
    timeout: 180
    services:
      - env-specific-xsuaa
```

### Piper Extension (.pipeline/extensions/preRelease/action.yml)

```yaml
name: 'Pre-Release Extension'
description: 'Fetch Docker credentials and deploy to CF'

runs:
  using: 'composite'
  steps:
    - name: Fetch Docker credentials from Vault
      id: vault
      uses: hashicorp/vault-action@v3
      with:
        url: https://vault.tools.sap
        namespace: ies/hyperspace/pipelines
        method: approle
        roleId: ${{ secrets.PIPER_VAULTAPPROLEID }}
        secretId: ${{ secrets.PIPER_VAULTAPPROLESECRETID }}
        secrets: |
          piper/data/sap-project-gtlcinfra-poc-1/docker-config password | CF_DOCKER_PASSWORD

    - name: Create manifest-variables.yml
      shell: bash
      run: |
        VERSION=$(cat .pipeline/commonPipelineEnvironment/artifactVersion)
        SPACE=$(cat .pipeline/commonPipelineEnvironment/custom/cfSpace || echo "dev")
        cat > manifest-variables.yml << EOF
        version: ${VERSION}
        space: ${SPACE}
        EOF
        echo "Created manifest-variables.yml: version=${VERSION}, space=${SPACE}"

    - name: Deploy to Cloud Foundry
      uses: piper/piper-action@v1
      env:
        CF_DOCKER_PASSWORD: ${{ env.CF_DOCKER_PASSWORD }}
      with:
        step-name: cloudFoundryDeploy
        flags: >-
          --defaultConfig .pipeline/config.yml
          --vars-file manifest-variables.yml
```

## Pipeline Flow

### PR Build
```
1. Checkout
2. gradleExecuteBuild → JAR
3. Done (no image push, no deploy)
```

### Deployable Build (dev/qa/prod)
```
1. Checkout
2. hashicorp/vault-action → Fetch all secrets explicitly
3. artifactPrepareVersion → Generate cloud version (no commit)
4. Validate version propagation
5. gradleExecuteBuild → JAR
6. dockerBuild → Build image, push to registry
7. Piper Extension:
   a. Fetch CF_DOCKER_PASSWORD from Vault
   b. Create manifest-variables.yml
   c. cloudFoundryDeploy → Deploy to CF
```

## What We Bypass (GPP Limitations)

- `sapCallStagingService` — Not using SAP staging repo
- `sapDownloadArtifact` — Not downloading from staging
- GPP's automatic Vault secret injection (unreliable)

## What We Keep

- `artifactPrepareVersion` — Version generation
- `gradleExecuteBuild` — Build JAR
- `dockerBuild` — Build & push image
- `cloudFoundryDeploy` — Deploy to CF
- `sapCumulusUpload` — Compliance reporting (optional)

## Client Reference Syntax

```yaml
# hello-world-service/.github/workflows/deploy-qa.yml
jobs:
  deploy_qa_build:
    uses: GTLCInfra/gh-action-template/.github/workflows/deploy-qa.docker.yml@v2.0.0
    with:
      skip_validation: ${{ fromJSON(inputs.skip_validation || 'false') }}
    secrets:
      PIPER_VAULTAPPROLEID: ${{ secrets.PIPER_VAULTAPPROLEID }}
      PIPER_VAULTAPPROLESECRETID: ${{ secrets.PIPER_VAULTAPPROLESECRETID }}
```

**Note:** The Docker workflows require explicit Vault secrets — `secrets: inherit` will NOT work because the reusable workflow declares specific required secrets.

## Testing Checklist

- [ ] VERSION file content propagates to artifact version
- [ ] Docker image tagged with correct version
- [ ] Image pushed to registry successfully
- [ ] CF pulls image with correct credentials
- [ ] Health check passes after deployment
- [ ] PR builds don't push images or deploy

## Rollback Plan

If Docker deployment fails:
1. Client workflows can reference original `*.yml` (MTA variant)
2. Both MTA and Docker templates coexist in gh-action-template
3. No changes to mta.yaml required for rollback
