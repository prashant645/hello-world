# Template-Only CI/CD Approach

**Date:** 2026-08-27  
**Status:** Design  
**Authors:** Claude Code + Jeffrey Shi

## Executive Summary

Simplify client CI/CD configuration by consolidating all pipeline settings into a single manifest file (`.pipeline/gtlc.yml`) while keeping thin workflow files that point to centralized templates. This reduces client-side configuration from ~8 workflow files + multiple piper configs to a single source of truth for all deployment settings.

## Current State (v3.0.0 + v1.0.54)

### Client Repository Structure
```
hello-world-service/
├── .github/workflows/
│   ├── pr-build.yml                 # 20 lines
│   ├── create-release.yml           # 18 lines
│   ├── deploy-cf-dev.yml            # 42 lines
│   ├── deploy-cf-qa.yml             # 42 lines
│   ├── deploy-cf-prod.yml           # 42 lines
│   ├── deploy-kyma-dev.yml          # 78 lines
│   ├── deploy-kyma-qa.yml           # 78 lines
│   └── deploy-kyma-prod.yml         # 78 lines
├── .pipeline/
│   ├── config.yml                   # Base piper config (57 lines)
│   ├── env-pr.yml                   # PR-specific (8 lines)
│   ├── cf/
│   │   ├── config.yml               # CF-specific (optional)
│   │   ├── env-dev.yml              # CF dev (10 lines)
│   │   ├── env-qa.yml               # CF qa (10 lines)
│   │   └── env-prod.yml             # CF prod (10 lines)
│   └── kyma/
│       ├── config.yml               # Kyma-specific (optional)
│       ├── env-dev.yml              # Kyma dev (7 lines)
│       ├── env-qa.yml               # Kyma qa (7 lines)
│       └── env-prod.yml             # Kyma prod (7 lines)
├── helm/
│   └── hello-world-service/
│       ├── Chart.yaml
│       ├── values.yaml
│       ├── values-dev.yaml
│       ├── values-qa.yaml
│       ├── values-prod.yaml
│       └── templates/
├── manifest.yml                     # CF manifest
└── src/                             # Application code
```

**Total configuration:** ~500+ lines across 16+ files

### Current Workflow Pattern

**CF Deployment:**
```yaml
jobs:
  deploy_cf_dev:
    uses: GTLCInfra/gh-action-template/.github/workflows/gtlcinfra-pipeline.docker.yml@v3.0.0
    with:
      build-type: 'deployable'
      environment: 'dev'
      base-config-path: '.pipeline/config.yml'
      env-config-path: '.pipeline/cf/env-dev.yml'
      deploy-target: 'cf'
      skip-validation: false
      docker-config-vault-path: 'piper/data/.../docker-config'
      cf-vault-path: 'piper/data/.../cf'
    secrets:
      PIPER_VAULTAPPROLEID: ${{ secrets.PIPER_VAULTAPPROLEID }}
      PIPER_VAULTAPPROLESECRETID: ${{ secrets.PIPER_VAULTAPPROLESECRETID }}
```

**Kyma Deployment:**
```yaml
jobs:
  build_kyma_dev:
    uses: GTLCInfra/gh-action-template/.github/workflows/gtlcinfra-pipeline.docker.yml@v3.0.0
    with:
      build-type: 'deployable'
      environment: 'dev'
      base-config-path: '.pipeline/config.yml'
      env-config-path: '.pipeline/kyma/env-dev.yml'
      deploy-target: 'none'  # Build only
      skip-validation: false
      docker-config-vault-path: 'piper/data/.../docker-config'
      
  deploy_kyma_dev:
    needs: build_kyma_dev
    uses: GTLCInfra/gh-action-template/.github/workflows/deploy-kyma.yml@v3.0.0
    with:
      kyma-vault-path: 'piper/data/.../kyma'
      environment: 'dev'
      namespace: 'dev'
      helm-chart-path: 'helm/hello-world-service'
      helm-values-file: 'values-dev.yaml'
      docker-vault-path: 'piper/data/.../docker-config'
      docker-registry: 'gtlc-docker.common.repositories.cloud.sap'
      helm-release-name: 'hello-world-service'
      download-cpe-artifact: true
    secrets:
      PIPER_VAULTAPPROLEID: ${{ secrets.PIPER_VAULTAPPROLEID }}
      PIPER_VAULTAPPROLESECRETID: ${{ secrets.PIPER_VAULTAPPROLESECRETID }}
      KYMA_KUBECONFIG: ${{ secrets.KYMA_KUBECONFIG }}
```

### Current Piper Configuration Cascade

```bash
# Build stage calls piper with:
--defaultConfig .pipeline/config.yml              # Base config
--defaultConfig .pipeline/{target}/env-{env}.yml  # Environment-specific
```

## Proposed State: Template-Only Approach

### Client Repository Structure
```
hello-world-service/
├── .github/workflows/
│   ├── pr-build.yml                 # 15 lines (thin pointer)
│   ├── create-release.yml           # 15 lines (thin pointer)
│   ├── deploy-cf-dev.yml            # 25 lines (thin pointer + triggers)
│   ├── deploy-cf-qa.yml             # 25 lines (thin pointer + triggers)
│   ├── deploy-cf-prod.yml           # 20 lines (thin pointer + triggers)
│   ├── deploy-kyma-dev.yml          # 25 lines (thin pointer + triggers)
│   ├── deploy-kyma-qa.yml           # 25 lines (thin pointer + triggers)
│   └── deploy-kyma-prod.yml         # 20 lines (thin pointer + triggers)
├── .pipeline/
│   └── gtlc.yml                     # ⭐ Single source of truth (~150 lines)
├── helm/
│   └── hello-world-service/
│       ├── Chart.yaml
│       ├── values.yaml
│       ├── values-dev.yaml
│       ├── values-qa.yaml
│       ├── values-prod.yaml
│       └── templates/
├── manifest.yml                     # CF manifest
└── src/                             # Application code
```

**Total configuration:** ~320 lines across 9 files (36% reduction)

### GTLC Manifest Schema

**File: `.pipeline/gtlc.yml`**

```yaml
# ==============================================================================
# GTLC Pipeline Configuration
# ==============================================================================
# Single source of truth for all CI/CD pipeline configuration.
# Includes service metadata, build config, and deployment targets.
#
# This file is read by:
#   - gh-action-template/.github/workflows/pipeline-unified.yml
#
# Template version compatibility: v3.0.0+
# ==============================================================================

# ============================================================
# Service Metadata
# ============================================================
service:
  name: hello-world-service
  # Vault base path - used as prefix for all vault paths
  vault-base: piper/data/sap-project-gtlcinfra-poc-1/hello-world-service

# ============================================================
# Build Configuration
# ============================================================
build:
  # Build tool: gradle, maven, npm
  tool: gradle
  
  # Docker configuration
  docker:
    registry: gtlc-docker.common.repositories.cloud.sap
    # Vault path for Docker registry credentials
    vault-path: piper/data/sap-project-gtlcinfra-poc-1/hello-world-service/docker-config
    dockerfile: Dockerfile
    # Container image name (without registry prefix)
    image-name: hello-world-service
  
  # Piper pipeline configuration
  piper:
    # Vault configuration
    vault:
      server-url: https://vault.tools.sap
      namespace: ies/hyperspace/pipelines
      # Base vault path (without pipeline name)
      base-path: piper/sap-project-gtlcinfra-poc-1
    
    # Version management
    version:
      source-file: VERSION
      build-tool: custom
      versioning-type: cloud_noTag
      commit-version: false
    
    # Build settings
    gradle:
      use-wrapper: true
      create-bom: false
      publish: false
    
    # Docker build settings
    docker:
      vault-secret-name: docker-config
    
    # General settings
    native-build: false
    verbose: true
  
  # Environment-specific piper configs (optional - for advanced use cases)
  piper-configs:
    # Base config applied to all builds (optional - uses template defaults)
    # base: .pipeline/config.yml
    # PR build config (optional - uses template defaults)
    # pr: .pipeline/env-pr.yml

# ============================================================
# Deployment Targets
# ============================================================
deployments:
  # ============================================================
  # Cloud Foundry Deployments
  # ============================================================
  - target: cf
    # Vault path for CF credentials
    vault-path: piper/data/sap-project-gtlcinfra-poc-1/hello-world-service/cf
    # CF manifest file
    manifest: manifest.yml
    
    # Piper configuration for CF deployments (optional)
    piper:
      # CF-specific piper config (optional - uses template defaults)
      # target-config: .pipeline/cf/config.yml
      # Piper stages
      stages:
        Release:
          cloudFoundryDeploy: false
        Post:
          vaultRotateSecretId: false
    
    # CF environments
    environments:
      - name: dev
        # CF space name
        space: dev
        # Trigger configuration
        trigger:
          branch: develop
          # File paths that trigger deployment
          paths:
            - src/**
            - .pipeline/cf/**
            - manifest.yml
            - build.gradle
            - gradle.properties
            - xs-security.json
            - settings.gradle
            - VERSION
        # Piper environment overrides
        piper:
          productive-branch: develop
          stages:
            Build:
              sapCallStagingService: false
              sapCumulusUpload: false
        # Validation settings
        skip-validation: false
        
      - name: qa
        space: qa
        trigger:
          branch: main
          paths:
            - src/**
            - .pipeline/cf/**
            - manifest.yml
            - build.gradle
            - gradle.properties
            - xs-security.json
            - settings.gradle
            - VERSION
        piper:
          productive-branch: main
          stages:
            Build:
              sapCallStagingService: false
              sapCumulusUpload: false
            
      - name: prod
        space: prod
        # Manual trigger only
        trigger:
          workflow_dispatch: true
        piper:
          productive-branch: release-v*
          stages:
            Build:
              sapCallStagingService: false
              sapCumulusUpload: false
        # Skip validation when auto-triggered by release workflow
        skip-validation-on-auto: true

  # ============================================================
  # Kyma Deployments
  # ============================================================
  - target: kyma
    # Vault path for Kyma credentials (kubeconfig)
    vault-path: piper/data/sap-project-gtlcinfra-poc-1/hello-world-service/kyma
    
    # Helm chart configuration
    helm:
      # Path to helm chart directory
      chart-path: helm/hello-world-service
      # Helm release name
      release-name: hello-world-service
    
    # Piper configuration for Kyma deployments (optional)
    piper:
      # Kyma-specific piper config (optional - uses template defaults)
      # target-config: .pipeline/kyma/config.yml
      stages:
        Release:
          cloudFoundryDeploy: false
        Post:
          vaultRotateSecretId: false
    
    # Kyma environments
    environments:
      - name: dev
        # Kubernetes namespace
        namespace: dev
        # Helm values file (relative to chart-path)
        helm-values: values-dev.yaml
        # Trigger configuration
        trigger:
          branch: develop
          paths:
            - src/**
            - .pipeline/kyma/**
            - helm/**
            - Dockerfile
            - build.gradle
            - gradle.properties
            - xs-security.json
            - settings.gradle
            - VERSION
        # Piper environment overrides
        piper:
          productive-branch: develop
          stages:
            Build:
              sapCallStagingService: false
              sapCumulusUpload: false
        skip-validation: false
            
      - name: qa
        namespace: qa
        helm-values: values-qa.yaml
        trigger:
          branch: main
          paths:
            - src/**
            - .pipeline/kyma/**
            - helm/**
            - Dockerfile
            - build.gradle
            - gradle.properties
            - xs-security.json
            - settings.gradle
            - VERSION
        piper:
          productive-branch: main
          stages:
            Build:
              sapCallStagingService: false
              sapCumulusUpload: false
            
      - name: prod
        namespace: prod
        helm-values: values-prod.yaml
        trigger:
          workflow_dispatch: true
        piper:
          productive-branch: release-v*
          stages:
            Build:
              sapCallStagingService: false
              sapCumulusUpload: false
        skip-validation-on-auto: true
```

### Thin Workflow Files

**PR Build (Universal):**
```yaml
# .github/workflows/pr-build.yml
name: PR Build

on:
  pull_request:
    types: [opened, synchronize, reopened]
    branches: [develop, main]

jobs:
  build_pr:
    if: github.event.pull_request.merged != true
    uses: GTLCInfra/gh-action-template/.github/workflows/pr-build.docker.yml@main
    with:
      manifest-path: .pipeline/gtlc.yml
    secrets:
      PIPER_VAULTAPPROLEID: ${{ secrets.PIPER_VAULTAPPROLEID }}
      PIPER_VAULTAPPROLESECRETID: ${{ secrets.PIPER_VAULTAPPROLESECRETID }}
```

**Create Release (Universal):**
```yaml
# .github/workflows/create-release.yml
name: Create Release
run-name: "Create Release v${{ inputs.version }}"

on:
  workflow_dispatch:
    inputs:
      version:
        description: 'Release version (e.g., 1.0.0)'
        required: true
        type: string

jobs:
  release:
    uses: GTLCInfra/gh-action-template/.github/workflows/create-release.yml@main
    with:
      version: ${{ inputs.version }}
      manifest-path: .pipeline/gtlc.yml
    secrets: inherit
```

**CF Deployment:**
```yaml
# .github/workflows/deploy-cf-dev.yml
name: Deploy to CF Dev

on:
  workflow_dispatch:
    inputs:
      skip_validation:
        description: 'Skip validation stage'
        required: false
        default: false
        type: boolean
  push:
    branches: [develop]
    paths:
      - 'src/**'
      - '.pipeline/cf/**'
      - 'manifest.yml'
      - 'build.gradle'
      - 'gradle.properties'
      - 'xs-security.json'
      - 'settings.gradle'
      - 'VERSION'

jobs:
  deploy:
    uses: GTLCInfra/gh-action-template/.github/workflows/pipeline-unified.yml@main
    with:
      manifest-path: .pipeline/gtlc.yml
      target: cf
      environment: dev
      skip-validation: ${{ inputs.skip_validation == true }}
    secrets:
      PIPER_VAULTAPPROLEID: ${{ secrets.PIPER_VAULTAPPROLEID }}
      PIPER_VAULTAPPROLESECRETID: ${{ secrets.PIPER_VAULTAPPROLESECRETID }}
```

**Kyma Deployment:**
```yaml
# .github/workflows/deploy-kyma-dev.yml
name: Deploy to Kyma Dev

on:
  workflow_dispatch:
    inputs:
      skip_validation:
        description: 'Skip validation stage'
        required: false
        default: false
        type: boolean
  push:
    branches: [develop]
    paths:
      - 'src/**'
      - '.pipeline/kyma/**'
      - 'helm/**'
      - 'Dockerfile'
      - 'build.gradle'
      - 'gradle.properties'
      - 'xs-security.json'
      - 'settings.gradle'
      - 'VERSION'

jobs:
  deploy:
    uses: GTLCInfra/gh-action-template/.github/workflows/pipeline-unified.yml@main
    with:
      manifest-path: .pipeline/gtlc.yml
      target: kyma
      environment: dev
      skip-validation: ${{ inputs.skip_validation == true }}
    secrets:
      PIPER_VAULTAPPROLEID: ${{ secrets.PIPER_VAULTAPPROLEID }}
      PIPER_VAULTAPPROLESECRETID: ${{ secrets.PIPER_VAULTAPPROLESECRETID }}
      KYMA_KUBECONFIG: ${{ secrets.KYMA_KUBECONFIG }}
```

## Template Implementation

### New Unified Pipeline Workflow

**File: `gh-action-template/.github/workflows/pipeline-unified.yml`**

This new workflow reads the manifest and orchestrates build + deployment.

```yaml
name: GTLC Unified Pipeline

on:
  workflow_call:
    inputs:
      manifest-path:
        description: 'Path to GTLC manifest (.pipeline/gtlc.yml)'
        required: false
        type: string
        default: '.pipeline/gtlc.yml'
      target:
        description: 'Deployment target: cf or kyma'
        required: true
        type: string
      environment:
        description: 'Environment: dev, qa, prod'
        required: true
        type: string
      skip-validation:
        description: 'Skip validation stage'
        required: false
        type: boolean
        default: false
    secrets:
      PIPER_VAULTAPPROLEID:
        required: true
      PIPER_VAULTAPPROLESECRETID:
        required: true
      KYMA_KUBECONFIG:
        required: false

env:
  PIPER_ACTION_SAP_PIPER_VERSION: '1.412.1'
  PIPER_ACTION_SAP_PIPER_OWNER: project-piper
  PIPER_ACTION_SAP_PIPER_REPOSITORY: sap-piper
  PIPER_ACTION_GITHUB_ENTERPRISE_TOKEN: ${{ secrets.GITHUB_TOKEN }}

jobs:
  # ============================================================
  # Parse Manifest & Generate Piper Configs
  # ============================================================
  parse-manifest:
    runs-on: [self-hosted]
    outputs:
      # Service config
      service-name: ${{ steps.parse.outputs.service-name }}
      vault-base: ${{ steps.parse.outputs.vault-base }}
      
      # Build config
      build-tool: ${{ steps.parse.outputs.build-tool }}
      docker-registry: ${{ steps.parse.outputs.docker-registry }}
      docker-vault-path: ${{ steps.parse.outputs.docker-vault-path }}
      dockerfile: ${{ steps.parse.outputs.dockerfile }}
      docker-image-name: ${{ steps.parse.outputs.docker-image-name }}
      
      # Piper config paths (generated)
      base-config-path: ${{ steps.parse.outputs.base-config-path }}
      env-config-path: ${{ steps.parse.outputs.env-config-path }}
      
      # Deployment config
      deployment-vault-path: ${{ steps.parse.outputs.deployment-vault-path }}
      
      # CF-specific
      cf-space: ${{ steps.parse.outputs.cf-space }}
      cf-manifest: ${{ steps.parse.outputs.cf-manifest }}
      
      # Kyma-specific
      kyma-namespace: ${{ steps.parse.outputs.kyma-namespace }}
      kyma-helm-chart: ${{ steps.parse.outputs.kyma-helm-chart }}
      kyma-helm-values: ${{ steps.parse.outputs.kyma-helm-values }}
      kyma-helm-release: ${{ steps.parse.outputs.kyma-helm-release }}
      
    steps:
      - uses: actions/checkout@v4
      
      - name: Install yq
        run: |
          if ! command -v yq &> /dev/null; then
            wget -qO /tmp/yq https://github.com/mikefarah/yq/releases/latest/download/yq_linux_amd64
            chmod +x /tmp/yq
            sudo mv /tmp/yq /usr/local/bin/yq
          fi
      
      - name: Parse GTLC manifest and generate piper configs
        id: parse
        run: |
          MANIFEST="${{ inputs.manifest-path }}"
          TARGET="${{ inputs.target }}"
          ENV="${{ inputs.environment }}"
          
          echo "📋 Parsing manifest: $MANIFEST"
          echo "🎯 Target: $TARGET"
          echo "🌍 Environment: $ENV"
          
          # ============================================================
          # Extract Service Configuration
          # ============================================================
          SERVICE_NAME=$(yq eval '.service.name' "$MANIFEST")
          VAULT_BASE=$(yq eval '.service.vault-base' "$MANIFEST")
          
          echo "service-name=$SERVICE_NAME" >> $GITHUB_OUTPUT
          echo "vault-base=$VAULT_BASE" >> $GITHUB_OUTPUT
          
          # ============================================================
          # Extract Build Configuration
          # ============================================================
          BUILD_TOOL=$(yq eval '.build.tool' "$MANIFEST")
          DOCKER_REGISTRY=$(yq eval '.build.docker.registry' "$MANIFEST")
          DOCKER_VAULT_PATH=$(yq eval '.build.docker.vault-path' "$MANIFEST")
          DOCKERFILE=$(yq eval '.build.docker.dockerfile // "Dockerfile"' "$MANIFEST")
          DOCKER_IMAGE_NAME=$(yq eval '.build.docker.image-name' "$MANIFEST")
          
          echo "build-tool=$BUILD_TOOL" >> $GITHUB_OUTPUT
          echo "docker-registry=$DOCKER_REGISTRY" >> $GITHUB_OUTPUT
          echo "docker-vault-path=$DOCKER_VAULT_PATH" >> $GITHUB_OUTPUT
          echo "dockerfile=$DOCKERFILE" >> $GITHUB_OUTPUT
          echo "docker-image-name=$DOCKER_IMAGE_NAME" >> $GITHUB_OUTPUT
          
          # ============================================================
          # Generate Base Piper Config
          # ============================================================
          mkdir -p .pipeline/generated
          
          cat > .pipeline/generated/config.yml << 'EOF'
          general:
            buildTool: '$(yq eval '.build.tool' "$MANIFEST")'
            vaultPath: '$(yq eval '.build.piper.vault.base-path' "$MANIFEST")'
            vaultBasePath: '$(yq eval '.build.piper.vault.base-path' "$MANIFEST")'
            vaultPipelineName: '$(yq eval '.service.name' "$MANIFEST")'
            vaultServerUrl: '$(yq eval '.build.piper.vault.server-url' "$MANIFEST")'
            vaultNamespace: '$(yq eval '.build.piper.vault.namespace' "$MANIFEST")'
            nativeBuild: $(yq eval '.build.piper.native-build // false' "$MANIFEST")
            verbose: $(yq eval '.build.piper.verbose // true' "$MANIFEST")

          stages:
            Build:
              gradleExecuteBuild: true
              dockerBuild: true
              kanikoExecute: false

          steps:
            artifactPrepareVersion:
              buildTool: '$(yq eval '.build.piper.version.build-tool // "custom"' "$MANIFEST")'
              filePath: '$(yq eval '.build.piper.version.source-file // "VERSION"' "$MANIFEST")'
              versioningType: '$(yq eval '.build.piper.version.versioning-type // "cloud_noTag"' "$MANIFEST")'
              commitVersion: $(yq eval '.build.piper.version.commit-version // false' "$MANIFEST")
              additionalTargetTools:
                - $(yq eval '.build.tool' "$MANIFEST")

            gradleExecuteBuild:
              dockerImage: ''
              useWrapper: $(yq eval '.build.piper.gradle.use-wrapper // true' "$MANIFEST")
              createBom: $(yq eval '.build.piper.gradle.create-bom // false' "$MANIFEST")
              publish: $(yq eval '.build.piper.gradle.publish // false' "$MANIFEST")

            dockerBuild:
              containerImageName: '$(yq eval '.build.docker.image-name' "$MANIFEST")'
              dockerfilePath: '$(yq eval '.build.docker.dockerfile // "Dockerfile"' "$MANIFEST")'
              containerRegistryUrl: 'https://$(yq eval '.build.docker.registry' "$MANIFEST")'
              dockerConfigFileVaultSecretName: '$(yq eval '.build.piper.docker.vault-secret-name // "docker-config"' "$MANIFEST")'
          EOF
          
          echo "base-config-path=.pipeline/generated/config.yml" >> $GITHUB_OUTPUT
          
          # ============================================================
          # Find Deployment Target Configuration
          # ============================================================
          DEPLOYMENT_INDEX=$(yq eval ".deployments | to_entries | map(select(.value.target == \"$TARGET\")) | .[0].key" "$MANIFEST")
          
          if [ "$DEPLOYMENT_INDEX" = "null" ]; then
            echo "❌ Target '$TARGET' not found in manifest"
            exit 1
          fi
          
          DEPLOYMENT_VAULT_PATH=$(yq eval ".deployments[$DEPLOYMENT_INDEX].vault-path" "$MANIFEST")
          echo "deployment-vault-path=$DEPLOYMENT_VAULT_PATH" >> $GITHUB_OUTPUT
          
          # ============================================================
          # Find Environment Configuration
          # ============================================================
          ENV_INDEX=$(yq eval ".deployments[$DEPLOYMENT_INDEX].environments | to_entries | map(select(.value.name == \"$ENV\")) | .[0].key" "$MANIFEST")
          
          if [ "$ENV_INDEX" = "null" ]; then
            echo "❌ Environment '$ENV' not found for target '$TARGET'"
            exit 1
          fi
          
          # ============================================================
          # Generate Environment-Specific Piper Config
          # ============================================================
          PRODUCTIVE_BRANCH=$(yq eval ".deployments[$DEPLOYMENT_INDEX].environments[$ENV_INDEX].piper.productive-branch" "$MANIFEST")
          SAP_CALL_STAGING=$(yq eval ".deployments[$DEPLOYMENT_INDEX].environments[$ENV_INDEX].piper.stages.Build.sapCallStagingService // false" "$MANIFEST")
          SAP_CUMULUS_UPLOAD=$(yq eval ".deployments[$DEPLOYMENT_INDEX].environments[$ENV_INDEX].piper.stages.Build.sapCumulusUpload // false" "$MANIFEST")
          
          cat > .pipeline/generated/env-${TARGET}-${ENV}.yml << EOF
          general:
            productiveBranch: '$PRODUCTIVE_BRANCH'
          stages:
            Build:
              sapCallStagingService: $SAP_CALL_STAGING
              sapCumulusUpload: $SAP_CUMULUS_UPLOAD
          EOF
          
          # Add CF-specific config
          if [ "$TARGET" = "cf" ]; then
            CF_SPACE=$(yq eval ".deployments[$DEPLOYMENT_INDEX].environments[$ENV_INDEX].space" "$MANIFEST")
            echo "steps:" >> .pipeline/generated/env-${TARGET}-${ENV}.yml
            echo "  cloudFoundryDeploy:" >> .pipeline/generated/env-${TARGET}-${ENV}.yml
            echo "    space: '$CF_SPACE'" >> .pipeline/generated/env-${TARGET}-${ENV}.yml
            
            CF_MANIFEST=$(yq eval ".deployments[$DEPLOYMENT_INDEX].manifest // \"manifest.yml\"" "$MANIFEST")
            
            echo "cf-space=$CF_SPACE" >> $GITHUB_OUTPUT
            echo "cf-manifest=$CF_MANIFEST" >> $GITHUB_OUTPUT
            
            echo "✅ CF Configuration:"
            echo "   Space: $CF_SPACE"
            echo "   Manifest: $CF_MANIFEST"
          fi
          
          # Add Kyma-specific config
          if [ "$TARGET" = "kyma" ]; then
            KYMA_NAMESPACE=$(yq eval ".deployments[$DEPLOYMENT_INDEX].environments[$ENV_INDEX].namespace" "$MANIFEST")
            KYMA_HELM_CHART=$(yq eval ".deployments[$DEPLOYMENT_INDEX].helm.chart-path" "$MANIFEST")
            KYMA_HELM_VALUES=$(yq eval ".deployments[$DEPLOYMENT_INDEX].environments[$ENV_INDEX].helm-values" "$MANIFEST")
            KYMA_HELM_RELEASE=$(yq eval ".deployments[$DEPLOYMENT_INDEX].helm.release-name" "$MANIFEST")
            
            echo "kyma-namespace=$KYMA_NAMESPACE" >> $GITHUB_OUTPUT
            echo "kyma-helm-chart=$KYMA_HELM_CHART" >> $GITHUB_OUTPUT
            echo "kyma-helm-values=$KYMA_HELM_VALUES" >> $GITHUB_OUTPUT
            echo "kyma-helm-release=$KYMA_HELM_RELEASE" >> $GITHUB_OUTPUT
            
            echo "✅ Kyma Configuration:"
            echo "   Namespace: $KYMA_NAMESPACE"
            echo "   Helm Chart: $KYMA_HELM_CHART"
            echo "   Helm Values: $KYMA_HELM_VALUES"
            echo "   Release: $KYMA_HELM_RELEASE"
          fi
          
          echo "env-config-path=.pipeline/generated/env-${TARGET}-${ENV}.yml" >> $GITHUB_OUTPUT
          
          echo "✅ Manifest parsed and piper configs generated"

  # ============================================================
  # Deploy to Cloud Foundry
  # ============================================================
  deploy-cf:
    if: inputs.target == 'cf'
    needs: parse-manifest
    uses: GTLCInfra/gh-action-template/.github/workflows/gtlcinfra-pipeline.docker.yml@main
    with:
      build-type: 'deployable'
      environment: ${{ inputs.environment }}
      base-config-path: ${{ needs.parse-manifest.outputs.base-config-path }}
      env-config-path: ${{ needs.parse-manifest.outputs.env-config-path }}
      deploy-target: 'cf'
      skip-validation: ${{ inputs.skip-validation }}
      docker-config-vault-path: ${{ needs.parse-manifest.outputs.docker-vault-path }}
      cf-vault-path: ${{ needs.parse-manifest.outputs.deployment-vault-path }}
    secrets:
      PIPER_VAULTAPPROLEID: ${{ secrets.PIPER_VAULTAPPROLEID }}
      PIPER_VAULTAPPROLESECRETID: ${{ secrets.PIPER_VAULTAPPROLESECRETID }}

  # ============================================================
  # Build for Kyma
  # ============================================================
  build-kyma:
    if: inputs.target == 'kyma'
    needs: parse-manifest
    uses: GTLCInfra/gh-action-template/.github/workflows/gtlcinfra-pipeline.docker.yml@main
    with:
      build-type: 'deployable'
      environment: ${{ inputs.environment }}
      base-config-path: ${{ needs.parse-manifest.outputs.base-config-path }}
      env-config-path: ${{ needs.parse-manifest.outputs.env-config-path }}
      deploy-target: 'none'
      skip-validation: ${{ inputs.skip-validation }}
      docker-config-vault-path: ${{ needs.parse-manifest.outputs.docker-vault-path }}
    secrets:
      PIPER_VAULTAPPROLEID: ${{ secrets.PIPER_VAULTAPPROLEID }}
      PIPER_VAULTAPPROLESECRETID: ${{ secrets.PIPER_VAULTAPPROLESECRETID }}

  # ============================================================
  # Deploy to Kyma
  # ============================================================
  deploy-kyma:
    if: inputs.target == 'kyma'
    needs: [parse-manifest, build-kyma]
    uses: GTLCInfra/gh-action-template/.github/workflows/deploy-kyma.yml@main
    with:
      kyma-vault-path: ${{ needs.parse-manifest.outputs.deployment-vault-path }}
      environment: ${{ inputs.environment }}
      namespace: ${{ needs.parse-manifest.outputs.kyma-namespace }}
      helm-chart-path: ${{ needs.parse-manifest.outputs.kyma-helm-chart }}
      helm-values-file: ${{ needs.parse-manifest.outputs.kyma-helm-values }}
      docker-vault-path: ${{ needs.parse-manifest.outputs.docker-vault-path }}
      docker-registry: ${{ needs.parse-manifest.outputs.docker-registry }}
      helm-release-name: ${{ needs.parse-manifest.outputs.kyma-helm-release }}
      download-cpe-artifact: true
    secrets:
      PIPER_VAULTAPPROLEID: ${{ secrets.PIPER_VAULTAPPROLEID }}
      PIPER_VAULTAPPROLESECRETID: ${{ secrets.PIPER_VAULTAPPROLESECRETID }}
      KYMA_KUBECONFIG: ${{ secrets.KYMA_KUBECONFIG }}
```

## Implementation Plan

### Phase 1: Template Development (Template Repo)

1. **Create `pipeline-unified.yml` workflow**
   - Implement manifest parsing logic
   - Generate piper configs dynamically
   - Wire up existing `gtlcinfra-pipeline.docker.yml` and `deploy-kyma.yml`
   - Test with pilot project

2. **Update `pr-build.docker.yml`**
   - Add `manifest-path` input
   - Extract PR build config from manifest (if present)
   - Fall back to existing behavior for backward compatibility

3. **Update `create-release.yml`**
   - Add `manifest-path` input
   - Read production trigger config from manifest
   - Use to automatically trigger correct prod workflows

### Phase 2: Client Migration (Client Repos)

1. **Create `.pipeline/gtlc.yml` manifest**
   - Consolidate all configuration from existing files
   - Validate with schema/lint tool

2. **Update workflow files to thin pointers**
   - Replace verbose workflows with thin wrappers
   - Point to `pipeline-unified.yml@main`

3. **Test deployments**
   - PR builds
   - Dev deployments
   - QA deployments
   - Production deployments

4. **Remove old config files** (optional)
   - Keep `.pipeline/config.yml` for backward compatibility
   - Remove target-specific configs (`.pipeline/cf/`, `.pipeline/kyma/`)

### Phase 3: Rollout

1. **Pilot with 1-2 projects**
2. **Document migration guide**
3. **Gradual rollout to all projects**
4. **Deprecate old pattern** (keep for 3-6 months)

## Benefits

### For Client Repos

1. **Single source of truth** - All CI/CD config in one file
2. **Reduced duplication** - No repeated vault paths, registry URLs, etc.
3. **Easier to understand** - One file to read vs 16+ files
4. **Simpler updates** - Change one value vs updating multiple files
5. **Less boilerplate** - Thin workflow files are just pointers

### For Template Maintenance

1. **Centralized logic** - All complexity in template, not scattered across clients
2. **Backward compatible** - Existing patterns still work
3. **Version control** - Clients reference `@main`, get updates automatically
4. **Testing** - Validate manifest schema, catch errors early

### Overall

- **36% reduction** in configuration lines
- **50% fewer files** to maintain per client repo
- **Zero workflow logic** in client repos
- **Automatic updates** when template improves

## Risks & Mitigations

### Risk: Breaking changes in manifest schema

**Mitigation:**
- Version the manifest schema
- Maintain backward compatibility for 3-6 months
- Provide migration tool/script

### Risk: Manifest parsing failures

**Mitigation:**
- Comprehensive validation in `parse-manifest` job
- Clear error messages with exact location of issue
- Fall back to explicit piper configs if manifest parsing fails

### Risk: Template changes break clients

**Mitigation:**
- Thorough testing with pilot projects
- Gradual rollout
- Maintain old patterns in parallel during transition
- CI/CD for template repo itself

## Open Questions

1. **Should we support inline piper config in manifest?**
   - Pro: Everything in one place
   - Con: Manifest becomes very large
   - Decision: Support both - inline for simple cases, file refs for complex

2. **How to handle advanced piper customizations?**
   - Pro: Manifest covers 90% of use cases
   - Con: Some projects need custom piper steps
   - Decision: Support escape hatch - if `.pipeline/config.yml` exists, use it instead of generated

3. **Should manifest be validated in CI?**
   - Pro: Catch errors early
   - Con: Adds dependency on validator tool
   - Decision: Yes - add lightweight YAML schema validation

## Success Criteria

1. ✅ Pilot project successfully deploys using manifest-only approach
2. ✅ No regression in deployment success rate
3. ✅ Configuration complexity reduced by >30%
4. ✅ Developer feedback is positive
5. ✅ Migration guide is clear and complete

## References

- Current template: `gh-action-template@v3.0.0`
- Current client: `hello-world-service@v1.0.54`
- GitHub Actions reusable workflows: https://docs.github.com/en/actions/using-workflows/reusing-workflows
- Piper configuration: https://www.project-piper.io/configuration/
