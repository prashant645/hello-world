# Kyma Bootstrap Contract Design

**Date:** 2026-09-10  
**Status:** Draft  
**Primary Target:** SAP BTP Kyma  
**Future Target Extension:** Cloud Foundry + XSUAA

## Executive Summary

This design defines the proposed **contract/schema** for a generalized Kyma bootstrap model that separates:

1. **cluster bootstrap**
2. **namespace/app bootstrap framework**
3. **project-local namespace/app bootstrap instances**

The contract is intended to support:
- centralized platform defaults
- project-specific overlays
- reusable automation in `gh-action-template`
- future extension to Cloud Foundry without redesigning auth concepts

This is a **design artifact only**. It does not implement the schema parser, generator, or workflows.

---

## Problem Statement

A fully hardcoded bootstrap solution is too rigid because real projects vary in:
- namespace names
- app names
- public hosts
- XSUAA names and lifecycle choices
- ServiceAccount ownership choices
- RBAC scope
- exposure policy
- operator/gateway assumptions

At the same time, allowing every project to define bootstrap however it wants leads to:
- drift
- snowflake configs
- unclear security ownership
- duplicated logic

The solution is a **central contract with project-local values**.

---

## Goals

The bootstrap contract should:

1. standardize bootstrap inputs across services
2. support centralized platform defaults and local service overlays
3. distinguish cluster scope from namespace/app scope
4. allow strong ownership boundaries
5. support dry-run / render / diff / apply / verify modes
6. prepare for later Cloud Foundry extension
7. allow runtime ServiceAccount to be bootstrap-owned by default

---

## Non-Goals

This contract does **not** define:
- the implementation language of the generator
- whether manifests are rendered via Helm, yq, Go templates, Jsonnet, Cue, or another tool
- exact GitHub workflow implementation
- a full multi-cloud resource model

---

## Architectural Model

## 1) Layered input model

The contract should support three logical layers.

### Layer A: Platform blueprint
Central, reusable defaults controlled by template/platform maintainers.

Examples:
- operator namespaces
- gateway namespace/name defaults
- RBAC profiles
- naming conventions
- security defaults
- environment policies
- cluster capability flags

### Layer B: Environment overlay
Environment-specific adjustments such as:
- `dev`, `qa`, `prod`
- internet exposure allowed or restricted
- approval requirements
- stricter runtime identity rules in prod
- host/domain naming rules

### Layer C: Service overlay
Project-local values provided by the service repo.

Examples:
- service name
- namespace name
- runtime ServiceAccount name
- XSUAA names
- APIRule host name
- which optional modules are enabled

The bootstrap engine should merge these layers into concrete resources and checks.

---

## 2) Scope split

### Cluster bootstrap scope
Centralized and platform-owned.

Examples:
- cluster prerequisites
- shared gateway assumptions
- operator prerequisites
- cluster discovery RBAC
- common policies

### Namespace/app bootstrap scope
Project-local instance, centrally standardized.

Examples:
- namespace creation
- deployer ServiceAccount
- runtime ServiceAccount
- namespace RBAC
- cross-namespace RoleBindings
- namespace labels
- secret bootstrap
- app-specific auth/exposure config prerequisites

---

## Proposed Contract Shape

The design recommends a single logical bootstrap spec with well-defined sections.

## 1) Top-level sections

Suggested conceptual sections:

- `apiVersion`
- `kind`
- `metadata`
- `target`
- `platformProfile`
- `environment`
- `service`
- `bootstrap`
- `exposure`
- `auth`
- `identity`
- `rbac`
- `secrets`
- `verification`
- `executionPolicy`

This structure is meant to keep the contract stable even when target-specific adapters are added later.

---

## 2) Metadata section

Purpose:
- identify the owning service and environment
- support auditing and generation metadata

Suggested fields:
- service name
- owning team
- environment name
- target platform
- schema version
- optional annotations/tags

---

## 3) Target section

Purpose:
- declare deployment target and keep the model CF-extensible

Suggested fields:
- `type`: `kyma` now, later `cf`
- `clusterProfile`: reference to shared platform blueprint
- `capabilities`: optional overrides/discovery flags

For Kyma, examples of capabilities:
- APIRule available
- BTP operator available
- gateway discovery enabled

This avoids burying Kyma assumptions deep inside the auth model.

---

## 4) Service section

Purpose:
- define app-specific identifiers

Suggested fields:
- service/app name
- namespace
- helm release name
- chart path reference (optional for bootstrap validation)
- workload classification (`public-service`, `internal-service`, etc.)

---

## 5) Bootstrap section

Purpose:
- describe which bootstrap modules should run and under what ownership assumptions

Suggested fields:
- create namespace or expect existing
- apply namespace labels
- create deployer identity or expect existing
- create runtime identity or expect existing
- bootstrap secrets or verify only
- mode flags:
  - render only
  - diff only
  - apply
  - verify

This section controls behavior, not just data.

---

## 6) Exposure section

Purpose:
- standardize internet/public exposure behavior

Suggested fields:
- `mode`: `apirule`, `internal`, future `route`
- enabled / disabled
- gateway namespace/name
- host / host template
- path rules
- whether public exposure is allowed in this environment
- HTTPS expectation

For Kyma today:
- this maps to APIRule generation and verification

For future CF:
- this could map to route/domain configuration

---

## 7) Auth section

Purpose:
- separate auth-provider choices from target-specific deployment mechanics

Suggested fields:
- `provider`: `xsuaa`, `none`, future values
- preflight enabled
- post-deploy verification enabled
- resource lifecycle mode:
  - precreated
  - partially managed
  - managed
- instance name
- binding name
- xsappname
- expected token URL rules
- required scopes/authorities for smoke tests

This is the key abstraction that lets the same design extend to CF later.

---

## 8) Identity section

Purpose:
- define deployer and runtime identity ownership clearly

Suggested fields:

### Deployer identity
- name
- namespace
- ownership: always bootstrap-owned
- kubeconfig generation required or not

### Runtime identity
- name
- creation mode:
  - `precreated` (recommended default)
  - `managed` (opt-in)
- annotations
- automount token policy
- associated role profile or references

Important design rule:
- runtime ServiceAccount should default to `precreated`
- normal deploy workflows should reference it, not create it, unless explicitly enabled

---

## 9) RBAC section

Purpose:
- configure standard RBAC profiles without embedding app-specific YAML logic in every repo

Suggested fields:
- namespace RBAC profile name
- cross-namespace RBAC modules enabled
- allowed resource categories
- prod restrictions / stricter modes if needed
- runtime SA role requirements if any

Recommended model:
- project repos choose from centrally defined profiles/modules
- they should not define arbitrary RBAC semantics from scratch unless explicitly allowed

Examples of modules:
- namespace deployer read/write profile
- gateway discovery read profile
- BTP operator read profile
- runtime pod-debug profile (if allowed)

---

## 10) Secrets section

Purpose:
- standardize how bootstrap locates and verifies secrets

Suggested fields:
- secret source mode
- expected namespace secret name(s)
- operator secret source reference
- docker registry secret behavior
- vault references if relevant
- whether secret material is copied, referenced, or only verified

This keeps secret handling explicit and auditable.

---

## 11) Verification section

Purpose:
- define read-only checks that bootstrap/app delivery can reuse

Suggested fields:
- verify namespace label
- verify deployer can read required resources
- verify runtime SA exists
- verify secret parity
- verify XSUAA instance/binding readiness
- verify APIRule readiness path enabled
- verify drift policy for release/prod gates

This section should support both bootstrap verification and pre-release drift auditing.

---

## 12) Execution policy section

Purpose:
- constrain when/how bootstrap operations may modify resources

Suggested fields:
- who may apply
- manual approval required or not
- environments allowed for apply
- allowed operation modes by env
- protected resources list
- whether this spec is bootstrap-only or also usable in audit mode

This helps enforce governance, not just technical rendering.

---

## Ownership Semantics

The contract should make ownership explicit.

## Bootstrap-owned resources
- deployer ServiceAccount
- deployer RBAC
- cross-namespace RBAC
- namespace labels
- bootstrap credentials secrets / setup references
- runtime ServiceAccount by default
- runtime SA security-sensitive annotations/bindings

## App-deployment-owned resources
- Deployment
- Service
- APIRule
- rollout and post-deploy verification
- app-scoped release settings

A spec instance should be rejected if it attempts to blur those ownership boundaries without an explicit override policy.

---

## Profiles and Modules

To balance reuse and flexibility, the contract should support:

## 1) Profiles

Profiles are centrally defined bundles of defaults.

Examples:
- `public-xsuaa-service`
- `internal-service`
- `public-prod-restricted`
- `sandbox-app-managed-runtime-sa`

Profiles reduce the number of raw knobs exposed to project repos.

---

## 2) Modules

Modules are optional add-ons.

Examples:
- APIRule exposure module
- XSUAA preflight module
- XSUAA post-deploy verification module
- BTP operator cross-namespace read module
- gateway discovery module
- kubeconfig generation module
- drift audit module

Project repos should enable modules, not reimplement them.

---

## Suggested Validation Rules

The schema/contract validator should enforce rules such as:

- if `target.type=kyma` and `exposure.mode=apirule`, gateway config must be resolvable
- if `auth.provider=xsuaa`, required XSUAA naming and lifecycle fields must be present
- if runtime SA mode is `precreated`, deploy workflow contract must not require runtime SA creation
- if prod exposure is public, HTTPS verification must be enabled by policy unless explicitly exempted
- if privileged RBAC modules are enabled, execution policy must require restricted apply path

These are semantic rules, not just field existence checks.

---

## Render / Diff / Apply / Verify Modes

The contract should support at least four execution modes:

## Render
- generate concrete manifests and derived settings
- no cluster changes

## Diff
- compare desired state to cluster state
- no cluster changes

## Apply
- perform allowed bootstrap mutations
- restricted identity recommended

## Verify
- run read-only checks after apply or before release

This makes the same contract usable for onboarding, maintenance, and auditing.

---

## Relationship to `gh-action-template`

The centralized template/platform layer should own:
- schema definition
- validation logic
- profile catalog
- module catalog
- reusable generators/helpers
- reusable deploy workflow
- reusable audit/preflight helpers

Project repos should own:
- spec instances / values
- app-specific names and toggles
- app-specific XSUAA names
- app-specific hostnames
- env-specific overlay choices

This is the intended balance between standardization and flexibility.

---

## Future Cloud Foundry Extension

This contract is intentionally designed so the auth model survives a target change.

### Shared across Kyma and future CF
- `auth.provider=xsuaa`
- instance/binding identity concepts
- auth smoke-test expectations
- scope verification
- lifecycle ownership choices

### Target adapter changes later
- Kyma uses namespace, ServiceAccount, APIRule, K8s resources
- CF would use space, route, CF service binding/service instance concepts

That means the contract should stabilize around **intent**, not only around K8s primitives.

---

## Recommended Next Steps

1. review and approve this contract direction
2. decide where the schema/validator lives
3. define a first minimal spec instance for `hello-world-service`
4. define the first set of centrally supported profiles/modules
5. implement Kyma-only support first
6. keep CF mapping as a reserved extension path

---

## Bottom Line

The bootstrap should be **general in logic, parameterized in values, and layered by ownership**.

The right contract is not a single hardcoded manifest for all apps.
It is:
- a centralized schema
- platform defaults and reusable modules
- project-local overlays and instances
- strong ownership and verification rules

That gives enough flexibility for real-world project differences without losing standardization.

