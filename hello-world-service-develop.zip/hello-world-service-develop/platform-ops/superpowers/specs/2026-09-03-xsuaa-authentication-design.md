# XSUAA Authentication and Authorization Design

**Date:** 2026-09-03  
**Status:** Approved  
**Deployment Target:** SAP BTP Kyma (primary), Cloud Foundry (future)

## Overview

Integrate XSUAA (Extended Services for User Account and Authentication) into the hello-world-service to provide OAuth2-based authentication and authorization with role-based access control.

## Requirements

- Two permission levels: **Read** and **Write**
- Hierarchical permissions: Write scope includes Read scope
- POST-only API endpoints (no GET for security)
- Two endpoints:
  - `POST /api/v1/greetings` - Read greetings (requires Read scope)
  - `POST /api/v1/greetings/update` - Update service configuration (requires Write scope)
- Runtime configuration updates for rate limiting and validation rules
- Deploy to Kyma initially, with CF support documented for future use

## Architecture

### 1. XSUAA Configuration (xs-security.json)

Define security descriptor with scopes and role templates:

```json
{
  "xsappname": "hello-world-service-${CF_SPACE}",
  "tenant-mode": "dedicated",
  "scopes": [
    {
      "name": "$XSAPPNAME.Read",
      "description": "Read greetings via POST /api/v1/greetings"
    },
    {
      "name": "$XSAPPNAME.Write",
      "description": "Update service configuration via POST /api/v1/greetings/update (includes Read)"
    }
  ],
  "role-templates": [
    {
      "name": "Reader",
      "description": "Can read greetings only",
      "scope-references": ["$XSAPPNAME.Read"]
    },
    {
      "name": "Writer",
      "description": "Can read greetings and update service configuration",
      "scope-references": ["$XSAPPNAME.Read", "$XSAPPNAME.Write"]
    }
  ]
}
```

**Key design decisions:**
- `$XSAPPNAME` placeholder replaced at runtime with actual application name
- `${CF_SPACE}` variable keeps xsappname unique per environment (dev, qa, prod) - for Kyma use hardcoded value like "hello-world-service-kyma"
- Writer role explicitly includes both Read and Write scope references (hierarchical)
- Role templates auto-create role collections in BTP Cockpit after deployment

### 2. Spring Security Configuration

Update `SecurityConfig.java` to enforce scope-based authorization:

```java
@Bean
public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
    http
        .csrf(csrf -> csrf.disable())
        .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
        .authorizeHttpRequests(auth -> auth
            .requestMatchers("/actuator/**").permitAll()
            .requestMatchers("/api/v1/greetings/update").hasAuthority("Write")
            .requestMatchers("/api/v1/greetings").hasAuthority("Read")
            .anyRequest().authenticated()
        )
        .oauth2ResourceServer(oauth2 -> oauth2.jwt(jwt -> {}));
    
    return http.build();
}
```

**Security rules:**
- Most specific paths first (`/greetings/update` before `/greetings`)
- `/actuator/**` remains public for Kubernetes health checks
- Stateless session management (JWT token per request, no cookies)
- OAuth2 Resource Server validates JWT tokens from XSUAA
- SAP BTP Security library auto-wires JWT decoder and scope converter

**Changes from current state:**
- Remove `CreateScope` and `AdminScope` references
- Remove `/api/items/**` and `/api/admin/**` endpoint rules
- Change scope from `ReadScope` to `Read` for existing `/api/v1/greetings` endpoint

### 3. Controller Endpoints

Update `GreetingController.java`:

**Existing endpoint (scope change only):**
```java
@PostMapping("/greetings")
@PreAuthorize("hasAuthority('Read')")
public GreetingResponse generalGreeting(@Valid @RequestBody GreetingRequest request) {
    return greetingService.createGreeting(request);
}
```

**New endpoint for configuration updates:**
```java
@PostMapping("/greetings/update")
@PreAuthorize("hasAuthority('Write')")
public ConfigUpdateResponse updateConfiguration(
    @Valid @RequestBody ConfigUpdateRequest request,
    @AuthenticationPrincipal Token token
) {
    return configurationService.updateConfiguration(request);
}
```

**Request/Response models:**

`ConfigUpdateRequest.java`:
```java
public class ConfigUpdateRequest {
    @Valid
    private RateLimitConfig rateLimit;
    
    @Valid
    private ValidationConfig validation;
    
    public static class RateLimitConfig {
        @Min(1) @Max(1000)
        private Integer requestsPerMinute;
        
        private Boolean enabled;
    }
    
    public static class ValidationConfig {
        @Min(1) @Max(100)
        private Integer maxWords;
        
        @Min(1) @Max(500)
        private Integer maxCharacters;
    }
}
```

`ConfigUpdateResponse.java`:
```java
public class ConfigUpdateResponse {
    private String status;
    private ConfigUpdateRequest appliedConfig;
    private String message;
    private String updatedBy;  // From JWT token
    private Instant updatedAt;
}
```

**Cleanup:**
- Remove `/api/items` endpoint (demo endpoint with CreateScope)
- Remove `/api/admin` endpoint (demo endpoint with AdminScope)

### 4. Configuration Management Service

Create new `ConfigurationService` to manage runtime settings:

**Component:** `com.sap.gtlc.security.service.ConfigurationService`

**Responsibilities:**
- Store current configuration in memory
- Validate and apply configuration updates
- Provide thread-safe access to configuration
- Expose current settings to rate limiting and validation components

**Configuration properties class:**
```java
@ConfigurationProperties(prefix = "greeting-service")
@Component
public class GreetingServiceConfig {
    private RateLimitConfig rateLimit = new RateLimitConfig();
    private ValidationConfig validation = new ValidationConfig();
    
    @Data
    public static class RateLimitConfig {
        private int requestsPerMinute = 10;
        private boolean enabled = true;
    }
    
    @Data
    public static class ValidationConfig {
        private int maxWords = 10;
        private int maxCharacters = 50;
    }
}
```

**Service implementation:**
```java
@Service
public class ConfigurationService {
    private final AtomicReference<GreetingServiceConfig> currentConfig;
    
    public ConfigUpdateResponse updateConfiguration(ConfigUpdateRequest request) {
        // Validate request
        // Update configuration atomically
        // Return response with applied config
    }
    
    public GreetingServiceConfig getCurrentConfig() {
        return currentConfig.get();
    }
}
```

**Integration points:**
- `RateLimitingFilter` reads `requestsPerMinute` and `enabled` from ConfigurationService
- Input validation reads `maxWords` and `maxCharacters` from ConfigurationService
- Configuration persists for application lifetime (resets on pod restart)
- Future: Can be extended to persist to database or SAP BTP Configuration Service

**Thread safety:**
- Use `AtomicReference` for lock-free reads
- Synchronize only during updates
- Configuration updates are rare (write operations), reads are frequent

### 5. Kyma Deployment with XSUAA

**Step 1: Create XSUAA Service Instance**

Create file `platform-ops/k8s/xsuaa/namespaces/dev/apps/hello-world-service/serviceinstance.yaml`:
```yaml
apiVersion: services.cloud.sap.com/v1
kind: ServiceInstance
metadata:
  name: hello-world-xsuaa
  namespace: <namespace>
spec:
  serviceOfferingName: xsuaa
  servicePlanName: application
  parameters:
    xsappname: hello-world-service-kyma
    tenant-mode: dedicated
    scopes:
      - name: "$XSAPPNAME.Read"
        description: "Read greetings via POST /api/v1/greetings"
      - name: "$XSAPPNAME.Write"
        description: "Update service configuration via POST /api/v1/greetings/update (includes Read)"
    role-templates:
      - name: "Reader"
        description: "Can read greetings only"
        scope-references: ["$XSAPPNAME.Read"]
      - name: "Writer"
        description: "Can read greetings and update service configuration"
        scope-references: ["$XSAPPNAME.Read", "$XSAPPNAME.Write"]
```

**Step 2: Create Service Binding**

Create file `platform-ops/k8s/xsuaa/namespaces/dev/apps/hello-world-service/servicebinding.yaml`:
```yaml
apiVersion: services.cloud.sap.com/v1
kind: ServiceBinding
metadata:
  name: hello-world-xsuaa-binding
  namespace: <namespace>
spec:
  serviceInstanceName: hello-world-xsuaa
  secretName: hello-world-xsuaa-secret
```

**Step 3: Update Helm Deployment**

Update `helm/hello-world-service/templates/deployment.yaml`:

```yaml
spec:
  template:
    spec:
      containers:
      - name: {{ .Chart.Name }}
        env:
          - name: SERVICE_BINDING_ROOT
            value: /bindings
        volumeMounts:
          - name: xsuaa-binding
            mountPath: /bindings/xsuaa
            readOnly: true
      volumes:
        - name: xsuaa-binding
          secret:
            secretName: hello-world-xsuaa-secret
```

Add to `helm/hello-world-service/values.yaml`:
```yaml
xsuaa:
  enabled: true
  secretName: hello-world-xsuaa-secret
```

**Step 4: Auto-configuration**

The `resourceserver-security-spring-boot-starter` dependency automatically:
- Detects service bindings at `SERVICE_BINDING_ROOT` environment variable
- Reads XSUAA configuration from mounted secret at `/bindings/xsuaa`
- Configures JWT decoder with XSUAA issuer URL and public keys
- Sets up token validation and scope extraction
- No additional application code required

**Deployment commands:**
```bash
# Apply XSUAA service instance and binding
kubectl apply -f platform-ops/k8s/xsuaa/namespaces/dev/apps/hello-world-service/serviceinstance.yaml
kubectl apply -f platform-ops/k8s/xsuaa/namespaces/dev/apps/hello-world-service/servicebinding.yaml

# Wait for binding to be ready
kubectl wait --for=condition=Ready servicebinding/hello-world-xsuaa-binding --timeout=300s

# Deploy application via Helm
helm upgrade --install hello-world-service ./helm/hello-world-service \
  --set image.tag=<version> \
  --namespace <namespace>
```

**Testing flow:**
1. Deploy XSUAA ServiceInstance and ServiceBinding to Kyma
2. Verify secret created: `kubectl get secret hello-world-xsuaa-secret`
3. Deploy application with secret mounted
4. Assign role collections in BTP Cockpit:
   - Navigate to Security → Role Collections
   - Create `HelloWorld_Reader` and `HelloWorld_Writer` collections
   - Add role templates: Reader → `Reader`, Writer → `Reader` + `Writer`
   - Assign users to role collections
5. Obtain JWT token via OAuth2 client credentials flow or user authentication
6. Test endpoints with `Authorization: Bearer <token>` header

### 6. Cloud Foundry Deployment (Future)

**For CF deployment, the same xs-security.json is used with different binding mechanism:**

**Step 1: Update XSUAA Service**
```bash
cf update-service env-specific-xsuaa -c xs-security.json
```

**Step 2: Service Binding**

Already configured in `manifest.yml`:
```yaml
services:
  - env-specific-xsuaa
```

**Step 3: Auto-configuration**

The same Spring Boot starter reads from `VCAP_SERVICES` environment variable instead of mounted secrets. No code changes needed between Kyma and CF.

**Step 4: Deploy**
```bash
cf push
```

Role assignment in BTP Cockpit is identical to Kyma approach.

## Data Flow

### Authentication Flow

1. User authenticates with XSUAA (OAuth2 Authorization Server)
2. XSUAA returns JWT token containing user scopes
3. User sends request with `Authorization: Bearer <token>` header
4. Spring Security OAuth2 Resource Server validates token:
   - Verifies signature using XSUAA public keys
   - Checks token expiration
   - Extracts scopes from token claims
5. `SecurityFilterChain` checks endpoint path and required authority
6. Request allowed if user has required scope, otherwise 403 Forbidden

### Authorization Flow (Read)

```
User (with Read scope)
  → POST /api/v1/greetings + JWT token
  → Spring Security validates token
  → Check: hasAuthority('Read')? ✓
  → GreetingController.generalGreeting()
  → GreetingService.createGreeting()
  → Return GreetingResponse
```

### Authorization Flow (Write)

```
User (with Write scope)
  → POST /api/v1/greetings/update + JWT token
  → Spring Security validates token
  → Check: hasAuthority('Write')? ✓ (Write scope includes Read)
  → GreetingController.updateConfiguration()
  → ConfigurationService.updateConfiguration()
  → Validate and apply new settings
  → RateLimitingFilter and validation components pick up changes
  → Return ConfigUpdateResponse
```

## Error Handling

**401 Unauthorized:**
- Missing Authorization header
- Invalid JWT token (expired, malformed, invalid signature)
- Response: RFC 7807 Problem Details with `type: "about:blank"`, `status: 401`

**403 Forbidden:**
- Valid token but insufficient scope
- Example: User with Read scope tries to access `/api/v1/greetings/update`
- Response: RFC 7807 Problem Details with `type: "about:blank"`, `status: 403`

**400 Bad Request:**
- Invalid configuration update request (values out of range)
- Response: RFC 7807 Problem Details with validation errors

**Existing error handling:**
- `GlobalExceptionHandler` already returns RFC 7807 Problem Details
- Add handler for `AccessDeniedException` (403) and `AuthenticationException` (401)

## Testing Strategy

### Unit Tests

1. **SecurityConfig Test:**
   - Verify endpoint-to-scope mappings
   - Test that actuator endpoints remain public
   - Mock JWT authentication with different scopes

2. **ConfigurationService Test:**
   - Validate configuration update logic
   - Test thread safety with concurrent updates
   - Verify validation rules enforcement

3. **Controller Tests:**
   - Test `/api/v1/greetings` with Read scope (success)
   - Test `/api/v1/greetings` without token (401)
   - Test `/api/v1/greetings/update` with Write scope (success)
   - Test `/api/v1/greetings/update` with Read scope only (403)
   - Test configuration update with invalid values (400)

### Integration Tests

1. **XSUAA Integration:**
   - Use `@SpringBootTest` with `@WithMockUser` for scope testing
   - Mock JWT tokens with specific scopes
   - Verify token validation and scope extraction

2. **End-to-End:**
   - Deploy to Kyma dev environment
   - Test with real XSUAA tokens
   - Verify role collection assignments work correctly
   - Test configuration updates persist across requests

## Security Considerations

1. **Token Validation:**
   - All tokens validated against XSUAA public keys
   - Signature verification prevents token tampering
   - Expiration checks prevent replay attacks

2. **Scope Hierarchy:**
   - Write scope explicitly includes Read scope in role template
   - Prevents privilege escalation (users cannot grant themselves scopes)
   - Role assignment controlled via BTP Cockpit (separate from application)

3. **Configuration Updates:**
   - Only users with Write scope can modify settings
   - Validation prevents malicious values (e.g., requestsPerMinute: 1000000)
   - Configuration changes logged with user identity from JWT token
   - In-memory storage means bad config resets on restart (fail-safe)

4. **Stateless Sessions:**
   - No session state stored in application (JWT contains all auth info)
   - Horizontal scaling without session affinity requirements
   - Token revocation handled by XSUAA (short token lifetimes)

5. **Health Endpoints:**
   - `/actuator/health` remains public for Kubernetes probes
   - Other actuator endpoints can be secured separately if needed
   - Consider moving actuator to separate port (management port) in production

## CI/CD Integration

### Current Pipeline Support

The existing CI/CD pipeline already supports XSUAA integration:

**Trigger paths in `.pipeline/gtlc.yml` include:**
- `xs-security.json` - Changes to XSUAA configuration trigger deployments
- Kyma dev environment triggers on `develop` branch
- Kyma qa environment triggers on `main` branch

**What's already in place:**
1. GitHub Actions workflow calls reusable template from `gh-action-template`
2. Helm chart deployment via `helm upgrade --install`
3. Docker registry secret auto-created in namespace
4. Kubeconfig retrieved from Vault

### Required CI/CD Additions

**1. XSUAA Service Provisioning (One-Time Setup)**

XSUAA ServiceInstance and ServiceBinding must be created **manually** before first deployment:

```bash
# Apply XSUAA service instance (reads xs-security.json parameters)
kubectl apply -f platform-ops/k8s/xsuaa/namespaces/dev/apps/hello-world-service/serviceinstance.yaml -n dev

# Apply service binding (creates secret)
kubectl apply -f platform-ops/k8s/xsuaa/namespaces/dev/apps/hello-world-service/servicebinding.yaml -n dev

# Wait for binding to be ready
kubectl wait --for=condition=Ready servicebinding/hello-world-xsuaa-binding -n dev --timeout=300s

# Verify secret created
kubectl get secret hello-world-xsuaa-secret -n dev
```

**Why manual?** SAP BTP Service Operator requires namespace-level permissions and is environment-specific. Creating services via CI/CD requires:
- Service Operator installed in Kyma cluster
- CI/CD service account with permissions to create ServiceInstances
- Environment-specific XSUAA configurations (dev, qa, prod have different app names)

**Recommendation:** Create XSUAA services manually per environment as part of initial setup. Services persist across deployments and only need recreation if xs-security.json changes significantly.

**2. Update Helm Chart to Mount XSUAA Secret**

Helm chart already handles application deployment. Add XSUAA secret mount:

```yaml
# In deployment.yaml
env:
  - name: SERVICE_BINDING_ROOT
    value: /bindings
volumeMounts:
  - name: xsuaa-binding
    mountPath: /bindings/xsuaa
    readOnly: true
volumes:
  - name: xsuaa-binding
    secret:
      secretName: hello-world-xsuaa-secret
```

**3. Optional: XSUAA Service Update in CI/CD**

If you want CI/CD to update XSUAA services when xs-security.json changes:

Add step to reusable workflow in `gh-action-template`:

```yaml
- name: Update XSUAA Service Instance
  if: github.event_name == 'push'  # Only on commits, not manual triggers
  run: |
    # Check if xs-security.json changed in this commit
    if git diff HEAD^ HEAD --name-only | grep -q "xs-security.json"; then
      echo "xs-security.json changed, updating XSUAA service..."
      
      # Update service instance with new parameters
      kubectl patch servicinstance hello-world-xsuaa -n ${{ inputs.namespace }} \
        --type merge \
        --patch "$(cat platform-ops/k8s/xsuaa/namespaces/dev/apps/hello-world-service/serviceinstance.yaml)"
      
      # Wait for service instance to reconcile
      kubectl wait --for=condition=Ready serviceinstance/hello-world-xsuaa \
        -n ${{ inputs.namespace }} --timeout=300s
      
      echo "XSUAA service updated successfully"
    else
      echo "xs-security.json unchanged, skipping XSUAA update"
    fi
```

**Trade-offs:**
- ✅ Automatic XSUAA updates when security config changes
- ❌ Adds complexity to CI/CD
- ❌ Requires careful testing (wrong XSUAA config breaks authentication)
- ❌ Service updates take 2-5 minutes (increases deployment time)

**Recommendation for Phase 1:** Manual XSUAA service management. Add automation in Phase 2 if xs-security.json changes frequently.

### Deployment Flow with XSUAA

**Initial Setup (One-Time):**
```bash
# 1. Create XSUAA service (manual)
kubectl apply -f platform-ops/k8s/xsuaa/namespaces/dev/apps/hello-world-service/serviceinstance.yaml -n dev
kubectl apply -f platform-ops/k8s/xsuaa/namespaces/dev/apps/hello-world-service/servicebinding.yaml -n dev

# 2. Wait for secret
kubectl wait --for=condition=Ready servicebinding/hello-world-xsuaa-binding -n dev --timeout=300s

# 3. Verify secret exists
kubectl get secret hello-world-xsuaa-secret -n dev
```

**Every Deployment (Automated via CI/CD):**
```bash
# GitHub Actions workflow triggers
# ↓
# Reusable workflow in gh-action-template runs
# ↓
# Helm deploys application with XSUAA secret mounted
helm upgrade --install hello-world-service ./helm/hello-world-service \
  --set image.tag=${VERSION} \
  -f values-dev.yaml \
  --namespace dev \
  --wait --timeout 5m

# Application starts, reads XSUAA config from /bindings/xsuaa
# ↓
# Spring Boot auto-configures OAuth2 Resource Server
# ↓
# Endpoints secured with Read/Write scopes
```

### CI/CD Validation

Add to existing pipeline validation:

**Pre-deployment checks:**
1. Verify XSUAA secret exists in namespace before Helm deploy
   ```bash
   kubectl get secret hello-world-xsuaa-secret -n ${namespace} || exit 1
   ```

**Post-deployment checks:**
1. Verify pod has XSUAA volume mounted
   ```bash
   kubectl get pod -l app=hello-world-service -n dev -o jsonpath='{.items[0].spec.volumes[*].name}' | grep xsuaa-binding
   ```

2. Check application logs for XSUAA initialization
   ```bash
   kubectl logs -l app=hello-world-service -n dev | grep "XSUAA"
   ```

3. Test unauthenticated endpoint returns 401
   ```bash
   curl -f http://hello-world-service.dev.svc.cluster.local:8080/api/v1/greetings -X POST \
     -H "Content-Type: application/json" \
     -d '{"message":"test"}' \
     && exit 1 || echo "✓ Endpoint requires authentication"
   ```

## Migration Path

### Phase 1: Current → XSUAA (This Design)
1. Update xs-security.json with Read/Write scopes
2. Create XSUAA ServiceInstance and ServiceBinding in Kyma (manual, per environment)
3. Update Helm chart to mount XSUAA secret
4. Update SecurityConfig with new scope mappings
5. Add ConfigurationService and update endpoint
6. Deploy via CI/CD (GitHub Actions → Helm)
7. Assign role collections in BTP Cockpit
8. Test with assigned role collections

### Phase 2: Future Enhancements
1. Persist configuration to database or BTP Configuration Service
2. Add audit logging for configuration changes
3. Add more granular scopes (e.g., separate rate-limit and validation scopes)
4. Implement configuration history/rollback
5. Add CF deployment when needed (same code, different binding)

## Dependencies

**Already present in build.gradle:**
- `spring-boot-starter-security` - Spring Security framework
- `resourceserver-security-spring-boot-starter:3.4.0` - SAP BTP XSUAA integration

**No additional dependencies required.**

## Configuration Files Changed

1. **xs-security.json** - Add scopes and role templates
2. **src/main/java/com/sap/gtlc/security/security/SecurityConfig.java** - Update scope mappings
3. **src/main/java/com/sap/gtlc/security/controller/GreetingController.java** - Update scopes, add update endpoint, remove old endpoints
4. **helm/hello-world-service/templates/deployment.yaml** - Add XSUAA secret mount
5. **helm/hello-world-service/values.yaml** - Add XSUAA configuration
6. **platform-ops/k8s/xsuaa/namespaces/dev/apps/hello-world-service/serviceinstance.yaml** - New file for Kyma XSUAA service
7. **platform-ops/k8s/xsuaa/namespaces/dev/apps/hello-world-service/servicebinding.yaml** - New file for Kyma XSUAA binding

**New files:**
8. **src/main/java/com/sap/gtlc/security/service/ConfigurationService.java** - Configuration management
9. **src/main/java/com/sap/gtlc/security/model/ConfigUpdateRequest.java** - Request model
10. **src/main/java/com/sap/gtlc/security/model/ConfigUpdateResponse.java** - Response model
11. **src/main/java/com/sap/gtlc/security/config/GreetingServiceConfig.java** - Configuration properties

## Success Criteria

1. ✅ User with Reader role can call POST `/api/v1/greetings`
2. ✅ User with Reader role CANNOT call POST `/api/v1/greetings/update` (403)
3. ✅ User with Writer role can call both endpoints
4. ✅ Unauthenticated requests to protected endpoints return 401
5. ✅ Configuration updates via `/api/v1/greetings/update` take effect immediately
6. ✅ Rate limiting respects updated configuration
7. ✅ Health endpoints remain accessible without authentication
8. ✅ Application works identically on Kyma and CF (after binding setup)
