# Kyma Deployment Design for hello-world-service

**Date**: 2026-08-22  
**Status**: Approved  
**Target**: Deploy hello-world-service to BTP Kyma cluster in `dev` namespace

## Overview

This design adds Kyma deployment capability to hello-world-service while preserving existing Cloud Foundry deployment. The solution uses Helm charts for Kubernetes-native packaging and GitHub Actions with reusable workflows for CI/CD.

## Goals

1. Deploy hello-world-service Docker image to Kyma cluster
2. Reuse existing build and validation pipeline
3. Support multiple environments (dev, qa, prod)
4. Maintain separation from CF deployment
5. Use Helm for production-ready deployment management

## Non-Goals

- Replace or modify existing CF deployment
- Implement ingress/external routing (can be added later)
- Auto-scaling configuration (start with fixed replicas)

## Architecture

### Three-Layer Architecture

**Layer 1: GitHub Workflow** (`.github/workflows/deploy-kyma-dev.yml`)
- Triggers on push to `develop` branch or manual dispatch
- Calls reusable workflow from `gh-action-template`
- Passes Vault path for kubeconfig secret and deployment parameters

**Layer 2: Reusable Workflow** (in `gh-action-template` repo)
- New workflow: `.github/workflows/deploy-kyma-dev.yml`
- Similar to existing `deploy-dev.docker.yml` pattern
- Retrieves kubeconfig from Vault using Piper credentials
- Sets up kubectl and Helm CLI
- Executes deployment to Kyma cluster

**Layer 3: Helm Chart** (in this repo)
- Location: `helm/hello-world-service/`
- Base chart with templates for Deployment, Service
- Environment-specific values files (`values-dev.yaml`, `values-qa.yaml`, `values-prod.yaml`)

## Components

### 1. Client Workflow

**File**: `.github/workflows/deploy-kyma-dev.yml`

```yaml
name: Deploy to Kyma Dev

on:
  workflow_dispatch:
    inputs:
      skip_validation:
        description: 'Skip validation stage'
        required: false
        default: false
        type: boolean
  push:
    branches:
      - "develop"

jobs:
  deploy_kyma_dev:
    uses: GTLCInfra/gh-action-template/.github/workflows/deploy-kyma-dev.yml@v2.1.0
    with:
      skip_validation: ${{ fromJSON(inputs.skip_validation || 'false') }}
      kyma-vault-path: 'piper/data/sap-project-gtlcinfra-poc-1/hello-world-service/kyma'
      environment: 'dev'
      namespace: 'dev'
      helm-chart-path: 'helm/hello-world-service'
      helm-values-file: 'values-dev.yaml'
    secrets:
      PIPER_VAULTAPPROLEID: ${{ secrets.PIPER_VAULTAPPROLEID }}
      PIPER_VAULTAPPROLESECRETID: ${{ secrets.PIPER_VAULTAPPROLESECRETID }}
```

**Inputs:**
- `kyma-vault-path` - Vault path for kubeconfig secret
- `environment` - Environment name for tracking (dev/qa/prod)
- `namespace` - Kubernetes namespace to deploy to
- `helm-chart-path` - Relative path to Helm chart in repo
- `helm-values-file` - Environment-specific values file

### 2. Reusable Workflow Implementation

**File**: `gh-action-template/.github/workflows/deploy-kyma-dev.yml`

**Steps:**
1. **Checkout Code** - Clone repository with Helm charts
2. **Retrieve Kubeconfig from Vault** - Use Piper's Vault integration to fetch kubeconfig
3. **Setup kubectl** - Install kubectl CLI and configure with kubeconfig
4. **Setup Helm** - Install Helm 3 CLI
5. **Create Namespace** - Idempotently create namespace:
   ```bash
   kubectl create namespace ${namespace} --dry-run=client -o yaml | kubectl apply -f -
   ```
6. **Create Docker Registry Secret** - Convert Vault docker-config to Kubernetes Secret:
   ```bash
   kubectl create secret docker-registry docker-registry-secret \
     --docker-server=gtlc-docker.common.repositories.cloud.sap \
     --docker-username=${USERNAME} \
     --docker-password=${PASSWORD} \
     --namespace ${namespace} \
     --dry-run=client -o yaml | kubectl apply -f -
   ```
7. **Helm Upgrade/Install** - Deploy application:
   ```bash
   helm upgrade --install hello-world-service ${helm-chart-path} \
     -f ${helm-chart-path}/${helm-values-file} \
     --namespace ${namespace} \
     --wait \
     --timeout 5m
   ```

**Key Technical Details:**
- Kubeconfig is base64 decoded and written to temporary file
- `kubectl` configured with: `export KUBECONFIG=/tmp/kubeconfig`
- Helm `--wait` ensures deployment succeeds before marking job complete
- `--timeout 5m` prevents hanging on failed deployments
- All namespace and secret operations are idempotent (safe to re-run)

### 3. Helm Chart Structure

**Directory**: `helm/hello-world-service/`

```
helm/hello-world-service/
├── Chart.yaml
├── values.yaml
├── values-dev.yaml
├── values-qa.yaml
├── values-prod.yaml
└── templates/
    ├── deployment.yaml
    ├── service.yaml
    ├── ingress.yaml (optional)
    └── _helpers.tpl
```

**Chart.yaml:**
```yaml
apiVersion: v2
name: hello-world-service
description: Secure Hello World Greeting REST API
type: application
version: 1.0.0
appVersion: "1.0.0"
```

**values.yaml (base defaults):**
```yaml
replicaCount: 1

image:
  repository: gtlc-docker.common.repositories.cloud.sap/hello-world-service
  pullPolicy: IfNotPresent
  tag: ""  # Overridden by appVersion

imagePullSecrets:
  - name: docker-registry-secret

service:
  type: ClusterIP
  port: 8080
  targetPort: 8080

resources:
  limits:
    cpu: 500m
    memory: 512Mi
  requests:
    cpu: 250m
    memory: 256Mi

livenessProbe:
  httpGet:
    path: /actuator/health
    port: 8080
  initialDelaySeconds: 30
  periodSeconds: 10

readinessProbe:
  httpGet:
    path: /actuator/health
    port: 8080
  initialDelaySeconds: 10
  periodSeconds: 5
```

**values-dev.yaml (environment overrides):**
```yaml
replicaCount: 1

image:
  tag: "latest"

resources:
  limits:
    cpu: 500m
    memory: 512Mi
  requests:
    cpu: 250m
    memory: 256Mi
```

**Key Templates:**
- `deployment.yaml` - Pod specification, replicas, health checks, environment variables
- `service.yaml` - ClusterIP service exposing port 8080
- `ingress.yaml` - (Optional) External routing if needed later
- `_helpers.tpl` - Reusable template helpers

## Data Flow

### Deployment Flow

```
Developer pushes to develop branch
  ↓
GitHub Actions triggered
  ↓
Calls reusable workflow from gh-action-template
  ↓
Retrieve secrets from Vault:
  - kyma kubeconfig (base64 encoded)
  - docker-config credentials
  ↓
Setup kubectl & Helm CLIs
  ↓
Configure kubectl with kubeconfig
  ↓
Create namespace 'dev' (idempotent)
  ↓
Create docker-registry-secret in namespace (idempotent)
  ↓
Helm upgrade --install with values-dev.yaml
  ↓
Helm waits for pods to reach Ready state
  ↓
Deployment succeeds ✓
```

### Secret Management

**Two Authentication Contexts:**

1. **Pipeline → Kubernetes API**
   - Uses kubeconfig from Vault
   - Authenticates kubectl/helm commands
   - Vault path: `piper/data/sap-project-gtlcinfra-poc-1/hello-world-service/kyma`
   - Format: `{"kubeconfig": "<base64-encoded-kubeconfig>"}`

2. **Kubernetes Nodes → Docker Registry**
   - Uses docker-config credentials from Vault
   - Authenticates image pulls by kubelet
   - Vault path: `piper/data/sap-project-gtlcinfra-poc-1/hello-world-service/docker-config`
   - Converted to Kubernetes Secret of type `dockerconfigjson`

**Vault Setup Required:**

**Kubeconfig Secret:**
```bash
# 1. Download kubeconfig
curl -o kubeconfig.yaml https://kyma-env-broker.cp.stage.kyma.cloud.sap/kubeconfig/ED9D876C-A50E-471A-B3C6-E9E3D1BA7A8E

# 2. Base64 encode
base64 -i kubeconfig.yaml | tr -d '\n'

# 3. Store in Vault at:
# Path: piper/data/sap-project-gtlcinfra-poc-1/hello-world-service/kyma
# Key: kubeconfig
# Value: <base64-encoded-content>
```

## Error Handling

### Deployment Failures

**Helm Automatic Rollback:**
- Helm's `--wait` flag monitors pod health during deployment
- If pods fail to start within `--timeout 5m`, deployment fails
- Helm automatically preserves previous release
- No manual intervention needed for rollback

**Manual Rollback (if needed):**
```bash
helm rollback hello-world-service --namespace dev
```

**Common Failure Scenarios:**

1. **Image Pull Failure**
   - Cause: Docker registry secret misconfigured or missing
   - Detection: Pod status shows `ImagePullBackOff`
   - Fix: Verify docker-config in Vault, check secret creation step

2. **Health Check Failure**
   - Cause: Application fails to start or `/actuator/health` returns error
   - Detection: Pod status shows `CrashLoopBackOff` or not Ready
   - Fix: Check pod logs with `kubectl logs -n dev <pod-name>`

3. **Resource Constraints**
   - Cause: Insufficient CPU/memory in namespace
   - Detection: Pod status shows `Pending` with scheduling error
   - Fix: Adjust resource requests/limits in values file

4. **Invalid Kubeconfig**
   - Cause: Vault secret expired or incorrect
   - Detection: kubectl commands fail with authentication error
   - Fix: Re-download and update kubeconfig in Vault

**Pipeline Error Visibility:**
- Each step logs clearly to GitHub Actions
- Failed step shows error message and exit code
- Helm provides detailed error messages for deployment failures

## Testing Strategy

### Phase 1: Local Validation

**Helm Chart Linting:**
```bash
helm lint helm/hello-world-service
```

**Dry-run Installation:**
```bash
helm install --dry-run --debug hello-world-service \
  helm/hello-world-service \
  -f helm/hello-world-service/values-dev.yaml
```

### Phase 2: Pipeline Testing

**Initial Deployment:**
1. Trigger manual workflow dispatch for first deployment
2. Monitor GitHub Actions logs for each step
3. Verify successful completion

**Kubernetes Validation:**
```bash
# Check pod status
kubectl get pods -n dev

# Check deployment
kubectl get deployment -n dev hello-world-service

# Check service
kubectl get svc -n dev hello-world-service

# View logs
kubectl logs -n dev -l app=hello-world-service

# Describe pod for troubleshooting
kubectl describe pod -n dev <pod-name>
```

**Application Testing:**
```bash
# Port-forward to local machine
kubectl port-forward -n dev svc/hello-world-service 8080:8080

# Test health endpoint
curl http://localhost:8080/actuator/health

# Test greeting endpoint
curl http://localhost:8080/greet?name=TestUser

# Verify rate limiting
for i in {1..15}; do curl http://localhost:8080/greet?name=Test; done
```

### Phase 3: Validation

**Success Criteria:**
- ✓ Pipeline completes without errors
- ✓ Pods reach Running and Ready state
- ✓ Health checks pass (liveness and readiness)
- ✓ Application responds correctly to API requests
- ✓ Rate limiting and security features work
- ✓ Subsequent deployments update successfully
- ✓ Rollback works if deployment fails

**Comparison with CF Deployment:**
- Verify identical application behavior
- Compare API response formats
- Validate security features (input sanitization, rate limiting)

## Multi-Environment Strategy

### Workflow Files

**Dev Environment:**
- File: `.github/workflows/deploy-kyma-dev.yml`
- Trigger: Push to `develop` branch or manual
- Namespace: `dev`
- Values: `values-dev.yaml`

**QA Environment:**
- File: `.github/workflows/deploy-kyma-qa.yml`
- Trigger: Push to `main` branch or manual
- Namespace: `qa`
- Values: `values-qa.yaml`

**Production Environment:**
- File: `.github/workflows/deploy-kyma-prod.yml`
- Trigger: Manual only (from release tags)
- Namespace: `prod`
- Values: `values-prod.yaml`

### Environment Differences

Each environment can customize:
- Replica count
- Resource limits/requests
- Image tag (latest, specific version, or production tag)
- Environment-specific configuration

**Example values-prod.yaml:**
```yaml
replicaCount: 3  # Higher availability

image:
  tag: "1.0.0"  # Specific version, not latest

resources:
  limits:
    cpu: 1000m
    memory: 1Gi
  requests:
    cpu: 500m
    memory: 512Mi
```

## Implementation Checklist

### In hello-world-service repo:
- [ ] Create Helm chart structure in `helm/hello-world-service/`
- [ ] Write `Chart.yaml`, `values.yaml`, and environment values files
- [ ] Create Helm templates (deployment, service)
- [ ] Create `.github/workflows/deploy-kyma-dev.yml`
- [ ] Create `.github/workflows/deploy-kyma-qa.yml`
- [ ] Create `.github/workflows/deploy-kyma-prod.yml`
- [ ] Test Helm chart locally with `helm lint` and dry-run

### In gh-action-template repo:
- [ ] Create `.github/workflows/deploy-kyma-dev.yml` reusable workflow
- [ ] Implement Vault kubeconfig retrieval
- [ ] Implement kubectl and Helm setup
- [ ] Implement namespace and secret creation
- [ ] Implement Helm deployment step
- [ ] Add error handling and logging
- [ ] Document usage in repo README

### Vault Setup:
- [ ] Download kubeconfig from Kyma
- [ ] Base64 encode kubeconfig
- [ ] Store in Vault at: `piper/data/sap-project-gtlcinfra-poc-1/hello-world-service/kyma`
- [ ] Verify docker-config secret exists in Vault
- [ ] Test Vault access with pipeline credentials

### Testing:
- [ ] Lint Helm chart locally
- [ ] Dry-run Helm installation
- [ ] Trigger first deployment to dev
- [ ] Verify pod status and logs
- [ ] Test application endpoints
- [ ] Verify subsequent deployments work
- [ ] Test rollback scenario

## Future Enhancements

**Not included in initial implementation:**
- External ingress/routing (add when needed)
- Horizontal Pod Autoscaling (HPA)
- Pod Disruption Budgets (PDB)
- Network policies for pod-to-pod communication
- Persistent volumes (if needed for stateful features)
- Monitoring and alerting integration
- Blue-green or canary deployments

## References

- Kyma Cluster: https://api.c-1282d6a.stage.kyma.ondemand.com/
- Kubeconfig URL: https://kyma-env-broker.cp.stage.kyma.cloud.sap/kubeconfig/ED9D876C-A50E-471A-B3C6-E9E3D1BA7A8E
- Docker Registry: https://gtlc-docker.common.repositories.cloud.sap
- Vault Base Path: piper/data/sap-project-gtlcinfra-poc-1/hello-world-service
- Helm Documentation: https://helm.sh/docs/
- Kubernetes Documentation: https://kubernetes.io/docs/
