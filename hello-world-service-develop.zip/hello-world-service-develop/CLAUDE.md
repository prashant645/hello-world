# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

Secure Hello World Greeting REST API built with Spring Boot 3.5.16 and Java 21. This is a demonstration service showcasing security best practices including input sanitization, rate limiting, and secure API design.

## Build & Development Commands

### Build System
- **Build tool**: Gradle 8.10+ with Groovy DSL
- **Java version**: 21 (managed via Java toolchain)
- **Always use Gradle wrapper** (`./gradlew`) rather than local Gradle installation

### Essential Commands
```bash
# Clean build
./gradlew clean build

# Run application locally
./gradlew bootRun
# Or: java -jar build/libs/hello-world-service-1.0.0.jar

# Run all tests
./gradlew test

# Run single test class
./gradlew test --tests com.sap.gtlc.security.controller.GreetingControllerTest

# Run specific test method
./gradlew test --tests "com.sap.gtlc.security.controller.GreetingControllerTest.testSpecificMethod"

# Build executable Spring Boot JAR
./gradlew bootJar

# List all available tasks
./gradlew tasks
```

### Local Development
- Application runs on **port 8080**
- OpenAPI/Swagger UI: http://localhost:8080/swagger-ui.html
- OpenAPI JSON: http://localhost:8080/api-docs
- Health endpoint: http://localhost:8080/actuator/health

## Architecture

### Package Structure
```
com.sap.gtlc.security/
├── controller/       # REST API controllers
├── service/          # Business logic layer
├── model/            # DTOs and domain models
├── security/         # Security components (rate limiting, input sanitization)
├── validation/       # Custom validation logic
└── exception/        # Exception handlers and custom exceptions
```

### Security Features

This service implements multiple layers of security:

1. **Rate Limiting** (`RateLimitingFilter`)
   - Per-IP rate limiting using Guava's RateLimiter
   - Default: 10 requests per minute per IP
   - Can be disabled via `rate-limiting.enabled=false` property
   - Uses X-Forwarded-For header for proxy environments

2. **Input Sanitization** (`InputSanitizer`)
   - Removes control characters
   - Blocks shell metacharacters (`;`, `&`, `|`, `` ` ``, `$`, `(`, `)`, `<`, `>`, `\`)
   - Throws `SecurityValidationException` if dangerous characters detected
   - All user input should pass through sanitization

3. **Request Size Limits**
   - Max HTTP POST size: 1KB (configured in application.yml)
   - Connection timeout: 20s

### Exception Handling

Custom exception hierarchy with global exception handler:
- `ValidationException` - for business validation errors
- `SecurityValidationException` - for security-related validation failures
- `GlobalExceptionHandler` - returns RFC 7807 Problem Details responses

All errors follow the Problem Details standard with structured JSON responses.

## Deployment

### SAP BTP Cloud Foundry Deployment

**Deployment Target:**
- Environment: Canary (eu01-canary)
- Global Account: GTLC-test-canary
- Organization: GTLC-test_hello-qyodsuvs
- Space: dev
- URL: https://hello-world-service-dev.cfapps.eu01-canary.hana.ondemand.com

**CI/CD Pipeline:**
- Uses SAP Project "Piper" pipeline (.pipeline/config.yml)
- Vault configuration: `piper/sap-project-gtlcinfra-poc`
- Native build with Gradle (sapmachine:21-jdk Docker image)
- Stages: Build → Acceptance → Performance → Security → Compliance → Release → Post
- Cloud Foundry deployment uses manifest.yml
- Health check endpoint: /actuator/health

### Important Build Details

1. **JAR Generation**
   - Only the executable Spring Boot JAR is built (the plain JAR is disabled)
   - Path pattern: `build/libs/hello-world-service-*.jar`
   - Cloud Foundry manifest expects this pattern

2. **Version Management**
   - Version is read from `VERSION` file in repository root
   - Current version format: semantic versioning (e.g., 1.0.0)

3. **Pipeline Stages**
   - `gradleExecuteBuild: true` runs in Build stage to ensure JAR exists
   - Release stage includes CF deployment and Cumulus upload
   - sapDownloadArtifact disabled in early stages, enabled only in Release

## Configuration

### Application Properties
- Main config: `src/main/resources/application.yml`
- Spring profile for CF: `cloud` (set via SPRING_PROFILES_ACTIVE in manifest)
- Key configurations:
  - Server port: 8080
  - Graceful shutdown with 30s timeout
  - Actuator endpoints: health, info, metrics
  - Logging level: DEBUG for application code, INFO for root

### Environment-Specific Configuration
- Use Spring profiles for environment-specific config
- Cloud Foundry variables interpolated via manifest.yml (`${LANDSCAPE}`, `${CF_DOMAIN}`)

## Testing Strategy

- Unit tests for all layers (controller, service, validation, security)
- Integration tests for API endpoints
- Security-focused test cases for input sanitization and rate limiting
- Test naming convention: `[ClassName]Test.java`