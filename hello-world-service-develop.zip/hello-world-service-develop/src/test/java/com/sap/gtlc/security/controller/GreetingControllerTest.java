package com.sap.gtlc.security.controller;

import com.sap.gtlc.security.config.TestSecurityConfig;
import com.sap.gtlc.security.exception.SecurityValidationException;
import com.sap.gtlc.security.exception.ValidationException;
import com.sap.gtlc.security.model.GreetingRequest;
import com.sap.gtlc.security.model.GreetingResponse;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
@Import(TestSecurityConfig.class)
@WithMockUser(authorities = {"Read"})
class GreetingControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Test
    void shouldReturnGreetingForValidMessage() throws Exception {
        // Act & Assert
        mockMvc.perform(post("/api/v1/greetings")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"message\":\"Hello World\"}"))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON))
            .andExpect(jsonPath("$.greeting").value("Hello, we received your message: Hello World."));
    }

    @Test
    void shouldReturn400ForValidationException() throws Exception {
        // Arrange - send a message with 11 words (exceeds max 10) but under 50 chars
        // Act & Assert
        mockMvc.perform(post("/api/v1/greetings")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"message\":\"a b c d e f g h i j k\"}"))
            .andExpect(status().isBadRequest())
            .andExpect(content().contentType(MediaType.APPLICATION_PROBLEM_JSON))
            .andExpect(jsonPath("$.type").value("https://api.sap.com/problems/validation-error"))
            .andExpect(jsonPath("$.status").value(400))
            .andExpect(jsonPath("$.title").value("Validation Error"))
            .andExpect(jsonPath("$.detail").value("Word count is 11, maximum allowed is 10"));
    }

    @Test
    void shouldReturn400ForSecurityValidationException() throws Exception {
        // Act & Assert
        mockMvc.perform(post("/api/v1/greetings")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"message\":\"hello; rm -rf /\"}"))
            .andExpect(status().isBadRequest())
            .andExpect(content().contentType(MediaType.APPLICATION_PROBLEM_JSON))
            .andExpect(jsonPath("$.type").value("https://api.sap.com/problems/security-error"))
            .andExpect(jsonPath("$.status").value(400))
            .andExpect(jsonPath("$.title").value("Security Validation Error"))
            .andExpect(jsonPath("$.detail").value("Message contains potentially dangerous characters"));
    }

    @Test
    void shouldReturn400ForEmptyMessage() throws Exception {
        mockMvc.perform(post("/api/v1/greetings")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"message\":\"\"}"))
            .andExpect(status().isBadRequest())
            .andExpect(content().contentType(MediaType.APPLICATION_PROBLEM_JSON))
            .andExpect(jsonPath("$.type").value("https://api.sap.com/problems/validation-error"));
    }

    @Test
    void shouldReturn400ForMissingMessage() throws Exception {
        mockMvc.perform(post("/api/v1/greetings")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{}"))
            .andExpect(status().isBadRequest())
            .andExpect(content().contentType(MediaType.APPLICATION_PROBLEM_JSON));
    }

    @Test
    void shouldReturn415ForInvalidContentType() throws Exception {
        mockMvc.perform(post("/api/v1/greetings")
                .contentType(MediaType.TEXT_PLAIN)
                .content("Hello World"))
            .andExpect(status().isUnsupportedMediaType());
    }

    @Test
    void shouldReturn400ForInvalidJson() throws Exception {
        mockMvc.perform(post("/api/v1/greetings")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{invalid json"))
            .andExpect(status().isBadRequest());
    }

    @Test
    void shouldReturn400ForMessageTooLong() throws Exception {
        // 51 chars, 10 words
        mockMvc.perform(post("/api/v1/greetings")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"message\":\"one two three four five six seven eight nine tenths\"}"))
            .andExpect(status().isBadRequest())
            .andExpect(content().contentType(MediaType.APPLICATION_PROBLEM_JSON))
            .andExpect(jsonPath("$.detail").value("Character count is 51, maximum allowed is 50"));
    }

    @Test
    void shouldAcceptMessageWithMaxLength() throws Exception {
        // Arrange - 50 characters, 10 words
        String maxLengthMessage = "one two three four five six seven eight nine tenth";

        // Act & Assert
        mockMvc.perform(post("/api/v1/greetings")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"message\":\"" + maxLengthMessage + "\"}"))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON));
    }

    @Test
    void shouldAcceptMessageWithPunctuation() throws Exception {
        // Act & Assert
        mockMvc.perform(post("/api/v1/greetings")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"message\":\"Hello, world! How are you?\"}"))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON))
            .andExpect(jsonPath("$.greeting").value("Hello, we received your message: Hello, world! How are you?."));
    }
}
