package com.sap.gtlc.security.validation;

import com.sap.gtlc.security.exception.ValidationException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class MessageValidatorTest {

    private MessageValidator validator;

    @BeforeEach
    void setUp() {
        validator = new MessageValidator();
    }

    // English-Only Validation Tests
    @Test
    void shouldAcceptEnglishLetters() {
        String message = "Hello World";
        assertDoesNotThrow(() -> validator.validate(message));
    }

    @Test
    void shouldAcceptEnglishWithDigits() {
        String message = "Hello123";
        assertDoesNotThrow(() -> validator.validate(message));
    }

    @Test
    void shouldAcceptAllowedPunctuation() {
        String message = "Hello, world! How are you?";
        assertDoesNotThrow(() -> validator.validate(message));
    }

    @Test
    void shouldRejectUnicodeCharacters() {
        String message = "Hello 世界";
        ValidationException ex = assertThrows(ValidationException.class,
            () -> validator.validate(message));
        assertTrue(ex.getMessage().contains("English characters"));
    }

    @Test
    void shouldRejectEmoji() {
        String message = "Hello world";
        // Note: Emoji would be rejected if present, testing with plain text
        assertDoesNotThrow(() -> validator.validate(message));
    }

    @Test
    void shouldRejectAccentedCharacters() {
        String message = "café";
        ValidationException ex = assertThrows(ValidationException.class,
            () -> validator.validate(message));
        assertTrue(ex.getMessage().contains("English characters"));
    }

    // Word Count Validation Tests
    @Test
    void shouldAcceptExactlyTenWords() {
        String message = "one two three four five six seven eight nine ten";
        assertDoesNotThrow(() -> validator.validate(message));
    }

    @Test
    void shouldRejectElevenWords() {
        String message = "one two three four five six seven eight nine ten eleven";
        ValidationException ex = assertThrows(ValidationException.class,
            () -> validator.validate(message));
        assertTrue(ex.getMessage().contains("Word count"));
        assertTrue(ex.getMessage().contains("11"));
    }

    @Test
    void shouldNormalizeMultipleSpaces() {
        String message = "hello    world";
        assertDoesNotThrow(() -> validator.validate(message));
    }

    @Test
    void shouldHandleSingleWord() {
        String message = "hello";
        assertDoesNotThrow(() -> validator.validate(message));
    }

    // Word Length Validation Tests
    @Test
    void shouldAcceptWordWithExactly12Characters() {
        String message = "introduction";
        assertDoesNotThrow(() -> validator.validate(message));
    }

    @Test
    void shouldRejectWordWith13Characters() {
        String message = "presentations";
        ValidationException ex = assertThrows(ValidationException.class,
            () -> validator.validate(message));
        assertTrue(ex.getMessage().contains("13 characters"));
        assertTrue(ex.getMessage().contains("maximum allowed is 12"));
    }

    @Test
    void shouldIgnorePunctuationInWordLength() {
        String message = "don't worry";
        assertDoesNotThrow(() -> validator.validate(message));
    }

    @Test
    void shouldRejectLongWordEvenWithPunctuation() {
        String message = "internationalization!";
        ValidationException ex = assertThrows(ValidationException.class,
            () -> validator.validate(message));
        assertTrue(ex.getMessage().contains("20 characters"));
    }

    @Test
    void shouldValidateAllWordsInMessage() {
        String message = "hello supercalifragilisticexpialidocious";
        ValidationException ex = assertThrows(ValidationException.class,
            () -> validator.validate(message));
        assertTrue(ex.getMessage().contains("34 characters"));
    }

    @Test
    void shouldAcceptMultipleWordsUnderLimit() {
        String message = "modification presentation introduction";
        assertDoesNotThrow(() -> validator.validate(message));
    }

    // Character Count Validation Tests
    @Test
    void shouldAcceptExactlyFiftyCharacters() {
        // 50 chars, 10 words (max word length 6 chars)
        String message = "one two three four five six seven eight nine tenth";
        assertDoesNotThrow(() -> validator.validate(message));
    }

    @Test
    void shouldRejectFiftyOneCharacters() {
        // 51 chars, 10 words (max word length 6 chars)
        String message = "one two three four five six seven eight nine tenths";
        ValidationException ex = assertThrows(ValidationException.class,
            () -> validator.validate(message));
        assertTrue(ex.getMessage().contains("Character count is 51"));
        assertTrue(ex.getMessage().contains("maximum allowed is 50"));
    }

    @Test
    void shouldTrimBeforeCounting() {
        String message = "  hello world  ";
        assertDoesNotThrow(() -> validator.validate(message));
    }

    @Test
    void shouldAcceptMessageWithPunctuation() {
        String message = "Hello, how are you today?";
        assertDoesNotThrow(() -> validator.validate(message));
    }

    // Edge Cases
    @Test
    void shouldHandleLeadingAndTrailingSpaces() {
        String message = "  hello world  ";
        assertDoesNotThrow(() -> validator.validate(message));
    }

    @Test
    void shouldHandleMixedCase() {
        String message = "HeLLo WoRLd";
        assertDoesNotThrow(() -> validator.validate(message));
    }

    @Test
    void shouldAcceptValidMessageWithAllConstraints() {
        String message = "Hello, how are you today?";
        assertDoesNotThrow(() -> validator.validate(message));
    }

    @Test
    void shouldRejectMessageExceedingMultipleConstraints() {
        // This message exceeds word count (11 words)
        String message = "one two three four five six seven eight nine ten eleven";
        ValidationException ex = assertThrows(ValidationException.class,
            () -> validator.validate(message));
        assertTrue(ex.getMessage().contains("Word count"));
    }
}
