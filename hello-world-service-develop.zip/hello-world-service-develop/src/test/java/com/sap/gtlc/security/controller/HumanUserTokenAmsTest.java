package com.sap.gtlc.security.controller;

import com.sap.gtlc.security.config.IasTestSecurityConfig;
import com.sap.gtlc.security.service.AmsAuthorizationService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.jwt;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * Tests for the human-user vs M2M token classification boundary in GreetingController.
 *
 * <p>The security invariant under test: when the token carries a {@code user_uuid} claim
 * (human user, arriving via PKCE or on-behalf-of exchange), AMS is the sole authorizer
 * and is always enforced — the token's {@code ias_apis} value is ignored. When no
 * {@code user_uuid} is present (M2M client_credentials token), {@code @PreAuthorize}
 * on {@code ias_apis} is sufficient and AMS is never consulted.
 *
 * <p><b>MCP privilege-elevation scenario</b>: an MCP server performs an RFC 8693
 * token exchange on behalf of a user. IAS applies the MCP server's dependency
 * permission ({@code ias_apis=[writers]}) to the exchanged token regardless of
 * whether it is M2M or a user exchange. Without the {@code user_uuid} check a
 * user with only a {@code readers} AMS policy could perform write operations by
 * tunnelling through the MCP server. These tests verify that scenario is blocked.
 */
@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
@Import(IasTestSecurityConfig.class)
class HumanUserTokenAmsTest {

    private static final String GREETING_BODY = "{\"message\":\"Hello\"}";
    private static final String UPDATE_BODY =
            "{\"rateLimit\":{\"requestsPerMinute\":20,\"enabled\":true}," +
            "\"validation\":{\"maxWords\":10,\"maxCharacters\":50}}";

    @Autowired
    private MockMvc mockMvc;

    /** Replaces the IasTestSecurityConfig stub so individual tests can configure behaviour. */
    @MockitoBean
    private AmsAuthorizationService amsAuthorizationService;

    // ── updateConfiguration (write) ───────────────────────────────────────────

    @Test
    void humanUser_amsGrantsWrite_returns200() throws Exception {
        when(amsAuthorizationService.isAmsAvailable()).thenReturn(true);
        when(amsAuthorizationService.hasPrivilege(any(), eq("write"), any(), any())).thenReturn(true);

        mockMvc.perform(post("/api/v1/greetings/update")
                .with(jwt()
                        .jwt(j -> j.subject("P000000")
                                   .claim("user_uuid", "9ae37bbf-fb04-46ed-a833-79c6b88ee45e"))
                        .authorities(new SimpleGrantedAuthority("writers")))
                .contentType(MediaType.APPLICATION_JSON)
                .content(UPDATE_BODY))
                .andExpect(status().isOk());
    }

    @Test
    void humanUser_amsDeniesWrite_returns403() throws Exception {
        when(amsAuthorizationService.isAmsAvailable()).thenReturn(true);
        when(amsAuthorizationService.hasPrivilege(any(), eq("write"), any(), any())).thenReturn(false);

        mockMvc.perform(post("/api/v1/greetings/update")
                .with(jwt()
                        .jwt(j -> j.subject("P000000")
                                   .claim("user_uuid", "9ae37bbf-fb04-46ed-a833-79c6b88ee45e"))
                        .authorities(new SimpleGrantedAuthority("writers")))
                .contentType(MediaType.APPLICATION_JSON)
                .content(UPDATE_BODY))
                .andExpect(status().isForbidden());
    }

    @Test
    void humanUser_amsUnavailable_write_returns403_failClosed() throws Exception {
        when(amsAuthorizationService.isAmsAvailable()).thenReturn(false);

        mockMvc.perform(post("/api/v1/greetings/update")
                .with(jwt()
                        .jwt(j -> j.subject("P000000")
                                   .claim("user_uuid", "9ae37bbf-fb04-46ed-a833-79c6b88ee45e"))
                        .authorities(new SimpleGrantedAuthority("writers")))
                .contentType(MediaType.APPLICATION_JSON)
                .content(UPDATE_BODY))
                .andExpect(status().isForbidden());

        verify(amsAuthorizationService, never()).hasPrivilege(any(), any(), any(), any());
    }

    /**
     * Core MCP privilege-elevation regression test.
     *
     * The token carries {@code ias_apis=[writers]} (inherited from the MCP server's
     * IAS dependency), but the user's own AMS policy only grants read access.
     * The backend must reject the write despite the elevated ias_apis value.
     *
     * <p>The user IS bound to an AMS policy (readers), so {@code detectPolicyBinding}
     * returns {@code BOUND}. AMS then denies the write, and the ias_apis fallback
     * must NOT be reached — the user's explicit AMS policy is the sole authority.</p>
     */
    @Test
    void humanUser_readersOnlyPolicy_writersToken_returns403() throws Exception {
        when(amsAuthorizationService.isAmsAvailable()).thenReturn(true);
        // User has a readers AMS policy — read is granted, write is not.
        when(amsAuthorizationService.hasPrivilege(any(), eq("read"),  any(), any())).thenReturn(true);
        when(amsAuthorizationService.hasPrivilege(any(), eq("write"), any(), any())).thenReturn(false);
        // detectPolicyBinding is called to determine whether the user has any AMS policy.
        // BOUND = enrolled; AMS is the sole authority → write denial must not fall through to ias_apis.
        when(amsAuthorizationService.detectPolicyBinding(any(), any(), any())).thenReturn(AmsAuthorizationService.PolicyBinding.BOUND);

        mockMvc.perform(post("/api/v1/greetings/update")
                .with(jwt()
                        .jwt(j -> j.subject("P000000")
                                   .claim("user_uuid", "9ae37bbf-fb04-46ed-a833-79c6b88ee45e")
                                   .claim("ias_apis", List.of("writers")))  // MCP has writers, but user's AMS policy wins
                        .authorities(new SimpleGrantedAuthority("writers")))
                .contentType(MediaType.APPLICATION_JSON)
                .content(UPDATE_BODY))
                .andExpect(status().isForbidden());
    }

    // ── OBO fallback: user has no AMS policy — inherit MCP ias_apis ───────────

    /**
     * OBO user with NO AMS policy, MCP server has {@code ias_apis=[writers]}.
     *
     * <p>Since the user is not bound to any AMS policy, the MCP server's permission
     * is inherited. {@code writers} qualifies for write access → 200.</p>
     */
    @Test
    void oboUser_noAmsPolicy_mcpHasWriters_write_returns200() throws Exception {
        when(amsAuthorizationService.isAmsAvailable()).thenReturn(true);
        when(amsAuthorizationService.hasPrivilege(any(), eq("write"), any(), any())).thenReturn(false);
        when(amsAuthorizationService.detectPolicyBinding(any(), any(), any())).thenReturn(AmsAuthorizationService.PolicyBinding.UNBOUND);  // no AMS policy

        mockMvc.perform(post("/api/v1/greetings/update")
                .with(jwt()
                        .jwt(j -> j.subject("P000000")
                                   .claim("user_uuid", "9ae37bbf-fb04-46ed-a833-79c6b88ee45e")
                                   .claim("ias_apis", List.of("writers")))
                        .authorities(new SimpleGrantedAuthority("writers")))
                .contentType(MediaType.APPLICATION_JSON)
                .content(UPDATE_BODY))
                .andExpect(status().isOk());
    }

    /**
     * OBO user with NO AMS policy, MCP server has {@code ias_apis=[writers]}.
     *
     * <p>{@code writers} also qualifies for read → 200 on the read endpoint.</p>
     */
    @Test
    void oboUser_noAmsPolicy_mcpHasWriters_read_returns200() throws Exception {
        when(amsAuthorizationService.isAmsAvailable()).thenReturn(true);
        when(amsAuthorizationService.hasPrivilege(any(), eq("read"), any(), any())).thenReturn(false);
        when(amsAuthorizationService.detectPolicyBinding(any(), any(), any())).thenReturn(AmsAuthorizationService.PolicyBinding.UNBOUND);  // no AMS policy

        mockMvc.perform(post("/api/v1/greetings")
                .with(jwt()
                        .jwt(j -> j.claim("user_uuid", "9ae37bbf-fb04-46ed-a833-79c6b88ee45e")
                                   .claim("ias_apis", List.of("writers")))
                        .authorities(new SimpleGrantedAuthority("writers")))
                .contentType(MediaType.APPLICATION_JSON)
                .content(GREETING_BODY))
                .andExpect(status().isOk());
    }

    /**
     * OBO user with NO AMS policy and MCP server has NO {@code ias_apis} claim.
     *
     * <p>The token carries {@code principal-propagation} authority (the IAS
     * "Allow all APIs for principal propagation" path) to pass {@code @PreAuthorize},
     * but the JWT itself has no {@code ias_apis} claim. The controller must deny
     * because there is neither an AMS policy nor an MCP-inherited permission.</p>
     */
    @Test
    void oboUser_noAmsPolicy_noIasApis_returns403() throws Exception {
        when(amsAuthorizationService.isAmsAvailable()).thenReturn(true);
        when(amsAuthorizationService.hasPrivilege(any(), any(), any(), any())).thenReturn(false);
        when(amsAuthorizationService.detectPolicyBinding(any(), any(), any())).thenReturn(AmsAuthorizationService.PolicyBinding.UNBOUND);  // no AMS policy

        // principal-propagation authority lets the request past @PreAuthorize so our
        // controller logic is reached; no ias_apis claim in the JWT means no fallback.
        mockMvc.perform(post("/api/v1/greetings")
                .with(jwt()
                        .jwt(j -> j.claim("user_uuid", "9ae37bbf-fb04-46ed-a833-79c6b88ee45e"))
                        // deliberately no ias_apis claim
                        .authorities(new SimpleGrantedAuthority("principal-propagation")))
                .contentType(MediaType.APPLICATION_JSON)
                .content(GREETING_BODY))
                .andExpect(status().isForbidden());
    }

    /**
     * OBO user IS bound to an AMS policy (readers) and AMS grants read.
     * The MCP server's ias_apis must be completely ignored — AMS is the sole authority.
     */
    @Test
    void oboUser_hasAmsPolicy_amsGrantsRead_returns200() throws Exception {
        when(amsAuthorizationService.isAmsAvailable()).thenReturn(true);
        when(amsAuthorizationService.hasPrivilege(any(), eq("read"), any(), any())).thenReturn(true);
        // detectPolicyBinding is NOT called when hasPrivilege succeeds on step 2

        mockMvc.perform(post("/api/v1/greetings")
                .with(jwt()
                        .jwt(j -> j.claim("user_uuid", "9ae37bbf-fb04-46ed-a833-79c6b88ee45e")
                                   .claim("ias_apis", List.of("writers")))  // MCP has writers, user has readers policy
                        .authorities(new SimpleGrantedAuthority("writers")))
                .contentType(MediaType.APPLICATION_JSON)
                .content(GREETING_BODY))
                .andExpect(status().isOk());
    }

    @Test
    void m2mToken_writersAuthority_returns200_amsNeverCalled() throws Exception {
        mockMvc.perform(post("/api/v1/greetings/update")
                // No user_uuid claim — M2M client_credentials token
                .with(jwt().authorities(new SimpleGrantedAuthority("writers")))
                .contentType(MediaType.APPLICATION_JSON)
                .content(UPDATE_BODY))
                .andExpect(status().isOk());

        verify(amsAuthorizationService, never()).isAmsAvailable();
        verify(amsAuthorizationService, never()).hasPrivilege(any(), any(), any(), any());
    }

    // ── greetings (read) ──────────────────────────────────────────────────────

    @Test
    void humanUser_amsGrantsRead_greetings_returns200() throws Exception {
        when(amsAuthorizationService.isAmsAvailable()).thenReturn(true);
        when(amsAuthorizationService.hasPrivilege(any(), eq("read"), any(), any())).thenReturn(true);

        mockMvc.perform(post("/api/v1/greetings")
                .with(jwt()
                        .jwt(j -> j.claim("user_uuid", "9ae37bbf-fb04-46ed-a833-79c6b88ee45e"))
                        .authorities(new SimpleGrantedAuthority("readers")))
                .contentType(MediaType.APPLICATION_JSON)
                .content(GREETING_BODY))
                .andExpect(status().isOk());
    }

    @Test
    void humanUser_amsUnavailable_greetings_returns403_failClosed() throws Exception {
        when(amsAuthorizationService.isAmsAvailable()).thenReturn(false);

        mockMvc.perform(post("/api/v1/greetings")
                .with(jwt()
                        .jwt(j -> j.claim("user_uuid", "9ae37bbf-fb04-46ed-a833-79c6b88ee45e"))
                        .authorities(new SimpleGrantedAuthority("readers")))
                .contentType(MediaType.APPLICATION_JSON)
                .content(GREETING_BODY))
                .andExpect(status().isForbidden());
    }

    @Test
    void m2mToken_readersAuthority_greetings_returns200_amsNeverCalled() throws Exception {
        mockMvc.perform(post("/api/v1/greetings")
                .with(jwt().authorities(new SimpleGrantedAuthority("readers")))
                .contentType(MediaType.APPLICATION_JSON)
                .content(GREETING_BODY))
                .andExpect(status().isOk());

        verify(amsAuthorizationService, never()).isAmsAvailable();
    }

    // ── getCurrentConfiguration (read config) ─────────────────────────────────

    @Test
    void humanUser_amsGrantsRead_config_returns200() throws Exception {
        when(amsAuthorizationService.isAmsAvailable()).thenReturn(true);
        when(amsAuthorizationService.hasPrivilege(any(), eq("read"), any(), any())).thenReturn(true);

        mockMvc.perform(get("/api/v1/greetings/config")
                .with(jwt()
                        .jwt(j -> j.claim("user_uuid", "9ae37bbf-fb04-46ed-a833-79c6b88ee45e"))
                        .authorities(new SimpleGrantedAuthority("readers"))))
                .andExpect(status().isOk());
    }

    @Test
    void humanUser_amsUnavailable_config_returns403_failClosed() throws Exception {
        when(amsAuthorizationService.isAmsAvailable()).thenReturn(false);

        mockMvc.perform(get("/api/v1/greetings/config")
                .with(jwt()
                        .jwt(j -> j.claim("user_uuid", "9ae37bbf-fb04-46ed-a833-79c6b88ee45e"))
                        .authorities(new SimpleGrantedAuthority("readers"))))
                .andExpect(status().isForbidden());
    }

    @Test
    void m2mToken_readersAuthority_config_returns200_amsNeverCalled() throws Exception {
        mockMvc.perform(get("/api/v1/greetings/config")
                .with(jwt().authorities(new SimpleGrantedAuthority("readers"))))
                .andExpect(status().isOk());

        verify(amsAuthorizationService, never()).isAmsAvailable();
    }
}
