package com.sap.gtlc.security.security;
import org.junit.jupiter.api.Test;
import org.springframework.security.oauth2.jwt.Jwt;
import java.util.List;
import java.util.Set;
import static org.assertj.core.api.Assertions.assertThat;
class SecurityConfigAuthorityMappingTest {
    @Test
    void shouldExtractReadersAndWritersFromSuffixedScopeValues() {
        Jwt jwt = Jwt.withTokenValue("t")
                .header("alg", "none")
                .claim("scope", List.of("hello-world-service-dev.Read", "hello-world-service-dev.Write"))
                .build();
        Set<String> authorities = SecurityConfig.extractShortAuthorities(jwt);
        assertThat(authorities).containsExactlyInAnyOrder("readers", "writers");
    }
    @Test
    void shouldExtractReadersAndWritersFromStringScopeClaim() {
        Jwt jwt = Jwt.withTokenValue("t")
                .header("alg", "none")
                .claim("scope", "hello-world-service-dev.Read hello-world-service-dev.Write")
                .build();
        Set<String> authorities = SecurityConfig.extractShortAuthorities(jwt);
        assertThat(authorities).containsExactlyInAnyOrder("readers", "writers");
    }
    @Test
    void shouldExtractReadersAndWritersFromJsonArrayStringScope() {
        Jwt jwt = Jwt.withTokenValue("t")
                .header("alg", "none")
                .claim("scope", "['Read', 'Write']")
                .build();
        Set<String> authorities = SecurityConfig.extractShortAuthorities(jwt);
        assertThat(authorities).containsExactlyInAnyOrder("readers", "writers");
    }
    @Test
    void shouldExtractReadersFromJsonArrayStringScope() {
        Jwt jwt = Jwt.withTokenValue("t")
                .header("alg", "none")
                .claim("scope", "['Read']")
                .build();
        Set<String> authorities = SecurityConfig.extractShortAuthorities(jwt);
        assertThat(authorities).containsExactly("readers");
    }
    @Test
    void shouldExtractReadersFromIasApisClaimArray() {
        Jwt jwt = Jwt.withTokenValue("t")
                .header("alg", "none")
                .claim("ias_apis", List.of("readers"))
                .build();
        Set<String> authorities = SecurityConfig.extractShortAuthorities(jwt);
        assertThat(authorities).containsExactly("readers");
    }
    @Test
    void shouldExtractWritersFromScpClaim() {
        Jwt jwt = Jwt.withTokenValue("t")
                .header("alg", "none")
                .claim("scp", List.of("hello-world-service-dev.Write"))
                .build();
        Set<String> authorities = SecurityConfig.extractShortAuthorities(jwt);
        assertThat(authorities).containsExactly("writers");
    }
    @Test
    void shouldIgnoreUnsupportedSuffixes() {
        Jwt jwt = Jwt.withTokenValue("t")
                .header("alg", "none")
                .claim("scope", List.of("uaa.resource", "foo.bar.Editor"))
                .claim("authorities", List.of("foo.baz.Viewer"))
                .build();
        Set<String> authorities = SecurityConfig.extractShortAuthorities(jwt);
        assertThat(authorities).isEmpty();
    }
    @Test
    void shouldGrantReadersFromConfiguredAzpClientId() {
        Jwt jwt = Jwt.withTokenValue("t")
                .header("alg", "none")
                .claim("azp", "read-client-id")
                .build();
        Set<String> authorities = SecurityConfig.extractConfiguredClientAuthorities(
                jwt,
                Set.of("read-client-id"),
                Set.of("write-client-id"));
        assertThat(authorities).containsExactly("readers");
    }
    @Test
    void shouldGrantWritersFromConfiguredClientIdClaim() {
        Jwt jwt = Jwt.withTokenValue("t")
                .header("alg", "none")
                .claim("client_id", "write-client-id")
                .build();
        Set<String> authorities = SecurityConfig.extractConfiguredClientAuthorities(
                jwt,
                Set.of("read-client-id"),
                Set.of("write-client-id"));
        assertThat(authorities).containsExactly("writers");
    }
    @Test
    void shouldNotGrantAuthoritiesFromAudienceClaim() {
        Jwt jwt = Jwt.withTokenValue("t")
                .header("alg", "none")
                .claim("aud", List.of("shared-client-id"))
                .build();
        Set<String> authorities = SecurityConfig.extractConfiguredClientAuthorities(
                jwt,
                Set.of("shared-client-id"),
                Set.of("shared-client-id"));
        assertThat(authorities).isEmpty();
    }
    @Test
    void shouldNotGrantAuthoritiesFromSubjectClaim() {
        Jwt jwt = Jwt.withTokenValue("t")
                .header("alg", "none")
                .claim("sub", "shared-client-id")
                .build();
        Set<String> authorities = SecurityConfig.extractConfiguredClientAuthorities(
                jwt,
                Set.of("shared-client-id"),
                Set.of("shared-client-id"));
        assertThat(authorities).isEmpty();
    }
}
