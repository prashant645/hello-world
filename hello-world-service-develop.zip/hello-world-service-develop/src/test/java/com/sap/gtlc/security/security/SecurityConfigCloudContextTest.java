package com.sap.gtlc.security.security;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.ApplicationContext;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.security.oauth2.jwt.NimbusJwtDecoder;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.TestPropertySource;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Verifies that SecurityConfig's explicit JwtDecoder bean is registered when
 * the cloud profile is active, and that no competing auto-configured decoder
 * is present. This guards against the ordering race between Spring Boot's
 * issuer-uri auto-configuration and SAP's @ConditionalOnMissingBean decoder.
 */
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.NONE)
@ActiveProfiles("cloud")
@TestPropertySource(properties = {
        "IAS_ISSUER_URI=https://a3enmtmdf.accounts400.ondemand.com",
        "IAS_CLIENT_ID=c76f51d5-8c27-4590-a972-070921dbff8c",
        "greeting-service.security.enabled=true",
        // Disable AMS auto-configuration in this context test — no IAS binding is mounted.
        // The AmsAutoConfiguration requires a live AuthorizationManagementService bean which
        // needs a real service binding. We only want to verify decoder bean wiring here.
        "spring.autoconfigure.exclude=" +
                "com.sap.cloud.security.ams.spring.autoconfigure.AmsAutoConfiguration," +
                "com.sap.cloud.security.ams.spring.autoconfigure.AmsMethodSecurityAutoConfiguration," +
                "com.sap.cloud.security.ams.spring.autoconfigure.AmsReadinessAutoConfiguration," +
                "com.sap.cloud.security.ams.spring.autoconfigure.AmsZtisConfiguration," +
                "com.sap.cloud.security.spring.autoconfig.HybridIdentityServicesAutoConfiguration," +
                "com.sap.cloud.security.spring.autoconfig.XsuaaTokenFlowAutoConfiguration"
})
class SecurityConfigCloudContextTest {

    @Autowired
    private ApplicationContext context;

    @Test
    @DisplayName("Exactly one JwtDecoder bean is present and it comes from SecurityConfig")
    void exactlyOneJwtDecoderFromSecurityConfig() {
        var decoders = context.getBeansOfType(JwtDecoder.class);
        assertThat(decoders)
                .as("Expected exactly one JwtDecoder bean — multiple decoders mean " +
                    "auto-configuration ordering is non-deterministic")
                .hasSize(1);
        assertThat(decoders.values().iterator().next())
                .isInstanceOf(NimbusJwtDecoder.class);
    }

    @Test
    @DisplayName("JwtDecoder bean is named 'jwtDecoder' (declared by SecurityConfig, not auto-configured)")
    void jwtDecoderBeanNamedBySecurityConfig() {
        assertThat(context.containsBean("jwtDecoder"))
                .as("SecurityConfig must declare @Bean public JwtDecoder jwtDecoder() " +
                    "so it wins deterministically over both Spring Boot and SAP auto-configurations")
                .isTrue();
    }
}
