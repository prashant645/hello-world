package com.sap.gtlc.security.service;

import com.sap.gtlc.security.exception.SecurityValidationException;
import com.sap.gtlc.security.exception.ValidationException;
import com.sap.gtlc.security.model.GreetingRequest;
import com.sap.gtlc.security.model.GreetingResponse;
import com.sap.gtlc.security.security.InputSanitizer;
import com.sap.gtlc.security.validation.MessageValidator;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class GreetingServiceImplTest {

    @Mock
    private MessageValidator messageValidator;

    @Mock
    private InputSanitizer inputSanitizer;

    @InjectMocks
    private GreetingServiceImpl greetingService;

    @BeforeEach
    void setUp() {
        // Default behavior: sanitizer returns input unchanged
        when(inputSanitizer.sanitize(anyString())).thenAnswer(invocation -> invocation.getArgument(0));
    }

    @Test
    void shouldCreateGreetingForValidMessage() {
        // Arrange
        GreetingRequest request = new GreetingRequest("Hello World");
        when(inputSanitizer.sanitize("Hello World")).thenReturn("Hello World");

        // Act
        GreetingResponse response = greetingService.createGreeting(request);

        // Assert
        assertNotNull(response);
        assertEquals("Hello, we received your message: Hello World.", response.greeting());
        verify(inputSanitizer).sanitize("Hello World");
        verify(messageValidator).validate("Hello World");
    }

    @Test
    void shouldSanitizeInputBeforeValidation() {
        // Arrange
        GreetingRequest request = new GreetingRequest("  hello  world  ");
        when(inputSanitizer.sanitize("  hello  world  ")).thenReturn("hello world");

        // Act
        GreetingResponse response = greetingService.createGreeting(request);

        // Assert
        assertEquals("Hello, we received your message: hello world.", response.greeting());
        verify(inputSanitizer).sanitize("  hello  world  ");
        verify(messageValidator).validate("hello world");
    }

    @Test
    void shouldThrowExceptionWhenSanitizerRejectsInput() {
        // Arrange
        GreetingRequest request = new GreetingRequest("hello; rm -rf /");
        when(inputSanitizer.sanitize("hello; rm -rf /"))
            .thenThrow(new SecurityValidationException("Message contains dangerous characters"));

        // Act & Assert
        assertThrows(SecurityValidationException.class,
            () -> greetingService.createGreeting(request));
        verify(inputSanitizer).sanitize("hello; rm -rf /");
        verify(messageValidator, never()).validate(anyString());
    }

    @Test
    void shouldThrowExceptionWhenValidatorRejectsInput() {
        // Arrange
        String message = "one two three four five six seven eight nine ten eleven";
        GreetingRequest request = new GreetingRequest(message);
        when(inputSanitizer.sanitize(message)).thenReturn(message);
        doThrow(new ValidationException("Word count exceeded"))
            .when(messageValidator).validate(message);

        // Act & Assert
        assertThrows(ValidationException.class,
            () -> greetingService.createGreeting(request));
        verify(inputSanitizer).sanitize(message);
        verify(messageValidator).validate(message);
    }

    @Test
    void shouldFormatGreetingCorrectly() {
        // Arrange
        GreetingRequest request = new GreetingRequest("test message");
        when(inputSanitizer.sanitize("test message")).thenReturn("test message");

        // Act
        GreetingResponse response = greetingService.createGreeting(request);

        // Assert
        assertTrue(response.greeting().startsWith("Hello, we received your message:"));
        assertTrue(response.greeting().contains("test message"));
        assertTrue(response.greeting().endsWith("."));
    }

    @Test
    void shouldHandleMessageWithPunctuation() {
        // Arrange
        GreetingRequest request = new GreetingRequest("Hello, world!");
        when(inputSanitizer.sanitize("Hello, world!")).thenReturn("Hello, world!");

        // Act
        GreetingResponse response = greetingService.createGreeting(request);

        // Assert
        assertEquals("Hello, we received your message: Hello, world!.", response.greeting());
    }

    @Test
    void shouldCallComponentsInCorrectOrder() {
        // Arrange
        GreetingRequest request = new GreetingRequest("test");
        when(inputSanitizer.sanitize("test")).thenReturn("test");

        // Act
        greetingService.createGreeting(request);

        // Assert - verify order of calls
        var inOrder = inOrder(inputSanitizer, messageValidator);
        inOrder.verify(inputSanitizer).sanitize("test");
        inOrder.verify(messageValidator).validate("test");
    }
}
