package com.sap.gtlc.security.security;

import com.sap.gtlc.security.config.IasTestSecurityConfig;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
@Import(IasTestSecurityConfig.class)
class IasSecurityTest {

    @Autowired
    private MockMvc mockMvc;

    @Test
    void shouldAllow401WhenNoAuthentication() throws Exception {
        mockMvc.perform(post("/api/v1/greetings")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"message\":\"Hello\"}"))
                .andExpect(status().isUnauthorized());
    }

    @Test
    @WithMockUser(authorities = {"readers"})
    void shouldAllowReadersGroupForGreetingsEndpoint() throws Exception {
        mockMvc.perform(post("/api/v1/greetings")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"message\":\"Hello\"}"))
                .andExpect(status().isOk());
    }

    @Test
    @WithMockUser(authorities = {"readers"})
    void shouldDenyReadersGroupForUpdateEndpoint() throws Exception {
        mockMvc.perform(post("/api/v1/greetings/update")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"rateLimit\":{\"requestsPerMinute\":20}}"))
                .andExpect(status().isForbidden());
    }

    @Test
    @WithMockUser(authorities = {"writers"})
    void shouldAllowWritersGroupForUpdateEndpoint() throws Exception {
        mockMvc.perform(post("/api/v1/greetings/update")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"rateLimit\":{\"requestsPerMinute\":20}}"))
                .andExpect(status().isOk());
    }

    @Test
    @WithMockUser(authorities = {"writers"})
    void shouldAllowWritersGroupForGreetingsEndpoint() throws Exception {
        mockMvc.perform(post("/api/v1/greetings")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"message\":\"Hello\"}"))
                .andExpect(status().isOk());
    }

    @Test
    void shouldDenyUpdateEndpointWithoutAuthentication() throws Exception {
        mockMvc.perform(post("/api/v1/greetings/update")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"rateLimit\":{\"requestsPerMinute\":20}}"))
                .andExpect(status().isUnauthorized());
    }

    @Test
    @WithMockUser(authorities = {"readers"})
    void shouldAllowReadersGroupForConfigEndpoint() throws Exception {
        mockMvc.perform(get("/api/v1/greetings/config"))
                .andExpect(status().isOk());
    }

    @Test
    @WithMockUser(authorities = {"admins"})
    void shouldAllowAdminsGroupForUpdateEndpoint() throws Exception {
        mockMvc.perform(post("/api/v1/greetings/update")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"rateLimit\":{\"requestsPerMinute\":20}}"))
                .andExpect(status().isOk());
    }

    @Test
    @WithMockUser(authorities = {"writers"})
    void shouldAllowWritersGroupForConfigEndpoint() throws Exception {
        mockMvc.perform(get("/api/v1/greetings/config"))
                .andExpect(status().isOk());
    }

    @Test
    void shouldDenyConfigEndpointWithoutAuthentication() throws Exception {
        mockMvc.perform(get("/api/v1/greetings/config"))
                .andExpect(status().isUnauthorized());
    }
}

