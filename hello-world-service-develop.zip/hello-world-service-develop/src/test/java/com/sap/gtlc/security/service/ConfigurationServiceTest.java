package com.sap.gtlc.security.service;

import com.sap.gtlc.security.config.GreetingServiceConfig;
import com.sap.gtlc.security.model.ConfigUpdateRequest;
import com.sap.gtlc.security.model.ConfigUpdateResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.assertj.core.api.Assertions.assertThat;

@ExtendWith(MockitoExtension.class)
class ConfigurationServiceTest {

    private ConfigurationService configurationService;
    private GreetingServiceConfig initialConfig;

    @BeforeEach
    void setUp() {
        initialConfig = new GreetingServiceConfig();
        initialConfig.getRateLimit().setRequestsPerMinute(10);
        initialConfig.getRateLimit().setEnabled(true);
        initialConfig.getValidation().setMaxWords(10);
        initialConfig.getValidation().setMaxCharacters(50);

        configurationService = new ConfigurationService(initialConfig);
    }

    @Test
    void shouldReturnCurrentConfiguration() {
        // Act
        GreetingServiceConfig result = configurationService.getCurrentConfig();

        // Assert
        assertThat(result.getRateLimit().getRequestsPerMinute()).isEqualTo(10);
        assertThat(result.getRateLimit().isEnabled()).isTrue();
        assertThat(result.getValidation().getMaxWords()).isEqualTo(10);
        assertThat(result.getValidation().getMaxCharacters()).isEqualTo(50);
    }

    @Test
    void shouldUpdateRateLimitConfiguration() {
        // Arrange
        ConfigUpdateRequest request = new ConfigUpdateRequest();
        ConfigUpdateRequest.RateLimitConfig rateLimit = new ConfigUpdateRequest.RateLimitConfig();
        rateLimit.setRequestsPerMinute(20);
        rateLimit.setEnabled(false);
        request.setRateLimit(rateLimit);

        // Act
        ConfigUpdateResponse response = configurationService.updateConfiguration(request, "test-user");
        GreetingServiceConfig result = configurationService.getCurrentConfig();

        // Assert
        assertThat(response.getStatus()).isEqualTo("success");
        assertThat(response.getMessage()).isEqualTo("Configuration updated successfully");
        assertThat(response.getUpdatedBy()).isEqualTo("test-user");
        assertThat(response.getUpdatedAt()).isNotNull();
        assertThat(response.getAppliedConfig()).isEqualTo(request);
        assertThat(result.getRateLimit().getRequestsPerMinute()).isEqualTo(20);
        assertThat(result.getRateLimit().isEnabled()).isFalse();
    }

    @Test
    void shouldUpdateValidationConfiguration() {
        // Arrange
        ConfigUpdateRequest request = new ConfigUpdateRequest();
        ConfigUpdateRequest.ValidationConfig validation = new ConfigUpdateRequest.ValidationConfig();
        validation.setMaxWords(20);
        validation.setMaxCharacters(100);
        request.setValidation(validation);

        // Act
        ConfigUpdateResponse response = configurationService.updateConfiguration(request, "test-user");
        GreetingServiceConfig result = configurationService.getCurrentConfig();

        // Assert
        assertThat(response.getStatus()).isEqualTo("success");
        assertThat(response.getMessage()).isEqualTo("Configuration updated successfully");
        assertThat(response.getUpdatedBy()).isEqualTo("test-user");
        assertThat(response.getUpdatedAt()).isNotNull();
        assertThat(response.getAppliedConfig()).isEqualTo(request);
        assertThat(result.getValidation().getMaxWords()).isEqualTo(20);
        assertThat(result.getValidation().getMaxCharacters()).isEqualTo(100);
    }
}
