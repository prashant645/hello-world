package com.sap.gtlc.security.config;

import com.sap.cloud.security.ams.api.Authorizations;
import com.sap.gtlc.security.service.AmsAuthorizationService;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Primary;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.List;

import static org.mockito.Mockito.mock;

@TestConfiguration
public class TestSecurityConfig {

    @Bean
    public JwtDecoder jwtDecoder() {
        return mock(JwtDecoder.class);
    }

    @Bean
    @Primary
    public SecurityFilterChain testSecurityFilterChain(HttpSecurity http) throws Exception {
        http
                .csrf(csrf -> csrf.disable())
                .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
                // Pre-populate the SecurityContext with a test user so @PreAuthorize checks pass.
                // The filter runs before Spring Security's own auth filters; it does not set
                // principal-propagation so the fail-closed AMS guard is never triggered.
                .addFilterBefore(testAuthenticationFilter(), UsernamePasswordAuthenticationFilter.class)
                .authorizeHttpRequests(auth -> auth.anyRequest().permitAll());
        return http.build();
    }

    /**
     * Injects a fallback mock user with readers / writers / admins authorities when
     * no authentication is already present in the SecurityContext.
     *
     * The null-check preserves any authentication installed by @WithMockUser or other
     * test-level setup, so role-specific tests remain meaningful and authorization
     * failures are not masked by the default user.
     *
     * principal-propagation is deliberately excluded from the fallback authorities so
     * the fail-closed AMS guard does not fire during tests that rely on this default.
     */
    @Bean
    public OncePerRequestFilter testAuthenticationFilter() {
        return new OncePerRequestFilter() {
            @Override
            protected void doFilterInternal(HttpServletRequest request,
                                            HttpServletResponse response,
                                            FilterChain filterChain) throws ServletException, IOException {
                var authorities = List.of(
                        new SimpleGrantedAuthority("readers"),
                        new SimpleGrantedAuthority("writers"),
                        new SimpleGrantedAuthority("admins")
                );
                var auth = new UsernamePasswordAuthenticationToken("test-user", null, authorities);
                if (SecurityContextHolder.getContext().getAuthentication() == null) {
                    SecurityContextHolder.getContext().setAuthentication(auth);
                }
                filterChain.doFilter(request, response);
            }
        };
    }

    @Bean
    @Primary
    public AmsAuthorizationService testAmsAuthorizationService() {
        // Return a mock AMS service for tests that always returns false (AMS not available)
        return new AmsAuthorizationService((Authorizations) null);
    }
}

