package com.sap.gtlc.security.security;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Profile;

import java.nio.file.Files;
import java.nio.file.Path;

import static org.assertj.core.api.Assertions.assertThat;

class SecurityConfigJwtDecoderConditionTest {

    @Test
    @DisplayName("SecurityConfig declares an explicit JwtDecoder bean")
    void securityConfigDeclaresExplicitJwtDecoder() throws Exception {
        assertThat(SecurityConfig.class.getDeclaredMethods())
                .extracting(java.lang.reflect.Method::getName)
                .contains("jwtDecoder");
    }

    @Test
    @DisplayName("SecurityConfig is guarded by the expected conditional annotations")
    void securityConfigConditionalAnnotations() {
        ConditionalOnProperty classProperty = SecurityConfig.class.getAnnotation(ConditionalOnProperty.class);
        assertThat(classProperty).isNotNull();
        assertThat(classProperty.prefix()).isEqualTo("greeting-service.security");
        assertThat(classProperty.name()).containsExactly("enabled");
        assertThat(classProperty.havingValue()).isEqualTo("true");

        Profile classProfile = SecurityConfig.class.getAnnotation(Profile.class);
        assertThat(classProfile).isNotNull();
        assertThat(classProfile.value()).containsExactly("!test");
    }

    @Test
    @DisplayName("application-cloud.yml does not exclude HybridIdentityServicesAutoConfiguration")
    void cloudYmlDoesNotExcludeHybridAutoConfiguration() throws Exception {
        String cloudConfig = Files.readString(Path.of("src/main/resources/application-cloud.yml"));
        // Strip comment lines before checking — the class name may appear in explanatory comments
        String withoutComments = cloudConfig.lines()
                .filter(line -> !line.stripLeading().startsWith("#"))
                .reduce("", (a, b) -> a + "\n" + b);
        assertThat(withoutComments)
                .as("HybridIdentityServicesAutoConfiguration must not be in the exclusion list: " +
                    "it installs JavaSecurityContextHolderStrategy which populates " +
                    "com.sap.cloud.security.token.SecurityContext so AMS can resolve the user")
                .doesNotContain("HybridIdentityServicesAutoConfiguration");
        assertThat(withoutComments).doesNotContain("xsuaa");
    }
}
