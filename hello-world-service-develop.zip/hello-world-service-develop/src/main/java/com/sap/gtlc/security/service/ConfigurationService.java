package com.sap.gtlc.security.service;

import com.sap.gtlc.security.config.GreetingServiceConfig;
import com.sap.gtlc.security.model.ConfigUpdateRequest;
import com.sap.gtlc.security.model.ConfigUpdateResponse;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.concurrent.atomic.AtomicReference;

@Service
public class ConfigurationService {

    private final AtomicReference<GreetingServiceConfig> currentConfig;

    public ConfigurationService(GreetingServiceConfig initialConfig) {
        this.currentConfig = new AtomicReference<>(copyConfig(initialConfig));
    }

    public GreetingServiceConfig getCurrentConfig() {
        return copyConfig(currentConfig.get());
    }

    public ConfigUpdateResponse updateConfiguration(ConfigUpdateRequest request, String updatedBy) {
        GreetingServiceConfig newConfig = copyConfig(currentConfig.get());

        if (request.getRateLimit() != null) {
            if (request.getRateLimit().getRequestsPerMinute() != null) {
                newConfig.getRateLimit().setRequestsPerMinute(request.getRateLimit().getRequestsPerMinute());
            }
            if (request.getRateLimit().getEnabled() != null) {
                newConfig.getRateLimit().setEnabled(request.getRateLimit().getEnabled());
            }
        }

        if (request.getValidation() != null) {
            if (request.getValidation().getMaxWords() != null) {
                newConfig.getValidation().setMaxWords(request.getValidation().getMaxWords());
            }
            if (request.getValidation().getMaxCharacters() != null) {
                newConfig.getValidation().setMaxCharacters(request.getValidation().getMaxCharacters());
            }
        }

        currentConfig.set(newConfig);

        return new ConfigUpdateResponse(
            "success",
            request,
            "Configuration updated successfully",
            updatedBy,
            Instant.now()
        );
    }

    private GreetingServiceConfig copyConfig(GreetingServiceConfig source) {
        GreetingServiceConfig copy = new GreetingServiceConfig();
        copy.getRateLimit().setRequestsPerMinute(source.getRateLimit().getRequestsPerMinute());
        copy.getRateLimit().setEnabled(source.getRateLimit().isEnabled());
        copy.getValidation().setMaxWords(source.getValidation().getMaxWords());
        copy.getValidation().setMaxCharacters(source.getValidation().getMaxCharacters());
        return copy;
    }
}
