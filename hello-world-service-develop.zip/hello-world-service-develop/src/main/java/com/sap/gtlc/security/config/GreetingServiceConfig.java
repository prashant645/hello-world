package com.sap.gtlc.security.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix = "greeting-service")
@Data
public class GreetingServiceConfig {
    private RateLimitConfig rateLimit = new RateLimitConfig();
    private ValidationConfig validation = new ValidationConfig();

    @Data
    public static class RateLimitConfig {
        private int requestsPerMinute = 10;
        private boolean enabled = true;
    }

    @Data
    public static class ValidationConfig {
        private int maxWords = 10;
        private int maxCharacters = 50;
    }
}
