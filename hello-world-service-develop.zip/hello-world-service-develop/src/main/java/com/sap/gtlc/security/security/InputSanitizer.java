package com.sap.gtlc.security.security;

import com.sap.gtlc.security.exception.SecurityValidationException;
import com.sap.gtlc.security.exception.ValidationException;
import org.springframework.stereotype.Component;

import java.util.regex.Pattern;

@Component
public class InputSanitizer {

    private static final Pattern CONTROL_CHARS = Pattern.compile("[\\x00-\\x1F\\x7F]");
    private static final Pattern SHELL_META_CHARS = Pattern.compile("[;&|`$()<>\\\\]");

    public String sanitize(String input) {
        if (input == null || input.isBlank()) {
            throw new ValidationException("Message cannot be empty");
        }

        // Replace control characters with spaces
        String sanitized = CONTROL_CHARS.matcher(input).replaceAll(" ");

        // Check for shell metacharacters (security validation)
        if (SHELL_META_CHARS.matcher(sanitized).find()) {
            throw new SecurityValidationException(
                "Message contains potentially dangerous characters"
            );
        }

        // Normalize whitespace
        sanitized = sanitized.trim().replaceAll("\\s+", " ");

        if (sanitized.isEmpty()) {
            throw new ValidationException("Message cannot be empty");
        }

        return sanitized;
    }
}
