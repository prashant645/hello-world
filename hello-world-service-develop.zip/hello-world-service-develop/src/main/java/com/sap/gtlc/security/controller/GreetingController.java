package com.sap.gtlc.security.controller;

import com.sap.gtlc.security.config.GreetingServiceConfig;
import com.sap.gtlc.security.model.ConfigUpdateRequest;
import com.sap.gtlc.security.model.ConfigUpdateResponse;
import com.sap.gtlc.security.model.GreetingRequest;
import com.sap.gtlc.security.model.GreetingResponse;
import com.sap.gtlc.security.service.ConfigurationService;
import com.sap.gtlc.security.service.GreetingService;
import com.sap.gtlc.security.service.AmsAuthorizationService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/**
 * REST Controller for the Hello World Greeting Service.
 *
 * Supports both legacy scope-based authorization (@PreAuthorize) and fine-grained
 * AMS (Authorization Management Service) authorization checks via AmsAuthorizationService.
 *
 * Resource Paths for AMS Authorization Checks:
 * - DataResource (read/write)
 * - ConfigResource (admin)
 */
@RestController
@RequestMapping(value = "/api/v1")
@Validated
@Tag(name = "Greetings", description = "Hello World Greeting API")
public class GreetingController {

    private static final Logger log = LoggerFactory.getLogger(GreetingController.class);

    // ── AMS privilege specs — every action/resource pair this service exposes.
    // Used to detect whether an OBO user has ANY AMS policy assignment at all
    // (i.e. at least one pair is granted) vs. having no binding whatsoever.
    private static final List<String[]> ALL_KNOWN_PRIVILEGE_CHECKS = List.of(
            new String[]{"read", "DataResource"},
            new String[]{"write", "DataResource"},
            new String[]{"admin", "ConfigResource"}
    );

    // ias_apis values that qualify a given action when falling back to MCP-server permission.
    // Note: "readers" qualifies for read but NOT for write — write requires writers or admins.
    private static final Set<String> READ_QUALIFYING_IAS_APIS  = Set.of("readers", "writers", "admins");
    private static final Set<String> WRITE_QUALIFYING_IAS_APIS = Set.of("writers", "admins");

    private final GreetingService greetingService;
    private final ConfigurationService configurationService;
    private final AmsAuthorizationService amsAuthorizationService;

    public GreetingController(GreetingService greetingService,
                            ConfigurationService configurationService,
                            @Autowired(required = false) AmsAuthorizationService amsAuthorizationService) {
        this.greetingService = greetingService;
        this.configurationService = configurationService;
        this.amsAuthorizationService = amsAuthorizationService;
    }

    @PostMapping(
            value = "/greetings",
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE
    )
    @ResponseStatus(HttpStatus.OK)
    @Operation(
            summary = "Create a greeting response",
            description = "Accepts a user message and returns a formatted greeting. " +
                    "The message is validated for length (max 10 words, 50 characters) " +
                    "and treated as plain text with no interpretation or command execution. " +
                    "Authorization is determined by the token type: " +
                    "(a) M2M tokens (no user_uuid — client_credentials): @PreAuthorize on the " +
                    "ias_apis claim (readers, writers, or admins) is the sole gate. AMS is not consulted. " +
                    "(b) OBO tokens (user_uuid present — on-behalf-of / PKCE exchange): " +
                    "AMS must be available (fail-closed if not). Resolution: " +
                    "(1) If the user is bound to an AMS policy, that policy is the sole authorizer — " +
                    "'read' on DataResource must be granted, and ias_apis is ignored. " +
                    "(2) If the user has NO AMS policy binding, the MCP server's ias_apis claim " +
                    "(readers/writers/admins) is inherited as the effective permission. " +
                    "If ias_apis is absent or insufficient, the request is denied."
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "200",
                    description = "Greeting created successfully",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = GreetingResponse.class)
                    )
            ),
            @ApiResponse(
                    responseCode = "400",
                    description = "Validation error",
                    content = @Content(mediaType = "application/problem+json")
            ),
            @ApiResponse(
                    responseCode = "401",
                    description = "Unauthorized - missing or invalid token",
                    content = @Content(mediaType = "application/problem+json")
            ),
            @ApiResponse(
                    responseCode = "403",
                    description = "Forbidden - insufficient scope or privilege",
                    content = @Content(mediaType = "application/problem+json")
            ),
            @ApiResponse(
                    responseCode = "429",
                    description = "Rate limit exceeded",
                    content = @Content(mediaType = "application/problem+json")
            ),
            @ApiResponse(
                    responseCode = "500",
                    description = "Internal server error",
                    content = @Content(mediaType = "application/problem+json")
            )
    })
    @PreAuthorize("hasAnyAuthority('readers', 'writers', 'admins', 'principal-propagation')")
    public ResponseEntity<GreetingResponse> greetings(
            @Valid @RequestBody GreetingRequest request,
            Authentication authentication) {

        logCallerIdentity("greetings", authentication);

        // M2M path: @PreAuthorize already enforced a qualifying ias_apis authority — done.
        // OBO path: apply the IAS + AMS two-tier resolution defined in resolveOboAuthorization().
        if (isHumanUserToken(authentication)) {
            if (!resolveOboAuthorization(authentication,
                    "read", "DataResource",
                    READ_QUALIFYING_IAS_APIS, "greetings")) {
                return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
            }
        }

        return ResponseEntity.ok(greetingService.createGreeting(request));
    }

    @GetMapping(
            value = "/greetings/config",
            produces = MediaType.APPLICATION_JSON_VALUE
    )
    @ResponseStatus(HttpStatus.OK)
    @Operation(
            summary = "Get runtime service configuration",
            description = "Returns current runtime configuration including rate limit and validation settings. " +
                    "Authorization is determined by the token type: " +
                    "(a) M2M tokens (no user_uuid — client_credentials): @PreAuthorize on the " +
                    "ias_apis claim (readers, writers, or admins) is the sole gate. AMS is not consulted. " +
                    "(b) OBO tokens (user_uuid present): AMS must be available (fail-closed if not). " +
                    "Resolution: (1) User is bound to an AMS policy → AMS enforces 'read' on DataResource; " +
                    "ias_apis is ignored. (2) User has no AMS policy → MCP server's ias_apis is inherited. " +
                    "Absent or insufficient ias_apis → denied."
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "200",
                    description = "Current configuration returned",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = GreetingServiceConfig.class)
                    )
            ),
            @ApiResponse(
                    responseCode = "401",
                    description = "Unauthorized - missing or invalid token",
                    content = @Content(mediaType = "application/problem+json")
            ),
            @ApiResponse(
                    responseCode = "403",
                    description = "Forbidden - requires an IAS+AMS permission group that grants read access",
                    content = @Content(mediaType = "application/problem+json")
            )
    })
    @PreAuthorize("hasAnyAuthority('readers', 'writers', 'admins', 'principal-propagation')")
    public ResponseEntity<GreetingServiceConfig> getCurrentConfiguration(Authentication authentication) {

        logCallerIdentity("getCurrentConfiguration", authentication);

        if (isHumanUserToken(authentication)) {
            if (!resolveOboAuthorization(authentication,
                    "read", "DataResource",
                    READ_QUALIFYING_IAS_APIS, "getCurrentConfiguration")) {
                return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
            }
        }

        return ResponseEntity.ok(configurationService.getCurrentConfig());
    }

    @PostMapping(
            value = "/greetings/update",
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE
    )
    @ResponseStatus(HttpStatus.OK)
    @Operation(
            summary = "Update service configuration",
            description = "Updates runtime configuration for rate limiting and validation rules. " +
                    "Changes take effect immediately. " +
                    "Authorization is determined by the token type: " +
                    "(a) M2M tokens (no user_uuid — client_credentials): @PreAuthorize on the " +
                    "ias_apis claim (writers or admins) is the sole gate. AMS is not consulted. " +
                    "(b) OBO tokens (user_uuid present): AMS must be available (fail-closed if not). " +
                    "Resolution: (1) User is bound to an AMS policy → AMS enforces 'write' on DataResource; " +
                    "ias_apis is ignored — a readers policy is insufficient even if the MCP server has writers. " +
                    "(2) User has no AMS policy → MCP server's ias_apis is inherited (writers or admins required). " +
                    "Absent or insufficient ias_apis → denied."
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "200",
                    description = "Configuration updated successfully",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = ConfigUpdateResponse.class)
                    )
            ),
            @ApiResponse(
                    responseCode = "400",
                    description = "Validation error - invalid configuration values",
                    content = @Content(mediaType = "application/problem+json")
            ),
            @ApiResponse(
                    responseCode = "401",
                    description = "Unauthorized - missing or invalid token",
                    content = @Content(mediaType = "application/problem+json")
            ),
            @ApiResponse(
                    responseCode = "403",
                    description = "Forbidden - requires an IAS+AMS permission group that grants write access",
                    content = @Content(mediaType = "application/problem+json")
            )
    })
    @PreAuthorize("hasAnyAuthority('writers', 'admins', 'principal-propagation')")
    public ResponseEntity<ConfigUpdateResponse> updateConfiguration(
            @Valid @RequestBody ConfigUpdateRequest request,
            Authentication authentication) {

        logCallerIdentity("updateConfiguration", authentication);

        // M2M path: @PreAuthorize already enforced writers/admins — done.
        // OBO path: apply the IAS + AMS two-tier resolution.
        if (isHumanUserToken(authentication)) {
            if (!resolveOboAuthorization(authentication,
                    "write", "DataResource",
                    WRITE_QUALIFYING_IAS_APIS, "updateConfiguration")) {
                return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
            }
        }

        Jwt jwt = authentication instanceof JwtAuthenticationToken jat ? (Jwt) jat.getToken() : null;
        String username = resolveUsername(jwt);
        return ResponseEntity.ok(configurationService.updateConfiguration(request, username));
    }

    /**
     * Logs the caller's identity and authorities for diagnostic purposes.
     *
     * For human user (principal-propagation) tokens this confirms the user
     * identity received from the IAS token exchange and shows which Spring
     * Security authorities were derived from the token's claims.
     *
     * For M2M tokens it shows the client identity and ias_apis-derived authorities.
     *
     * TODO: Downgrade to DEBUG and remove all-claims / email once the token
     * structure is confirmed and the implementation is stable.
     * See PR bot finding: full claim set (including PII) should not appear in
     * production INFO logs long-term.
     */
    private void logCallerIdentity(String endpoint, Authentication authentication) {
        try {
            if (authentication instanceof JwtAuthenticationToken jwtAuth) {
                var jwt = jwtAuth.getToken();
                boolean obo = isHumanUserToken(authentication);
                log.info("=== Backend caller identity [endpoint={}, path={}] ===",
                        endpoint, obo ? "OBO (human user)" : "M2M (service account)");
                log.info("  sub         : {}", jwt.getSubject());
                log.info("  email       : {}", jwt.getClaimAsString("email"));
                log.info("  user_uuid   : {}", jwt.getClaimAsString("user_uuid"));
                log.info("  iss         : {}", jwt.getIssuer());
                log.info("  aud         : {}", jwt.getAudience());
                log.info("  ias_apis    : {}", jwt.<Object>getClaim("ias_apis"));
                log.info("  groups      : {}", jwt.<Object>getClaim("groups"));
                log.info("  authorities : {}", authentication.getAuthorities());
                log.info("  all claims  : {}", jwt.getClaims());
            } else {
                log.info("=== Backend caller identity [endpoint={}] — non-JWT auth: {} ===",
                        endpoint, authentication);
            }
        } catch (Exception e) {
            log.warn("Could not log caller identity for endpoint={}", endpoint, e);
        }
    }

    // ── authorization helpers ─────────────────────────────────────────────────

    /**
     * Resolves authorization for OBO (On-Behalf-Of / principal-propagation) tokens.
     *
     * <h3>Design intent — unenrolled users are first-class</h3>
     * <p>Users are NOT required to be enrolled in any AMS policy. An unenrolled user
     * is a fully valid actor: they authenticated via IAS and arrived through an MCP
     * server that itself carries a declared {@code ias_apis} permission. In that case
     * the MCP server's permission is inherited as the effective access level. This is
     * intentional — it avoids forcing every user to be individually configured in IAS
     * Authorization before they can use the service through an MCP proxy.</p>
     *
     * <p>AMS enrollment is therefore opt-in. If a user IS enrolled, their AMS policy
     * takes full precedence and the MCP server's permission is ignored for that user.
     * This allows tenant admins to restrict or elevate individual users relative to the
     * default MCP-server permission without changing the MCP configuration.</p>
     *
     * <h3>Resolution order</h3>
     * <ol>
     *   <li><b>AMS unavailable</b> → deny (fail-closed). AMS must be reachable to
     *       confirm or rule out a user policy; we do not skip it.</li>
     *   <li><b>AMS grants {@code action} on {@code resourcePath}</b> → allow.
     *       User has a policy and it covers this action.</li>
     *   <li><b>AMS denies but user has ANY AMS policy binding</b> → deny.
     *       User is enrolled; their explicit policy is too restrictive for this action.</li>
     *   <li><b>User has no AMS policy (unenrolled)</b> → inherit the MCP server's
     *       {@code ias_apis} claim. If it contains a value that qualifies for
     *       {@code action} (per {@code qualifyingIasApis}), allow; otherwise deny.</li>
     * </ol>
     *
     * <p>AMS is consulted in every OBO request — including for unenrolled users.
     * The "no policy" conclusion is reached by observing that AMS grants nothing
     * across all known action/resource pairs, not by skipping AMS.</p>
     *
     * @param authentication     current Spring Security principal (OBO JWT)
     * @param action             AMS action name (e.g. "read", "write")
    * @param resourcePath       AMS resource path (e.g. "DataResource")
     * @param qualifyingIasApis  ias_apis values that satisfy this action level
     * @param endpoint           endpoint name used only for log context
     * @return {@code true} if the request should be allowed
     */
    private boolean resolveOboAuthorization(Authentication authentication,
                                             String action,
                                             String resourcePath,
                                             Set<String> qualifyingIasApis,
                                             String endpoint) {
        // Step 1: AMS must be available — fail-closed for any OBO token.
        if (amsAuthorizationService == null || !amsAuthorizationService.isAmsAvailable()) {
            log.warn("AMS unavailable — denying OBO request (fail-closed) [action={}, endpoint={}]",
                    action, endpoint);
            return false;
        }

        // Step 2: AMS grants the requested action → allow immediately.
        //
        // Resource attributes are passed for ABAC condition evaluation.
        // The policy condition:
        //   GRANT read ON DataResource WHERE $user.app_tid = $resource.tenantId
        // requires AMS to know the tenantId of the resource being accessed.
        //
        // For this service, the resource is owned by the IAS tenant in which the
        // service is deployed. The caller's app_tid (from their JWT) identifies
        // which tenant they belong to. Cross-tenant access is denied by the condition.
        //
        // In a real multi-tenant data service, tenantId would come from the data
        // record being accessed — not the caller's token.
        java.util.Map<String, Object> resourceAttributes = resolveResourceAttributes(authentication);
        if (amsAuthorizationService.hasPrivilege(authentication, action, resourcePath, resourceAttributes)) {
            return true;
        }

        // Step 3: AMS denied. Detect whether the user has ANY AMS policy binding.
        // Uses the tri-state detectPolicyBinding so AMS errors are fail-closed rather
        // than silently collapsing into "unenrolled" and granting ias_apis fallback.
        AmsAuthorizationService.PolicyBinding binding =
                amsAuthorizationService.detectPolicyBinding(authentication, ALL_KNOWN_PRIVILEGE_CHECKS,
                    resourceAttributes);

        if (binding == AmsAuthorizationService.PolicyBinding.ERROR) {
            log.warn("AMS error during enrollment detection — denying OBO (fail-closed) " +
                    "[action={}, endpoint={}]", action, endpoint);
            return false;
        }

        if (binding == AmsAuthorizationService.PolicyBinding.BOUND) {
            // User is AMS-managed; their policy does not cover this action → deny.
            log.warn("AMS denied '{}' on '{}' for OBO user (user has AMS policy, " +
                    "insufficient privilege) [endpoint={}]", action, resourcePath, endpoint);
            return false;
        }

        // Step 4: No AMS policy → inherit from the MCP server's ias_apis claim.
        Set<String> iasApis = extractIasApisFromJwt(authentication);
        if (iasApis.isEmpty()) {
            log.warn("OBO user has no AMS policy and MCP server has no ias_apis — " +
                    "denying [action={}, endpoint={}]", action, endpoint);
            return false;
        }
        if (Collections.disjoint(iasApis, qualifyingIasApis)) {
            log.warn("OBO user has no AMS policy; MCP ias_apis={} does not qualify for " +
                    "'{}' [qualifyingSet={}, endpoint={}]", iasApis, action, qualifyingIasApis, endpoint);
            return false;
        }
        log.info("OBO user has no AMS policy — inheriting MCP ias_apis={} as permission " +
                "[action={}, endpoint={}]", iasApis, action, endpoint);
        return true;
    }

    /**
     * Builds the resource instance attributes passed to AMS for ABAC condition evaluation.
     *
     * <p>The {@code tenantId} attribute matches the {@code attribute tenantId} declared on
     * {@code DataResource} in {@code schema.dcl}. AMS evaluates the policy condition
     * {@code WHERE $user.app_tid = $resource.tenantId} against this value.</p>
     *
     * <p>Here we use the caller's own {@code app_tid} as the resource's tenant identifier,
     * which models the rule "a user may only access data in their own IAS tenant".
     * In a real multi-tenant service, {@code tenantId} would come from the data record
     * being accessed (e.g. a database column), making the check instance-level rather
     * than caller-level.</p>
     */
    private static java.util.Map<String, Object> resolveResourceAttributes(Authentication authentication) {
        return java.util.Collections.emptyMap();
    }

    /**
     * Extracts the raw string values from the JWT {@code ias_apis} claim.
     *
     * <p>IAS represents {@code ias_apis} as a JSON array (at most one element per
     * IAS+AMS spec). Returns an empty set when the claim is absent.</p>
     */
    private static Set<String> extractIasApisFromJwt(Authentication authentication) {
        if (!(authentication instanceof JwtAuthenticationToken jwtAuth)) {
            return Collections.emptySet();
        }
        Object claim = jwtAuth.getToken().getClaim("ias_apis");
        if (claim == null) {
            return Collections.emptySet();
        }
        Set<String> result = new LinkedHashSet<>();
        if (claim instanceof java.util.List<?> list) {
            for (Object item : list) {
                if (item instanceof String s && !s.isBlank()) {
                    result.add(s.trim());
                }
            }
        } else if (claim instanceof String s && !s.isBlank()) {
            result.add(s.trim());
        }
        return result;
    }

    /**
     * Returns {@code true} when the JWT carries the IAS {@code user_uuid} claim,
     * indicating the token was issued for a human user (via PKCE or token exchange
     * on behalf of a user).
     *
     * This is the reliable signal to distinguish human-user tokens from M2M
     * client_credentials tokens. IAS only includes {@code user_uuid} in tokens
     * issued to human users; service tokens never carry it.
     *
     * Replaces the previous {@code isPrincipalPropagationToken()} check, which
     * looked for {@code principal-propagation} in {@code ias_apis}. That check was
     * unreliable because IAS sets {@code ias_apis} to the dependency's API permission
     * group (e.g. {@code writers}) for both M2M and OBO token exchanges — the
     * {@code principal-propagation} value is only present when the backend's Provided
     * API has "Allow all APIs for principal propagation" enabled, which cannot be
     * assumed at the code level.
     */
    private static boolean isHumanUserToken(Authentication authentication) {
        if (authentication instanceof JwtAuthenticationToken jwtAuth) {
            String userUuid = jwtAuth.getToken().getClaimAsString("user_uuid");
            return userUuid != null && !userUuid.isBlank();
        }
        return false;
    }

    // Commented out — no longer called after the isHumanUserToken() refactor.
    // Previously used alongside isPrincipalPropagationToken() to detect "mixed"
    // tokens (principal-propagation + a qualifying group authority) so that AMS
    // was treated as supplementary and its absence was tolerated. That logic was
    // removed because IAS sets ias_apis=[writers] on both M2M and human-user OBO
    // exchanges, making the mixed-authority detection unreliable. Human users are
    // now always gated through AMS (fail-closed) via isHumanUserToken(); the flat
    // group authority in ias_apis is ignored for human callers.
    //
    // Note: the "internal - readers / writers / admins" groups visible in IAS
    // Users & Authorizations are authorization-type groups auto-created from
    // policies. They appear in the JWT groups claim as their full display name
    // (e.g. "internal - readers") which does NOT match the short names checked
    // here. Those short names (readers / writers / admins) come exclusively from
    // ias_apis, not from IAS group membership.
    //
    // private static boolean hasAnyGroupAuthority(Authentication authentication, String... groups) {
    //     var permitted = java.util.Set.of(groups);
    //     return authentication.getAuthorities().stream()
    //             .anyMatch(a -> permitted.contains(a.getAuthority()));
    // }

    private static String resolveUsername(Jwt jwt) {
        if (jwt == null) {
            return "unknown";
        }

        String preferredUsername = jwt.getClaimAsString("preferred_username");
        if (preferredUsername != null && !preferredUsername.isBlank()) {
            return preferredUsername;
        }

        String name = jwt.getClaimAsString("name");
        if (name != null && !name.isBlank()) {
            return name;
        }

        String email = jwt.getClaimAsString("email");
        if (email != null && !email.isBlank()) {
            return email;
        }

        String subject = jwt.getSubject();
        return subject != null && !subject.isBlank() ? subject : "unknown";
    }
}
