package com.sap.gtlc.security.exception;

import jakarta.servlet.http.HttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@RestControllerAdvice
public class GlobalExceptionHandler {

    private static final Logger log = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    @ExceptionHandler(ValidationException.class)
    public ResponseEntity<ProblemDetail> handleValidationException(
            ValidationException ex, HttpServletRequest request) {

        log.warn("Validation failed: {}", ex.getMessage());

        ProblemDetail problem = ProblemDetail.builder()
            .type("https://api.sap.com/problems/validation-error")
            .title("Validation Error")
            .status(HttpStatus.BAD_REQUEST.value())
            .detail(ex.getMessage())
            .instance(request.getRequestURI())
            .build();

        return ResponseEntity
            .status(HttpStatus.BAD_REQUEST)
            .contentType(MediaType.APPLICATION_PROBLEM_JSON)
            .body(problem);
    }

    @ExceptionHandler(SecurityValidationException.class)
    public ResponseEntity<ProblemDetail> handleSecurityValidationException(
            SecurityValidationException ex, HttpServletRequest request) {

        log.warn("Security validation failed [clientIp={}]: {}",
            getClientIp(request), ex.getMessage());

        ProblemDetail problem = ProblemDetail.builder()
            .type("https://api.sap.com/problems/security-error")
            .title("Security Validation Error")
            .status(HttpStatus.BAD_REQUEST.value())
            .detail("Message contains potentially dangerous characters")
            .instance(request.getRequestURI())
            .build();

        return ResponseEntity
            .status(HttpStatus.BAD_REQUEST)
            .contentType(MediaType.APPLICATION_PROBLEM_JSON)
            .body(problem);
    }

    @ExceptionHandler(AccessDeniedException.class)
    public ResponseEntity<ProblemDetail> handleAccessDeniedException(
            AccessDeniedException ex, HttpServletRequest request) {

        log.warn("Access denied [clientIp={}]: {}", getClientIp(request), ex.getMessage());

        ProblemDetail problem = ProblemDetail.builder()
            .type("https://api.sap.com/problems/access-denied")
            .title("Access Denied")
            .status(HttpStatus.FORBIDDEN.value())
            .detail("Insufficient permissions to access this resource")
            .instance(request.getRequestURI())
            .build();

        return ResponseEntity
            .status(HttpStatus.FORBIDDEN)
            .contentType(MediaType.APPLICATION_PROBLEM_JSON)
            .body(problem);
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ProblemDetail> handleMethodArgumentNotValidException(
            MethodArgumentNotValidException ex, HttpServletRequest request) {

        List<ProblemDetail.Violation> violations = ex.getBindingResult()
            .getFieldErrors()
            .stream()
            .map(error -> new ProblemDetail.Violation(
                error.getField(),
                error.getDefaultMessage()
            ))
            .collect(Collectors.toList());

        ProblemDetail problem = ProblemDetail.builder()
            .type("https://api.sap.com/problems/validation-error")
            .title("Validation Error")
            .status(HttpStatus.BAD_REQUEST.value())
            .detail("Request validation failed")
            .instance(request.getRequestURI())
            .violations(violations)
            .build();

        return ResponseEntity
            .status(HttpStatus.BAD_REQUEST)
            .contentType(MediaType.APPLICATION_PROBLEM_JSON)
            .body(problem);
    }

    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ResponseEntity<ProblemDetail> handleHttpMessageNotReadableException(
            HttpMessageNotReadableException ex, HttpServletRequest request) {

        log.warn("Invalid request body: {}", ex.getMessage());

        ProblemDetail problem = ProblemDetail.builder()
            .type("https://api.sap.com/problems/validation-error")
            .title("Validation Error")
            .status(HttpStatus.BAD_REQUEST.value())
            .detail("Invalid request body format")
            .instance(request.getRequestURI())
            .build();

        return ResponseEntity
            .status(HttpStatus.BAD_REQUEST)
            .contentType(MediaType.APPLICATION_PROBLEM_JSON)
            .body(problem);
    }

    @ExceptionHandler(HttpMediaTypeNotSupportedException.class)
    public ResponseEntity<ProblemDetail> handleHttpMediaTypeNotSupportedException(
            HttpMediaTypeNotSupportedException ex, HttpServletRequest request) {

        log.warn("Unsupported media type: {}", ex.getMessage());

        ProblemDetail problem = ProblemDetail.builder()
            .type("https://api.sap.com/problems/unsupported-media-type")
            .title("Unsupported Media Type")
            .status(HttpStatus.UNSUPPORTED_MEDIA_TYPE.value())
            .detail("Content-Type must be application/json")
            .instance(request.getRequestURI())
            .build();

        return ResponseEntity
            .status(HttpStatus.UNSUPPORTED_MEDIA_TYPE)
            .contentType(MediaType.APPLICATION_PROBLEM_JSON)
            .body(problem);
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<ProblemDetail> handleGenericException(
            Exception ex, HttpServletRequest request) {

        String correlationId = UUID.randomUUID().toString();
        log.error("Unexpected error [correlationId={}]", correlationId, ex);

        ProblemDetail problem = ProblemDetail.builder()
            .type("https://api.sap.com/problems/internal-error")
            .title("Internal Server Error")
            .status(HttpStatus.INTERNAL_SERVER_ERROR.value())
            .detail("An unexpected error occurred")
            .instance(request.getRequestURI())
            .correlationId(correlationId)
            .build();

        return ResponseEntity
            .status(HttpStatus.INTERNAL_SERVER_ERROR)
            .contentType(MediaType.APPLICATION_PROBLEM_JSON)
            .body(problem);
    }

    private String getClientIp(HttpServletRequest request) {
        String xForwardedFor = request.getHeader("X-Forwarded-For");
        if (xForwardedFor != null && !xForwardedFor.isEmpty()) {
            return xForwardedFor.split(",")[0].trim();
        }
        return request.getRemoteAddr();
    }
}
