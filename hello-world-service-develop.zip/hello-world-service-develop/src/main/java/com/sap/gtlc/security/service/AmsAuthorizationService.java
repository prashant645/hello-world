package com.sap.gtlc.security.service;

import com.sap.cloud.security.ams.api.Authorizations;
import com.sap.cloud.security.ams.api.expression.AttributeName;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.security.core.Authentication;

import java.util.Collections;
import java.util.Map;
import java.util.Optional;

/**
 * Service for AMS-based fine-grained authorization checks.
 *
 * <p>Uses the request-scoped {@code Authorizations} bean auto-configured by
 * {@code spring-boot-starter-ams}. No reflection — the AMS starter is an
 * {@code implementation} dependency and is always on the classpath.</p>
 *
 * <h3>Bean-ordering note</h3>
 * {@code SecurityConfig} is initialized very early in the Spring lifecycle
 * (due to {@code @EnableWebSecurity} / {@code @EnableMethodSecurity}), <em>before</em>
 * AMS auto-configuration has registered the {@code Authorizations} bean. If the eager
 * {@link #AmsAuthorizationService(Authorizations)} constructor were used from
 * {@code SecurityConfig}, the bean would always be {@code null}.
 *
 * <p>Use the lazy {@link #AmsAuthorizationService(ApplicationContext)} constructor from
 * {@code SecurityConfig} instead. It defers resolution of the {@code Authorizations} bean
 * until the first call to {@link #isAmsAvailable()} or {@link #hasPrivilege}, by which time
 * all singleton beans — including AMS auto-configured ones — are fully initialized.</p>
 */
public class AmsAuthorizationService {

    private static final Logger log = LoggerFactory.getLogger(AmsAuthorizationService.class);

    /**
     * Tri-state result for {@link #detectPolicyBinding}.
     *
     * <ul>
     *   <li>{@code BOUND}   – AMS confirmed the user has at least one policy grant.</li>
     *   <li>{@code UNBOUND} – AMS confirmed the user has no policy assignment.</li>
     *   <li>{@code ERROR}   – At least one AMS call threw an exception; enrollment
     *       status is unknown. Callers MUST treat this as a denial (fail-closed).</li>
     * </ul>
     */
    public enum PolicyBinding { BOUND, UNBOUND, ERROR }

    /**
     * Request-scoped proxy for the current user's AMS authorizations.
     * Non-final so lazy resolution can assign it after construction.
     */
    private volatile Optional<Authorizations> amsAuthorizations;

    /**
     * Pending context for lazy resolution. {@code null} once resolved or when the
     * eager constructor was used.
     */
    private volatile ApplicationContext pendingContext;

    /**
     * Eager constructor — pass a pre-built {@code Authorizations} proxy for tests,
     * or {@code null} to create a permanently unavailable service.
     */
    public AmsAuthorizationService(Authorizations authorizations) {
        this.amsAuthorizations = Optional.ofNullable(authorizations);
        this.pendingContext = null;
        log.info("AMS initialised (eager): available={}", this.amsAuthorizations.isPresent());
    }

    /**
     * Lazy constructor — resolves the {@code Authorizations} bean from the
     * {@code ApplicationContext} on the first call to {@link #isAmsAvailable()} or
     * {@link #hasPrivilege}. Use from {@code SecurityConfig} to avoid the bean-ordering
     * issue described in the class-level Javadoc.
     */
    public AmsAuthorizationService(ApplicationContext applicationContext) {
        this.amsAuthorizations = Optional.empty();
        this.pendingContext = applicationContext;
    }

    // ── public API ────────────────────────────────────────────────────────────

    /**
     * Returns {@code true} when the {@code Authorizations} bean was found in the
     * Spring context.
     */
    public boolean isAmsAvailable() {
        resolveIfPending();
        return amsAuthorizations.isPresent();
    }

    /**
     * Checks whether the current principal has the given privilege on the specified
     * resource path, without resource instance attributes (flat RBAC — no ABAC conditions).
     */
    public boolean hasPrivilege(Authentication authentication, String action, String resourcePath) {
        return hasPrivilege(authentication, action, resourcePath, Collections.emptyMap());
    }

    /**
     * Checks whether the current principal has the given privilege on the specified
     * resource, passing resource instance attributes for ABAC condition evaluation.
     *
     * <p>The AMS policy engine evaluates conditions such as
     * {@code WHERE $user.app_tid = $resource.tenantId} against the provided
     * {@code resourceAttributes} map. The key names must match the {@code attribute}
     * declarations in {@code schema.dcl}.</p>
     *
     * <p>Example — tenant-scoped read check:</p>
     * <pre>{@code
     * hasPrivilege(auth, "read",
    *     "DataResource",
     *     Map.of("tenantId", callerAppTid));
     * }</pre>
     *
     * Returns {@code false} if AMS is unavailable or the check throws an exception.
     */
    public boolean hasPrivilege(Authentication authentication, String action, String resourcePath,
                                 Map<String, Object> resourceAttributes) {
        if (!isAmsAvailable()) {
            return false;
        }
        try {
            var decision = amsAuthorizations.get()
                .checkPrivilege(action, resourcePath, toAttributeMap(resourceAttributes));
            log.info("AMS privilege decision [action={}, resource={}, granted={}, denied={}, " +
                    "conditional={}, attrs={}]",
                action, resourcePath, decision.isGranted(), decision.isDenied(),
                !decision.isGranted() && !decision.isDenied(), resourceAttributes.keySet());
            return decision.isGranted();
        } catch (Exception e) {
            log.warn("AMS privilege check failed [action={}, resource={}, attrs={}]: {}",
                    action, resourcePath, resourceAttributes.keySet(), e.getMessage());
            return false;
        }
    }

    /**
     * Determines whether the current principal is enrolled in any AMS policy.
     *
     * <p>Returns a {@link PolicyBinding} tri-state rather than a boolean so that callers
     * can distinguish a confirmed non-enrollment ({@code UNBOUND}) from an AMS error
     * ({@code ERROR}) and deny on error rather than silently falling back to
     * {@code ias_apis}-based access. A boolean return would collapse ERROR and UNBOUND
     * into the same value, allowing a transient AMS failure to bypass a restrictive policy.</p>
     *
     * <h3>Resolution</h3>
     * <ul>
     *   <li>{@code BOUND}   – At least one privilege check was granted.
     *       User is enrolled; AMS is the sole authorizer for this request.</li>
     *   <li>{@code UNBOUND} – All checks returned denied with no exceptions.
     *       User has no AMS policy; caller may fall back to MCP {@code ias_apis}.</li>
     *   <li>{@code ERROR}   – At least one check threw an exception and none were granted.
     *       Enrollment status is unknown; caller MUST deny (fail-closed).</li>
     * </ul>
     *
     * <p>Each element of {@code actionsAndResources} must be a two-element array
     * {@code [action, resourcePath]}.</p>
     */
    public PolicyBinding detectPolicyBinding(Authentication authentication,
                                             java.util.List<String[]> actionsAndResources) {
        return detectPolicyBinding(authentication, actionsAndResources, Collections.emptyMap());
    }

    public PolicyBinding detectPolicyBinding(Authentication authentication,
                                             java.util.List<String[]> actionsAndResources,
                                             Map<String, Object> resourceAttributes) {
        if (!isAmsAvailable()) {
            return PolicyBinding.ERROR;
        }
        boolean anyError = false;
        for (String[] pair : actionsAndResources) {
            try {
            var decision = amsAuthorizations.get().checkPrivilege(pair[0], pair[1],
                toAttributeMap(resourceAttributes));
            log.info("AMS enrollment probe [action={}, resource={}, granted={}, denied={}, " +
                    "conditional={}, attrs={}]",
                pair[0], pair[1], decision.isGranted(), decision.isDenied(),
                !decision.isGranted() && !decision.isDenied(), resourceAttributes.keySet());
            if (decision.isGranted()) {
                    return PolicyBinding.BOUND;
                }
            } catch (Exception e) {
                log.warn("AMS detectPolicyBinding check failed [action={}, resource={}]: {}",
                        pair[0], pair[1], e.getMessage());
                anyError = true;
            }
        }
        return anyError ? PolicyBinding.ERROR : PolicyBinding.UNBOUND;
    }

    private static Map<AttributeName, Object> toAttributeMap(Map<String, Object> attributes) {
        Map<AttributeName, Object> typedAttributes = new java.util.HashMap<>();
        attributes.forEach((name, value) -> typedAttributes.put(AttributeName.of(name), value));
        return typedAttributes;
    }

    /**
     * @deprecated Use {@link #detectPolicyBinding} instead. This method collapses
     *     {@code ERROR} and {@code UNBOUND} into the same {@code false} return, which
     *     means a transient AMS failure is indistinguishable from confirmed non-enrollment
     *     and may cause the caller to grant fallback access from {@code ias_apis}.
     */
    @Deprecated
    public boolean hasAnyPrivilege(Authentication authentication,
                                   java.util.List<String[]> actionsAndResources) {
        return detectPolicyBinding(authentication, actionsAndResources) == PolicyBinding.BOUND;
    }

    // ── lazy resolution ───────────────────────────────────────────────────────

    /**
     * If a pending {@code ApplicationContext} is stored, resolves
     * the {@code Authorizations} bean via {@code ctx.getBean()} now.
     * Synchronized so concurrent requests on the first call are safe.
     *
     * <p>Resolution is attempted first and the context is cleared last so that
     * a {@code BeansException} leaves {@code pendingContext} set, allowing the
     * next request to retry rather than permanently disabling AMS.</p>
     */
    private synchronized void resolveIfPending() {
        if (pendingContext == null) {
            return;
        }
        ApplicationContext ctx = pendingContext;
        try {
            Authorizations proxy = ctx.getBean(Authorizations.class);
            this.amsAuthorizations = Optional.of(proxy);
            log.info("AMS initialised: available=true");
        } catch (BeansException e) {
            this.amsAuthorizations = Optional.empty();
            log.warn("AMS: Authorizations bean not found in context — will retry on next request. "
                    + "Ensure spring-boot-starter-ams is on the classpath and SERVICE_BINDING_ROOT "
                    + "is set with a valid IAS binding mounted. Cause: {}", e.getMessage());
            // Do NOT clear pendingContext here — leave it set so the next request retries
            // rather than permanently caching the failure until pod restart.
            return;
        }
        pendingContext = null;
    }

}

