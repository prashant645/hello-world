package com.sap.gtlc.security.model;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import lombok.Data;

@Data
public class ConfigUpdateRequest {
    @Valid
    private RateLimitConfig rateLimit;

    @Valid
    private ValidationConfig validation;

    @Data
    public static class RateLimitConfig {
        @Min(1)
        @Max(1000)
        private Integer requestsPerMinute;

        private Boolean enabled;
    }

    @Data
    public static class ValidationConfig {
        @Min(1)
        @Max(100)
        private Integer maxWords;

        @Min(1)
        @Max(500)
        private Integer maxCharacters;
    }
}
