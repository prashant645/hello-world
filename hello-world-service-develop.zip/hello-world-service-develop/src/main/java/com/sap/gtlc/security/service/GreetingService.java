package com.sap.gtlc.security.service;

import com.sap.gtlc.security.model.GreetingRequest;
import com.sap.gtlc.security.model.GreetingResponse;

public interface GreetingService {

    /**
     * Creates a greeting response from user message.
     *
     * @param request The greeting request with user message
     * @return Formatted greeting response
     * @throws com.sap.gtlc.security.exception.ValidationException if message validation fails
     * @throws com.sap.gtlc.security.exception.SecurityValidationException if security checks fail
     */
    GreetingResponse createGreeting(GreetingRequest request);
}
