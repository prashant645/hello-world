package com.sap.gtlc.security.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ConfigUpdateResponse {
    private String status;
    private ConfigUpdateRequest appliedConfig;
    private String message;
    private String updatedBy;
    private Instant updatedAt;
}
