package com.sap.gtlc.security.model;

import jakarta.validation.constraints.NotBlank;

public record GreetingRequest(
    @NotBlank(message = "Message cannot be empty")
    String message
) {}
