package com.sap.gtlc.security.service;

import com.sap.gtlc.security.model.GreetingRequest;
import com.sap.gtlc.security.model.GreetingResponse;
import com.sap.gtlc.security.security.InputSanitizer;
import com.sap.gtlc.security.validation.MessageValidator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public class GreetingServiceImpl implements GreetingService {

    private static final Logger log = LoggerFactory.getLogger(GreetingServiceImpl.class);

    private final MessageValidator messageValidator;
    private final InputSanitizer inputSanitizer;

    public GreetingServiceImpl(MessageValidator messageValidator, InputSanitizer inputSanitizer) {
        this.messageValidator = messageValidator;
        this.inputSanitizer = inputSanitizer;
    }

    @Override
    public GreetingResponse createGreeting(GreetingRequest request) {
        // 1. Sanitize input
        String sanitized = inputSanitizer.sanitize(request.message());

        // 2. Validate business rules
        messageValidator.validate(sanitized);

        // 3. Generate greeting (simple string concatenation - no template engine)
        String greeting = String.format(
            "Hello, we received your message: %s.",
            sanitized
        );

        log.info("Greeting created successfully [messageLength={}]", sanitized.length());

        return new GreetingResponse(greeting);
    }
}
