package com.sap.gtlc.security.model;

import jakarta.validation.constraints.NotNull;

public record GreetingResponse(
    @NotNull
    String greeting
) {}
