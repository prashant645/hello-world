package com.sap.gtlc.security.security;

import com.sap.cloud.security.spring.token.authentication.AuthenticationToken;
import com.sap.gtlc.security.service.AmsAuthorizationService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.core.convert.converter.Converter;
import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.oauth2.core.DelegatingOAuth2TokenValidator;
import org.springframework.security.oauth2.core.OAuth2TokenValidator;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.security.oauth2.jwt.JwtDecoders;
import org.springframework.security.oauth2.jwt.JwtValidators;
import org.springframework.security.oauth2.jwt.NimbusJwtDecoder;
import org.springframework.security.oauth2.server.resource.authentication.JwtGrantedAuthoritiesConverter;
import org.springframework.security.web.SecurityFilterChain;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Security configuration for IAS authentication with AMS-backed authorization.
 *
 * <p>This configuration validates IAS JWTs, extracts application permission groups from
 * {@code ias_apis} and related claims, and keeps a minimal client-ID fallback for technical
 * callers that are still configured via environment properties.</p>
 */
@Configuration
@EnableWebSecurity
@EnableMethodSecurity
@Profile("!test")
@ConditionalOnProperty(prefix = "greeting-service.security", name = "enabled", havingValue = "true", matchIfMissing = true)
public class SecurityConfig {

/*
==================================================================
@TODO should abstract into a class that each project should implement to define permissions
*/
    private static final Set<String> SUPPORTED_SHORT_AUTHORITIES =
            Set.of("readers", "writers", "admins", "principal-propagation");
    // @TODO consider name the permission groups like the keys, i.e. instead of readers, use Read, to eliminate the lookup.
    private static final Map<String, String> LEGACY_AUTHORITY_ALIASES = Map.of(
            "Read", "readers",
            "Write", "writers",
            "Admin", "admins"
    );
    private final Set<String> readClientIds;
    private final Set<String> writeClientIds;
/*
==================================================================
 */
    private final String issuerUri;
    private final String clientId;

    public SecurityConfig(
            @Value("${greeting-service.security.ias.read-client-ids:}") String readClientIds,
            @Value("${greeting-service.security.ias.write-client-ids:}") String writeClientIds,
            @Value("${IAS_ISSUER_URI:https://a3enmtmdf.accounts400.ondemand.com}") String issuerUri,
            @Value("${IAS_CLIENT_ID:}") String clientId) {
        this.readClientIds = parseCsv(readClientIds);
        this.writeClientIds = parseCsv(writeClientIds);
        this.issuerUri = issuerUri;
        this.clientId = clientId;
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
                .csrf(csrf -> csrf.disable())
                .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
                .authorizeHttpRequests(auth -> auth
                        .requestMatchers("/actuator/**").permitAll()
                        .requestMatchers(org.springframework.http.HttpMethod.GET, "/api-docs", "/api-docs/**", "/swagger-ui.html", "/swagger-ui/**").permitAll()
                        .anyRequest().authenticated())
                .oauth2ResourceServer(oauth2 -> oauth2.jwt(jwt -> jwt.jwtAuthenticationConverter(iasJwtAuthenticationConverter())));

        return http.build();
    }

    // Critical method to make AMS recognize callers.
    @Bean
    public Converter<Jwt, ? extends AbstractAuthenticationToken> iasJwtAuthenticationConverter() {
        JwtGrantedAuthoritiesConverter defaults = new JwtGrantedAuthoritiesConverter();
        // Return AuthenticationToken (SAP subclass of JwtAuthenticationToken) so that
        // getPrincipal() returns a SAP Token. JavaSecurityContextHolderStrategy.setContext()
        // checks instanceof Token and calls SecurityContext.setToken() — without this,
        // Principal.fromSecurityContext() returns null and AMS denies every privilege check.
        return jwt -> {
            Set<GrantedAuthority> authorities = new LinkedHashSet<>(defaults.convert(jwt));
            for (String shortAuthority : extractShortAuthorities(jwt)) {
                authorities.add(new SimpleGrantedAuthority(shortAuthority));
            }
            for (String shortAuthority : extractConfiguredClientAuthorities(jwt, readClientIds, writeClientIds)) {
                authorities.add(new SimpleGrantedAuthority(shortAuthority));
            }
            return new AuthenticationToken(jwt, authorities);
        };
    }

    @Bean
    public AmsAuthorizationService amsAuthorizationService(ApplicationContext applicationContext) {
        // Pass the ApplicationContext rather than a pre-resolved provider so that
        // SciAuthorizationsProvider is looked up lazily on the first request.
        // SecurityConfig is initialized before AMS auto-configuration runs; eager
        // resolution would always capture null and leave AMS permanently unavailable.
        return new AmsAuthorizationService(applicationContext);
    }

    @Bean
    public JwtDecoder jwtDecoder() {
        NimbusJwtDecoder decoder = JwtDecoders.fromIssuerLocation(issuerUri);
        List<OAuth2TokenValidator<Jwt>> validators = new ArrayList<>();
        validators.add(JwtValidators.createDefaultWithIssuer(issuerUri));
        if (!clientId.isBlank()) {
            validators.add(token -> {
                if (token.getAudience().contains(clientId)) {
                    return org.springframework.security.oauth2.core.OAuth2TokenValidatorResult.success();
                }
                return org.springframework.security.oauth2.core.OAuth2TokenValidatorResult.failure(
                    new org.springframework.security.oauth2.core.OAuth2Error(
                        "invalid_token", "Token audience does not include client ID " + clientId, null));
            });
        }
        decoder.setJwtValidator(new DelegatingOAuth2TokenValidator<>(validators));
        return decoder;
    }

    static Set<String> extractShortAuthorities(Jwt jwt) {
        Set<String> extracted = new LinkedHashSet<>();
        for (String value : collectClaimValues(jwt.getClaim("scope"))) {
            addIfSupported(extracted, value);
        }
        for (String value : collectClaimValues(jwt.getClaim("scp"))) {
            addIfSupported(extracted, value);
        }
        for (String value : collectClaimValues(jwt.getClaim("authorities"))) {
            addIfSupported(extracted, value);
        }
        for (String value : collectClaimValues(jwt.getClaim("ias_apis"))) {
            addIfSupported(extracted, value);
        }
        for (String value : collectClaimValues(jwt.getClaim("groups"))) {
            addIfSupported(extracted, value);
        }
        // OBO tokens always carry user_uuid (IAS only sets this for human users).
        // Inject principal-propagation so the @PreAuthorize gate admits OBO tokens
        // regardless of the MCP server's ias_apis level (e.g. "readers").
        // This allows resolveOboAuthorization to honour an AMS grant that elevates the
        // user beyond the MCP's declared permission — which would otherwise be blocked
        // by the method-level gate before AMS is ever consulted.
        String userUuid = jwt.getClaimAsString("user_uuid");
        if (userUuid != null && !userUuid.isBlank()) {
            extracted.add("principal-propagation");
        }
        return extracted;
    }

    // @TODO [scalability]
    // permissions of readClientIds, writeClientIds should be wrapped into a class object. 
    // ex: 
    // class ClientPermissions {
    //     Map<String, Set<String>> permissionToClientIds; // "read" -> readClientIds, "write" -> writeClientIds
    // }
    static Set<String> extractConfiguredClientAuthorities(Jwt jwt, Set<String> readClientIds, Set<String> writeClientIds) {
        Set<String> effectiveReadClientIds = readClientIds == null ? Collections.emptySet() : readClientIds;
        Set<String> effectiveWriteClientIds = writeClientIds == null ? Collections.emptySet() : writeClientIds;
        if (effectiveReadClientIds.isEmpty() && effectiveWriteClientIds.isEmpty()) {
            return Collections.emptySet();
        }

        Set<String> resolved = new LinkedHashSet<>();
        Set<String> clientIds = extractClientIdCandidates(jwt);
        if (!Collections.disjoint(clientIds, effectiveReadClientIds)) {
            resolved.add("readers");
        }
        if (!Collections.disjoint(clientIds, effectiveWriteClientIds)) {
            resolved.add("writers");
        }
        return resolved;
    }

    private static void addIfSupported(Set<String> sink, String value) {
        if (value == null || value.isBlank()) {
            return;
        }

        String canonicalValue = canonicalizeAuthority(value);
        if (canonicalValue != null) {
            sink.add(canonicalValue);
            return;
        }

        if (value.startsWith("[") && value.endsWith("]")) {
            String stripped = value.substring(1, value.length() - 1).trim();
            for (String item : stripped.split(",")) {
                String cleaned = item.trim();
                if (cleaned.startsWith("'") && cleaned.endsWith("'")) {
                    cleaned = cleaned.substring(1, cleaned.length() - 1).trim();
                }
                if (cleaned.startsWith("\"") && cleaned.endsWith("\"")) {
                    cleaned = cleaned.substring(1, cleaned.length() - 1).trim();
                }
                String canonicalItem = canonicalizeAuthority(cleaned);
                if (canonicalItem != null) {
                    sink.add(canonicalItem);
                }
            }
            return;
        }

        int lastDot = value.lastIndexOf('.');
        if (lastDot > -1 && lastDot < value.length() - 1) {
            String candidate = canonicalizeAuthority(value.substring(lastDot + 1));
            if (candidate != null) {
                sink.add(candidate);
            }
        }
    }

    private static String canonicalizeAuthority(String value) {
        if (value == null || value.isBlank()) {
            return null;
        }
        if (SUPPORTED_SHORT_AUTHORITIES.contains(value)) {
            return value;
        }
        return LEGACY_AUTHORITY_ALIASES.get(value);
    }

    private static List<String> collectClaimValues(Object claim) {
        List<String> values = new ArrayList<>();
        collectClaimValues(claim, values);
        return values;
    }

    private static void collectClaimValues(Object claim, List<String> sink) {
        if (claim == null) {
            return;
        }
        if (claim instanceof String str) {
            String trimmed = str.trim();
            if (!trimmed.isEmpty()) {
                if (trimmed.startsWith("[") && trimmed.endsWith("]")) {
                    sink.add(trimmed);
                    return;
                }
                for (String part : trimmed.split("\\s+")) {
                    if (!part.isBlank()) {
                        sink.add(part);
                    }
                }
            }
            return;
        }
        if (claim instanceof Collection<?> collection) {
            for (Object item : collection) {
                collectClaimValues(item, sink);
            }
            return;
        }
        if (claim instanceof Map<?, ?> map) {
            for (Object value : map.values()) {
                collectClaimValues(value, sink);
            }
            return;
        }
        sink.add(String.valueOf(claim));
    }

    private static Set<String> extractClientIdCandidates(Jwt jwt) {
        Set<String> clientIds = new LinkedHashSet<>();
        for (String value : collectClaimValues(jwt.getClaim("azp"))) {
            if (!value.isBlank()) {
                clientIds.add(value);
            }
        }
        for (String value : collectClaimValues(jwt.getClaim("client_id"))) {
            if (!value.isBlank()) {
                clientIds.add(value);
            }
        }
        return clientIds;
    }

    private static Set<String> parseCsv(String value) {
        if (value == null || value.isBlank()) {
            return Collections.emptySet();
        }
        Set<String> parsed = new LinkedHashSet<>();
        for (String part : value.split(",")) {
            String trimmed = part.trim();
            if (!trimmed.isEmpty()) {
                parsed.add(trimmed);
            }
        }
        return parsed;
    }

}

