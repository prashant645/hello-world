package com.sap.gtlc.security.validation;

import com.sap.gtlc.security.exception.ValidationException;
import org.springframework.stereotype.Component;

import java.util.regex.Pattern;

@Component
public class MessageValidator {

    private static final int MAX_WORDS = 10;
    private static final int MAX_CHARS = 50;
    private static final int MAX_WORD_LENGTH = 12;
    private static final Pattern ENGLISH_ONLY = Pattern.compile("^[a-zA-Z0-9\\s.,!?'-]+$");

    public void validate(String message) {
        validateEnglishOnly(message);
        validateWordCount(message);
        validateWordLength(message);
        validateCharacterCount(message);
    }

    private void validateEnglishOnly(String message) {
        if (!ENGLISH_ONLY.matcher(message).matches()) {
            throw new ValidationException("Only English characters are allowed");
        }
    }

    private void validateWordCount(String message) {
        String normalized = message.trim().replaceAll("\\s+", " ");
        long wordCount = normalized.isEmpty() ? 0 : normalized.split("\\s+").length;

        if (wordCount > MAX_WORDS) {
            throw new ValidationException(
                String.format(
                    "Word count is %d, maximum allowed is %d",
                    wordCount, MAX_WORDS
                )
            );
        }
    }

    private void validateWordLength(String message) {
        String normalized = message.trim().replaceAll("\\s+", " ");
        String[] words = normalized.split("\\s+");

        for (String word : words) {
            // Remove punctuation for length calculation
            String cleanWord = word.replaceAll("[.,!?'-]", "");
            int wordLength = cleanWord.length();

            if (wordLength > MAX_WORD_LENGTH) {
                throw new ValidationException(
                    String.format(
                        "Word '%s' has %d characters, maximum allowed is %d",
                        cleanWord, wordLength, MAX_WORD_LENGTH
                    )
                );
            }
        }
    }

    private void validateCharacterCount(String message) {
        int charCount = message.trim().length();

        if (charCount > MAX_CHARS) {
            throw new ValidationException(
                String.format(
                    "Character count is %d, maximum allowed is %d",
                    charCount, MAX_CHARS
                )
            );
        }
    }
}
