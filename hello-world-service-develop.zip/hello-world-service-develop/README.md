# Hello World Service

Secure Hello World Greeting REST API built with Spring Boot and Java 21.

## Authentication Model

This branch uses **IAS + AMS** for authentication and authorization.

- The application validates bearer tokens directly against the IAS issuer URI.
- AMS authorization is driven by the `ias_apis` JWT claim emitted by IAS for client-dependency based access tokens.
- The primary permission groups are `readers`, `writers`, and `admins`.

For IAS tenant setup, AMS policy wiring, client credentials, and token requests, see `AMS.md`.

## API Documentation

The service exposes OpenAPI documentation with **read-only anonymous access** for easy API exploration and integration:

### Endpoints

| Endpoint | HTTP Method | Description | Authentication |
|----------|-------------|-------------|-----------------|
| `/api-docs` | GET | OpenAPI specification in JSON format | Anonymous (GET only) |
| `/swagger-ui.html` | GET | Swagger UI - Interactive API documentation | Anonymous (GET only) |
| `/swagger-ui/**` | GET | Swagger UI static resources | Anonymous (GET only) |

### Accessing API Docs

When running the application locally:

```bash
# OpenAPI specification
curl http://localhost:8080/api-docs | jq

# Swagger UI (open in browser)
http://localhost:8080/swagger-ui.html
```

### Configuration

API documentation is configured in `application.yml`:

```yaml
springdoc:
  api-docs:
    path: /api-docs
  swagger-ui:
    path: /swagger-ui.html
```

### Security

These endpoints allow developers and integrators to discover and understand the API without requiring authentication tokens. Anonymous access is restricted to **GET requests only** to prevent accidental exposure of mutation endpoints (POST/PUT/DELETE). All actual API endpoints (`/api/v1/**`) continue to require proper authentication and authorization.

### Run locally
```dockerfile
SPRING_PROFILES_ACTIVE=cloud \
SPRING_AUTOCONFIGURE_EXCLUDE=com.sap.cloud.security.ams.spring.autoconfigure.AmsAutoConfiguration,com.sap.cloud.security.ams.spring.autoconfigure.AmsMethodSecurityAutoConfiguration \
./gradlew bootRun --args='--greeting-service.security.enabled=false'
```

## Kubernetes Setup Guides

- BTP Operator install, verification, and troubleshooting: `platform-ops/k8s/btp-operator/README.md`
- IAS + AMS setup and token flow for this service: `AMS.md`
- Helm chart notes for IAS deployment: `helm/hello-world-service/README.md`

Kyma setup order before the first pipeline run:

1. Install BTP operator once per cluster using `platform-ops/k8s/btp-operator/README.md`
2. Configure IAS provider/client applications and AMS policies using `AMS.md`
3. Run the Kyma pipeline; Helm injects the IAS issuer URI directly into the application

PR validation workflows that only build and test do not require cluster or IAS setup.

## Prerequisites

- Java 21
- Gradle 8.10+ (or use the included Gradle wrapper)

## Version Management

When updating the version in `VERSION`, also run:

```bash
./scripts/sync-version.sh
```

## Building the Project

```bash
./gradlew clean build
```

## Running the Application

```bash
./gradlew bootRun
```

Or run the generated JAR:

```bash
java -jar build/libs/hello-world-service-<version>.jar
```

## Running Tests

```bash
./gradlew test
```

## Kyma Dev Rollout Verification

Use the one-command verifier to run APIRule readiness and the IAS smoke test:

```bash
IAS_CLIENT_ID=<your-client-id> \
IAS_CLIENT_SECRET=<your-client-secret> \
IAS_CLIENT_DEPENDENCY_NAME=scope \
EXPECTED_IAS_API=readers \
bash platform-ops/k8s/apiRule/scripts/test-kyma-dev-e2e.sh
```

# Progress
- [x] IAS M2M without additional IdP, kyma
- [x] Kyma template
- [x] Unified workflow (CF + Kyma) template
- [x] Piper-based CF deployment
- [x] Kyma deployment
- [x] Piper mta build and deployment
- [x] Piper-based PR build
