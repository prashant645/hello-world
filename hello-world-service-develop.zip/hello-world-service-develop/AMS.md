# Machine-to-Machine(M2M) authentication and authorization
Pre-requisitors: 
- IAS tenant has been created and 
- trust has been established for the subaccount 

Quick Facts:
- Permission is encoded in the `ias_apis` array attribute of the generated access token
- Permission is DCL policy-based and source-controlled
- client app dependency name: scope
- client credentials
  -[dev client](https://password.wdf.sap.corp/passvault/#/pwd/0000658386)
  -[qa client]()
  -[prod client]() 
- policies in this AMS setup
  - readers
  - writers
  - admins
- See [rationales](#Why AMS for authorization)

The SciAuthorizationsProvider handles M2M automatically via the ias_apis claim — no user, no groups needed. The consumer registers in IAS, declares which API permission group it needs, and the JWT carries that group. The provider validates and calls checkPrivilege.  

## AMS Setup

### Initial setup
See platform-ops/k8s/ams/README.md

### IAS Configuration
After successfully applied the AMS service instance and bindings, in the initial setup, a bundle application will automatically created in the IAS tenant. That app is the Provider App (the backend server/resource server which requires protection).

#### Provider App: Define API Permission Groups in IAS

In IAS Admin Console → your ias-dev app (backend server, the provider) → APIs tab → Add permission groups:
  - readers
  - writers
  - admins

#### Consumer/Client App Registration

Each client app registers directly in IAS Admin Console → Applications → Create — no BTP ServiceInstance, no Kyma needed. Then under Dependencies, add your provider app and select the permission group for that client.

This is purely an IAS admin console operation. The client can run anywhere.

## Source code adoption
 
### Step 1 — pom.xml sample 
Need to adopt for gradle/groovy builds
```pom
<dependencyManagement>
   <dependencies>
      <dependency>
         <groupId>com.sap.cloud.security.ams</groupId>
         <artifactId>ams-bom</artifactId>
         <version>4.5.1</version>  <!-- check Maven Central for latest -->
         <type>pom</type>
         <scope>import</scope>
      </dependency>
   </dependencies>
</dependencyManagement>

<dependencies>
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-web</artifactId>
    </dependency>
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-security</artifactId>
    </dependency>
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-oauth2-resource-server</artifactId>
    </dependency>

    <!-- SAP IAS JWT validation -->
    <dependency>
        <groupId>com.sap.cloud.security</groupId>
        <artifactId>resourceserver-security-spring-boot-starter</artifactId>
    </dependency>

    <!-- AMS: auto-configures SciAuthorizationsProvider -->
    <dependency>
        <groupId>com.sap.cloud.security.ams</groupId>
        <artifactId>spring-boot-starter-ams</artifactId>
    </dependency>
</dependencies>

<build>
    <plugins>
        <!-- Compiles .dcl → .dcn for local testing -->
        <plugin>
            <groupId>com.sap.cloud.security.ams</groupId>
            <artifactId>dcl-compiler-plugin</artifactId>
        </plugin>
    </plugins>
</build>
```
### Step 2 — Spring Security Config (sample)
```java
@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
            .csrf(csrf -> csrf.disable())
            .sessionManagement(sm -> sm
                .sessionCreationPolicy(SessionCreationPolicy.STATELESS))
            .authorizeHttpRequests(auth -> auth
                .requestMatchers("/actuator/health").permitAll()
                .anyRequest().authenticated()
            )
            .oauth2ResourceServer(oauth2 -> oauth2.jwt(Customizer.withDefaults()));
        return http.build();
    }
}
```
spring-boot-starter-ams auto-configures SciAuthorizationsProvider as a Spring Bean. No manual wiring needed.

### Step 3 — Controllers with checkPrivilege (sample)
```java
@RestController
@RequestMapping("/api")
public class DataController {

    private final SciAuthorizationsProvider authorizationsProvider;

    public DataController(SciAuthorizationsProvider authorizationsProvider) {
        this.authorizationsProvider = authorizationsProvider;
    }

    @GetMapping("/data")
    public ResponseEntity<?> getData(Authentication authentication) {
        Authorizations authorizations = authorizationsProvider.getAuthorizations(authentication);

        if (!authorizations.checkPrivilege("read",
                "com.yourcompany.hello.world.service.DataResource").isGranted()) {
            return ResponseEntity.status(403).build();
        }
        return ResponseEntity.ok(dataService.getAll());
    }

    @PostMapping("/data")
    public ResponseEntity<?> writeData(@RequestBody DataItem item,
                                        Authentication authentication) {
        Authorizations authorizations = authorizationsProvider.getAuthorizations(authentication);

        if (!authorizations.checkPrivilege("write",
                "com.yourcompany.hello.world.service.DataResource").isGranted()) {
            return ResponseEntity.status(403).build();
        }
        dataService.save(item);
        return ResponseEntity.status(201).build();
    }

    @PutMapping("/config")
    public ResponseEntity<?> updateConfig(@RequestBody Config cfg,
                                           Authentication authentication) {
        Authorizations authorizations = authorizationsProvider.getAuthorizations(authentication);

        if (!authorizations.checkPrivilege("admin",
                "com.yourcompany.hello.world.service.ConfigResource").isGranted()) {
            return ResponseEntity.status(403).build();
        }
        configService.update(cfg);
        return ResponseEntity.ok().build();
    }
}
```
SciAuthorizationsProvider.getAuthorizations(authentication) reads the ias_apis claim from the M2M JWT, maps it to the corresponding AMS policy, and the checkPrivilege call enforces it.

**Important — M2M and OBO are NOT handled identically:**

- **M2M tokens** (no `user_uuid` claim — `client_credentials` grant): `checkPrivilege` via `SciAuthorizationsProvider` is sufficient. The `ias_apis` claim encodes the permission group; AMS resolves it to the matching policy.

- **OBO tokens** (human user, `user_uuid` present — principal propagation via RFC 8693 token exchange): a two-tier resolution is required. `checkPrivilege` alone is not enough because an unenrolled user (not assigned to any AMS policy) would always be denied, which is incorrect per the flow design. The backend must:
  1. Call `checkPrivilege` for the requested action — if granted, allow (user has an AMS policy covering this action).
  2. If denied, call `hasAnyPrivilege` across all known action/resource pairs to determine whether the user is enrolled at all.
  3. If the user has ANY AMS policy binding but it doesn't cover this action → deny (insufficient privilege).
  4. If the user has NO AMS policy (unenrolled) → inherit the MCP server's `ias_apis` claim as the effective permission. If absent or insufficient, deny.

The OBO two-tier resolution is implemented in `GreetingController.resolveOboAuthorization()`. The simple `checkPrivilege` pattern shown in Step 3 below applies to M2M only.

### Step 4 — Microservice app deployment to Kyma
Mount my-api-ias-secret in your Deployment — the spring-boot-starter-ams auto-configures from the mounted secret via SERVICE_BINDING_ROOT:
```yaml
env:
- name: SERVICE_BINDING_ROOT
  value: /bindings
  volumeMounts:
- name: ias-vol
  mountPath: /bindings/my-api-ias-secret
  readOnly: true
  volumes:
- name: ias-vol
  secret:
  secretName: my-api-ias-secret
```

## Access Token
- Request: 'scope' is the name of the dependency in IAS client app config
```bash
curl --request POST \
  --url https://a3enmtmdf.accounts400.ondemand.com/oauth2/token \
  --header 'Authorization: Basic <masked>' \
  --header 'Content-Type: application/x-www-form-urlencoded' \
  --data 'grant_type=client_credentials&resource=urn:sap:identity:application:provider:name:scope'
````
- Decoded JWT token. Even though ias_apis is a JSON array, IAS+AMS only allow 1 element in the array.
```json
{
  "ias_apis": [
    "readers"
  ],
  "sub": "<masked>",
  "aud": "<masked>",
  "app_tid": "<masked>",
  "sap_id_type": "app",
  "azp": "<masked>",
  "iss": "https://a3enmtmdf.accounts400.ondemand.com",
  "azpacr": "1",
  "exp": 1789672979,
  "iat": 1789669379,
  "jti": "<masked>"
}
```

# M2M + OBO (On-Behalf-Of / Principal Propagation)

When a human user calls through an MCP server (e.g. Joule Work Desktop via `hello-world-mcp`), the MCP server performs an RFC 8693 token exchange so the backend receives a token carrying the user's identity. This is the OBO path.

## How OBO tokens are identified

The backend detects OBO tokens by the presence of the `user_uuid` claim, which IAS only includes in tokens issued to human users. `client_credentials` (M2M) tokens never carry `user_uuid`.

## Authorization resolution order for OBO

```
OBO request arrives (user_uuid present)
│
├─ AMS unavailable? → DENY (fail-closed — AMS must be reachable)
│
├─ AMS grants the requested action (checkPrivilege)?
│    └─ YES → ALLOW (user is enrolled and their policy covers this action)
│
├─ AMS denied. Does the user have ANY AMS policy binding (hasAnyPrivilege)?
│    └─ YES → DENY (user is enrolled but their policy is too restrictive for this action)
│
└─ User has NO AMS policy (unenrolled)
     ├─ MCP server's ias_apis covers this action? → ALLOW (inherit MCP permission)
     └─ ias_apis absent or insufficient → DENY
```

## IAS configuration for OBO

- The MCP server application (`hello-world-mcp-iasams-dev`) must have the `hello-world-service` backend registered as a dependency with `dependency name = scope`.
- The MCP server uses its own client credentials (`IAS_CLIENT_ID` / `IAS_CLIENT_SECRET`) to call the IAS token exchange endpoint.
- The `resource` parameter in the exchange request is `urn:sap:identity:application:provider:name:scope`.

## Assigning users to AMS policies

In the IAS Admin Console → `ias-dev` application → **Authorization** tab:
- A user who should have restricted access (e.g. `jeffrey.shi@sap.com` with `readers`) is added directly to the IAS application and assigned to the `readers` authorization policy.
- Users who are NOT configured here are unenrolled — they inherit the MCP server's `ias_apis` as their effective permission.

## Implementation reference

- MCP side: `IasUserTokenExchanger.exchange()` — performs the RFC 8693 exchange.
- MCP side: `HelloWorldClient.resolveBackendToken()` — selects M2M vs OBO token per request.
- Backend side: `GreetingController.resolveOboAuthorization()` — applies the two-tier resolution above.
- Backend side: `AmsAuthorizationService.detectPolicyBinding()` — detects unenrolled users (tri-state: `BOUND` / `UNBOUND` / `ERROR`). `hasAnyPrivilege()` is deprecated — it collapses `ERROR` and `UNBOUND` into the same `false`, which would silently grant `ias_apis` fallback access on a transient AMS failure.

---

# Why AMS for authorization

[The future proof IAS + AMS solution is the BTP recommended approach for authentication and authorization](https://community.sap.com/t5/technology-blog-posts-by-sap/ams-vs-xsuaa-the-future-of-authentication-and-authorization-in-sap-btp/ba-p/14169154). What You've Achieved: Separation of "What" from "Who"

| Concern	| Owner |	Where |
| :---     | :---   | :---   |
| What permissions mean — policy logic |	Service developer | DCL in Git, deployed via CI/CD |
| Who gets which permission level	| Tenant admin	| IAS UI — dependency assignment only |
IAS alone collapses both into the same UI, same person, same time. IAS + AMS cleanly separates them.

Additional Advantages Beyond Version Control
1. Fine-Grained, Contextual Authorization (ABAC)
   IAS alone is coarse: does this token have this role? AMS enables attribute-based conditions:
```
POLICY readers {
  GRANT read ON DataResource WHERE $user.app_tid = $resource.tenantId;
}
```
Instance-level, tenant-scoped, context-aware checks — evaluated at runtime by the @sap/ams library inside your service. IAS has no equivalent.

2. Authorization Evaluated In-Process
   The @sap/ams policy engine runs inside your service, not as a remote call. No network hop to an external authorization server at request time. Latency is local.

3. Audit-Ready Policy Lifecycle
   Every permission change is a commit, a PR, a review, a deployment record. For IP compliance and GTLC governance this is significant — you have a full audit trail of who approved what policy change and when, which IAS UI changes do not provide.

4. Tenant Admin Cannot Break Authorization Logic
   In IAS alone, a tenant admin with sufficient privilege can modify policy conditions, add exceptions, or broaden scope directly in the UI — possibly without the service owner knowing. With AMS, the policy logic is immutable from the IAS side. The worst an admin can do is assign a user to a higher permission group than intended — the logic itself is frozen.

5. Testable Before Deployment
   DCL policies can be unit tested in CI before they reach any environment. You can assert "a token with ias_apis: ['readers'] must be authorized for read and must NOT be authorized for write" as an automated test. IAS-only policies have no equivalent testing path.

6. Consistent Across All Tenants
   One DCL deployment covers all tenants of your service uniformly. IAS-only authorization requires configuring policies per-tenant in each IAS tenant separately — a maintenance and consistency problem at scale.

## The Accepted Trade-off

The cost is exactly what I went through: more infrastructure, more moving parts, a Kubernetes job as part of my deployment pipeline. Whether that cost is justified depends on how complex the authorization logic needs to get. 

For simple role checks, IAS alone is cheaper. The moment I need per-tenant isolation, resource-level conditions, or compliance-grade auditability, AMS pays for itself.


# Reference
- [Main doc entrance for cloud identity services](https://sap.github.io/cloud-identity-developer-guide/)
- [M2M](https://sap.github.io/cloud-identity-developer-guide/Authorization/SystemToSystem.html)
- [Authorization Checks](https://sap.github.io/cloud-identity-developer-guide/Authorization/AuthorizationChecks.html)
- [Spring Boot (Non-CAP) AMS example](https://github.com/SAP-samples/ams-samples-java)