# hello-world-service Helm chart

## IAS + AMS deployment mode

This chart deploys the service in IAS + AMS mode:

1. The application validates JWTs directly against the IAS issuer URI.
2. Helm injects the issuer URI through `IAS_ISSUER_URI`.
3. The IAS service binding secret is mounted under `SERVICE_BINDING_ROOT` so the AMS starter can auto-configure authorization.
4. Endpoint authorization uses IAS+AMS permission groups such as `readers`, `writers`, and `admins`, primarily derived from the JWT `ias_apis` claim.

No XSUAA service instance or XSUAA-specific secret mount is required.

## IAS / AMS configuration

Set the key IAS settings in the values files:

```yaml
ias:
  issuerUri: https://a3enmtmdf.accounts400.ondemand.com
  bindingSecretName: ias-secret
  clientDependencyName: scope
```

Notes:

- `IAS_ISSUER_URI` is passed to the container as an environment variable.
- `SERVICE_BINDING_ROOT=/bindings` is configured and the secret referenced by `ias.bindingSecretName` is mounted at `/bindings/<bindingSecretName>`.
- Spring Security uses the issuer URI to fetch the IAS JWKS and validate JWTs.
- The AMS starter reads the bound secret and evaluates authorization policies against the `ias_apis` claim.

## Quick check

Render the chart and confirm the deployment includes the IAS issuer URI and the mounted binding secret:

```bash
helm template hello-world-service ./helm/hello-world-service \
  --namespace dev \
  -f ./helm/hello-world-service/values.yaml \
  -f ./helm/hello-world-service/values-dev.yaml | grep -E 'IAS_ISSUER_URI|SERVICE_BINDING_ROOT|ias-secret|kind:'
```

## HTTPS FQDN exposure (Kyma)

For dev, the chart is configured to expose the app through `APIRule` v2 (HTTPS) instead of a raw `LoadBalancer` IP.

Preflight checks before pipeline deploy:

```bash
kubectl get crd apirules.gateway.kyma-project.io
kubectl get crd gateways.networking.istio.io
kubectl wait --for=jsonpath='{.status.state}'=Ready apigateway/default --timeout=5m
kubectl -n kyma-system get gateway kyma-gateway
```

If any of these are missing, enable the one-time Kyma `api-gateway` and `istio` modules in the cluster before deploying the chart.

